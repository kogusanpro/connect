"""
<copyright file="product_type.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from datetime import datetime

from rest_framework.response import Response
from rest_framework import status


class HttpResponseUtil:
    @staticmethod
    def ok(error_message=None, success=True, extra_info={}):
        return HttpResponseUtil.response(
            http_status=status.HTTP_200_OK,
            success=success,
            error_status=None,
            error_message=error_message,
            extra_info=extra_info)

    @staticmethod
    def bad_request(error_message="Invalid Parameter", success=False, extra_info={}):
        return HttpResponseUtil.response(
            http_status=status.HTTP_400_BAD_REQUEST,
            success=success,
            error_status=str(status.HTTP_400_BAD_REQUEST),
            error_message=error_message,
            extra_info=extra_info)

    @staticmethod
    def forbidden(error_message="Forbidden", success=False, extra_info={}):
        return HttpResponseUtil.response(
            http_status=status.HTTP_403_FORBIDDEN,
            success=success,
            error_status=str(status.HTTP_403_FORBIDDEN),
            error_message=error_message,
            extra_info=extra_info)

    @staticmethod
    def not_found(error_message="Not Found", success=False, extra_info={}):
        return HttpResponseUtil.response(
            http_status=status.HTTP_404_NOT_FOUND,
            success=success,
            error_status=str(status.HTTP_404_NOT_FOUND),
            error_message=error_message,
            extra_info=extra_info)

    @staticmethod
    def internal_server_error(error_message="Internal error", success=False, extra_info={}):
        return HttpResponseUtil.response(
            http_status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=success,
            error_status=str(status.HTTP_500_INTERNAL_SERVER_ERROR),
            error_message=error_message,
            extra_info=extra_info)

    @staticmethod
    def response(http_status, success, error_status, error_message, extra_info={}):
        response = {
            **{
                'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
                'error_status': error_status,
                'error_message': error_message
            }, **extra_info
        }

        if success is not None:
            response.update({'success': success})

        return Response(response, status=http_status)
