"""
<copyright file="contract_info_util.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from typing import Any, Dict, List


def is_zuora_data(contract_info: Dict[str, Any]) -> bool:
    '''契約情報がZuora対象かどうかを判定する

    判定条件：[サブスクリプション番号]が、NULLでない かつ 空文字でない場合はZuora対象

    Args:
        contract_info (Dict[str, Any]): Cebisの契約情報

    Returns:
        bool: Zuora対象の契約情報の場合はTrue、それ以外の場合はFalse
    '''
    if (
        contract_info.get('subscription_number') is None
        or len(contract_info['subscription_number']) == 0
    ):
        return False

    return True


def filter_zuora_data(contract_info_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    '''Cebisの契約情報リストからZuora対象の契約情報のみを抽出する

    Args:
        contract_info_list (List[Dict[str, Any]]): Cebisの契約情報リスト

    Returns:
        List[Dict[str, Any]]: Zuora対象のみの契約情報が格納されたリスト
    '''
    return [contract_info for contract_info in contract_info_list if is_zuora_data(contract_info)]
