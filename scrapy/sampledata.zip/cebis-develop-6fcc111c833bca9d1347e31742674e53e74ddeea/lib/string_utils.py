"""
<copyright file="string_utils.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""

class StringUtils:
    """
    文字列操作を行うユーティリティクラス
    """

    @staticmethod
    def convert_emptystring_if_none(text):
        """
        渡された値がnullであれば空文字を返し、そうでなければそのままの値を返す
        :type text: str
        :param str: チェック対象の文字列
        :return: ''か元のstring
        """
        if text is None:
            return ''
        return str(text)
