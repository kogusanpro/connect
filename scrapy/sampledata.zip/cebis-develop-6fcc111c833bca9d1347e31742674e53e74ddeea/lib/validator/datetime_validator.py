"""
<copyright file="datetime_validator.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import datetime


class DateTimeValidator:
    """
    日付・時刻に関するバリデーションを行うクラス
    """
    @staticmethod
    def is_valid_YmdTHMSZ(date_time_str)->bool:
        """
        引数で渡された文字列がYmdTHMSZ形式の日付として妥当かをチェックして返す
        :type date_time_str: str
        :param date_time_str: チェック対象の文字列
        :return:
        """

        try:
            datetime.datetime.strptime(date_time_str, '%Y%m%dT%H%M%SZ')
            return True
        except ValueError:
            return False

    @staticmethod
    def is_valid_timezone(timezone):
        allow_values = ['UTC', 'JST']
        if timezone.upper() in allow_values:
            return True
        return False
