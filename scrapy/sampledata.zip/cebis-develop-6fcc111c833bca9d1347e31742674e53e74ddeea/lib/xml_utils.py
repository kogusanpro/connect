"""
<copyright file="xml_utils.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from xml.sax import saxutils

class XmlUtils:
    """
    XML関連のユーティリティクラス
    """

    @staticmethod
    def esc_include_quot(src: str)->str:
        """
        引数で渡された文字列をエスケープして返す
        デフォルトの動作に加えて、'と"をエスケープします
        :param src:
        :return:
        """
        esc_str_dict = {
            '"': "&quot;",
            "'": "&apos;",
        }
        return saxutils.escape(src, esc_str_dict)
