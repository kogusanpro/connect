"""
<copyright file="utils.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from datetime import datetime
import json
import re
from pprint import pprint
import sys
import time
from typing import Any, Dict, Generator, List, Optional

from pytz import UTC, timezone
import logging
import requests
from django.utils.timezone import datetime, timedelta
from dateutil.relativedelta import relativedelta

def logger():
    """
    loggerのインスタンスを返す
    :return: :object:
    """
    return logging.getLogger('django')

def convert_datetime_format(datetime):
    """
     yyyymmddThhiissZのフォーマットでリクエストされるdatetimeをDBが認識できる
     yyyy-mm-dd hh:ii:ssに変換する
     :param datetime:日時
     :type datetime: str
     :return: :string:フォーマット後の日時
    """
    datetime = re.search('(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z',
                         datetime)
    return '{0}-{1}-{2} {3}:{4}:{5}'.format(
            datetime.group(1), datetime.group(2), datetime.group(3),
            datetime.group(4), datetime.group(5), datetime.group(6))


def convert_date_format(datetime):
    """
     yyyymmddのフォーマットでリクエストされるdatetimeをDBが認識できる
     yyyy-mm-ddに変換する
     :param datetime:日時
     :type datetime: str
     :return: :string:フォーマット後の日時
    """
    datetime = re.search('(\d{4})(\d{2})(\d{2})',
                         datetime)
    return '{0}-{1}-{2}'.format(
            datetime.group(1), datetime.group(2), datetime.group(3))


def check_date_ym_format(datetime):
    """
     yyyymmのフォーマットにっているかのチェック
     :param datetime:日時
     :type datetime: str
     :return: :boolean:
    """
    if re.fullmatch('(\d{6})', datetime):
        return True
    return False


def check_date_ymd_format(datetime):
    """
     yyyymmddのフォーマットにっているかのチェック
     :param datetime:日時
     :type datetime: str
     :return: :boolean:
    """
    if re.fullmatch('(\d{8})', datetime):
        return True
    return False


def check_datetime_format(datetime):
    """
     yyyymmddThhiissZのフォーマットにっているかのチェック
     :param datetime:日時
     :type datetime: str
     :return: :boolean:
    """
    if re.fullmatch('(\d{8})T(\d{6})Z', datetime):
        return True
    return False


def today_is_the_end_of_month(date_time):
    """
     日付が月末であるかのチェック
     :param datetime:日時
     :type date_time: str
     :return: :boolean:
    """
    date_time = datetime.strptime(date_time, '%Y%m%d')
    next_month = date_time.replace(day=28) + timedelta(days=4)
    result_time = next_month - timedelta(days=next_month.day)

    if date_time == result_time:
        return True
    return False


# 影響範囲がデカイので既存コードのリファクタリングは後回しにします。
class DateTimeUtil:
    """
    日付・時刻に関するユーティリティクラス
    """
    @staticmethod
    def get_current_ym():
        """
        現在の日付をYYYYMM形式で返す
        :rtype str
        :return:
        """
        return datetime.utcnow().strftime('%Y%m')

    @staticmethod
    def get_specific_now_time(time):
        """
         指定日時の現在時刻を返す
         :param time:時
         :type datetime: str
         :return:
        """
        date = datetime.now(tz=UTC).strftime('%Y-%m-%d')+' '+time
        return datetime.strptime(date, '%Y-%m-%d %H:%M:%S').replace(tzinfo=UTC)

    @staticmethod
    def get_prev_ym():
        """
        前月の日付をYYYYMM形式で返す
        :rtype str
        :return:
        """
        now = datetime.utcnow()
        if now.month != 1:
            prev_month = now.replace(month=now.month - 1, day=1)
        else:
            prev_month = now.replace(year=now.year - 1, month=12, day=1)

        return prev_month.strftime('%Y%m')

    @staticmethod
    def get_prev_specific_date_ym(date_time):
        """
        引数で受け取った日付文字列の前月の年月をyyyyMM形式のフォーマットに変換して返す
        :type date_time str
        :param date_time:
        :rtype str
        :return:
        """
        date_time = datetime.strptime(date_time, '%Y%m%d')

        if date_time.month != 1:
            prev_month = date_time.replace(month=date_time.month - 1, day=1)
        else:
            prev_month = date_time.replace(year=date_time.year - 1, month=12, day=1)

        return prev_month.strftime('%Y%m')

    @staticmethod
    def get_prev_specific_date_ymd(date_time, num_month):
        """
        引数で受け取った日付のNヶ月の日付をyyyyMM形式のフォーマットに変換して返す
        :type date_time str
        :param date_time:
        :type num_month int
        :param num_month: 月数
        :rtype str
        :return:
        """
        date_time = datetime.strptime(date_time, '%Y%m%d')

        y = num_month // 12
        m = num_month % 12

        if date_time.month > m:
            prev_month = date_time.replace(year=date_time.year - y, month=date_time.month - m, day=1)
        else:
            prev_month = date_time.replace(year=date_time.year - y - 1, month=12 - (m - date_time.month), day=1)

        next_month = prev_month.replace(day=28) + timedelta(days=4)
        result_date = next_month - timedelta(days=next_month.day)

        return result_date.strftime('%Y%m%d')

    @staticmethod
    def get_prev_y():
        """
        前月の日付をYYYY形式で返す
        :rtype str
        :return:
        """
        now = datetime.utcnow()
        if now.month != 1:
            prev_month = now.replace(month=now.month - 1, day=1)
        else:
            prev_month = now.replace(year=now.year - 1, month=12, day=1)

        return prev_month.strftime('%Y')

    @staticmethod
    def format_YmdTHMSZ_utc(date_time_obj):
        """
        引数で受け取ったdatetimeオブジェクトをyyyyMMddTHHmmssZ形式の
        フォーマットに変換して返す
        :type date_time_obj datetime
        :param date_time_obj:
        :rtype:str
        :return: フォーマット後の文字列
        """
        return date_time_obj.strftime('%Y%m%dT%H%M%SZ')

    @staticmethod
    def format_iso8601_utc(date_time_obj):
        """
        引数で受け取ったdatetimeオブジェクトを%Y-%m-%dT%H:%M:%SZ形式の
        フォーマットに変換して返す
        :type date_time_obj datetime
        :param date_time_obj:
        :rtype:str
        :return: フォーマット後の文字列
        """
        return date_time_obj.strftime('%Y-%m-%dT%H:%M:%SZ')


    @staticmethod
    def iso_8601_to_YmdTHMSZ_utc(date_time_str):
        """
        引数で受け取った文字列をYYYY-MM-DDTHH:MM:SSZ形式の
        文字列をyyyyMMddTHHmmssZ形式に変換して返す
        YYYY-MM-DDTHH:MM:SSZ形式としてパースできない場合は
        そのまま返す
        :type date_time_str: str
        :param date_time_str:
        :rtype:str
        :return: 変換後の文字列
        """

        try:
            datetime_obj = datetime.strptime(date_time_str, '%Y-%m-%dT%H:%M:%SZ')
            return DateTimeUtil.format_YmdTHMSZ_utc(datetime_obj)
        except ValueError:
            return date_time_str

    @staticmethod
    def YmdTHMSZ_utc_to_iso_8601(date_time_str):
        """
        引数で受け取った文字列をyyyyMMddTHHmmssZ形式の
        文字列をYYYY-MM-DDTHH:MM:SSZ形式に変換して返す
        yyyyMMddTHHmmssZ形式としてパースできない場合は
        そのまま返す
        :type date_time_str: str
        :param date_time_str:
        :rtype:str
        :return: 変換後の文字列
        """

        try:
            datetime_obj = datetime.strptime(date_time_str, '%Y%m%dT%H%M%SZ')
            return DateTimeUtil.format_iso8601_utc(datetime_obj)
        except ValueError:
            return date_time_str

    @staticmethod
    def utc_now_aware():
        """
        UTCでの現在日時をawareな形式で返却します
        :return:
        """
        return datetime.now(tz=UTC)

    @staticmethod
    def convert_date_format(datetime):
        """
         yyyymmddのフォーマットでリクエストされるdatetimeをDBが認識できる
         yyyy-mm-ddに変換する
         :param datetime:日時
         :type datetime: str
         :return: :string:フォーマット後の日時
        """
        datetime = re.search('(\d{4})(\d{2})(\d{2})',
                             datetime)
        return '{0}-{1}-{2}'.format(
                datetime.group(1), datetime.group(2), datetime.group(3))

    @staticmethod
    def convert_date_format_235959(input_datetime):
        """
         yyyymmddのフォーマットでリクエストされるdatetimeを
         yyyy-mm-dd 23:59:59に変換する
         :param datetime:日時
         :type datetime: str
         :return: :string:フォーマット後の日時
        """
        return datetime.strptime(
            '%s 23:59:59' % DateTimeUtil.convert_date_format(
                input_datetime), '%Y-%m-%d %H:%M:%S')

    @staticmethod
    def convert_date_format_000000(input_datetime):
        """
         yyyymmddのフォーマットでリクエストされるdatetimeを
         yyyy-mm-dd 00:00:00に変換する
         :param datetime:日時
         :type datetime: str
         :return: :string:フォーマット後の日時
        """
        return datetime.strptime(
            '%s 00:00:00' % DateTimeUtil.convert_date_format(
                input_datetime), '%Y-%m-%d %H:%M:%S')

    @staticmethod
    def replace_utc(datetime):
        """
         timezoneをUTCに変換する
         :param datetime:日時
         :type datetime: str
         :return: :string:フォーマット後の日時
        """
        return datetime.replace(
            tzinfo=timezone('UTC'))

    @staticmethod
    def replace_jst(datetime):
        """
         timezoneをJSTに変換する
         :param datetime:日時
         :type datetime: str
         :return: :string:フォーマット後の日時
        """
        tokyo_timezone = timezone('Asia/Tokyo')
        return tokyo_timezone.localize(datetime)

    @staticmethod
    def replace_utc(datetime):
        """
         timezoneをUTCに変換する
         :param datetime:日時
         :type datetime: str
         :return: :string:フォーマット後の日時
        """
        return datetime.replace(
            tzinfo=timezone('UTC'))

    @staticmethod
    def replace_aware_utc(datetime):
        """
         timezone-awareな時刻のタイムゾーンを変更する
         :param datetime:日時
         :type datetime: datetime object
         :return: :datetime object:
        """
        return datetime.astimezone(timezone('UTC'))

    @staticmethod
    def get_begin_of_next_month(base_date: datetime)->datetime:
        """
        引数で渡された日付の翌月1日の00:00:00を表すdatetimeオブジェクトを返す
        :return:
        """
        if base_date.month != 12:
            return base_date.replace(month=base_date.month + 1, day=1, hour=0, minute=0, second=0, microsecond=0)

        return base_date.replace(year=base_date.year + 1, month=1, day=1, hour=0, minute=0, second=0, microsecond=0)

    @staticmethod
    def get_end_of_the_month(base_date: datetime)->datetime:
        """
        引数で渡された日時の、時刻は同じで日付が月末を表すdatetimeオブジェクトを返す
        :return:
        """
        return (base_date + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

    @staticmethod
    def YmdTHMSZ_utc_to_YmdHMS_utc(input_datetime) -> datetime:

        """
        引数で受け取ったyyyyMMddTHHmmssZ形式の文字列を
        YYYY-MM-DD HH:MM:SS形式に変換して返す
        :param input_datetime:
        :rtype:str
        :return: datetime
        """

        return datetime.strptime(convert_datetime_format(
            input_datetime), "%Y-%m-%d %H:%M:%S")


class ServerUtil:

    def __init__(self, runtime, zuora_tenant: Dict[str, str] = None):
        self.runtime = runtime
        if zuora_tenant:
            self.zuora_tenant = zuora_tenant
            self._zuora_access_token_generator = self._get_zuora_access_token(zuora_tenant)

    def get_cebis_response(self, url: str, params: dict, method: str, data: dict, api_key: str):
        """
        データを取得するには、ApiGatewayサービスにアクセスする
        :param data: POSTメソッドで使用されるパラメーター本体
        :param method: http訪問方法
        :param url: アクセスするインターフェース
        :param params: APIが使用されるパラメーター
        :param api_key: api keyのvalue
        :return: JSONデータを取得する
        """
        # requestsのframeworkを使用する対象
        session = requests.Session()

        #  設置する必要があるパラメータ
        session.trust_env = False
        session.keep_alive = False

        # 異常の情報
        error_message = None

        # CEBISのへーだー
        cebis_request_header = {'x-api-key': api_key, 'Content-Type': 'application/json'}

        for retry_time in range(5):
            try:
                # GET方法
                if method.upper() == 'GET':
                    cebis_response = session.get(url=url, params=params, headers=cebis_request_header)

                # POST方法
                elif method.upper() == 'POST':
                    cebis_response = session.post(url=url, data=data, params=params, headers=cebis_request_header)

                # デフォルト方法(GET)
                else:
                    cebis_response = session.get(url=url, params=params, headers=cebis_request_header)
                return cebis_response
            except requests.exceptions.RequestException as e:
                time.sleep(10)
                error_message = e
        self.runtime.logger.fatal(error_message)
        self.runtime.logger.fatal('Failed to get list of contracts from cebis ...')
        self.runtime.logger.fatal('System exit ...')
        sys.exit(0)

    def get_k5_response(self, url: str, params: dict, method: str, allow_token_time_out_minutes: int,
                        data: dict, k5_tenant: dict):
        """
        富士通k5のデータを取得
        :param method: http??方法
        :param url: アクセスするインターフェース
        :param params: APIが使用するパラメーター
        :param allow_token_time_out_minutes: トークンがチェックされる有効期間
        :param data: POSTメソッドで使用されるパラメーター本体
        :param k5_tenant: tenantのリスト,
        :return:JSONデータを取得
        """
        # 取得するk5のトークン
        k5_token = self._get_k5_token(allow_token_time_out_minutes, k5_tenant=k5_tenant)

        # requestsのframeworkを使用する対象
        session = requests.Session()

        #  設置する必要があるパラメータ
        session.keep_alive = False

        # 異常の情報
        error_message = None

        # k5のへーだー
        k5_request_header = {
            'Content-Type': 'application/json',
            'Access-Token': k5_token
        }

        for retry_time in range(5):
            try:
                # GET方法
                if method.upper() == 'GET':
                    k5_response = session.get(url=url, params=params, headers=k5_request_header)
                # POST方法
                elif method.upper() == 'POST':
                    k5_response = session.post(url=url, data=data, params=params, headers=k5_request_header)
                # デフォルト方法(GET)
                else:
                    k5_response = session.get(url=url, params=params, headers=k5_request_header)

                return k5_response
            except requests.exceptions.RequestException as e:
                # 失敗した場合は、10秒待ちます
                time.sleep(10)
                error_message = e
        # 5回の失敗の場合
        self.runtime.logger.fatal(error_message)
        self.runtime.logger.fatal('Failed to get list of contracts from K5 ...')
        self.runtime.logger.fatal('System exit ...')
        sys.exit(0)

    def _get_k5_token(self, allow_token_time_out_minutes: int, k5_tenant: dict):
        """
        Tokenは30分間有効です
        トークンの有効期間がtoken_time_out_secondsより小さい場合、トークンを再取得します
        :param allow_token_time_out_minutes: トークンの有効性チェック時間,
        :param k5_tenant: tenantのリスト,
        :return k5_token: Tokenデータを取得
        """
        # requestsのframeworkを使用する対象
        session = requests.Session()

        #  設置する必要があるパラメータ
        session.keep_alive = False

        # 異常の情報
        error_message = None

        # k5トークンのへーだー
        k5_token_request_header = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'charset': 'UTF-8'
        }

        # k5トークンのパラメータ
        k5_token_data = {
            "grant_type": k5_tenant.get('grant_type'),
            "scope": k5_tenant.get('scope'),
            "client_id": k5_tenant.get('client_id'),
            "client_secret": k5_tenant.get('client_secret')
        }
        for retry_time in range(5):
            try:
                # K5を訪問し、現在のトークン情報を取得する
                k5_token_response = requests.post(
                    url=k5_tenant.get('auth_host') + k5_tenant.get('auth_url'),
                    data=k5_token_data,
                    headers=k5_token_request_header
                )
                # token取得正常的?合　トークンが取得できる場合
                if k5_token_response.status_code == 201:
                    # トークンの残り時間
                    k5_token_valid_minutes = k5_token_response.json().get('expires_in')
                    # トークンの現在時間は予定時間より小さい場合
                    if k5_token_valid_minutes < allow_token_time_out_minutes:
                        params = {'access_token': k5_token_response.json().get('access_token')}
                        # トークンを削除する
                        requests.delete(
                            url=k5_tenant.get('auth_host') + k5_tenant.get('auth_url'),
                            params=params,
                            data=k5_token_data,
                            headers=k5_token_request_header
                        )
                    else:
                        # トークンが取得できる場合、k5_tokenを戻る。
                        k5_token = k5_token_response.json().get('access_token')
                        # client_idの保存
                        self.runtime.client_id = k5_token_response.json().get('client_id')
                        return k5_token
            except requests.exceptions.RequestException as e:
                time.sleep(10)
                error_message = e
        self.runtime.logger.fatal(error_message)
        self.runtime.logger.info('Failed to get token from Fujitsu k5 API over 5 times ...')
        self.runtime.logger.info('System exit ...')
        sys.exit(0)


    @staticmethod
    def _get_zuora_access_token(zuora_tenant: Dict[str, str]) -> Generator[str, None, None]:
        '''ZuoraAPIの（有効期限が切れていない）OAuthアクセストークンを返却するジェネレーター。

        前回のアクセストークン取得時より3000秒以上経過した場合は再取得する。

        上記以外は前回取得したアクセストークンをそのまま返却する。

        Args:
            zuora_tenant (Dict[str, str]): ZuoraAPIアクセストークン取得のための接続情報

        Returns:
            Generator[str]: ZuoraAPIのOAuthアクセストークンを取得するジェネレーター

        Raises:
            ConnectionError: ZuoraAPIのアクセストークン取得に失敗
        '''
        # アクセストークン再取得のための秒数の閾値
        # 前回アクセストークン時からこの秒数を上回ると再度アクセストークンを取得する
        TIME_THRESHOLD = 3000

        def __request_zuora_access_token(zuora_tenant: Dict[str, str]) -> str:
            '''ZuoraAPIのOAuthアクセストークンを取得する関数
            '''
            # リクエストヘッダ
            req_header = {
                'Content-Type': 'application/x-www-form-urlencoded',
            }

            # リクエストボディ
            req_body = {
                'client_id': zuora_tenant['client_id'],
                'client_secret': zuora_tenant['client_secret'],
                'grant_type': zuora_tenant['grant_type'],
            }

            # OAuth API URL
            api_url = zuora_tenant['endpoint_url'] + zuora_tenant['auth_url']

            # アクセストークン取得
            response = requests.post(api_url, headers=req_header, data=req_body)
            if response.status_code == 200:
                access_token: str = response.json()['access_token']
                return access_token
            else:
                raise ConnectionError

        # アクセストークンを最後に取得した日時を格納
        last_token_time = datetime.now()

        # 初回時のアクセストークンを取得
        access_token = __request_zuora_access_token(zuora_tenant)
        yield access_token

        # 2回目以降のアクセストークン取得
        while True:
            # 最後にアクセストークンを取得した時刻と現在時刻の差分を取り、閾値を下回っている場合は再取得する。
            # 閾値を下回っていない場合はそれまでのアクセストークンを使いまわす。
            diff_seconds = (datetime.now() - last_token_time).seconds
            if diff_seconds > TIME_THRESHOLD:
                access_token = __request_zuora_access_token(zuora_tenant)
                last_token_time = datetime.now()

            yield access_token


    def execute_zuora_api(
            self,
            url: str,
            method: str,
            headers: Dict[str, str] = {},
            params: Any = None,
            data: Any = None,
            **kwargs: Dict[str, Any]
        ) -> requests.Response:
        '''ZuoraAPIを実行し、レスポンスを取得する。

        最大5回までAPIリクエストを試みるが、それでも失敗した場合はプログラムを終了する。

        Args:
            url (str): APIのURL
            method (str): リクエストメソッド（GET、POSTなど）
            headers (Dict[str, str]): リクエストヘッダ（リクエスト時に独自のヘッダを使用したい場合はこの引数で設定する）
            params (Any): リクエストパラメータ
            data (Any): リクエストボディ
            kwargs (Dict[str, Any]): キーワード引数

        Returns:
            requests.Response: APIレスポンス
        '''
        err_msg = None
        for _ in range(5):
            try:
                # アクセストークンの取得
                access_token = next(self._zuora_access_token_generator)

                # リクエストヘッダ
                default_header = {
                    'Authorization': 'Bearer ' + access_token,
                    'Content-Type': 'application/json',
                }

                # 引数で渡ってきたヘッダとマージする
                merged_header = {**default_header, **headers}

                # APIリクエスト実行
                response = requests.request(
                    url=url,
                    method=method.upper(),
                    headers=merged_header,
                    params=params,
                    data=data,
                    **kwargs
                )
                return response
            except Exception as e:
                err_msg = e
                time.sleep(10)

        # リクエスト失敗
        self.runtime.logger.fatal(err_msg)
        self.runtime.logger.info('Failed to get response from Zuora over 5 times ...')
        self.runtime.logger.info('System exit ...')
        sys.exit(0)


    def get_zuora_data_query_result(
            self,
            query: str,
            use_index_join: bool = True,
            read_deleted: bool = False,
        ) -> Optional[List[Dict[str, Any]]]:
        '''ZuoraのData Query APIを実行し、クエリ実行結果を取得する。

        クエリの実行が一定時間で完了しない場合はワーニングやエラーメッセージを表示してプログラム終了する。

        Args:
            query (str): Data Query APIで実行するSQL
            use_index_join (bool): Data Query内でIndex JOINを利用するかどうか（同APIのuseIndexJoinに該当）
            readDeleted (bool): 論理削除されたデータも実行結果に出力するか（同APIのreadDeletedに該当）

        Returns:
            Optional[List[Dict[str, Any]]]: クエリ実行結果。クエリが失敗した場合はNone。
        '''

        # Zuora Data Query実行の待ち時間（分）閾値
        DATA_QUERY_WAIT_TIME_WARN = 10  # WARNレベル
        DATA_QUERY_WAIT_TIME_ERROR = 15  # ERRORレベル

        # Data Query実行登録APIを実行
        api_url = self.zuora_tenant['endpoint_url'] + self.zuora_tenant['data_query_url']
        req_body = {
            'compression': 'NONE',
            'output': {
                'target': 'S3'
            },
            'outputFormat': 'JSON',  # ←この出力フォーマットを変更する場合は以下の処理内容も見直すこと
            'query': query,
            'useIndexJoin': use_index_join,
            'readDeleted': read_deleted,
        }
        response = self.execute_zuora_api(api_url, 'POST', data=json.dumps(req_body))
        if response.status_code == 200:
            # Data QueryがZuoraで承認されたかチェック
            response_data = response.json()['data']
            query_status = response_data['queryStatus']
            if query_status != 'accepted':
                self.runtime.logger.fatal(f'Query [{query}] was not accepted by Zuora')
                return None

            # 承認されたクエリのジョブIDを取得
            job_id = response_data['id']
        else:
            self.runtime.logger.fatal(f'Failed to post query [{query}] to Zuora')
            return None

        # クエリの実行完了までData Queryジョブのステータスを監視する
        api_url = self.zuora_tenant['endpoint_url'] + self.zuora_tenant['data_query_url'] + '/' + job_id
        query_start_time = datetime.now()
        while True:
            # Zuora側でクエリ実行中なので少し待ってから実行ステータス確認
            time.sleep(1)

            response = self.execute_zuora_api(api_url, 'GET')
            response_json = response.json()
            if response.status_code == 200:
                response_data = response_json['data']
                query_status: str = response_data['queryStatus']
                if query_status == 'in_progress':
                    # まだZuora側でクエリを実行中

                    # クエリ実行経過時間
                    elapsed_second: int = (datetime.now() - query_start_time).seconds
                    if elapsed_second > DATA_QUERY_WAIT_TIME_ERROR * 60:
                        # クエリの実行がERRORレベルの実行時間閾値を超えた場合
                        self.runtime.logger.error(f'Elapsed {elapsed_second} seconds when executing Zuora Data Query')
                        return None
                    elif elapsed_second > DATA_QUERY_WAIT_TIME_WARN * 60:
                        # クエリの実行がWARNレベルの実行時間閾値を超えた場合は警告ログを出力
                        self.runtime.logger.warn(f'Elapsed {elapsed_second} seconds when executing Zuora Data Query')

                    continue
                else:
                    # クエリ実行完了
                    break
            else:
                return None

        # クエリ実行失敗
        if query_status != 'completed':
            self.runtime.logger.fatal(f'Data Query [{query}] was not completed by Zuora')
            if 'errorMessage' in response_data:
                self.runtime.logger.fatal(f"error_message: [{response_data['errorMessage']}]")
            return None

        # 出力結果が0件であれば空のリストを返す
        if response_data['outputRows'] == 0:
            return list()

        # Zuora側で出力されたファイル（JSONL）をダウンロードし、ファイル中身を取得
        query_result_file_url: str = response_data['dataFile']
        response = requests.get(url=query_result_file_url)
        if response.status_code != 200:
            self.runtime.logger.fatal(f'Failed to get file [{query_result_file_url}] from Zuora')
            return None

        jsonl_data = response.text.split('\n')  # JSONLファイルなので行ごとに分割
        jsonl_data = [json.loads(json_data) for json_data in jsonl_data]  # JSON文字列から辞書型に変換

        return jsonl_data
