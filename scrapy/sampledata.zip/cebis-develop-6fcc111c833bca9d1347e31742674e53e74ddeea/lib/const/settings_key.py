"""
<copyright file="setting_key.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
MAINTENANCE_YAML_KEY = 'maintenance.yml'
