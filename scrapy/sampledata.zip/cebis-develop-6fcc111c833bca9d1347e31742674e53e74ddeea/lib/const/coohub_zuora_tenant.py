"""
<copyright file="coohub_zuora_tenant.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""
from django.conf import settings

ZUORA_TENANT = {
    'client_id': settings.ZUORA_TOKEN['CLIENT_ID'],
    'client_secret': settings.ZUORA_TOKEN['CLIENT_SECRET'],
    'grant_type': 'client_credentials',
    'endpoint_url': settings.ZUORA_TOKEN['API_ENDPOINT'],
    'auth_url': settings.ZUORA_TOKEN['AUTH_URL'],
    'data_query_url': settings.ZUORA_TOKEN['DATA_QUERY_URL'],
}
