"""
<copyright file="contract_service_state.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
ACTIVE = 'active'
INACTIVE = 'inactive'
TRIAL = 'trial'
