"""
<copyright file="product_type.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""

ESKER_PRODUCT_CODE_LIST = [
    'MVAR2200',  # Esker on Demand AP  基本サービスプラン（エントリーエディション）
    'MVAR2201',  # Esker on Demand AP  ERP接続オプションプラン（エントリーエディション）
    'MVAR2202',  # Esker on Demand AP  従量課金必須オプションプラン（エントリーエディション）
    'MVAR2203',  # Esker on Demand AP  データ保持7年オプションプラン（エントリーエディション）
    'MVAR2204',  # Esker on Demand AP  基本サービスプラン（ベーシックエディション）
    'MVAR2205',  # Esker on Demand AP  ERP接続オプションプラン（ベーシックエディション）
    'MVAR2206',  # Esker on Demand AP  従量課金必須オプションプラン（ベーシックエディション）
    'MVAR2207',  # Esker on Demand AP  データ保持7年オプションプラン（ベーシックエディション）
    'MVAR2208',  # Esker on Demand AP  基本サービスプラン（アドバンスエディション）
    'MVAR2209',  # Esker on Demand AP  ERP接続オプションプラン（アドバンスエディション）
    'MVAR2210',  # Esker on Demand AP  従量課金必須オプションプラン（アドバンスエディション）
    'MVAR2211',  # Esker on Demand AP  データ保持7年オプションプラン（アドバンスエディション）
    'MVAR2212',  # Esker on Demand AP  基本サービスプラン（エンタープライズエディション）
    'MVAR2213',  # Esker on Demand AP  ERP接続オプションプラン（エンタープライズエディション）
    'MVAR2214',  # Esker on Demand AP  従量課金必須オプションプラン（エンタープライズエディション）
    'MVAR2215',  # Esker on Demand AP  データ保持7年オプションプラン（エンタープライズエディション）
    'MVAR2216',  # Esker on Demand AP  基本サービス優待プラン（エントリーエディション）
    'MVAR2217',  # Esker on Demand AP  ERP接続オプション優待プラン（エントリーエディション）
    'MVAR2218',  # Esker on Demand AP  従量課金必須オプション優待プラン（エントリーエディション）
    'MVAR2219',  # Esker on Demand AP  データ保持7年オプション優待プラン（エントリーエディション）
    'MVAR2220',  # Esker on Demand AP  基本サービス優待プラン（ベーシックエディション）
    'MVAR2221',  # Esker on Demand AP  ERP接続オプション優待プラン（ベーシックエディション）
    'MVAR2222',  # Esker on Demand AP  従量課金必須オプション優待プラン（ベーシックエディション）
    'MVAR2223',  # Esker on Demand AP  データ保持7年オプション優待プラン（ベーシックエディション）
    'MVAR2224',  # Esker on Demand AP  基本サービス優待プラン（アドバンスエディション）
    'MVAR2225',  # Esker on Demand AP  ERP接続オプション優待プラン（アドバンスエディション）
    'MVAR2226',  # Esker on Demand AP  従量課金必須オプション優待プラン（アドバンスエディション）
    'MVAR2227',  # Esker on Demand AP  データ保持7年オプション優待プラン（アドバンスエディション）
    'MVAR2228',  # Esker on Demand AP  基本サービス優待プラン（エンタープライズエディション）
    'MVAR2229',  # Esker on Demand AP  ERP接続オプション優待プラン（エンタープライズエディション）
    'MVAR2230',  # Esker on Demand AP  従量課金必須オプション優待プラン（エンタープライズエディション）
    'MVAR2231',  # Esker on Demand AP  データ保持7年オプション優待プラン（エンタープライズエディション）
    'MVAR2232',  # Esker on Demand AP  基本サービス3年契約プラン（エントリーエディション）
    'MVAR2233',  # Esker on Demand AP  ERP接続オプション3年契約プラン（エントリーエディション）
    'MVAR2234',  # Esker on Demand AP  従量課金必須オプション3年契約プラン（エントリーエディション）
    'MVAR2235',  # Esker on Demand AP  データ保持7年オプション3年契約プラン（エントリーエディション）
    'MVAR2236',  # Esker on Demand AP  基本サービス3年契約プラン（ベーシックエディション）
    'MVAR2237',  # Esker on Demand AP  ERP接続オプション3年契約プラン（ベーシックエディション）
    'MVAR2238',  # Esker on Demand AP  従量課金必須オプション3年契約プラン（ベーシックエディション）
    'MVAR2239',  # Esker on Demand AP  データ保持7年オプション3年契約プラン（ベーシックエディション）
    'MVAR2240',  # Esker on Demand AP  基本サービス3年契約プラン（アドバンスエディション）
    'MVAR2241',  # Esker on Demand AP  ERP接続オプション3年契約プラン（アドバンスエディション）
    'MVAR2242',  # Esker on Demand AP  従量課金必須オプション3年契約プラン（アドバンスエディション）
    'MVAR2243',  # Esker on Demand AP  データ保持7年オプション3年契約プラン（アドバンスエディション）
    'MVAR2244',  # Esker on Demand AP  基本サービス3年契約プラン（エンタープライズエディション）
    'MVAR2245',  # Esker on Demand AP  ERP接続オプション3年契約プラン（エンタープライズエディション）
    'MVAR2246',  # Esker on Demand AP  従量課金必須オプション3年契約プラン（エンタープライズエディション）
    'MVAR2247',  # Esker on Demand AP  データ保持7年オプション3年契約プラン（エンタープライズエディション）
    'MVAR2248',  # Esker on Demand AP  基本サービス3年契約優待プラン（エントリーエディション）
    'MVAR2249',  # Esker on Demand AP  ERP接続オプション3年契約優待プラン（エントリーエディション）
    'MVAR2250',  # Esker on Demand AP  従量課金必須オプション3年契約優待プラン（エントリーエディション）
    'MVAR2251',  # Esker on Demand AP  データ保持7年オプション3年契約優待プラン（エントリーエディション）
    'MVAR2252',  # Esker on Demand AP  基本サービス3年契約優待プラン（ベーシックエディション）
    'MVAR2253',  # Esker on Demand AP  ERP接続オプション3年契約優待プラン（ベーシックエディション）
    'MVAR2254',  # Esker on Demand AP  従量課金必須オプション3年契約優待プラン（ベーシックエディション）
    'MVAR2255',  # Esker on Demand AP  データ保持7年オプション3年契約優待プラン（ベーシックエディション）
    'MVAR2256',  # Esker on Demand AP  基本サービス3年契約優待プラン（アドバンスエディション）
    'MVAR2257',  # Esker on Demand AP  ERP接続オプション3年契約優待プラン（アドバンスエディション）
    'MVAR2258',  # Esker on Demand AP  従量課金必須オプション3年契約優待プラン（アドバンスエディション）
    'MVAR2259',  # Esker on Demand AP  データ保持7年オプション3年契約優待プラン（アドバンスエディション）
    'MVAR2260',  # Esker on Demand AP  基本サービス3年契約優待プラン（エンタープライズエディション）
    'MVAR2261',  # Esker on Demand AP  ERP接続オプション3年契約優待プラン（エンタープライズエディション）
    'MVAR2262',  # Esker on Demand AP  従量課金必須オプション3年契約優待プラン（エンタープライズエディション）
    'MVAR2263',  # Esker on Demand AP  データ保持7年オプション3年契約優待プラン（エンタープライズエディション）
    'MVAR4100',  # クラウドサイン電子契約基本サービス
    'MVAR4101',  # クラウドサインStandardプラン
    'MVAR4102',  # クラウドサインBusinessプラン
    'MVAR4103',  # クラウドサイン書類インポートオプション
    'MVAR4104',  # クラウドサインStandardプラン（優待価格A）
    'MVAR4105',  # クラウドサインStandardプラン（優待価格B）
    'MVAR4106',  # クラウドサインStandardプラン（優待価格C）
    'MVAR4107',  # クラウドサインStandardプラン（優待価格D）
    'MVAR4108',  # クラウドサインBusinessプラン（優待価格A）
    'MVAR4109',  # クラウドサインBusinessプラン（優待価格B）
    'MVAR4110',  # クラウドサインBusinessプラン（優待価格C）
    'MVAR4111',  # クラウドサインBusinessプラン（優待価格D）
    'MVAR4112',  # クラウドサインBusinessプラン（優待価格E）
    'MVAR4113',  # クラウドサインBusinessプラン（優待価格F）
    'MVAR4114',  # クラウドサインBusinessプラン（優待価格G）
    'MVAR4115',  # クラウドサインBusinessプラン（優待価格H）
    'MVAR4116',  # クラウドサインBusinessプラン（優待価格I）
    'MVAR4117',  # クラウドサイン初期設定オプション
    'MVAR4118',  # クラウドサイン初期設定オプション（優待価格）
    'MVAR4150',  # クラウドサインNOW基本サービス
    'MVAR4151',  # クラウドサインNOW基本プラン
    'MVAR4152',  # クラウドサインNOW帳票出力
    'MVAR4153',  # クラウドサインNOW基本プラン（優待価格A）
    'MVAR4154',  # クラウドサインNOW基本プラン（優待価格B）
    'MVAR4155',  # クラウドサインNOW基本プラン（優待価格C）
    'MVAR4156',  # クラウドサインNOW基本プラン（優待価格D）
    'MVAR4157',  # クラウドサインNOW利用ライセンス
    'MVAR4158',  # クラウドサインNOW利用ライセンス(kintone版)
    'MVAR4159',  # クラウドサインNOW利用ライセンス（優待価格A）
    'MVAR4160',  # クラウドサインNOW利用ライセンス（優待価格B）
    'MVAR4161',  # クラウドサインNOW利用ライセンス（優待価格C）
    'MVAR4162',  # クラウドサインNOW初期設定費用：端末
    'MVAR4163',  # クラウドサインNOW端末追加費用
    'MVAR4164',  # クラウドサインNOW初期設定費用：データベース、帳票
    'MVAR4165',  # クラウドサインNOWDB/帳票追加
    'MVAR4170',  # クラウドサイン＃MAKE基本サービス
    'MVAR4171',  # クラウドサイン＃MAKE初期設定費用
    'MVAR4172',  # クラウドサイン＃MAKE基本プラン
    'MSUI2301',  # SUIREN&KOURYU SCSMobileSIM_Auto10GB_Multi
    'MSUI2302',  # SUIREN&KOURYU SCSMobileSIM_Auto20GB_Multi
    'MSUI2303',  # SUIREN&KOURYU SCSMobileSIM_Auto30GB_Multi
    'MSUI2304',  # SUIREN&KOURYU SCSMobileSIM_Auto50GB_Multi
    'MSUI2305',  # SUIREN&KOURYU SCSMobileSIM_Auto100GB_Multi
    'MSUI2311',  # SUIREN&KOURYU SCSMobileSIM_Auto10GB_Nano
    'MSUI2312',  # SUIREN&KOURYU SCSMobileSIM_Auto20GB_Nano
    'MSUI2313',  # SUIREN&KOURYU SCSMobileSIM_Auto30GB_Nano
    'MSUI2314',  # SUIREN&KOURYU SCSMobileSIM_Auto50GB_Nano
    'MSUI2315',  # SUIREN&KOURYU SCSMobileSIM_Auto100GB_Nano
    'MSUI2300',  # SUIREN&KOURYU SCSMobileSIM_Autoシェア_Multi
    'MSUI2310',  # SUIREN&KOURYU SCSMobileSIM_Autoシェア_Nano
    'MSUI2102',  # SUIREN&KOURYU SCSMobileSIM_Auto初期費用
    'MSUI2701',  # SUIREN&KOURYU ベーシックSIM3_Auto10GB_Multi
    'MSUI2702',  # SUIREN&KOURYU ベーシックSIM3_Auto20GB_Multi
    'MSUI2703',  # SUIREN&KOURYU ベーシックSIM3_Auto30GB_Multi
    'MSUI2704',  # SUIREN&KOURYU ベーシックSIM3_Auto50GB_Multi
    'MSUI2705',  # SUIREN&KOURYU ベーシックSIM3_Auto100GB_Multi
    'MSUI2711',  # SUIREN&KOURYU ベーシックSIM3_Auto10GB_Nano
    'MSUI2712',  # SUIREN&KOURYU ベーシックSIM3_Auto20GB_Nano
    'MSUI2713',  # SUIREN&KOURYU ベーシックSIM3_Auto30GB_Nano
    'MSUI2714',  # SUIREN&KOURYU ベーシックSIM3_Auto50GB_Nano
    'MSUI2715',  # SUIREN&KOURYU ベーシックSIM3_Auto100GB_Nano
    'MSUI2700',  # SUIREN&KOURYU ベーシックSIM3_Autoシェア_Multi
    'MSUI2710',  # SUIREN&KOURYU ベーシックSIM3_Autoシェア_Nano
    'MSUI2103',  # SUIREN&KOURYU ベーシックSIM3_Auto初期費用
    'MWPS0001',  # WPSS CocoDesk 基本サービス
    'MWPS0002',  # WPSS CocoDesk 5ユーザー利用パック
    'MWPS0010',  # WPSS CocoDesk 利用料(予約枠)
    'MWPS0011',  # WPSS CocoDesk 利用料10%off(予約枠)
    'MWPS0012',  # WPSS CocoDesk 利用料20%off(予約枠)
    'MWPS0013'  # WPSS CocoDesk 利用料30%off(予約枠)
]