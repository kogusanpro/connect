"""
<copyright file="calling_api_origins.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
BILLING_INFRASTRUCTURE = 'BILLING_INFRASTRUCTURE'
CALCULATION_SYSTEM = 'CALCULATION_SYSTEM'
SERVICE_PROVIDER = 'SERVICE_PROVIDER'
PORTAL_INFRASTRUCTURE = 'PORTAL_INFRASTRUCTURE'
