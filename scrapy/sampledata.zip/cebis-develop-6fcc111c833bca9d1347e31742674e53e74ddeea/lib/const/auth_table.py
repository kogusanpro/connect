"""
<copyright file="auth_table.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from lib.const.calling_api_origins import BILLING_INFRASTRUCTURE, CALCULATION_SYSTEM, SERVICE_PROVIDER, PORTAL_INFRASTRUCTURE
from collections import namedtuple


def get_auth_table(base_error, request_id):
    AuthItem = namedtuple('AuthItem', ('view', 'method', 'allow_origins', 'response'))
    AUTH_TABLE = [
        AuthItem('subscriptions_usage', 'POST', [SERVICE_PROVIDER], dict(base_error, **{'success': False, 'usage_id': None})),
        AuthItem('usage_upload_url', 'POST', [SERVICE_PROVIDER], dict(base_error, **{'success': False, 'presigned_url': None, 'request_id': request_id})),
        AuthItem('usage_download_url', 'GET', [CALCULATION_SYSTEM, SERVICE_PROVIDER], dict(base_error, **{'success': False, 'presigned_url': None, 'request_id': request_id})),
        AuthItem('subscriptions_bulk_fetch', 'GET', [CALCULATION_SYSTEM], dict(base_error, **{'success': False, 'count': None, 'subscriptions': None})),
        AuthItem('subscriptions_billing', 'POST', [CALCULATION_SYSTEM], dict(base_error, **{'success': False})),
        AuthItem('subscriptions_detail', 'POST', [BILLING_INFRASTRUCTURE], dict(base_error, **{'success': False})),
        AuthItem('subscriptions_detail', 'GET', [BILLING_INFRASTRUCTURE], dict(base_error, **{'success': False, 'count': None, 'subscriptions': None})),
        AuthItem('batch_process_info', 'GET', [SERVICE_PROVIDER, CALCULATION_SYSTEM], dict(base_error, **{'state': 'failure', 'request_id': request_id, 'total_records': None})),
        AuthItem('usage_info', 'GET', [SERVICE_PROVIDER], dict(base_error, **{'success': False})),
        AuthItem('subscriptions_billings', 'GET', [PORTAL_INFRASTRUCTURE], dict(base_error, **{'success': False})),
    ]
    return AUTH_TABLE
