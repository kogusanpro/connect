"""
<copyright file="coohub_k5_tenants.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""
import os
from django.conf import settings

K5_TENANTS = [
    {
        'client_id': settings.K5_TOKEN['USER'],
        'client_secret': settings.K5_TOKEN['PASSWORD'],
        'grant_type': 'client_credentials',
        'scope': 'service_contract',
        'auth_host': 'https://auth-api.jp-east-1.paas.cloud.global.fujitsu.com',
        'auth_url': '/API/oauth2/token/',
        'standard_value': 19000101
    }
]
