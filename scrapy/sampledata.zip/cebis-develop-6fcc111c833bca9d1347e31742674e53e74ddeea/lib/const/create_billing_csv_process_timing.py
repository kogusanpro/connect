"""
<copyright file="product_type.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""

PROCESS_TIMING_LIST = [
    '1st',
    '2nd'
]