"""
<copyright file="s3_for_usage.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
CSV_DIR_IN = 'IN'
CSV_DIR_PROCESSING = 'PROCESSING'
CSV_DIR_OUT = 'OUT'
