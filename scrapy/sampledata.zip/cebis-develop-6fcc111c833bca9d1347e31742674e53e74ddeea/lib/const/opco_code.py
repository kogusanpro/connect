"""
<copyright file="product_type.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""

OPCO_CODE_LIST = [
    'FX',  # Fuji Xerox
    'FXA',  # Fuji Xerox Australia Pty. Ltd.
    'FXCA',  # Fuji Xerox Asia Pacific Pte Ltd., Cambodia Operations
    'FXCL',  # Fuji Xerox (China) Limited
    'FXHK',  # Fuji Xerox (Hong Kong) Limited
    'FXK',  # Fuji Xerox Korea Co., Ltd.
    'FXM',  # Fuji Xerox Asia Pacific Pte Ltd., Malaysia Operations
    'FXMM',  # Fuji Xerox Asia Pacific Pte Ltd., Myanmar Branch
    'FXNZ',  # Fuji Xerox New Zealand Ltd.
    'FXP',  # Fuji Xerox Philippines, Inc.
    'FXS',  # Fuji Xerox Singapore Pte Ltd.
    'FXTH',  # Fuji Xerox (Thailand) Co., Ltd.
    'FXTW',  # Fuji Xerox Taiwan Corporation
    'FXV',  # Fuji Xerox Vietnam Company Limited
    'PTAG'  # PT Astra Graphia, Tbk.
]

OPCO_TIMEZONE = {
    'FX': 'Asia/Tokyo',  # Fuji Xerox
    'FXA': 'Etc/GMT-10',  # Fuji Xerox Australia Pty. Ltd.
    'FXCA': 'Asia/Phnom_Penh',  # Fuji Xerox Asia Pacific Pte Ltd., Cambodia Operations
    'FXCL': 'Asia/Shanghai',  # Fuji Xerox (China) Limited
    'FXHK': 'Asia/Hong_Kong',  # Fuji Xerox (Hong Kong) Limited
    'FXK': 'Asia/Seoul',  # Fuji Xerox Korea Co., Ltd.
    'FXM': 'Asia/Kuala_Lumpur',  # Fuji Xerox Asia Pacific Pte Ltd., Malaysia Operations
    'FXMM': 'Asia/Rangoon',  # Fuji Xerox Asia Pacific Pte Ltd., Myanmar Branch
    'FXNZ': 'Etc/GMT-12',  # Fuji Xerox New Zealand Ltd.
    'FXP': 'Asia/Manila',  # Fuji Xerox Philippines, Inc.
    'FXS': 'Asia/Singapore',  # Fuji Xerox Singapore Pte Ltd.
    'FXTH': 'Asia/Bangkok',  # Fuji Xerox (Thailand) Co., Ltd.
    'FXTW': 'Asia/Taipei',  # Fuji Xerox Taiwan Corporation
    'FXV': 'Asia/Saigon',  # Fuji Xerox Vietnam Company Limited
    'PTAG': 'Asia/Jakarta'  # PT Astra Graphia, Tbk.
}

OPCO_CURRENCY = {
    'FX': {'CURRENCY': 'JPY', 'DECIMAL_PLACES': 0, 'TAX_RATE': 10},  # Fuji Xerox
    'FXA': {'CURRENCY': 'AUD', 'DECIMAL_PLACES': 2, 'TAX_RATE': 10},  # Fuji Xerox Australia Pty. Ltd.
    'FXCA': {'CURRENCY': 'KHR', 'DECIMAL_PLACES': 0, 'TAX_RATE': None},  # Fuji Xerox Asia Pacific Pte Ltd., Cambodia Operations
    'FXCL': {'CURRENCY': 'CNY', 'DECIMAL_PLACES': 0, 'TAX_RATE': None},  # Fuji Xerox (China) Limited
    'FXHK': {'CURRENCY': 'HKD', 'DECIMAL_PLACES': 2, 'TAX_RATE': 0},  # Fuji Xerox (Hong Kong) Limited
    'FXK': {'CURRENCY': 'KRW', 'DECIMAL_PLACES': 0, 'TAX_RATE': 10},  # Fuji Xerox Korea Co., Ltd.
    'FXM': {'CURRENCY': 'MYR', 'DECIMAL_PLACES': 2, 'TAX_RATE': 6},  # Fuji Xerox Asia Pacific Pte Ltd., Malaysia Operations
    'FXMM': {'CURRENCY': 'MMK', 'DECIMAL_PLACES': 0, 'TAX_RATE': None},  # Fuji Xerox Asia Pacific Pte Ltd., Myanmar Branch
    'FXNZ': {'CURRENCY': 'NZD', 'DECIMAL_PLACES': 2, 'TAX_RATE': 15},  # Fuji Xerox New Zealand Ltd.
    'FXP': {'CURRENCY': 'PHP', 'DECIMAL_PLACES': 2, 'TAX_RATE': 12},  # Fuji Xerox Philippines, Inc.
    'FXS': {'CURRENCY': 'SGD', 'DECIMAL_PLACES': 2, 'TAX_RATE': 7},  # Fuji Xerox Singapore Pte Ltd.
    'FXTH': {'CURRENCY': 'THB', 'DECIMAL_PLACES': 2, 'TAX_RATE': 7},  # Fuji Xerox (Thailand) Co., Ltd.
    'FXTW': {'CURRENCY': 'TWD', 'DECIMAL_PLACES': 0, 'TAX_RATE': 5},  # Fuji Xerox Taiwan Corporation
    'FXV': {'CURRENCY': 'VND', 'DECIMAL_PLACES': 2, 'TAX_RATE': 10},  # Fuji Xerox Vietnam Company Limited
    'PTAG': {'CURRENCY': 'IDR', 'DECIMAL_PLACES': None, 'TAX_RATE': None},  # PT Astra Graphia, Tbk.
}
