"""
<copyright file="product_type.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
USAGE_NOT_FOUND = 'Usage not found'
USAGE_NOT_CALCULATED = 'Usage not calculated'
BILLING_RECORDS_ARE_NOT_CREATED = 'Billing records are not created.'

CONTRACT_NOT_FOUND = 'Contract not found'
INVALID_PARAMETER = 'Invalid Parameter'
