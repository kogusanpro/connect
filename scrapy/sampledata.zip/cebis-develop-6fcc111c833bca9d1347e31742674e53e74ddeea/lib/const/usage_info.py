"""
<copyright file="usage_info.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
FREE_ITEM_FOR_PSEUDO_RECORD = 'This record is dummy for flat rate calculation.'
