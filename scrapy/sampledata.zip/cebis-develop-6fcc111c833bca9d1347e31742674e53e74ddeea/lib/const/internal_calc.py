"""
<copyright file="product_type.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
SUBSCRIPTION_ID_POSTFIX = 'G'
PRODUCT_CODE_POSTFIXES = [
    'C6', 'C7', 'C8', 'C9', 'C10', 'C11'
]

# Zuoraプロフィットシェアカスタムフィールド情報
# コードとカスタムフィールド名の対応表
ZUORA_PROFITSHARE_CUSTOMFIELD_DICT = {
    'C6' : 'C6_Genka__c',           # [C6]原価
    'C7' : 'C7_ShikiriKakaku__c',   # [C7]仕切り価格
    'C8' : 'C8_HanbaiTesuryo__c',   # [C8]販売手数料
    'C9' : 'C9_KeiyakuTesuryo__c',  # [C9]契約手数料
    'C10': 'C10_Hoshuryo__c',       # [C10]保守料
    'C11': 'C11_Shoukairyo__c',     # [C11]紹介料
}
