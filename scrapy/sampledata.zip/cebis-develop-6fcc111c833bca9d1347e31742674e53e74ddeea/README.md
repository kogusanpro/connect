# Cebis開発環境構築手順
ここでは開発端末の環境として
- Windows10 Enterprise または Professional（1903以降）
- Docker Desktop for Windows 2.4.0.0

を想定して記載する。

## 1. Git for Windowsのインストール
Git for Windowsをインストールする。（インストール時のオプションはデフォルトのままでよい）

[https://gitforwindows.org/](https://gitforwindows.org/)

インストール後、「Git Bash」を起動し、以下のコマンドを順次実行していく。

```bash
# 社内プロキシ設定
git config --global http.proxy http://proxy.fujixerox.co.jp:8080
git config --global https.proxy http://proxy.fujixerox.co.jp:8080

# Gitユーザー設定（各自の統合認証IDとメールアドレスを記入）
git config --global user.name "fx*****"
git config --global user.email "******@fujixerox.co.jp"

# チェックアウトやコミット時にファイルの改行コード変換を行わないようにする設定
git config --global core.autocrlf false
```

## 2. Docker Desktop for Windowsのインストール
Docker Desktop for Windowsをインストールする。（インストール時のオプションはデフォルトのままでよい）

[https://hub.docker.com/editions/community/docker-ce-desktop-windows/](https://hub.docker.com/editions/community/docker-ce-desktop-windows/)

> ※インストール中に「WSL2 Linuxカーネルの更新」を求められた場合は下記URL内に記載されているようにLinuxカーネルの更新プログラムをダウンロードしてインストールする。
> 
> [https://docs.microsoft.com/ja-jp/windows/wsl/wsl2-kernel](https://docs.microsoft.com/ja-jp/windows/wsl/wsl2-kernel)

PowerShell上からdockerコマンドおよびdocker-composeコマンドが実行できることを確認する。

```bash
docker --version
docker-compose --version
```

※Docker関連のコマンドはコマンドプロンプトやGit Bash上では正常に動作しない場合があるので必ずPowerShell上で実行すること

## 3. Docker社内プロキシ設定
Dockerに社内プロキシの設定を行う。

上記でインストールしたDockerを起動（Windowsのスタートメニューより「Docker Desktop」を選択）する。

### 3.1. 環境変数設定
Windowsのシステム環境変数に以下の変数を追加する。

|変数名|値|
|:---|:---|
|HTTP_PROXY|http://proxy.fujixerox.co.jp:8080|
|HTTPS_PROXY|http://proxy.fujixerox.co.jp:8080|
|NO_PROXY|localhost,127.0.0.1|

### 3.2. Dockerデーモン用プロキシ設定
外部（DockerHub）からDockerイメージをダウンロードするために必要。

1. タスクトレイにあるDockerアイコンを右クリック→[Settings]を選択
1. [Resources]→[PROXIES]を選択
1. [Manual proxy configuration]をオンにし、HTTP欄に「http://proxy.fujixerox.co.jp:8080」を入力
1. 右下の[Apply & Restart]ボタンを押下（Dockerデーモンが再起動される）

### 3.3. Dockerコンテナ用プロキシ設定
Dockerコンテナがインターネットにアクセスするために必要。

開発端末のホームフォルダ（C:\Users\fx*****）直下の[.docker]フォルダ内にある[config.json]をテキストエディタで開き（[config.json]が存在しない場合は作成する）、以下の内容に書き換えて保存する。

```json
{
    "proxies": {
        "default": {
            "httpProxy": "http://proxy.fujixerox.co.jp:8080",
            "httpsProxy": "http://proxy.fujixerox.co.jp:8080",
            "noProxy": "localhost,127.0.0.1,10.*,172.*,192.168.*"
        }
    }
}
```

上記設定後、Dockerデーモンを再起動（タスクトレイにあるDockerアイコンを右クリック→[Restart]を選択）する。

## 4. AWS認証ファイル配置
1. ホームフォルダ（C:\Users\fx*****）直下に[.aws]フォルダを作成
1. 別途入手したAWS（soldev環境）の認証ファイル（config、credentialファイル）を上記の[.aws]フォルダ直下に配置

## 5. 認証ファイル設定（AWS以外）
1. [secret.env.template]をコピーして[secret.env]ファイルを作成する、もしくは他の人から別途入手する
1. [secret.env]ファイル内の設定値を入力する

※[secret.env]ファイルに認証情報を格納するため、
- コミットしない（[.gitignore]に記載しているため基本的にコミットはできない）
- 誤りをなくすために開発目的以外の認証情報を入力しないこと（QA環境、本番環境用の認証情報など）

こと

## 6. GitLabリポジトリからソースをクローン
Git Bashを起動する。

```bash
# 別途GitLabのID、パスワードを求められるので入力
git clone https://soldev-env.fujixerox.co.jp/ppup/cebis.git
cd cebis
git switch develop
```

## 7. DBセットアップ
PowerShellで上記でクローンしたリポジトリフォルダ直下まで移動し、以下のコマンドを実行する。

```bash
cd cebis
docker-compose up -d db
```

※初回実行時はDockerイメージのダウンロードがあるため時間がかかる

上記コマンド終了後、DBコンテナのサービスが立ち上がるまで10秒ほど待ってから以下のコマンドを実行する。

```bash
# DBマイグレーション
docker-compose run --rm web python manage.py migrate
```

# Cebisアプリケーション動作確認
PowerShellで上記のリポジトリフォルダ直下まで移動し、以下のコマンドを実行する。

```bash
docker-compose up -d db
# 上記コマンド実行後、10秒ほど待ち以下のコマンドを実行する
docker-compose up -d
```

ブラウザ等で [http://localhost:8000/subscriptions/](http://localhost:8000/subscriptions/) にアクセスし、

```json
{"time_stamp": "20201021T092714Z", "error_status": "401", "error_message": "Invalid IP address or API key", "success": false, "count": null, "subscriptions": null}
```

のようなレスポンスが得られればアプリケーションは動作している。（APIキーをリクエストに付与していないため、エラーのレスポンスが得られるのは正しい）

上記確認後、PowerShellにて以下のコマンドを実行する。（動作確認で使用していたコンテナが削除される）

```bash
docker-compose down
```

# Visual Studio Codeでの開発手順例
現状、Dockerコンテナを利用した開発ではVisual Studio Code（[https://code.visualstudio.com/](https://code.visualstudio.com/)）を使用するのが最適である。

ここでは、Visual Studio Code（以下、VSCode）を用いた開発手順例を記載する。

## 1. VSCode拡張機能のインストール
VSCodeで以下の拡張機能（=プラグイン）をインストールする。

- Japanese Language Pack for Visual Studio Code（[https://marketplace.visualstudio.com/items?itemName=MS-CEINTL.vscode-language-pack-ja](https://marketplace.visualstudio.com/items?itemName=MS-CEINTL.vscode-language-pack-ja)）

    用途：VSCodeの日本語化

- Docker（[https://marketplace.visualstudio.com/items?itemName=ms-azuretools.vscode-docker](https://marketplace.visualstudio.com/items?itemName=ms-azuretools.vscode-docker)）

    用途：主にDockerコンテナの操作で利用

- Remote Containers（[https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-containers](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-containers)）

    用途：コンテナ上のファイル編集やコマンド実行をVSCode上で行う

## 2. コンテナ起動
1. VSCodeからリポジトリフォルダ（cebis）を以下に記載のいずれかの手順で開く。
    - VSCodeのメニューから[ファイル]→[フォルダーを開く]で[cebis]フォルダを選択
    - Windowsエクスプローラー上で[cebis]フォルダを右クリック→[Codeで開く]を選択

1. 以下のいずれかの手順でRemote Containerプラグインを用いてコンテナ内部をVSCode上で開く。
    - VSCodeが起動してしばらくするとVSCode右下に「Folders contains a Dev Container configuration file. ～」というポップアップが表示されるので、ポップアップ内の[Reopen in Container]ボタンを押下
    - VSCode左下にある緑色の「><」のようなボタンを押下し、VSCode上部に表示される選択肢から「Remote-Containers: Reopen in Container」を選択
    - VSCodeで[F1]キーを押下し、上部に表示される検索テキストボックスから「Remote-Containers: Reopen in Container」を検索して選択する

1. しばらくするとVSCodeがコンテナ内部の表示に切り替わる ※初回実施時にはコンテナ作成やVSCodeプラグイン等のダウンロードがあるため少し時間がかかる

## 3. プログラム実行
VSCode下部にターミナルが表示されていない場合は、メニューの[ターミナル]→[新しいターミナル]を選択するとコンテナのbashが起動する。（bashのため、lsやcat等のLinuxコマンドも実行可能）

CebisのAPIやバッチを実行するにはbash上で直接コマンドを実行する。

- API

    ```bash
    python manage.py runserver 0.0.0.0:8000
    ```

- バッチ（例：擬似従量データ生成バッチ）

    ```bash
    python manage.py create_billing_record --target_month 202006
    ```

※CebisAPIを利用するバッチを実行する場合は別のターミナルでAPIサーバーを起動してから実行すること

## 4. デバッグ方法
VSCodeの左のアクティビティーバーより[デバッグ]ビューを選択する。

実行プロファイルにAPIサービスとバッチのデバッグ用プロフィールを登録しているので（.vscode/launch.json）、プルダウンよりデバッグ対象のものを選択する。

    API → REST APIのデバッグ
    BATCH 〇〇〇 → 対象バッチのデバッグ

VSCode上の対象ソースにブレークポイントを設定し、[デバッグ]ビューの[デバッグの開始]ボタンを選択すれば、ブレークポイントで動作が停止しステップ実行等が操作が可能。

なお、バッチ実行に付与するオプションはデバッグ開始時にVSCode上部にテキストボックスが現れるため、その都度入力していく。

# その他
## MySQLコンテナへの接続情報
Windows上のMySQLクライアント（MySQL Workbench、HeidiSQLなど）からMySQLコンテナへ接続する際は以下の接続情報を使用する。

|項目|値|
|:---|:---|
|ホスト|localhost または 127.0.0.1|
|ポート|3306|
|ユーザー|root|
|パスワード|password|
|データベース|cebis|

※接続エラーとなる場合はMySQLコンテナが開始しているか確認すること

## MySQLデータを初期化する方法
MySQLデータのテーブルデータ等は[db/data]フォルダ内に永続化されるように設定されている。（そのためMySQLコンテナを削除してもテーブルデータはそのまま残る）

MySQLデータを初期化したい場合は[db/data]フォルダ直下のファイルとフォルダを削除すること。

## Pipfileや環境変数を更新した場合

- Pipfile
- Pipfile.lock

を更新した場合やdocker-compose.ymlの環境変数を更新した場合は、Dockerイメージを再作成しないとその内容がコンテナに反映されない。

以下のいずれかの方法でイメージの再作成が行う。

※コンテナは停止していること

- PowerShellにてCebisリポジトリの直下まで移動し、以下のコマンドを実行

    ```bash
    docker-compose build --no-cache --force-rm web
    ```

- VSCodeのDocker拡張機能もしくは以下のdockerコマンドにてCebisのDockerコンテナおよびイメージを削除する

    ```bash
    # dockerコマンドでイメージおよびコンテナを削除
    docker container rm cebis_web_1
    docker image rm cebis_web:latest
    ```

    上記手順実行後にVSCodeの[Remote Containers]拡張機能でコンテナを起動するようにすればPipfile更新後のイメージが作成される。

## 不要なDockerイメージやコンテナを削除する方法
VSCodeの「Remote Containers」の拡張機能では
- Dockerfileやdocker-compose.ymlを更新した場合
- 上記のDockerイメージを再作成した場合

にDockerイメージを新しく作成している。

このままだと古いDockerイメージで開発端末のデータ量を徐々に圧迫されていくので、定期的にPowerShellで以下のコマンドを実行し不要なイメージやコンテナを削除する。

```bash
docker system prune # 削除するかどうかの確認があるが「y」を入力
```
