"""
<copyright file="tests_create_pseudo_usage.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from io import StringIO
import freezegun
from unittest import mock
from unittest.mock import call

from django.core.management import call_command, CommandError
from django.test import TestCase
from django.utils.timezone import datetime, timedelta

from subscriptions.factory_boy import ContractInfoFactory, ContractServiceInfoFactory, ProductInfoFactory,\
    UsageInfoFactory
from subscriptions.models import UsageInfo
from lib.const.contract_service_state import ACTIVE, INACTIVE, TRIAL
from lib.utils import DateTimeUtil
from pytz import UTC

COMMAND = 'create_pseudo_usage'


class CreatePseudoUsageTests(TestCase):

    def test_invalid_batch_exec_date(self):
        """
        バッチ実行時の引数が不正な形式の場合にエラーになることをテストする
        :return:
        """
        out = StringIO()
        with self.assertRaises(CommandError):
            call_command(COMMAND, stdout=out)
            call_command(COMMAND, '2018-01-01T00:00:00Z', stdout=out)
            call_command(COMMAND, '2018/01/01T00:00:00Z', stdout=out)
            call_command(COMMAND, '20180101T00:00:00z', stdout=out)
            call_command(COMMAND, '20180230T000000Z', stdout=out)

    @freezegun.freeze_time('2000-01-01 09:00:00')
    def test_create_active_and_service_started_and_flat_rate(self):
        """
        契約状態がアクティブかつ、サービス手配完了日時が
        バッチ実行日時より未来日付でない定額課金のデータに対して従量データが生成される
        ことをテストする
        :return:
        """

        now = DateTimeUtil.utc_now_aware()
        past_date = now + timedelta(days=-1)
        future_date = now + timedelta(days=1)
        target_ym = now.strftime('%Y%m')

        flat_product1 = ProductInfoFactory(flat_rate=True)
        flat_product2 = ProductInfoFactory(flat_rate=True)
        flat_product3 = ProductInfoFactory(flat_rate=True)

        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date,
                                   product_code=flat_product1)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now,
                                   product_code=flat_product2)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=future_date,
                                   product_code=flat_product3)

        out = StringIO()
        call_command(COMMAND, stdout=out)
        test_date = '2000-01-31 14:00:00'
        test_date = datetime.strptime(test_date, '%Y-%m-%d %H:%M:%S').replace(tzinfo=UTC)

        usages = UsageInfo.objects.all()
        # 定額課金のデータが2件登録されてるはず
        self.assertEqual(usages.count(), 2)
        # 対象月度が正しく登録されていることを確認
        for usage in usages:
            self.assertEqual(usage.target_month, target_ym)
            self.assertEqual(usage.license_user, None)
            self.assertEqual(usage.free_item1, 'This record is dummy for flat rate calculation.')
            self.assertEqual(usage.free_item2, None)
            self.assertEqual(usage.start_time, test_date)
            self.assertEqual(usage.end_time, test_date)


    def test_non_create_active_and_service_started_and_non_flat_rate(self):
        """
        契約状態がアクティブかつ、サービス手配完了日時が
        バッチ実行日時より未来日付でも定額課金でないデータに対しては従量データが生成されないことをテストする
        ことをテストする
        :return:
        """

        now = DateTimeUtil.utc_now_aware()
        past_date = now + timedelta(days=-1)
        future_date = now + timedelta(days=1)
        target_ym = now.strftime('%Y%m')

        none_flat_product1 = ProductInfoFactory(flat_rate=False)
        none_flat_product2 = ProductInfoFactory(flat_rate=False)
        none_flat_product3 = ProductInfoFactory(flat_rate=False)

        contract_info = ContractInfoFactory()
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date,
                                   product_code=none_flat_product1)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now,
                                   product_code=none_flat_product2)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=future_date,
                                   product_code=none_flat_product3)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        usages = UsageInfo.objects.all()
        # 定額課金のデータが登録されていないはず
        self.assertEqual(usages.count(), 0)

    def test_create_inactive_and_cancel_current_month_and_flat_rate(self):
        """
        契約状態がインアクティブかつ、サービス解約手配完了日時の年月が
        バッチ実行日時の年月と一致するデータに対して請求データが生成される
        ことをテストする
        :return:
        """

        now = DateTimeUtil.utc_now_aware()

        flat_product1 = ProductInfoFactory(flat_rate=True)
        flat_product2 = ProductInfoFactory(flat_rate=True)
        flat_product3 = ProductInfoFactory(flat_rate=True)
        flat_product4 = ProductInfoFactory(flat_rate=True)
        flat_product5 = ProductInfoFactory(flat_rate=True)

        now = DateTimeUtil.utc_now_aware()
        first_day = now.replace(day=1)
        if now.month == 1:
            past_month = now.replace(month=12, year=now.year - 1)
        else:
            past_month = now.replace(month=now.month - 1, day=10)
        if now.month == 12:
            future_month = now.replace(month=1, year=now.year + 1, day=10)
        else:
            future_month = now.replace(month=now.month + 1, day=10)
        target_ym = now.strftime('%Y%m')

        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=now, product_code=flat_product1)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day, product_code=flat_product2)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day + timedelta(days=-1), product_code=flat_product3)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=past_month, product_code=flat_product4)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=future_month, product_code=flat_product5)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        usages = UsageInfo.objects.all()
        # 定額課金のデータが2件登録されていないはず
        self.assertEqual(usages.count(), 2)
        # 対象月度が正しく登録されていることを確認
        self.assertEqual(usages[0].start_time, now)
        self.assertEqual(usages[0].end_time, now)
        self.assertEqual(usages[1].start_time, first_day)
        self.assertEqual(usages[1].end_time, first_day)
        for usage in usages:
            self.assertEqual(usage.target_month, target_ym)
            self.assertEqual(usage.license_user, None)
            self.assertEqual(usage.free_item1, 'This record is dummy for flat rate calculation.')
            self.assertEqual(usage.free_item2, None)


    def test_non_create_inactive_and_cancel_current_month_and_non_flat_rate(self):
        """
        契約状態がインアクティブかつ、サービス解約手配完了日時の年月が
        バッチ実行日時の年月と一致するデータに対して請求データが生成される
        ことをテストする
        :return:
        """

        now = DateTimeUtil.utc_now_aware()

        non_flat_product1 = ProductInfoFactory(flat_rate=False)
        non_flat_product2 = ProductInfoFactory(flat_rate=False)
        non_flat_product3 = ProductInfoFactory(flat_rate=False)
        non_flat_product4 = ProductInfoFactory(flat_rate=False)

        now = DateTimeUtil.utc_now_aware()
        first_day = now.replace(day=1)
        if now.month == 1:
            past_month = now.replace(month=12, year=now.year - 1)
        else:
            past_month = now.replace(month=now.month - 1, day=10)
        if now.month == 12:
            future_month = now.replace(month=1, year=now.year + 1, day=10)
        else:
            future_month = now.replace(month=now.month + 1, day=10)
        target_ym = now.strftime('%Y%m')

        # 1件目の契約
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=now, product_code=non_flat_product1)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day + timedelta(days=-1), product_code=non_flat_product2)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=past_month, product_code=non_flat_product3)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=future_month, product_code=non_flat_product4)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        usages = UsageInfo.objects.all()
        # 定額課金のデータが存在しないので、1件も登録されていないはず
        self.assertEqual(usages.count(), 0)

    def test_not_create_trial(self):
        """
        契約状態がトライアルの場合擬似従量データが生成され無いことをテストする
        :return:
        """

        now = DateTimeUtil.utc_now_aware()
        first_day = now.replace(day=1)
        if now.month == 1:
            past_month = now.replace(month=12, year=now.year - 1)
        else:
            past_month = now.replace(month=now.month - 1, day=10)
        if now.month == 12:
            future_month = now.replace(month=1, year=now.year + 1, day=10)
        else:
            future_month = now.replace(month=now.month + 1, day=10)
        target_ym = now.strftime('%Y%m')

        flat_product1 = ProductInfoFactory(flat_rate=True)
        flat_product2 = ProductInfoFactory(flat_rate=True)
        flat_product3 = ProductInfoFactory(flat_rate=True)
        flat_product4 = ProductInfoFactory(flat_rate=True)
        flat_product5 = ProductInfoFactory(flat_rate=True)

        # 1件目の契約
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL,
                                   service_cancel_time=now, product_code=flat_product1)
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL,
                                   service_cancel_time=first_day, product_code=flat_product2)
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL,
                                   service_cancel_time=first_day + timedelta(days=-1), product_code=flat_product3)
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL,
                                   service_cancel_time=past_month, product_code=flat_product4)
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL,
                                   service_cancel_time=future_month, product_code=flat_product5)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        usages = UsageInfo.objects.all()
        self.assertEqual(usages.count(), 0)

    def test_create_active_and_service_started_and_inactive_and_cancel_current_month(self):
        """
        ・契約状態がアクティブかつ、サービス手配完了日時がバッチ実行日時より未来日付かつ、定額課金の商品
        ・契約状態がインアクティブかつ、サービス解約手配完了日時の年月がバッチ実行日時の年月と一致かつ、定額課金の商品
        両方のパターンが混在する場合に、想定通りの請求データが生成されることをテストする
        :return:
        """

        now = DateTimeUtil.utc_now_aware()
        first_day = now.replace(day=1)
        if now.month == 1:
            past_month = now.replace(month=12, year=now.year - 1)
        else:
            past_month = now.replace(month=now.month - 1, day=10)
        if now.month == 12:
            future_month = now.replace(month=1, year=now.year + 1, day=10)
        else:
            future_month = now.replace(month=now.month + 1, day=10)
        past_date = now + timedelta(days=-1)
        future_date = now + timedelta(days=1)
        target_ym = now.strftime('%Y%m')

        flat_product1 = ProductInfoFactory(flat_rate=True)
        flat_product2 = ProductInfoFactory(flat_rate=True)
        flat_product3 = ProductInfoFactory(flat_rate=True)
        flat_product4 = ProductInfoFactory(flat_rate=True)
        flat_product5 = ProductInfoFactory(flat_rate=True)
        flat_product6 = ProductInfoFactory(flat_rate=True)
        flat_product7 = ProductInfoFactory(flat_rate=True)

        # 1件目の契約 ACTIVE
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date,
                                   product_code=flat_product1)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now,
                                   product_code=flat_product2)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=future_date,
                                   product_code=flat_product3)

        # 2件目の契約 INACTIVE
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=now,
                                   product_code=flat_product1)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day, product_code=flat_product2)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day + timedelta(days=-1),
                                   product_code=flat_product3)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=past_month,
                                   product_code=flat_product4)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=future_month,
                                   product_code=flat_product5)

        # 3件目の契約 ACTIVE INACTIVE混在
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date,
                                   product_code=flat_product1)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now,
                                   product_code=flat_product2)

        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=now,
                                   product_code=flat_product3)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day, product_code=flat_product4)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day + timedelta(days=-1),
                                   product_code=flat_product5)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=past_month,
                                   product_code=flat_product6)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=future_month,
                                   product_code=flat_product7)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        usages = UsageInfo.objects.all()
        # 従量データは3件登録されてるはず
        self.assertEqual(usages.count(), 8)
        # 対象月度が正しく登録されていることを確認
        for usage in usages:
            self.assertEqual(usage.target_month, target_ym)
            self.assertEqual(usage.license_user, None)
            self.assertEqual(usage.free_item1, 'This record is dummy for flat rate calculation.')
            self.assertEqual(usage.free_item2, None)

    def __special_date_common_test(self):
        """
        特殊な日付のテストに共通して使い回すテストロジック
        :return:
        """
        now = DateTimeUtil.utc_now_aware()
        first_day = now.replace(day=1)
        if now.month == 1:
            past_month = now.replace(month=12, year=now.year - 1)
        else:
            past_month = now.replace(month=now.month - 1, day=10)
        if now.month == 12:
            future_month = now.replace(month=1, year=now.year + 1, day=10)
        else:
            future_month = now.replace(month=now.month + 1, day=10)
        past_date = now + timedelta(days=-1)
        future_date = now + timedelta(days=1)
        target_ym = now.strftime('%Y%m')

        flat_product1 = ProductInfoFactory(flat_rate=True)
        flat_product2 = ProductInfoFactory(flat_rate=True)
        flat_product3 = ProductInfoFactory(flat_rate=True)
        flat_product4 = ProductInfoFactory(flat_rate=True)
        flat_product5 = ProductInfoFactory(flat_rate=True)
        flat_product6 = ProductInfoFactory(flat_rate=True)
        flat_product7 = ProductInfoFactory(flat_rate=True)

        # 1件目の契約 ACTIVE
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date,
                                   product_code=flat_product1)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now,
                                   product_code=flat_product2)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=future_date,
                                   product_code=flat_product3)

        # 2件目の契約 INACTIVE
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=now,
                                   product_code=flat_product1)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day, product_code=flat_product2)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day + timedelta(days=-1),
                                   product_code=flat_product3)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=past_month,
                                   product_code=flat_product4)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=future_month,
                                   product_code=flat_product5)

        # 3件目の契約 ACTIVE INACTIVE混在
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date,
                                   product_code=flat_product1)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now,
                                   product_code=flat_product2)

        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=now,
                                   product_code=flat_product3)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day, product_code=flat_product4)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day + timedelta(days=-1),
                                   product_code=flat_product5)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=past_month,
                                   product_code=flat_product6)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=future_month,
                                   product_code=flat_product7)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        usages = UsageInfo.objects.all()
        # 従量データは3件登録されてるはず
        self.assertEqual(usages.count(), 8)
        # 対象月度が正しく登録されていることを確認
        for usage in usages:
            self.assertEqual(usage.target_month, target_ym)
            self.assertEqual(usage.license_user, None)
            self.assertEqual(usage.free_item1, 'This record is dummy for flat rate calculation.')
            self.assertEqual(usage.free_item2, None)

    @freezegun.freeze_time('2020-02-29 23:00:00')
    def test_leap_year(self):
        """
        閏年の2/29にバッチを実行した場合でも正常に処理が完了することをテストする
        :return:
        """
        self.__special_date_common_test()

    @freezegun.freeze_time('2018-01-31 23:00:00')
    def test_leap_year(self):
        """
        1/31(前月が前年)にバッチを実行した場合でも正常に処理が完了することをテストする
        :return:
        """
        self.__special_date_common_test()

    @freezegun.freeze_time('2018-12-31 23:00:00')
    def test_leap_year(self):
        """
        12/31(翌月が来年)にバッチを実行した場合でも正常に処理が完了することをテストする
        :return:
        """
        self.__special_date_common_test()

    @mock.patch('logging.Logger.error')
    @freezegun.freeze_time('2000-01-01 09:00:00')
    def test_logging_exists_usage_info(self, mock_logger):
        """
        従量データテーブルに既にレコードが存在していた場合にエラーログが出力されることをテストする
        :return:
        """

        now = DateTimeUtil.utc_now_aware()
        past_date = now + timedelta(days=-1)
        flat_product1 = ProductInfoFactory(flat_rate=True, product_code='product1')

        contract_info = ContractInfoFactory(subscription_id=1)
        contract_service_info = ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE,
                                                           service_start_time=past_date, product_code=flat_product1,
                                                           license_quantity=10)
        batch_time = '20000131T140000Z'
        usage_id = f'{contract_service_info.subscription_id}_{contract_service_info.product_code_id}_' \
                    f'{batch_time}_{batch_time}_{contract_service_info.license_quantity}'

        UsageInfoFactory(usage_id=usage_id, subscription=contract_info)

        out = StringIO()
        call_command(COMMAND, stdout=out)
        mock_logger.assert_has_calls([
            call(f'subscription_id 1 and usage_id 1_product1_{batch_time}_{batch_time}_10 is '
                 f'already exists in usage_info')
        ])
