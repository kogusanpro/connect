"""
<copyright input_file_path="tests_coohub_manual_execute_calculations.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2020-2020. All rights reserved.
</copyright>
"""
from django.core.management import call_command, CommandError
from django.test import TestCase
from rest_framework import status
from unittest import mock
from datetime import datetime
from pytz import UTC, timezone
import os
import sys
import json
from lib.utils import DateTimeUtil

COMMAND = 'coohub_manual_execute_calculations'


@mock.patch('batch.management.commands.coohub_manual_execute_calculations.ServerUtil.get_k5_response')
class CoohubManualExecuteCalculationsTests(TestCase):
    def setUp(self):
        os.environ['K5_API_ENDPOINT'] = 'https://business-support-k5.jp-east-1.paas.cloud.global.fujitsu.com'
        os.environ['K5_MANUAL_EXECUTE_CALCULATIONS_URL'] = '/API/v2/api/manualexecute/calculations'

    def tearDown(self):
        if sys.argv[-1] == str('charlie.settings.ci'):
            pass
        else:
            pass

    def test_validation(self, mock):
        """
        不正な入力パラメータでエラーが返ることのテスト
        """
        with self.assertRaises(CommandError) as cm:
            call_command(
                COMMAND,
                '--executed_date',
                'executed_date',
            )
        self.assertIsInstance(cm.exception, CommandError)
        self.assertEqual(cm.exception.args[0], "executed_date was invalid format in this request body")

    def test_manual_execute_calculations_result_ok(self, mock):
        """
        COOHUBは正常に実行することのテスト（K5で実行成功）
        """
        mock.return_value = MockResponse(
            {
                "receipt_code": "R00000000000001",
                "result_information": {
                    "result": "OK"
                }
            },
            status.HTTP_202_ACCEPTED
        )
        with self.assertRaises(SystemExit) as se:
            call_command(
                COMMAND,
                '--executed_date',
                '20171212',
            )
        self.assertEqual(se.exception.code, 0)
        self.assertIsInstance(se.exception, SystemExit)
        mock.assert_called_with(
            url='https://business-support-k5.jp-east-1.paas.cloud.global.fujitsu.com'
                '/API/v2/api/manualexecute/calculations',
            params=dict(),
            method='POST',
            allow_token_time_out_minutes=5,
            data=json.dumps({
                'batch_division': '03',
                'target_month': '201711',
                'execute_restriction_release': '1'
            }),
            k5_tenant={
                'client_id': 'fx28845',
                'client_secret': 'P@ssw0rd',
                'grant_type': 'client_credentials',
                'scope': 'service_contract',
                'auth_host': 'https://auth-api.jp-east-1.paas.cloud.global.fujitsu.com',
                'auth_url': '/API/oauth2/token/',
                'standard_value': 19000101
            }
        )

    def test_manual_execute_calculations_result_ng(self, mock):
        """
        COOHUBは正常に実行することのテスト（K5で実行失敗）
        """
        mock.return_value = MockResponse(
            {
                "receipt_code": "R00000000000001",
                "result_information": {
                    "result": "NG",
                    "detailed_result": "Execution failed"
                }
            },
            status.HTTP_202_ACCEPTED
        )
        with self.assertRaises(SystemExit) as se:
            call_command(
                COMMAND,
                '--executed_date',
                '20171212',
            )
        self.assertEqual(se.exception.code, 1)
        self.assertIsInstance(se.exception, SystemExit)
        mock.assert_called_with(
            url='https://business-support-k5.jp-east-1.paas.cloud.global.fujitsu.com'
                '/API/v2/api/manualexecute/calculations',
            params=dict(),
            method='POST',
            allow_token_time_out_minutes=5,
            data=json.dumps({
                'batch_division': '03',
                'target_month': '201711',
                'execute_restriction_release': '1'
            }),
            k5_tenant={
                'client_id': 'fx28845',
                'client_secret': 'P@ssw0rd',
                'grant_type': 'client_credentials',
                'scope': 'service_contract',
                'auth_host': 'https://auth-api.jp-east-1.paas.cloud.global.fujitsu.com',
                'auth_url': '/API/oauth2/token/',
                'standard_value': 19000101
            }
        )

    def test_not_execute_date(self, mock):
        """
        COOHUBは正常に実行することのテスト（K5で実行成功）（executed_dateが未設定）
        """
        mock.return_value = MockResponse(
            {
                "receipt_code": "R00000000000001",
                "result_information": {
                    "result": "OK"
                }
            },
            status.HTTP_202_ACCEPTED
        )
        with self.assertRaises(SystemExit) as se:
            call_command(
                COMMAND,
            )
        self.assertEqual(se.exception.code, 0)
        self.assertIsInstance(se.exception, SystemExit)
        mock.assert_called_with(
            url='https://business-support-k5.jp-east-1.paas.cloud.global.fujitsu.com'
                '/API/v2/api/manualexecute/calculations',
            params=dict(),
            method='POST',
            allow_token_time_out_minutes=5,
            data=json.dumps({
                'batch_division': '03',
                'target_month': DateTimeUtil.get_prev_specific_date_ym(
                    datetime.utcnow().replace(tzinfo=UTC).astimezone(timezone('Asia/Tokyo')).strftime('%Y%m%d')),
                'execute_restriction_release': '1'
            }),
            k5_tenant={
                'client_id': 'fx28845',
                'client_secret': 'P@ssw0rd',
                'grant_type': 'client_credentials',
                'scope': 'service_contract',
                'auth_host': 'https://auth-api.jp-east-1.paas.cloud.global.fujitsu.com',
                'auth_url': '/API/oauth2/token/',
                'standard_value': 19000101
            }
        )

    def test_prev_specific_date_ym(self, mock):
        """
        一月で正常に実行することのテスト
        """
        mock.return_value = MockResponse(
            {
                "receipt_code": "R00000000000001",
                "result_information": {
                    "result": "OK"
                }
            },
            status.HTTP_202_ACCEPTED
        )
        with self.assertRaises(SystemExit) as se:
            call_command(
                COMMAND,
                '--executed_date',
                '20180112',
            )
        self.assertEqual(se.exception.code, 0)
        self.assertIsInstance(se.exception, SystemExit)
        mock.assert_called_with(
            url='https://business-support-k5.jp-east-1.paas.cloud.global.fujitsu.com'
                '/API/v2/api/manualexecute/calculations',
            params=dict(),
            method='POST',
            allow_token_time_out_minutes=5,
            data=json.dumps({
                'batch_division': '03',
                'target_month': '201712',
                'execute_restriction_release': '1'
            }),
            k5_tenant={
                'client_id': 'fx28845',
                'client_secret': 'P@ssw0rd',
                'grant_type': 'client_credentials',
                'scope': 'service_contract',
                'auth_host': 'https://auth-api.jp-east-1.paas.cloud.global.fujitsu.com',
                'auth_url': '/API/oauth2/token/',
                'standard_value': 19000101
            }
        )

    def test_http_400_bad_request(self, mock):
        """
        異常になるテスト
        """
        mock.return_value = MockResponse(
            {
                "receipt_code": "R00000000000001",
                "result_information": {
                    "result": "NG",
                    "detailed_result": "Execution failed"
                }
            },
            status.HTTP_400_BAD_REQUEST
        )
        with self.assertRaises(SystemExit) as se:
            call_command(
                COMMAND,
                '--executed_date',
                '20500112',
            )
        self.assertEqual(se.exception.code, 1)
        mock.assert_called_with(
            url='https://business-support-k5.jp-east-1.paas.cloud.global.fujitsu.com'
                '/API/v2/api/manualexecute/calculations',
            params=dict(),
            method='POST',
            allow_token_time_out_minutes=5,
            data=json.dumps({
                'batch_division': '03',
                'target_month': '204912',
                'execute_restriction_release': '1'
            }),
            k5_tenant={
                'client_id': 'fx28845',
                'client_secret': 'P@ssw0rd',
                'grant_type': 'client_credentials',
                'scope': 'service_contract',
                'auth_host': 'https://auth-api.jp-east-1.paas.cloud.global.fujitsu.com',
                'auth_url': '/API/oauth2/token/',
                'standard_value': 19000101
            }
        )


class MockResponse:
    def __init__(self, json_data, status_code):
        self.json_data = json_data
        self.status_code = status_code

    def json(self):
        return self.json_data
