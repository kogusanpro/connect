"""
<copyright file="services.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import os.path
from datetime import timedelta

from django.db.models import Q, QuerySet

from lib.const.contract_service_state import ACTIVE, INACTIVE
from subscriptions.models import ContractServiceInfo, BillingDetailInfo, UsageInfo


def query_billing_target(batch_time) -> QuerySet:
    """
    請求対象となる契約データを検索して返す
    :param batch_time: 月末23:00:00
    :param begin_of_month: 月初1日00:00:00
    :rtype QuerySet
    :return: 請求対象となる契約データのクエリセット
    """

    sql = """
    SELECT
      *
    FROM
      (
        SELECT
          csi.*
        FROM
          contract_service_info csi
          INNER JOIN
          contract_info ci
            ON  csi.subscription_id           = ci.subscription_id
        WHERE
          csi.state                           = %s
          AND csi.service_start_time         <= %s
          AND csi.service_start_time         <> ''
          AND COALESCE(ci.contract_code, '') <> ''
          AND (ci.subscription_number = '' OR ci.subscription_number IS NULL)
        UNION ALL
        SELECT
          csi.*
        FROM
          contract_service_info csi
          INNER JOIN
          contract_info ci
            ON  csi.subscription_id           = ci.subscription_id
        WHERE
          csi.state                           = %s
          AND csi.service_cancel_time        >= %s
          AND csi.service_cancel_time        >= csi.service_start_time
          AND csi.service_start_time         < %s
          AND COALESCE(ci.contract_code, '') <> ''
          AND (ci.subscription_number = '' OR ci.subscription_number IS NULL)
      ) tmp
    ORDER BY
      subscription_id ASC,
      product_code    ASC
    """

    return ContractServiceInfo.objects.raw(sql, [ACTIVE, batch_time, INACTIVE, batch_time, batch_time])


def query_pseudo_usage_target(now, begin_of_month, begin_of_next_month):
    """
    擬似従量データ作成用のクエリセットを取得して返す
    :param now: バッチ実行日時
    :param begin_of_month: バッチ実行年月の月初の日付
    :param begin_of_next_month: バッチ実行年月の翌月月初の日付
    :return:擬似従量データ作成用のクエリセット
    :rtype QuerySet
    """

    sql = """
    SELECT
        *
    FROM
        (
            SELECT
                csi.*
            FROM
                contract_service_info csi
                INNER JOIN
                    product_info pi
                ON  csi.product_code     = pi.product_code
            WHERE
                pi.dummy_usage = TRUE
            AND csi.service_start_time  <= %s
            AND csi.state                = %s
            UNION ALL
            SELECT
                csi.*
            FROM
                contract_service_info csi
            INNER JOIN
                product_info pi
            ON  csi.product_code         = pi.product_code
            WHERE
                pi.dummy_usage = TRUE
            AND csi.service_cancel_time >= %s
            AND csi.service_cancel_time  < %s
            AND csi.state                = %s
        ) tmp
    ORDER BY
        subscription_id,
        product_code
    """

    return ContractServiceInfo.objects.raw(sql, [now, ACTIVE, begin_of_month, begin_of_next_month, INACTIVE])


def query_billing_csv_target(target_month):
    """
    :rtype: list[BillingDetailInfo]
    :return:
    """

    sql = """
    SELECT
        bi.subscription_id                  AS subscription_id
        ,ci.opco_code                       AS opco_code
        ,ci.contract_code                   AS contract_code
        ,bi.target_month                    AS target_month
        ,bi.start_date                      AS start_date
        ,bi.end_date                        AS end_date
        ,bi.billing                         AS billing
        ,bi.unit_of_money                   AS unit_of_money
        ,bi.state                           AS state
        ,bdi.id                             AS id
        ,bdi.product_code                   AS product_code
        ,bdi.license_quantity               AS license_quantity
        ,bdi.billing                        AS billing_for_product_code
        ,bdi.quantity                       AS quantity
        ,budi.license_user                  AS license_user
        ,budi.billing                       AS billing_usage_detail
        ,budi.quantity                      AS billing_usage_quantity
        ,pi.free_item1                      AS product_info_free_item1
    FROM
        billing_info bi
        INNER JOIN
            contract_info ci
        ON  bi.subscription_id = ci.subscription_id OR bi.subscription_id = CONCAT(ci.subscription_id,'G')
        INNER JOIN
            billing_detail_info bdi
        ON  bi.subscription_id              = bdi.subscription_id
        AND bi.target_month                 = bdi.target_month
        INNER JOIN
            product_info pi
        ON  bdi.product_code                = pi.product_code         
        LEFT JOIN
        billing_usage_detail_info budi
        ON bdi.subscription_id              = budi.subscription_id
        AND bdi.target_month                = budi.target_month
        AND bdi.product_code                = budi.product_code
    WHERE
        bi.target_month                     = %s
        AND COALESCE(ci.contract_code, '') <> ''
    ORDER BY
        bdi.subscription_id
        ,bdi.target_month
        ,bdi.product_code
        ,budi.license_user
"""

    # TODO 想定最大件数とメモリ消費量に応じてSSCursorの利用を検討する
    return BillingDetailInfo.objects.raw(sql, [target_month])


def query_illegality_contract_service():
    """
    サービスの状態が「Active」にも関わらず、サービス開始手配完了日時がNullの契約を抽出する
    :return:
    """

    return ContractServiceInfo.objects.filter(
        Q(state=ACTIVE)
        &
        Q(service_start_time__isnull=True)
    ).order_by('subscription_id')


def query_inactive_and_usage_after_cancel(now):
    """
    直近1時間以内に登録された従量データに紐づく契約サービスの状態が「Inactive」で、
    かつ解約手配完了日時が利用開始日時よりも前だった契約を抽出する
    :return:
    """
    sql = """
    SELECT
        csi.id                      AS id
        ,csi.subscription_id        AS subscription_id
        ,csi.product_code           AS product_code
        ,csi.service_cancel_time    AS service_cancel_time
        ,ui.start_time              AS start_time
    FROM
        usage_info ui
        INNER JOIN
            contract_service_info csi
        ON  ui.subscription_id      = csi.subscription_id
        AND ui.product_code         = csi.product_code
        AND ui.deleted              = FALSE
    WHERE
        ui.created_time            >= %s
        AND csi.state               = %s
        AND csi.service_cancel_time < ui.start_time
    ORDER BY
        csi.subscription_id
        ,csi.product_code
        ,ui.usage_id
"""

    past_time = now - timedelta(hours=1)
    return ContractServiceInfo.objects.raw(sql, [past_time, INACTIVE])


def query_no_subscription_in_contract_info(now):
    """
    対応する契約情報が存在しない従量データを抽出する
    :param now:バッチ処理実行日時
    :return:
    """
    sql = """
    SELECT
        ui.id                      AS id
        ,ui.subscription_id        AS subscription_id
        ,ui.usage_id               AS usage_id
    FROM
        usage_info ui
        LEFT JOIN
            contract_info ci
        ON  ui.subscription_id = ci.subscription_id
    WHERE
        ci.subscription_id IS NULL
        AND ui.created_time   >= %s
        AND ui.deleted         = FALSE
    ORDER BY
        ui.id
"""
    past_time = now - timedelta(hours=1)
    return UsageInfo.objects.raw(sql, [past_time])


def query_daily_usage_calculation_target(executed_date):
    """
    日次利用量計算の対象となる契約データを検索して返す
    :param executed_date:
    :rtype QuerySet
    :return: 日次利用量計算の対象となる契約データのクエリセット
    """
    the_day_before_batch_run_day = executed_date - timedelta(days=1)

    # 利用中でかつ手配が完了しているまたは解約済みだが今月解約したばかりの集計対象の契約サービスを検索する
    # お試し契約は集計対象にしない
    # 定額課金商品は集計対象にしない
    sql = """
        SELECT DISTINCT
            1 id,
            csi.subscription_id,
            csi.product_code,
            csi.service_start_time,
            csi.service_cancel_time
        FROM `contract_service_info` csi 
            INNER JOIN `product_info` pin 
            ON csi.product_code = pin.product_code
            INNER JOIN `contract_info` ci 
            ON ci.subscription_id = csi.subscription_id
        WHERE 
            ((state = 'active'
            AND csi.service_start_time IS NOT NULL
            AND DATE_FORMAT(DATE_ADD(csi.service_start_time, INTERVAL 9 HOUR), '%%Y%%m%%d') < %s
            AND (%s <= DATE_ADD(csi.service_cancel_time, INTERVAL 9 HOUR) OR (csi.service_cancel_time IS NULL)))
            OR (
            state = 'inactive'
            AND DATE_FORMAT(DATE_ADD(csi.service_cancel_time, INTERVAL 9 HOUR), '%%Y%%m') = %s
            ))
            AND pin.flat_rate IS FALSE
            AND ci.contract_code IS NOT NULL
            AND (csi.service_start_time <= csi.service_cancel_time OR csi.service_cancel_time IS NULL)
    """
    return ContractServiceInfo.objects.raw(sql, [executed_date.strftime("%Y%m%d"), the_day_before_batch_run_day,
                                                 the_day_before_batch_run_day.strftime("%Y%m")])


def get_tmp_dir():
    """
    バッチ処理用のTMPディレクトリの絶対パスを生成して返す
    :return:
    """

    cur_path = os.path.dirname(os.path.abspath(__file__))
    tmp_path = os.path.join(cur_path, 'tmp')
    tmp_path = os.path.abspath(tmp_path)
    return tmp_path
