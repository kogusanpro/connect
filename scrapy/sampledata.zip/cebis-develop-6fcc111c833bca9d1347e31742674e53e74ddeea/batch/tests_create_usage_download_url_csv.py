"""
<copyright file="tests_create_usage_download_url_csv.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.core.management import call_command, CommandError
from django.test import TestCase
from io import StringIO
from status.models import CsvBatchProcessInfo
from subscriptions.models import ContractInfo, UsageInfo, ProductInfo, ContractServiceInfo
import boto3
from datetime import datetime
from django.conf import settings
import random
import string
import os
import csv
import tempfile
from pytz import timezone
from lib.utils import DateTimeUtil
from subscriptions.factory_boy import ContractInfoFactory, UsageInfoFactory, \
     ContractServiceInfoFactory, ProductInfoFactory
import sys
from batch.services import get_tmp_dir

COMMAND = 'create_usage_download_url_csv'


class CreateUsageDownloadUrlCsvTests(TestCase):
    def setUp(self):
        self.request_id = self._get_randam_id()
        """
        # # システム環境変数で定義されているので、不必要です。
        # self.bucketname = os.environ[
        #     'S3_USAGE_DOWNLOAD_BUCKET'] = self._get_randam_id()
        """
        self.bucketname = os.environ['S3_USAGE_DOWNLOAD_BUCKET']
        self.filename = self._get_randam_id()
        self.s3 = boto3.client('s3', endpoint_url=settings.AWS_S3_ENDPOINT)
        """
        # # システム環境変数で定義されているので、create_bucketは不必要です。
        # self._create_bucket(bucketname=self.bucketname)
        """
        self._create_file_on_s3(
            bucketname=self.bucketname,
            filename=self.filename
        )

        CsvBatchProcessInfo.objects.create(
            request_id=self.request_id,
            requested_time=DateTimeUtil.utc_now_aware(),
            process_result='Processing',
        )

    def tearDown(self):
        """
        # # 開発環境でのみテストファイルを削除する。
        """
        if sys.argv[-1] == str('charlie.settings.ci'):
            CsvBatchProcessInfo.objects.all().delete()
            ContractInfo.objects.all().delete()
            UsageInfo.objects.all().delete()
            ProductInfo.objects.all().delete()
            ContractServiceInfo.objects.all().delete()
            self.s3.delete_object(Bucket=self.bucketname, Key=self.filename)
        else:
            pass

    def test_validation(self):
        """
        不正な入力パラメータでエラーが返ることのテスト
        """
        out = StringIO()
        with self.assertRaises(CommandError):
            call_command(
                COMMAND,
                stdout=out
            )
            call_command(
                COMMAND,
                'not_found_request_id',
                self.filename,
                '--from_created_date',
                '20180301',
                '--to_created_date',
                '20180331',
                '--time_zone',
                'UTC',
                stdout=out
            )
            call_command(
                COMMAND,
                self.request_id,
                'non_existance_name',
                '--from_created_date',
                '20180301',
                '--to_created_date',
                '20180331',
                '--time_zone',
                'UTC',
                stdout=out
            )

            call_command(
                COMMAND,
                self.request_id,
                self.filename,
                '--from_created_date',
                '20180301',
                '--to_created_date',
                '20180331',
                '--to_created_datetime',
                '20180331T235959Z',
                '--include_trial_data',
                stdout=out
            )
            call_command(
                COMMAND,
                self.request_id,
                self.filename,
                '--from_created_date',
                'from_created_date',
                '--to_created_date',
                '20180331',
                '--include_trial_data',
                stdout=out
            )
            call_command(
                COMMAND,
                self.request_id,
                self.filename,
                '--from_created_date',
                '20180301',
                '--to_created_date',
                'to_created_date',
                '--include_trial_data',
                stdout=out
            )
            call_command(
                COMMAND,
                self.request_id,
                self.filename,
                '--from_created_date',
                '20180302',
                '--to_created_date',
                '20180301',
                '--include_trial_data',
                stdout=out
            )

            call_command(
                COMMAND,
                self.request_id,
                self.filename,
                '--to_created_date',
                '20180301',
                '--include_trial_data',
                stdout=out
            )

            call_command(
                COMMAND,
                self.request_id,
                self.filename,
                '--time_zone',
                'UTC',
                '--from_created_datetime',
                '20180301T000000Z',
                '--to_created_datetime',
                '20180331T235959Z',
                '--include_trial_data',
                stdout=out
            )
            call_command(
                COMMAND,
                self.request_id,
                self.filename,
                '--from_created_datetime',
                'from_created_datetime',
                '--to_created_datetime',
                '20180331T235959Z',
                '--include_trial_data',
                stdout=out
            )
            call_command(
                COMMAND,
                self.request_id,
                self.filename,
                '--from_created_datetime',
                '20180301T000000Z',
                '--to_created_datetime',
                'to_created_datetime',
                '--include_trial_data',
                stdout=out
            )
            call_command(
                COMMAND,
                self.request_id,
                self.filename,
                '--from_created_datetime',
                '20180302T000000Z',
                '--to_created_datetime',
                '20180301T235959Z',
                '--include_trial_data',
                stdout=out
            )

            call_command(
                COMMAND,
                self.request_id,
                self.filename,
                '--to_created_datetime',
                '20180331T235959Z',
                '--include_trial_data',
                stdout=out
            )

            call_command(
                COMMAND,
                self.request_id,
                self.filename,
                '--include_trial_data',
                stdout=out
            )

    def test_range_filter_usage_info(self):
        """
        subscription_idとproduct_code無しで正常に範囲検索してCSVアップロード出来ることをテスト
        """

        contract = ContractInfoFactory(subscription_id=self.request_id)
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id1',
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id2',
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id3',
            created_time=datetime(2018, 3, 15, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id4',
            created_time=datetime(2018, 4, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id5',
            created_time=datetime(2018, 2, 28, 0, 0, 1, tzinfo=timezone('UTC')))

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180331',
            '--time_zone',
            'UTC',
            '--include_trial_data',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        data = []
        for row in csv.DictReader(lines):
            data.append(row['#usage_id'])

        assert data[0] == 'test_usage_id2'
        assert data[1] == 'test_usage_id3'
        assert data[2] == 'test_usage_id1'
        assert len(data) == 3
        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 3
        assert result.error_code == 'S'

    def test_range_filter_usage_info_with_subscription_id(self):
        """
        subscription_idのパラメータ付きで正常に範囲検索してCSVアップロード出来ることをテスト
        """
        contract0 = ContractInfoFactory(subscription_id='dpa_70015100')
        contract1 = ContractInfoFactory(subscription_id='dpa_70015101')
        UsageInfoFactory(
            subscription=contract0,
            usage_id='test_usage_id1',
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract0,
            usage_id='test_usage_id2',
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract1,
            usage_id='test_usage_id3',
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract1,
            usage_id='test_usage_id4',
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180401',
            '--time_zone',
            'UTC',
            '--include_trial_data',
            subscription_id='dpa_70015101',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        data = []
        for row in csv.DictReader(lines):
            data.append(row['#usage_id'])

        assert data[0] == 'test_usage_id4'
        assert data[1] == 'test_usage_id3'
        assert len(data) == 2
        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 2
        assert result.error_code == 'S'

    def test_range_filter_usage_info_with_product_code(self):
        """
        product_codeのパラメータ付きで正常に範囲検索してCSVアップロード出来ることをテスト
        """
        contract = ContractInfoFactory(subscription_id='dpa_70015100')
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id1',
            product_code='ABCD1000',
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id2',
            product_code='ABCD1000',
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id3',
            product_code='ABCD1001',
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id4',
            product_code='ABCD1001',
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180401',
            '--time_zone',
            'UTC',
            '--include_trial_data',
            product_code='ABCD1000',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        data = []
        for row in csv.DictReader(lines):
            data.append(row['#usage_id'])

        assert data[0] == 'test_usage_id2'
        assert data[1] == 'test_usage_id1'
        assert len(data) == 2
        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 2
        assert result.error_code == 'S'

    def test_range_filter_usage_info_with_subscription_id_product_code(self):
        """
        subscription_idとproduct_codeのパラメータ付きで正常に範囲検索してCSVアップロード出来ることをテスト
        """
        contract0 = ContractInfoFactory(subscription_id='dpa_70015100')
        contract1 = ContractInfoFactory(subscription_id='dpa_70015101')
        UsageInfoFactory(
            subscription=contract0,
            usage_id='test_usage_id1',
            product_code='ABCD1000',
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract1,
            usage_id='test_usage_id2',
            product_code='ABCD1000',
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract0,
            usage_id='test_usage_id3',
            product_code='ABCD1001',
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract1,
            usage_id='test_usage_id4',
            product_code='ABCD1001',
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180331',
            '--time_zone',
            'UTC',
            '--include_trial_data',
            subscription_id='dpa_70015101',
            product_code='ABCD1000',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        data = []
        for row in csv.DictReader(lines):
            data.append(row['#usage_id'])

        assert data[0] == 'test_usage_id2'
        assert len(data) == 1
        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 1
        assert result.error_code == 'S'

    def test_range_filter_usage_info_jst(self):
        """
        従量テーブルの範囲検索テスト(JST)
        """
        contract = ContractInfoFactory(subscription_id='dpa_70015100')
        # NG
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id1',
            created_time=datetime(2018, 3, 31, 14, 0, 0, tzinfo=timezone('UTC')))
        # NG
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id2',
            created_time=datetime(2018, 4, 28, 15, 0, 0, tzinfo=timezone('UTC')))
        # OK
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id3',
            created_time=datetime(2018, 3, 31, 15, 0, 0, tzinfo=timezone('UTC')))
        # OK
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id4',
            created_time=datetime(2018, 4, 28, 0, 0, 0, tzinfo=timezone('UTC')))
        # OK
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id5',
            created_time=datetime(2018, 4, 15, 0, 0, 0, tzinfo=timezone('UTC')))

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180401',
            '--to_created_date',
            '20180428',
            '--time_zone',
            'JST',
            '--include_trial_data',
            stdout=out)
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        data = []
        for row in csv.DictReader(lines):
            data.append(row['#usage_id'])

        assert data[0] == 'test_usage_id3'
        assert data[1] == 'test_usage_id5'
        assert data[2] == 'test_usage_id4'
        assert len(data) == 3

    def test_success_but_contract_code_null_or_blank(self):
        """
        契約連番がnull及び空文字列のデータは取得されていないことを確認
        """
        contract15 = ContractInfoFactory(subscription_id='dpa_70015',contract_code=None)
        contract16 = ContractInfoFactory(subscription_id='dpa_70016',contract_code='')
        contract17 = ContractInfoFactory(subscription_id='dpa_70017',contract_code='xxx')
        UsageInfoFactory(
            subscription=contract15,
            usage_id='test_usage_id_1',
            created_time=datetime(2018, 3, 15, 0, 0, 1, tzinfo=timezone('UTC')))

        UsageInfoFactory(
            subscription=contract15,
            usage_id='test_usage_id_2',
            created_time=datetime(2018, 3, 15, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract16,
            usage_id='test_usage_id_3',
            created_time=datetime(2018, 3, 15, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract16,
            usage_id='test_usage_id_4',
            created_time=datetime(2018, 3, 15, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract17,
            usage_id='test_usage_id_5',
            created_time=datetime(2018, 3, 15, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract17,
            usage_id='test_usage_id_6',
            created_time=datetime(2018, 3, 15, 0, 0, 10, tzinfo=timezone('UTC')))

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180314',
            '--to_created_date',
            '20180316',
            '--time_zone',
            'UTC',
            '--include_trial_data',
            stdout=out)

        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.process_result == 'Success'
        assert result.records == 2
        assert result.error_code == 'S'
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        data = []
        for row in csv.DictReader(lines):
            data.append(row['#usage_id'])
        assert data[0] == 'test_usage_id_5'
        assert data[1] == 'test_usage_id_6'
        assert len(data) == 2

    def test_success_with_count_zero(self):
        """
        usage_infoの検索データ結果件数が0件の場合でもCSVはアップロードされる
        """

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180801',
            '--to_created_date',
            '20180831',
            '--time_zone',
            'UTC',
            '--include_trial_data',
            stdout=out)

        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 0
        assert result.error_code == 'S'

        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        assert lines[0] ==\
            '"#usage_id","subscription_id","product_code","target_month",'\
            '"start_date_time","end_date_time","quantity","license_user",'\
            '"free_item1","free_item2","create_date_time","modified_date_time"'

    def test_fail_with_invalid_date(self):
        """
        ありえない日付が渡ってくるとfailすることをテスト
        """

        out = StringIO()
        with self.assertRaises(CommandError):
            call_command(
                COMMAND,
                self.request_id,
                self.filename,
                '--from_created_date',
                '20180801',
                '--to_created_date',
                '20180854',
                '--time_zone',
                'UTC',
                '--include_trial_data',
                stdout=out)

    def test_success_with_internal_calc(self):
        """
        internal_calcフラグがたった状態で正常に範囲検索してCSVアップロード出来ることをテスト
        """

        contract = ContractInfoFactory(subscription_id=self.request_id)
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id1',
            product_code='product1',
            free_item2='item21',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            end_time=datetime(2018, 3, 31, 0, 0, 0, tzinfo=timezone('UTC')),
            quantity=8,
            license_user='aaa',
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id2',
            product_code='product2',
            free_item2='item22',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            end_time=datetime(2018, 3, 31, 0, 0, 0, tzinfo=timezone('UTC')),
            quantity=8,
            license_user='aaa',
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id3',
            product_code='product3',
            free_item2='item23',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            end_time=datetime(2018, 3, 31, 0, 0, 0, tzinfo=timezone('UTC')),
            quantity=8,
            license_user=None,
            created_time=datetime(2018, 3, 15, 0, 0, 0, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id4',
            product_code='product4',
            free_item2='item24',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            end_time=datetime(2018, 3, 31, 0, 0, 0, tzinfo=timezone('UTC')),
            quantity=8,
            license_user='aaa',
            created_time=datetime(2018, 4, 2, 0, 0, 0, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id5',
            product_code='product5',
            free_item2='item25',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            end_time=datetime(2018, 3, 31, 0, 0, 0, tzinfo=timezone('UTC')),
            quantity=8,
            license_user='aaa',
            created_time=datetime(2018, 2, 28, 0, 0, 1, tzinfo=timezone('UTC')))

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180401',
            '--time_zone',
            'UTC',
            '--internal_calc',
            '--include_trial_data',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        subscription_ids = []
        product_codes = []
        free_items2 = []
        usage_ids = []
        for row in csv.DictReader(lines):
            subscription_ids.append(row['subscription_id'])
            product_codes.append(row['product_code'])
            free_items2.append(row['free_item2'])
            usage_ids.append(row['#usage_id'])

        assert subscription_ids[0] == self.request_id
        assert subscription_ids[1] == self.request_id+'G'
        assert subscription_ids[2] == self.request_id+'G'
        assert subscription_ids[3] == self.request_id+'G'
        assert subscription_ids[4] == self.request_id+'G'
        assert subscription_ids[5] == self.request_id+'G'
        assert subscription_ids[6] == self.request_id+'G'
        assert subscription_ids[7] == self.request_id
        assert subscription_ids[8] == self.request_id+'G'
        assert subscription_ids[9] == self.request_id+'G'
        assert subscription_ids[10] == self.request_id+'G'
        assert subscription_ids[11] == self.request_id+'G'
        assert subscription_ids[12] == self.request_id+'G'
        assert subscription_ids[13] == self.request_id+'G'
        assert subscription_ids[14] == self.request_id
        assert subscription_ids[15] == self.request_id+'G'
        assert subscription_ids[16] == self.request_id+'G'
        assert subscription_ids[17] == self.request_id+'G'
        assert subscription_ids[18] == self.request_id+'G'
        assert subscription_ids[19] == self.request_id+'G'
        assert subscription_ids[20] == self.request_id+'G'
        assert len(subscription_ids) == 21

        assert product_codes[0] == 'product2'
        assert product_codes[1] == 'product2C6'
        assert product_codes[2] == 'product2C7'
        assert product_codes[3] == 'product2C8'
        assert product_codes[4] == 'product2C9'
        assert product_codes[5] == 'product2C10'
        assert product_codes[6] == 'product2C11'
        assert product_codes[7] == 'product3'
        assert product_codes[8] == 'product3C6'
        assert product_codes[9] == 'product3C7'
        assert product_codes[10] == 'product3C8'
        assert product_codes[11] == 'product3C9'
        assert product_codes[12] == 'product3C10'
        assert product_codes[13] == 'product3C11'
        assert product_codes[14] == 'product1'
        assert product_codes[15] == 'product1C6'
        assert product_codes[16] == 'product1C7'
        assert product_codes[17] == 'product1C8'
        assert product_codes[18] == 'product1C9'
        assert product_codes[19] == 'product1C10'
        assert product_codes[20] == 'product1C11'
        assert len(product_codes) == 21

        assert free_items2[0] == 'item22'
        assert free_items2[1] == 'C6'
        assert free_items2[2] == 'C7'
        assert free_items2[3] == 'C8'
        assert free_items2[4] == 'C9'
        assert free_items2[5] == 'C10'
        assert free_items2[6] == 'C11'
        assert free_items2[7] == 'item23'
        assert free_items2[8] == 'C6'
        assert free_items2[9] == 'C7'
        assert free_items2[10] == 'C8'
        assert free_items2[11] == 'C9'
        assert free_items2[12] == 'C10'
        assert free_items2[13] == 'C11'
        assert free_items2[14] == 'item21'
        assert free_items2[15] == 'C6'
        assert free_items2[16] == 'C7'
        assert free_items2[17] == 'C8'
        assert free_items2[18] == 'C9'
        assert free_items2[19] == 'C10'
        assert free_items2[20] == 'C11'
        assert len(free_items2) == 21

        assert usage_ids[0] == 'test_usage_id2'
        assert usage_ids[1] == self.request_id+'G_product2C6_20180330T000000Z_20180331T000000Z_8_aaa'
        assert usage_ids[2] == self.request_id+'G_product2C7_20180330T000000Z_20180331T000000Z_8_aaa'
        assert usage_ids[3] == self.request_id+'G_product2C8_20180330T000000Z_20180331T000000Z_8_aaa'
        assert usage_ids[4] == self.request_id+'G_product2C9_20180330T000000Z_20180331T000000Z_8_aaa'
        assert usage_ids[5] == self.request_id+'G_product2C10_20180330T000000Z_20180331T000000Z_8_aaa'
        assert usage_ids[6] == self.request_id+'G_product2C11_20180330T000000Z_20180331T000000Z_8_aaa'
        assert usage_ids[7] == 'test_usage_id3'
        assert usage_ids[8] == self.request_id+'G_product3C6_20180330T000000Z_20180331T000000Z_8'
        assert usage_ids[9] == self.request_id+'G_product3C7_20180330T000000Z_20180331T000000Z_8'
        assert usage_ids[10] == self.request_id+'G_product3C8_20180330T000000Z_20180331T000000Z_8'
        assert usage_ids[11] == self.request_id+'G_product3C9_20180330T000000Z_20180331T000000Z_8'
        assert usage_ids[12] == self.request_id+'G_product3C10_20180330T000000Z_20180331T000000Z_8'
        assert usage_ids[13] == self.request_id+'G_product3C11_20180330T000000Z_20180331T000000Z_8'
        assert usage_ids[14] == 'test_usage_id1'
        assert usage_ids[15] == self.request_id+'G_product1C6_20180330T000000Z_20180331T000000Z_8_aaa'
        assert usage_ids[16] == self.request_id+'G_product1C7_20180330T000000Z_20180331T000000Z_8_aaa'
        assert usage_ids[17] == self.request_id+'G_product1C8_20180330T000000Z_20180331T000000Z_8_aaa'
        assert usage_ids[18] == self.request_id+'G_product1C9_20180330T000000Z_20180331T000000Z_8_aaa'
        assert usage_ids[19] == self.request_id+'G_product1C10_20180330T000000Z_20180331T000000Z_8_aaa'
        assert usage_ids[20] == self.request_id+'G_product1C11_20180330T000000Z_20180331T000000Z_8_aaa'
        assert len(usage_ids) == 21

        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 21
        assert result.error_code == 'S'

    def test_without_include_trial_data(self):
        """
        お試し契約期間従量データ有効化フラグが無効の際の正常系テスト
        """
        contract = ContractInfoFactory(subscription_id=self.request_id)
        product1 = ProductInfoFactory(product_code='prd01')
        product2 = ProductInfoFactory(product_code='prd02')
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id',
            product_code='prd02',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 15, 0, 0, 1, tzinfo=timezone('UTC'))
        )
        ContractServiceInfoFactory(
            subscription=contract,
            product_type='basic',
            service_start_time=datetime(2018, 3, 28, 0, 0, 1, tzinfo=timezone('UTC')),
            product_code=product1
        )
        ContractServiceInfoFactory(
            subscription=contract,
            product_type='basic',
            service_start_time=datetime(2018, 3, 28, 0, 0, 1, tzinfo=timezone('UTC')),
            product_code=product2
        )

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180331',
            '--time_zone',
            'UTC',
            '--include_trial_data',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        data = []
        for row in csv.DictReader(lines):
            data.append(row['#usage_id'])

        assert data[0] == 'test_usage_id'
        assert len(data) == 1
        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 1
        assert result.error_code == 'S'

    def test_without_include_trial_data_and_product_type(self):
        """
        お試し契約期間従量データ有効化フラグが無効の際にproduct_typeがbasicでないデータは抽出されない
        """
        contract = ContractInfoFactory(subscription_id=self.request_id)
        product1 = ProductInfoFactory(product_code='prd01')
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 15, 0, 0, 1, tzinfo=timezone('UTC'))
        )
        ContractServiceInfoFactory(
            subscription=contract,
            product_type='option',
            service_start_time=datetime(2018, 3, 28, 0, 0, 1, tzinfo=timezone('UTC')),
            product_code=product1
        )

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180331',
            '--time_zone',
            'UTC',
            '--include_trial_data',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )

        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 1
        assert result.error_code == 'S'

        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        assert lines[0] ==\
            '"#usage_id","subscription_id","product_code","target_month",'\
            '"start_date_time","end_date_time","quantity","license_user",'\
            '"free_item1","free_item2","create_date_time","modified_date_time"'

    def test_without_include_trial_data_and_service_start_time(self):
        """
        お試し契約期間従量データ有効化フラグが無効の際に契約情報サービステーブルのservice_start_timeが重量テーブルのstart_timeより古い
        """
        contract = ContractInfoFactory(subscription_id=self.request_id)
        product1 = ProductInfoFactory(product_code='prd01')
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 15, 0, 0, 1, tzinfo=timezone('UTC'))
        )
        ContractServiceInfoFactory(
            subscription=contract,
            product_type='basic',
            service_start_time=datetime(2018, 3, 31, 0, 0, 1, tzinfo=timezone('UTC')),
            product_code=product1
        )

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180331',
            '--time_zone',
            'UTC',
            '--include_trial_data',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )

        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 1
        assert result.error_code == 'S'

        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        assert lines[0] ==\
            '"#usage_id","subscription_id","product_code","target_month",'\
            '"start_date_time","end_date_time","quantity","license_user",'\
            '"free_item1","free_item2","create_date_time","modified_date_time"'

    def test_without_include_trial_data_and_no_service_data(self):
        """
        お試し契約期間従量データ有効化フラグが無効の際に契約情報サービスが存在しなければデータは抽出されない
        """
        contract = ContractInfoFactory(subscription_id=self.request_id)
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 15, 0, 0, 1, tzinfo=timezone('UTC'))
        )

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180331',
            '--time_zone',
            'UTC',
            '--include_trial_data',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )

        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 1
        assert result.error_code == 'S'

        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        assert lines[0] ==\
            '"#usage_id","subscription_id","product_code","target_month",'\
            '"start_date_time","end_date_time","quantity","license_user",'\
            '"free_item1","free_item2","create_date_time","modified_date_time"'

    def test_without_include_trial_data_and_delete_flg(self):
        """
        お試し契約期間従量データ有効化フラグが無効の際に重量データの削除フラグがONであればデータは抽出されない
        """
        contract = ContractInfoFactory(subscription_id=self.request_id)
        product1 = ProductInfoFactory(product_code='prd01')
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id',
            deleted=True,
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 15, 0, 0, 1, tzinfo=timezone('UTC'))
        )
        ContractServiceInfoFactory(
            subscription=contract,
            product_type='basic',
            service_start_time=datetime(2018, 3, 28, 0, 0, 1, tzinfo=timezone('UTC')),
            product_code=product1
        )

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180331',
            '--time_zone',
            'UTC',
            '--include_trial_data',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )

        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 0
        assert result.error_code == 'S'

        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        assert lines[0] ==\
            '"#usage_id","subscription_id","product_code","target_month",'\
            '"start_date_time","end_date_time","quantity","license_user",'\
            '"free_item1","free_item2","create_date_time","modified_date_time"'

    def test_without_include_trial_data_and_subscription_id(self):
        """
        お試し契約期間従量データ有効化フラグが無効の際にsubscription_idのパラメータ付きで正常に範囲検索してCSVアップロード出来ることをテスト
        """
        contract0 = ContractInfoFactory(subscription_id='dpa_70015100')
        contract1 = ContractInfoFactory(subscription_id='dpa_70015101')
        product = ProductInfoFactory(product_code='prd01')
        UsageInfoFactory(
            subscription=contract0,
            usage_id='test_usage_id1',
            product_code='prd01',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract0,
            usage_id='test_usage_id2',
            product_code='prd01',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract1,
            usage_id='test_usage_id3',
            product_code='prd01',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract1,
            usage_id='test_usage_id4',
            product_code='prd01',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        ContractServiceInfoFactory(
            subscription=contract0,
            product_type='basic',
            service_start_time=datetime(2018, 3, 28, 0, 0, 1, tzinfo=timezone('UTC')),
            product_code=product
        )
        ContractServiceInfoFactory(
            subscription=contract1,
            product_type='basic',
            service_start_time=datetime(2018, 3, 28, 0, 0, 1, tzinfo=timezone('UTC')),
            product_code=product
        )

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180331',
            '--time_zone',
            'UTC',
            '--subscription_id',
            'dpa_70015101',
            '--include_trial_data',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        data = []
        for row in csv.DictReader(lines):
            data.append(row['#usage_id'])

        assert data[0] == 'test_usage_id4'
        assert data[1] == 'test_usage_id3'
        assert len(data) == 2
        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 2
        assert result.error_code == 'S'

    def test_without_include_trial_data_and_product_code(self):
        """
        お試し契約期間従量データ有効化フラグが無効の際にproduct_codeのパラメータ付きで正常に範囲検索してCSVアップロード出来ることをテスト
        """
        contract = ContractInfoFactory(subscription_id='dpa_70015100')
        product = ProductInfoFactory(product_code='ABCD1000')
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id1',
            product_code='ABCD1000',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id2',
            product_code='ABCD1000',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id3',
            product_code='ABCD1001',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id4',
            product_code='ABCD1001',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        ContractServiceInfoFactory(
            subscription=contract,
            product_type='basic',
            service_start_time=datetime(2018, 3, 28, 0, 0, 1, tzinfo=timezone('UTC')),
            product_code=product
        )

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180401',
            '--time_zone',
            'UTC',
            '--product_code',
            'ABCD1000',
            '--include_trial_data',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        data = []
        for row in csv.DictReader(lines):
            data.append(row['#usage_id'])

        assert data[0] == 'test_usage_id2'
        assert data[1] == 'test_usage_id1'
        assert len(data) == 2
        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 2
        assert result.error_code == 'S'

    def test_without_include_trial_data_and_subscription_id_product_code(self):
        """
        お試し契約期間従量データ有効化フラグが無効の際にsubscription_idとproduct_codeのパラメータ付きで正常に範囲検索してCSVアップロード出来ることをテスト
        """
        contract0 = ContractInfoFactory(subscription_id='dpa_70015100')
        contract1 = ContractInfoFactory(subscription_id='dpa_70015101')
        product0 = ProductInfoFactory(product_code='ABCD1000')
        product1 = ProductInfoFactory(product_code='ABCD1001')
        UsageInfoFactory(
            subscription=contract0,
            usage_id='test_usage_id1',
            product_code='ABCD1000',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract1,
            usage_id='test_usage_id2',
            product_code='ABCD1000',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract0,
            usage_id='test_usage_id3',
            product_code='ABCD1001',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract1,
            usage_id='test_usage_id4',
            product_code='ABCD1001',
            start_time=datetime(2018, 3, 30, 0, 0, 0, tzinfo=timezone('UTC')),
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        ContractServiceInfoFactory(
            subscription=contract0,
            product_type='basic',
            service_start_time=datetime(2018, 3, 28, 0, 0, 1, tzinfo=timezone('UTC')),
            product_code=product0
        )
        ContractServiceInfoFactory(
            subscription=contract1,
            product_type='basic',
            service_start_time=datetime(2018, 3, 28, 0, 0, 1, tzinfo=timezone('UTC')),
            product_code=product1
        )

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180331',
            '--time_zone',
            'UTC',
            '--subscription_id',
            'dpa_70015101',
            '--product_code',
            'ABCD1001',
            '--include_trial_data',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        data = []
        for row in csv.DictReader(lines):
            data.append(row['#usage_id'])

        assert data[0] == 'test_usage_id4'
        assert len(data) == 1
        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 1
        assert result.error_code == 'S'

    def test_from_created_date_to_created_date(self):
        """
        from_created_dateとto_created_dateを入力で正常に範囲検索してCSVアップロード出来ることをテスト
        """

        contract = ContractInfoFactory(subscription_id=self.request_id)
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id1',
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id2',
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id3',
            created_time=datetime(2018, 3, 15, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id4',
            created_time=datetime(2018, 4, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id5',
            created_time=datetime(2018, 2, 28, 0, 0, 1, tzinfo=timezone('UTC')))

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_date',
            '20180301',
            '--to_created_date',
            '20180331',
            '--time_zone',
            'UTC',
            '--include_trial_data',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        data = []
        for row in csv.DictReader(lines):
            data.append(row['#usage_id'])

        assert data[0] == 'test_usage_id2'
        assert data[1] == 'test_usage_id3'
        assert data[2] == 'test_usage_id1'
        assert len(data) == 3
        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 3
        assert result.error_code == 'S'

    def test_from_created_datetime_to_created_datetime(self):
        """
        from_created_dateとto_created_dateを入力で正常に範囲検索してCSVアップロード出来ることをテスト
        """

        contract = ContractInfoFactory(subscription_id=self.request_id)
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id1',
            created_time=datetime(2018, 3, 31, 23, 59, 58, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id2',
            created_time=datetime(2018, 3, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id3',
            created_time=datetime(2018, 3, 15, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id4',
            created_time=datetime(2018, 4, 1, 0, 0, 1, tzinfo=timezone('UTC')))
        UsageInfoFactory(
            subscription=contract,
            usage_id='test_usage_id5',
            created_time=datetime(2018, 2, 28, 0, 0, 1, tzinfo=timezone('UTC')))

        out = StringIO()
        call_command(
            COMMAND,
            self.request_id,
            self.filename,
            '--from_created_datetime',
            '20180301T000000Z',
            '--to_created_datetime',
            '20180331T235959Z',
            '--include_trial_data',
            stdout=out
        )
        object = self.s3.get_object(
            Bucket=self.bucketname,
            Key=self.filename,
        )
        lines = object['Body'].read().decode('utf-8').split()
        data = []
        for row in csv.DictReader(lines):
            data.append(row['#usage_id'])

        assert data[0] == 'test_usage_id2'
        assert data[1] == 'test_usage_id3'
        assert data[2] == 'test_usage_id1'
        assert len(data) == 3
        result = CsvBatchProcessInfo.objects.get(
            request_id=self.request_id
        )
        assert result.content_md5 is not None
        assert result.process_result == 'Success'
        assert result.records == 3
        assert result.error_code == 'S'

    def _get_randam_id(self):
        return ''.join([
            random.choice('%s%s' % (string.ascii_letters, string.digits))
            for i in range(10)
        ])

    """
    # # システム環境変数で定義されているので、create_bucketは不必要です。
    # def _create_bucket(self, bucketname):
    #     self.s3.create_bucket(
    #         ACL='private',
    #         Bucket=self.bucketname,
    #         CreateBucketConfiguration={
    #             'LocationConstraint': 'ap-northeast-1'
    #         },
    #     )
    """

    def _create_file_on_s3(self, bucketname, filename):
        temp_csv_file = tempfile.NamedTemporaryFile(dir=get_tmp_dir(), delete=False)
        with open(temp_csv_file.name, 'a') as fp:
            fp.close()
            s3 = boto3.resource('s3', endpoint_url=settings.AWS_S3_ENDPOINT)
            s3.meta.client.upload_file(
                temp_csv_file.name,
                bucketname,
                filename
            )
        temp_csv_file.flush()
