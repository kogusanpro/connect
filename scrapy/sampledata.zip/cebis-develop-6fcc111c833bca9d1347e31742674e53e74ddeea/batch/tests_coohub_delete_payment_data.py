"""
<copyright input_file_path="tests_coohub_delete_payment_data.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2020-2020. All rights reserved.
</copyright>
"""
from django.core.management import call_command, CommandError
from django.test import TestCase
from rest_framework import status
from unittest import mock
import os
import sys
import json

COMMAND = 'coohub_delete_payment_data'


@mock.patch('lib.utils.ServerUtil.get_k5_response')
class CoohubDeletePaymentDataTests(TestCase):
    def setUp(self):
        os.environ['K5_CUSTOMER_ID'] = 'dummy0000000000'
        os.environ['K5_API_ENDPOINT'] = 'https://business-support-k5.jp-east-1.paas.cloud.global.fujitsu.com'
        os.environ['K5_CREDIT_URL'] = '/API/v2/api/credit'

    def tearDown(self):
        if sys.argv[-1] == str('charlie.settings.ci'):
            pass
        else:
            pass

    def test_validation(self, mock):
        """
        不正な入力パラメータでエラーが返ることのテスト
        """
        with self.assertRaises(CommandError) as cm:
            call_command(
                COMMAND,
                '--executed_date',
                'executed_date',
            )
        self.assertIsInstance(cm.exception, CommandError)
        self.assertEqual(cm.exception.args[0], "executed_date was invalid format in this request body")
        self.assertEqual(mock.call_count, 0)

    def test_prev_specific_date_ymd_12(self, mock):
        """
        日本時間の毎月12日、正常に実行することのテスト
        """

        def my_side_effect(url: str, params: dict, method: str, allow_token_time_out_minutes: int,
                           data: dict, k5_tenant: dict):
            if method == "GET":
                return MockResponse(
                    {
                        "result_information": {
                            "result": "OK"
                        },
                        "charge_adjustment_information_list": [
                            {
                                "tenant_id": "fx28845",
                                "target_month": "201712",
                                "credit_id": "000000000000400",
                                "billing_to_id": "000000000000303",
                                "credit_charge": 5000
                            }
                        ]
                    },
                    status.HTTP_200_OK
                )
            elif method == "POST":
                return MockResponse(
                    {
                        'result_information': {
                            "result": "OK"
                        },
                        'credit_information_delete_list': [
                            {
                                'credit_id': '000000000000400'
                            }
                        ]
                    },
                    status.HTTP_200_OK
                )
            else:
                pass
        mock.side_effect = my_side_effect
        call_command(
            COMMAND,
            '--executed_date',
            '20180112',
        )
        mock.assert_any_call(
            url=os.environ['K5_API_ENDPOINT'] + os.environ['K5_CREDIT_URL'],
            params={
                'customer_id': 'dummy0000000000',
                'business_date': '20171231'
            },
            method='GET',
            allow_token_time_out_minutes=5,
            data=dict(),
            k5_tenant=self.get_k5_tenant()
        )
        mock.assert_any_call(
            url=os.environ['K5_API_ENDPOINT'] + os.environ['K5_CREDIT_URL'],
            params=dict(),
            method='POST',
            allow_token_time_out_minutes=5,
            data=json.dumps({
                'credit_information_delete_list': [
                    {
                        'credit_id': '000000000000400'
                    }
                ]
            }),
            k5_tenant=self.get_k5_tenant()
        )
        self.assertEqual(mock.call_count, 2)

    def test_prev_specific_date_ymd_end_month(self, mock):
        """
        日本時間の毎月月末、正常に実行することのテスト
        """

        def my_side_effect(url: str, params: dict, method: str, allow_token_time_out_minutes: int,
                           data: dict, k5_tenant: dict):
            if method == "GET":
                return MockResponse(
                    {
                        "result_information": {
                            "result": "OK"
                        },
                        "charge_adjustment_information_list": [
                            {
                                "tenant_id": "fx28845",
                                "target_month": "201612",
                                "credit_id": "000000000000400",
                                "billing_to_id": "000000000000303",
                                "credit_charge": 5000
                            }
                        ]
                    },
                    status.HTTP_200_OK
                )
            elif method == "POST":
                return MockResponse(
                    {
                        'result_information': {
                            "result": "OK"
                        },
                        'credit_information_delete_list': [
                            {
                                'credit_id': '000000000000400'
                            }
                        ]
                    },
                    status.HTTP_200_OK
                )
            else:
                pass
        mock.side_effect = my_side_effect
        call_command(
            COMMAND,
            '--executed_date',
            '20180131',
        )
        mock.assert_any_call(
            url=os.environ['K5_API_ENDPOINT'] + os.environ['K5_CREDIT_URL'],
            params={
                'customer_id': 'dummy0000000000',
                'business_date': '20161231'
            },
            method='GET',
            allow_token_time_out_minutes=5,
            data=dict(),
            k5_tenant=self.get_k5_tenant()
        )
        mock.assert_any_call(
            url=os.environ['K5_API_ENDPOINT'] + os.environ['K5_CREDIT_URL'],
            params=dict(),
            method='POST',
            allow_token_time_out_minutes=5,
            data=json.dumps({
                'credit_information_delete_list': [
                    {
                        'credit_id': '000000000000400'
                    }
                ]
            }),
            k5_tenant=self.get_k5_tenant()
        )
        self.assertEqual(mock.call_count, 2)

    def test_delete_payment_data_1200(self, mock):
        """
        1000件以上で、正常に実行することのテスト
        """

        def my_side_effect(url: str, params: dict, method: str, allow_token_time_out_minutes: int,
                           data: dict, k5_tenant: dict):
            if method == "GET":
                return MockResponse(
                    {
                        "result_information": {
                            "result": "OK"
                        },
                        "charge_adjustment_information_list": [
                            {
                                "tenant_id": "fx28845",
                                "target_month": "201711",
                                "credit_id": str(40000000000000 + i),
                                "billing_to_id": "000000000000303",
                                "credit_charge": 5000
                            } for i in range(0, 1200)
                        ]
                    },
                    status.HTTP_200_OK
                )
            elif method == "POST":
                if len(data) < 1000:
                    return MockResponse(
                        {
                            'result_information': {
                                "result": "OK"
                            },
                            'credit_information_delete_list': [
                                {
                                    "credit_id": str(40000000000000 + i)
                                } for i in range(1000, 1200)
                            ]
                        },
                        status.HTTP_200_OK
                    )
                else:
                    return MockResponse(
                        {
                            'result_information': {
                                "result": "OK"
                            },
                            'credit_information_delete_list': [
                                {
                                    "credit_id": str(40000000000000 + i)
                                } for i in range(0, 1000)
                            ]
                        },
                        status.HTTP_200_OK
                    )
            else:
                pass

        mock.side_effect = my_side_effect
        call_command(
            COMMAND,
            '--executed_date',
            '20171212',
        )
        mock.assert_any_call(
            url='https://business-support-k5.jp-east-1.paas.cloud.global.fujitsu.com'
                '/API/v2/api/credit',
            params={
                'customer_id': 'dummy0000000000',
                'business_date': '20171130'
            },
            method='GET',
            allow_token_time_out_minutes=5,
            data=dict(),
            k5_tenant=self.get_k5_tenant()
        )
        mock.assert_any_call(
            url='https://business-support-k5.jp-east-1.paas.cloud.global.fujitsu.com'
                '/API/v2/api/credit',
            params=dict(),
            method='POST',
            allow_token_time_out_minutes=5,
            data=json.dumps({
                'credit_information_delete_list': [
                    {
                        'credit_id': str(40000000000000 + i)
                    } for i in range(0, 1000)
                ]
            }),
            k5_tenant=self.get_k5_tenant()
        )
        mock.assert_any_call(
            url='https://business-support-k5.jp-east-1.paas.cloud.global.fujitsu.com'
                '/API/v2/api/credit',
            params=dict(),
            method='POST',
            allow_token_time_out_minutes=5,
            data=json.dumps({
                'credit_information_delete_list': [
                    {
                        'credit_id': str(40000000000000 + i)
                    } for i in range(1000, 1200)
                ]
            }),
            k5_tenant=self.get_k5_tenant()
        )
        self.assertEqual(mock.call_count, 3)

    def test_credit_get_result_ng(self, mock):
        """
        債権取得に失敗した場合のテスト
        """

        def my_side_effect(url: str, params: dict, method: str, allow_token_time_out_minutes: int,
                           data: dict, k5_tenant: dict):
            if method == "GET":
                return MockResponse(
                    {
                        "result_information": {
                            "result": "NG",
                            "detailed_result": "No data retrieved."
                        },
                        "charge_adjustment_information_list": []
                    },
                    status.HTTP_200_OK
                )
            else:
                pass
        mock.side_effect = my_side_effect
        with self.assertRaises(SystemExit) as se:
            call_command(
                COMMAND,
                '--executed_date',
                '20180112',
            )
        self.assertEqual(se.exception.code, 1)
        self.assertIsInstance(se.exception, SystemExit)
        mock.assert_any_call(
            url=os.environ['K5_API_ENDPOINT'] + os.environ['K5_CREDIT_URL'],
            params={
                'customer_id': 'dummy0000000000',
                'business_date': '20171231'
            },
            method='GET',
            allow_token_time_out_minutes=5,
            data=dict(),
            k5_tenant=self.get_k5_tenant()
        )
        self.assertEqual(mock.call_count, 1)

    def test_credit_get_not_retrieved(self, mock):
        """
        債権取得に失敗した場合のテスト
        """

        def my_side_effect(url: str, params: dict, method: str, allow_token_time_out_minutes: int,
                           data: dict, k5_tenant: dict):
            if method == "GET":
                return MockResponse(
                    {
                        "result_information": {
                            "result": "NG",
                            "detailed_result": "No data retrieved."
                        },
                        "charge_adjustment_information_list": []
                    },
                    status.HTTP_404_NOT_FOUND
                )
            else:
                pass
        mock.side_effect = my_side_effect
        with self.assertRaises(SystemExit) as se:
            call_command(
                COMMAND,
                '--executed_date',
                '20180112',
            )
        self.assertEqual(se.exception.code, 1)
        self.assertIsInstance(se.exception, SystemExit)
        mock.assert_any_call(
            url=os.environ['K5_API_ENDPOINT'] + os.environ['K5_CREDIT_URL'],
            params={
                'customer_id': 'dummy0000000000',
                'business_date': '20171231'
            },
            method='GET',
            allow_token_time_out_minutes=5,
            data=dict(),
            k5_tenant=self.get_k5_tenant()
        )
        self.assertEqual(mock.call_count, 1)

    def test_credit_delete_result_ng(self, mock):
        """
        債権削除に失敗した場合のテスト
        """

        def my_side_effect(url: str, params: dict, method: str, allow_token_time_out_minutes: int,
                           data: dict, k5_tenant: dict):
            if method == "GET":
                return MockResponse(
                    {
                        "result_information": {
                            "result": "OK"
                        },
                        "charge_adjustment_information_list": [
                            {
                                "tenant_id": "fx28845",
                                "target_month": "201712",
                                "credit_id": "000000000000400",
                                "billing_to_id": "000000000000303",
                                "credit_charge": 5000
                            }
                        ]
                    },
                    status.HTTP_200_OK
                )
            elif method == "POST":
                return MockResponse(
                    {
                        "result_information": {
                            "result": "NG",
                            "detailed_result": "Delete unsuccessful."
                        },
                        "creditdetail_information_delete_list": []
                    },
                    status.HTTP_200_OK
                )
            else:
                pass
        mock.side_effect = my_side_effect
        call_command(
            COMMAND,
            '--executed_date',
            '20180112',
        )
        mock.assert_any_call(
            url=os.environ['K5_API_ENDPOINT'] + os.environ['K5_CREDIT_URL'],
            params={
                'customer_id': 'dummy0000000000',
                'business_date': '20171231'
            },
            method='GET',
            allow_token_time_out_minutes=5,
            data=dict(),
            k5_tenant=self.get_k5_tenant()
        )
        mock.assert_any_call(
            url=os.environ['K5_API_ENDPOINT'] + os.environ['K5_CREDIT_URL'],
            params=dict(),
            method='POST',
            allow_token_time_out_minutes=5,
            data=json.dumps({
                'credit_information_delete_list': [
                    {
                        'credit_id': '000000000000400'
                    }
                ]
            }),
            k5_tenant=self.get_k5_tenant()
        )
        self.assertEqual(mock.call_count, 2)

    def test_credit_delete_unsuccessful(self, mock):
        """
        債権削除に失敗した場合のテスト
        """

        def my_side_effect(url: str, params: dict, method: str, allow_token_time_out_minutes: int,
                           data: dict, k5_tenant: dict):
            if method == "GET":
                return MockResponse(
                    {
                        "result_information": {
                            "result": "OK"
                        },
                        "charge_adjustment_information_list": [
                            {
                                "tenant_id": "fx28845",
                                "target_month": "201712",
                                "credit_id": "000000000000400",
                                "billing_to_id": "000000000000303",
                                "credit_charge": 5000
                            }
                        ]
                    },
                    status.HTTP_200_OK
                )
            elif method == "POST":
                return MockResponse(
                    {
                        "result_information": {
                            "result": "NG",
                            "detailed_result": "Delete unsuccessful."
                        },
                        "creditdetail_information_delete_list": []
                    },
                    status.HTTP_404_NOT_FOUND
                )
            else:
                pass
        mock.side_effect = my_side_effect
        call_command(
            COMMAND,
            '--executed_date',
            '20180112',
        )
        mock.assert_any_call(
            url=os.environ['K5_API_ENDPOINT'] + os.environ['K5_CREDIT_URL'],
            params={
                'customer_id': 'dummy0000000000',
                'business_date': '20171231'
            },
            method='GET',
            allow_token_time_out_minutes=5,
            data=dict(),
            k5_tenant=self.get_k5_tenant()
        )
        mock.assert_any_call(
            url=os.environ['K5_API_ENDPOINT'] + os.environ['K5_CREDIT_URL'],
            params=dict(),
            method='POST',
            allow_token_time_out_minutes=5,
            data=json.dumps({
                'credit_information_delete_list': [
                    {
                        'credit_id': '000000000000400'
                    }
                ]
            }),
            k5_tenant=self.get_k5_tenant()
        )
        self.assertEqual(mock.call_count, 2)

    def get_k5_tenant(self):
        return {
            'client_id': 'fx28845',
            'client_secret': 'P@ssw0rd',
            'grant_type': 'client_credentials',
            'scope': 'service_contract',
            'auth_host': 'https://auth-api.jp-east-1.paas.cloud.global.fujitsu.com',
            'auth_url': '/API/oauth2/token/',
            'standard_value': 19000101
        }


class MockResponse:
    def __init__(self, json_data, status_code):
        self.json_data = json_data
        self.status_code = status_code

    def json(self):
        return self.json_data
