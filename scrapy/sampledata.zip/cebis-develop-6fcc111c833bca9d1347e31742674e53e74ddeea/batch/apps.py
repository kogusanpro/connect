"""
<copyright file="app.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.apps import AppConfig


class BatchConfig(AppConfig):
    name = 'batch'
