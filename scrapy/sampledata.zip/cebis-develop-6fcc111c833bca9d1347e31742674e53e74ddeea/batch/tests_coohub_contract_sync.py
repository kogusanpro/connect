"""
<copyright file="tests_coohub_contract_sync.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""
from io import StringIO
from unittest import mock
from unittest.mock import call
from rest_framework import status
from django.core.management import call_command
from django.test import TestCase
import sys
import os
import django


COMMAND = 'coohub_sync_contract'

@mock.patch('lib.utils.ServerUtil.get_k5_response')
@mock.patch('lib.utils.ServerUtil.get_cebis_response')
@mock.patch('logging.Logger.info')
class CoohubContractSyncTests(TestCase):
    # set the default settings file
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "charlie.settings.ci")
    django.setup()

    def setUp(self):
        os.environ['K5_CUSTOMER_ID'] = "dummy0000000000"
        os.environ['CEBIS_API_ENDPOINT'] = "https://cebis-stg.fujixerox.co.jp/spf/api/v1"
        os.environ['CEBIS_SUBSCRIPTIONS_URL'] = "/subscriptions"
        os.environ['CEBIS_CALCULATION_SYSTEM_API_KEY'] = "13746a30-cfa4-42dd-82cd-59ab66ae039e"
        os.environ['K5_API_ENDPOINT'] = "https://business-support-k5.jp-east-1.paas.cloud.global.fujitsu.com"
        os.environ['K5_PRICE_MASTER_URL'] = "/API/v2/api/servicepricemaster"
        os.environ['K5_BASIC_CONTRACT_URL'] = "/API/v2/api/basiccontract"
        os.environ['K5_SERVICE_CONTRACT_URL'] = "/API/v2/api/servicecontracts"
        os.environ['ENTRY_ID'] = "fxy7726"
        os.environ['ADMINISTRATION_NUMBER'] = "1"
        os.environ['CLASSIFICATION_OF_CONTRACT'] = "0"


    def tearDown(self):
        if sys.argv[-1] == str('charlie.settings.ci'):
            pass
        else:
            pass

    def test_01_contract_sync_add(self, mock_info, mock_cebis, mock_k5):
        """
        cebisでの契約新規する場合
        """

        def my_side_effect_cebis(url: str, params: dict, method: str,
                            data: dict, api_key: str):
            if method == "GET":
                return MockResponse(
                    {
                        "success": "true",
                        "count": 4,
                        "time_stamp": "20200514T014330Z",
                        "error_status": "null",
                        "error_message": "null",
                        "subscriptions": [
                            {"subscription_id": "20200415SDER0002", "subscription_number": None, "opco_code": "FX", "spf_tenant_id": "ST1717B6B5C81",
                                "closing_day": -1, "created_time": "20200415T011927Z", "updated_time": "20200513T013857Z",
                                "products": [{"product_code": "MIC10101", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013856Z", "service_update_time": "null",
                                                "service_cancel_time": "null"}]},
                            {"subscription_id": "20200415SDER0001", "subscription_number": "", "opco_code": "FX", "spf_tenant_id": "ST1717B6841F4",
                                "closing_day": -1, "created_time": "20200415T011604Z", "updated_time": "20200513T013856Z",
                                "products": [{"product_code": "MIC10101", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013855Z", "service_update_time": "null",
                                                "service_cancel_time": "null"}]},
                            {"subscription_id": "20200415SDER0002G", "subscription_number": "1", "opco_code": "FX", "spf_tenant_id": "ST1717B6B5C81",
                                "closing_day": -1, "created_time": "20200415T011927Z", "updated_time": "20200513T013857Z",
                                "products": [{"product_code": "MIC10101C6", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013856Z", "service_update_time": "null",
                                                "service_cancel_time": "null"},
                                            {"product_code": "MIC10101C7", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013856Z", "service_update_time": "null",
                                                "service_cancel_time": "null"},
                                            {"product_code": "MIC10101C8", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013856Z", "service_update_time": "null",
                                                "service_cancel_time": "null"},
                                            {"product_code": "MIC10101C9", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013856Z", "service_update_time": "null",
                                                "service_cancel_time": "null"},
                                            {"product_code": "MIC10101C10", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013856Z", "service_update_time": "null",
                                                "service_cancel_time": "null"},
                                            {"product_code": "MIC10101C11", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013856Z", "service_update_time": "null",
                                                "service_cancel_time": "null"}]},
                            {"subscription_id": "20200415SDER0001G", "subscription_number": "1", "opco_code": "FX", "spf_tenant_id": "ST1717B6841F4",
                                "closing_day": -1, "created_time": "20200415T011604Z", "updated_time": "20200513T013856Z",
                                "products": [{"product_code": "MIC10101C6", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013855Z", "service_update_time": "null",
                                                "service_cancel_time": "null"},
                                            {"product_code": "MIC10101C7", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013855Z", "service_update_time": "null",
                                                "service_cancel_time": "null"},
                                            {"product_code": "MIC10101C8", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013855Z", "service_update_time": "null",
                                                "service_cancel_time": "null"},
                                            {"product_code": "MIC10101C9", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013855Z", "service_update_time": "null",
                                                "service_cancel_time": "null"},
                                            {"product_code": "MIC10101C10", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013855Z", "service_update_time": "null",
                                                "service_cancel_time": "null"},
                                            {"product_code": "MIC10101C11", "product_type": "basic", "state": "active",
                                                "license_users": "null", "license_quantity": 1,
                                                "service_start_time": "20200513T013855Z", "service_update_time": "null",
                                                "service_cancel_time": "null"}]}
                        ]
                    },
                    status.HTTP_200_OK
                )

        def my_side_effect_k51(url: str, params: dict, method: str, allow_token_time_out_minutes: int,
                           data: dict, k5_tenant: dict):
            if method == "GET":
                return MockResponse(
                    {
                    },
                    status.HTTP_200_OK
                )
        mock_cebis.side_effect = my_side_effect_cebis
        mock_k5.side_effect = my_side_effect_k51
        out = StringIO()
        call_command(COMMAND, executed_date="20200518", stdout=out)
        mock_info.assert_has_calls([call('Contract synchronization completed ...')])

class MockResponse:
    def __init__(self, json_data, status_code):
        self.json_data = json_data
        self.status_code = status_code

    def json(self):
        return self.json_data