"""
<copyright file="csv_file_pool.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import csv
from collections import namedtuple
import os

FilePool = namedtuple('FilePool', 'file writer')


class CsvFilePool:
    """
    仕向け地別のCSVファイルへの参照を管理するクラス
    """

    def __init__(self, filename_prefix, header_row=None, base_path=None):
        self.csv_pool = {}
        self.filename_prefix = filename_prefix
        self.header_row = header_row
        self.base_path = base_path

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        リソースのクリーンアップ処理
        :param exc_type:
        :param exc_val:
        :param exc_tb:
        :return:
        """
        for csv_obj in self.csv_pool.values():
            csv_obj.file.close()

    def get_writer(self, opco_code: str):
        """
        指定された仕向け地に対応するcsvファイルのwriterオブジェクトを取得する
        :type opco_code str:
        :param opco_code: 仕向け地
        :rtype: file
        :return:
        """

        # オブジェクト生成済みなら生成済みのオブジェクトをそのまま返す
        if opco_code in self.csv_pool:
            return self.csv_pool[opco_code].writer

        # オブジェクトを生成してプール内に追加する
        file_path = f'{self.filename_prefix}_{opco_code}.csv'
        if self.base_path is not None:
            file_path = os.path.join(self.base_path, file_path)
        file = open(file_path, 'w')
        writer = csv.writer(file, lineterminator='\n', quoting=csv.QUOTE_ALL)
        self.csv_pool[opco_code] = FilePool(file, writer)

        if self.header_row is not None:
            writer.writerow(self.header_row)
        return writer
