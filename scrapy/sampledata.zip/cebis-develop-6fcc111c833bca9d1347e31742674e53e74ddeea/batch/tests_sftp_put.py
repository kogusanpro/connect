"""
<copyright file="tests_create_usage_download_url_csv.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.test import TestCase
from io import StringIO
import boto3
from django.conf import settings
import random
import string
import os
import tempfile
from paramiko import SSHClient, AutoAddPolicy
from lib.utils import DateTimeUtil
from django.core.management import call_command

COMMAND = 'sftp_put'


class SftpPutTests(TestCase):
    def setUp(self):
        os.environ['S3_FOR_BILLING_CSV_BUCKET'] = self._get_randam_id()
        os.environ['S3_FOR_PROFITSHARE_CSV_BUCKET'] = self._get_randam_id()
        os.environ['SFTP_REMOTE_PATH'] = '/upload/' + self._get_randam_id() + '/'
        self._sftp_remote_mkdir(
            path=os.environ['SFTP_REMOTE_PATH']
        )
        self.s3 = boto3.client('s3', endpoint_url=settings.AWS_S3_ENDPOINT)
        self._create_bucket(bucketname=os.environ['S3_FOR_BILLING_CSV_BUCKET'])
        self._create_bucket(bucketname=os.environ['S3_FOR_PROFITSHARE_CSV_BUCKET'])

    def tearDown(self):
        self._sftp_remote_rmdir(
            path=os.environ['SFTP_REMOTE_PATH']
        )

    def test_uploaded_billing_csv(self):
        """
        billingの前月分データが正しくSFTPに送信されているかのテスト(それ以外のファイルが送信されていないこともテスト)
        """

        self._create_file_on_s3(
            bucketname=os.environ['S3_FOR_BILLING_CSV_BUCKET'],
            filename='FXA/' + DateTimeUtil.get_prev_y() + '/billing_FXA_' + DateTimeUtil.get_prev_ym() + '.csv'
        )

        self._create_file_on_s3(
            bucketname=os.environ['S3_FOR_BILLING_CSV_BUCKET'],
            filename='FXAB/' + DateTimeUtil.get_prev_y() + '/billing_FXAB_' + DateTimeUtil.get_prev_ym() + '.csv'
        )

        self._create_file_on_s3(
            bucketname=os.environ['S3_FOR_BILLING_CSV_BUCKET'],
            filename='FXA/2018/billing_FXA_201809.csv'
        )

        call_command(COMMAND, stdout=StringIO())
        uploaded_files = self._sftp_remote_files()
        self.assertEqual(uploaded_files, ['billing_FXA_' + DateTimeUtil.get_prev_ym() + '.csv'])
        self._sftp_remove_file(os.environ['SFTP_REMOTE_PATH'] + 'billing_FXA_' + DateTimeUtil.get_prev_ym() + '.csv')

    def test_uploaded_profitshare_csv(self):
        """
        billingの前月分データが正しくSFTPに送信されているかのテスト(それ以外のファイルが送信されていないこともテスト)
        """

        self._create_file_on_s3(
            bucketname=os.environ['S3_FOR_PROFITSHARE_CSV_BUCKET'],
            filename='FXA/' + DateTimeUtil.get_prev_y() + '/profitshare_FXA_' + DateTimeUtil.get_prev_ym() + '.csv'
        )

        self._create_file_on_s3(
            bucketname=os.environ['S3_FOR_PROFITSHARE_CSV_BUCKET'],
            filename='FXAB/' + DateTimeUtil.get_prev_y() + '/profitshare_FXAB_' + DateTimeUtil.get_prev_ym() + '.csv'
        )

        self._create_file_on_s3(
            bucketname=os.environ['S3_FOR_PROFITSHARE_CSV_BUCKET'],
            filename='FXA/2018/profitshare_FXA_201809.csv'
        )

        call_command(COMMAND, stdout=StringIO())
        uploaded_files = self._sftp_remote_files()
        self.assertEqual(uploaded_files, ['profitshare_FXA_' + DateTimeUtil.get_prev_ym() + '.csv'])
        self._sftp_remove_file(os.environ['SFTP_REMOTE_PATH'] + 'profitshare_FXA_' + DateTimeUtil.get_prev_ym() + '.csv')

    def test_duplicated_file(self):
        """
        ファイルの重複時にoldやold.1, old.2といった退避ファイルが作られることをテスト
        """
        self._create_file_on_s3(
            bucketname=os.environ['S3_FOR_BILLING_CSV_BUCKET'],
            filename='FXA/' + DateTimeUtil.get_prev_y() + '/billing_FXA_' + DateTimeUtil.get_prev_ym() + '.csv'
        )

        call_command(COMMAND, stdout=StringIO())
        call_command(COMMAND, stdout=StringIO())
        call_command(COMMAND, stdout=StringIO())
        call_command(COMMAND, stdout=StringIO())
        uploaded_files = self._sftp_remote_files()
        self.assertTrue('billing_FXA_' + DateTimeUtil.get_prev_ym() + '.csv' in uploaded_files)
        self.assertTrue('billing_FXA_' + DateTimeUtil.get_prev_ym() + '.csv.old' in uploaded_files)
        self.assertTrue('billing_FXA_' + DateTimeUtil.get_prev_ym() + '.csv.old.1' in uploaded_files)
        self.assertTrue('billing_FXA_' + DateTimeUtil.get_prev_ym() + '.csv.old.2' in uploaded_files)

        self._sftp_remove_file(os.environ['SFTP_REMOTE_PATH'] + 'billing_FXA_' + DateTimeUtil.get_prev_ym() + '.csv')
        self._sftp_remove_file(os.environ['SFTP_REMOTE_PATH'] + 'billing_FXA_' + DateTimeUtil.get_prev_ym() + '.csv.old')
        self._sftp_remove_file(os.environ['SFTP_REMOTE_PATH'] + 'billing_FXA_' + DateTimeUtil.get_prev_ym() + '.csv.old.1')
        self._sftp_remove_file(os.environ['SFTP_REMOTE_PATH'] + 'billing_FXA_' + DateTimeUtil.get_prev_ym() + '.csv.old.2')

    def _get_randam_id(self):
        return ''.join([
            random.choice('%s%s' % (string.ascii_letters, string.digits))
            for i in range(10)
        ])

    def _create_bucket(self, bucketname):
        self.s3.create_bucket(
            ACL='private',
            Bucket=bucketname,
            CreateBucketConfiguration={
                'LocationConstraint': 'ap-northeast-1'
            },
        )

    def _create_file_on_s3(self, bucketname, filename):
        temp_csv_file = tempfile.NamedTemporaryFile()
        with open(temp_csv_file.name, 'a') as fp:
            fp.close()
            s3 = boto3.resource('s3', endpoint_url=settings.AWS_S3_ENDPOINT)
            s3.meta.client.upload_file(
                temp_csv_file.name,
                bucketname,
                filename
            )
        temp_csv_file.flush()

    def _sftp_login(self):
        ssh = SSHClient()
        ssh.set_missing_host_key_policy(AutoAddPolicy())
        ssh.connect(
            hostname=settings.SFTP['HOST'],
            port=settings.SFTP['PORT'],
            username=settings.SFTP['USER'],
            password=settings.SFTP['PASSWORD']
        )

        return ssh.open_sftp()

    def _sftp_remote_files(self):
        sftp = self._sftp_login()
        return sftp.listdir(os.environ['SFTP_REMOTE_PATH'])

    def _sftp_remote_mkdir(self, path):
        self._sftp_login().mkdir(path)

    def _sftp_remote_rmdir(self, path):
        self._sftp_login().rmdir(path)

    def _sftp_remove_file(self, file):
        self._sftp_login().remove(file)
