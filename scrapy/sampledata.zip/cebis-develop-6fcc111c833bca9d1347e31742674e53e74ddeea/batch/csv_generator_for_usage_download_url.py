"""
<copyright file="csv_generator_for_usage_download_url.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import boto3
import re
import os
from django.conf import settings
from lib.string_utils import StringUtils
from lib.utils import DateTimeUtil
import tempfile
import csv
import hashlib
from lib.const.internal_calc import SUBSCRIPTION_ID_POSTFIX, PRODUCT_CODE_POSTFIXES
from subscriptions.serializers import SubscriptionsUsagePostSerializer


class CsvGeneratorForUsageDownloadUrl:
    def __init__(self, filename):
        self.bucketkey = filename
        self.bucketname = os.environ.get('S3_USAGE_DOWNLOAD_BUCKET')
        self.temp_csv_file = tempfile.NamedTemporaryFile()
        self.counting_process = 0

    def get_md5(self):
        return self.md5

    def create_header(self):
        """
        CSVファイルのヘッダ行を生成する
        :return:
        """

        header = list()
        header.append('#usage_id')
        header.append('subscription_id')
        header.append('product_code')
        header.append('target_month')
        header.append('start_date_time')
        header.append('end_date_time')
        header.append('quantity')
        header.append('license_user')
        header.append('free_item1')
        header.append('free_item2')
        header.append('create_date_time')
        header.append('modified_date_time')

        self.header = header

    def generate_csv_to_local(self, data, internal_calc=False):
        """
         CSVをlocalに出力する
         :return: :void:
        """
        with open(self.temp_csv_file.name, 'a') as fp:
            self.generate_csv(
                fp=fp,
                data=data,
                internal_calc=internal_calc)
            fp.close()

    def upload_csv_to_s3(self):
        """
         CSVをS3にアップする
         :return: :void:
        """
        s3 = boto3.resource('s3', endpoint_url=settings.AWS_S3_ENDPOINT)
        s3.meta.client.upload_file(
            self.temp_csv_file.name,
            self.bucketname,
            self.bucketkey
        )
        self.calculate_md5(filename=self.temp_csv_file.name)
        self.temp_csv_file.flush()

    def calculate_md5(self, filename):
        data = open(filename, 'r')
        self.md5 = hashlib.md5(data.read().encode('utf-8')).hexdigest()
        data.close()

    def generate_csv(self, fp, data, internal_calc=False):
        """
         CSVデータを生成する
         :return: :string: CSVデータ
        """
        writer = csv.writer(fp, lineterminator='\n', quoting=csv.QUOTE_ALL)
        if os.path.getsize(self.temp_csv_file.name) == 0:
            self.create_header()
            writer.writerow(self.header)
        for csv_content in data:
            usage_id = str(csv_content.usage_id)
            subscription_id = str(csv_content.subscription_id)
            product_code = str(csv_content.product_code)
            target_month = str(csv_content.target_month)
            start_time = DateTimeUtil.format_iso8601_utc(
                csv_content.start_time)
            end_time = DateTimeUtil.format_iso8601_utc(
                csv_content.end_time)
            quantity = str(csv_content.quantity)
            license_user = StringUtils.convert_emptystring_if_none(
                csv_content.license_user)
            free_item1 = StringUtils.convert_emptystring_if_none(
                csv_content.free_item1)
            free_item2 = StringUtils.convert_emptystring_if_none(
                csv_content.free_item2)
            created_time = DateTimeUtil.format_iso8601_utc(
                csv_content.created_time)
            updated_time = DateTimeUtil.format_iso8601_utc(
                csv_content.updated_time)
            csv_row = list()
            csv_row.append(usage_id)
            csv_row.append(subscription_id)
            csv_row.append(product_code)
            csv_row.append(target_month)
            csv_row.append(start_time)
            csv_row.append(end_time)
            csv_row.append(quantity)
            csv_row.append(license_user)
            csv_row.append(free_item1)
            csv_row.append(free_item2)
            csv_row.append(created_time)
            csv_row.append(updated_time)
            writer.writerow(csv_row)
            self.counting_process += 1
            if internal_calc is True:
                self.generate_ghost_csv(
                    writer=writer,
                    csv_content=csv_content
                )

    def generate_ghost_csv(
        self,
        writer,
        csv_content
    ):
        """
         プロフィットシェア計算用の重量データCSV生成する
         :return: :void:
        """
        subscription_id = csv_content.subscription_id + SUBSCRIPTION_ID_POSTFIX
        for product_code_posfix in PRODUCT_CODE_POSTFIXES:
            product_code = csv_content.product_code + product_code_posfix
            usage_id = SubscriptionsUsagePostSerializer.generate_usage_id(
                None,
                subscription_id=subscription_id,
                product_code=product_code,
                start_time=DateTimeUtil.format_YmdTHMSZ_utc(
                    csv_content.start_time),
                end_time=DateTimeUtil.format_YmdTHMSZ_utc(
                    csv_content.end_time),
                quantity=csv_content.quantity,
                license_user=csv_content.license_user
            )
            free_item2 = product_code_posfix

            usage_id = str(usage_id)
            subscription_id = str(subscription_id)
            product_code = str(product_code)
            target_month = str(csv_content.target_month)
            start_time = DateTimeUtil.format_iso8601_utc(
                csv_content.start_time)
            end_time = DateTimeUtil.format_iso8601_utc(
                csv_content.end_time)
            quantity = str(csv_content.quantity)
            license_user = StringUtils.convert_emptystring_if_none(
                csv_content.license_user)
            free_item1 = StringUtils.convert_emptystring_if_none(
                csv_content.free_item1)
            free_item2 = str(free_item2)
            created_time = DateTimeUtil.format_iso8601_utc(
                csv_content.created_time)
            updated_time = DateTimeUtil.format_iso8601_utc(
                csv_content.updated_time)
            csv_row = list()
            csv_row.append(usage_id)
            csv_row.append(subscription_id)
            csv_row.append(product_code)
            csv_row.append(target_month)
            csv_row.append(start_time)
            csv_row.append(end_time)
            csv_row.append(quantity)
            csv_row.append(license_user)
            csv_row.append(free_item1)
            csv_row.append(free_item2)
            csv_row.append(created_time)
            csv_row.append(updated_time)
            writer.writerow(csv_row)
            self.counting_process += 1
