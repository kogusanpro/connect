"""
<copyright file="tests_create_billing.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from io import StringIO
from unittest import mock
from unittest.mock import call
import freezegun

from django.core.management import call_command
from django.test import TestCase
from django.utils.timezone import datetime, timedelta

from subscriptions.factory_boy import BillingInfoFactory, BillingDetailInfoFactory, \
    ContractInfoFactory, ContractServiceInfoFactory, ProductInfoFactory
from subscriptions.models import BillingInfo, BillingDetailInfo
from lib.const.contract_service_state import ACTIVE, INACTIVE, TRIAL
from lib.const.billing_info_state import NEW
from lib.utils import DateTimeUtil

COMMAND = 'create_billing_record'


class CreateBillingTests(TestCase):

    def test_create_active_and_service_started(self):
        """
        契約状態がアクティブかつ、サービス手配開始日時が
        バッチ実行日時より未来日付でないデータに対して請求データが生成される
        ことをテストする
        :return:
        """

        now = DateTimeUtil.utc_now_aware()
        past_date = now + timedelta(days=-30)
        future_date = now + timedelta(days=30)
        target_ym = now.strftime('%Y%m')

        # 1件目の契約
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=future_date)
        # 2件目の契約
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=future_date)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        billings = BillingInfo.objects.all()
        # ヘッダは請求情報レコードが2件、プロフィットシェア料金情報レコード2件登録されてるはず
        self.assertEqual(billings.count(), 2 + 2)
        # 対象月度が正しく登録されていることを確認
        for billing in billings:
            self.assertEqual(target_ym, billing.target_month)
            self.assertEqual(NEW, billing.state)

        # 明細は請求情報レコードが4件、プロフィットシェア料金情報レコード24件登録されてるはず
        billing_details = BillingDetailInfo.objects.all()
        self.assertEqual(billing_details.count(), 4 + 24)
        for detail in billings:
            self.assertEqual(target_ym, detail.target_month)

    def test_not_create_active_and_service_started_trial(self):
        """
        契約状態がアクティブかつ、サービス手配完了日時が
        バッチ実行日時より未来日付でないデータでも、お試し契約の場合は請求データが生成されない
        ことをテストする
        :return:
        """

        now = DateTimeUtil.utc_now_aware()
        past_date = now + timedelta(days=-1)
        future_date = now + timedelta(days=1)
        target_ym = now.strftime('%Y%m')

        # 1件目の契約
        contract_info = ContractInfoFactory(contract_code=None)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=future_date)
        # 2件目の契約
        contract_info = ContractInfoFactory(contract_code='')
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=future_date)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        billings = BillingInfo.objects.all()
        self.assertEqual(billings.count(), 0)

        billing_details = BillingDetailInfo.objects.all()
        self.assertEqual(billing_details.count(), 0)

    ## def test_create_inactive_and_cancel_current_month(self):
    #     """
    #     契約状態がインアクティブかつ、サービス解約手配完了日時の年月が
    #     バッチ実行日時の年月と一致するデータに対して請求データが生成される
    #     ことをテストする
    #     :return:
    #     """
    #
    #     now = DateTimeUtil.utc_now_aware()
    #     first_day = now.replace(day=1)
    #     if now.month == 1:
    #         past_month = now.replace(month=12, year=now.year - 1)
    #     else:
    #         past_month = now.replace(month=now.month - 1, day=10)
    #     if now.month == 12:
    #         future_month = now.replace(month=1, year=now.year + 1, day=10)
    #     else:
    #         future_month = now.replace(month=now.month + 1, day=10)
    #     target_ym = now.strftime('%Y%m')
    #
    #     # 1件目の契約
    #     contract_info = ContractInfoFactory()
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
    #                                service_cancel_time=now)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
    #                                service_cancel_time=first_day + timedelta(days=-1))
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
    #                                service_cancel_time=past_month)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
    #                                service_cancel_time=future_month)
    #     # 2件目の契約 複数レコードヒット
    #     contract_info = ContractInfoFactory()
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
    #                                service_cancel_time=now)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
    #                                service_cancel_time=first_day)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
    #                                service_cancel_time=now)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
    #                                service_cancel_time=past_month)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
    #                                service_cancel_time=future_month)
    #
    #     out = StringIO()
    #     call_command(COMMAND, stdout=out)
    #
    #     billings = BillingInfo.objects.all()
    #     # ヘッダは請求情報レコードが2件、プロフィットシェア料金情報レコード2件登録されてるはず
    #     self.assertEqual(billings.count(), 2 + 2)
    #     # 対象月度が正しく登録されていることを確認
    #     for billing in billings:
    #         self.assertEqual(target_ym, billing.target_month)
    #         self.assertEqual(NEW, billing.state)
    #
    #     # 明細は請求情報レコードが4件、プロフィットシェア料金情報レコード24件登録されてるはず
    #     billing_details = BillingDetailInfo.objects.all()
    #     self.assertEqual(billing_details.count(), 4 + 24)
    #     for detail in billings:
    #         self.assertEqual(target_ym, detail.target_month)

    def test_not_create_inactive_and_cancel_current_month_trial(self):
        """
        契約状態がインアクティブかつ、サービス解約手配完了日時の年月が
        バッチ実行日時の年月と一致しても、お試し契約の場合は請求データが生成されない
        ことをテストする
        :return:
        """

        now = DateTimeUtil.utc_now_aware()
        first_day = now.replace(day=1)
        if now.month == 1:
            past_month = now.replace(month=12, year=now.year - 1)
        else:
            past_month = now.replace(month=now.month - 1, day=10)
        if now.month == 12:
            future_month = now.replace(month=1, year=now.year + 1, day=10)
        else:
            future_month = now.replace(month=now.month + 1, day=10)
        target_ym = now.strftime('%Y%m')

        # 1件目の契約
        contract_info = ContractInfoFactory(contract_code=None)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day + timedelta(days=-1))
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=past_month)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=future_month)
        # 2件目の契約 複数レコードヒット
        contract_info = ContractInfoFactory(contract_code='')
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=past_month)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=future_month)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        billings = BillingInfo.objects.all()
        self.assertEqual(billings.count(), 0)

        billing_details = BillingDetailInfo.objects.all()
        self.assertEqual(billing_details.count(), 0)

    def test_not_create_trial(self):
        """
        契約状態がトライアルの場合請求データが生成され無いことをテストする
        :return:
        """

        now = DateTimeUtil.utc_now_aware()
        first_day = now.replace(day=1)
        if now.month == 1:
            past_month = now.replace(month=12, year=now.year - 1)
        else:
            past_month = now.replace(month=now.month - 1, day=10)
        if now.month == 12:
            future_month = now.replace(month=1, year=now.year + 1, day=10)
        else:
            future_month = now.replace(month=now.month + 1, day=10)
        target_ym = now.strftime('%Y%m')

        # 1件目の契約
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL, service_cancel_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL,
                                   service_cancel_time=first_day + timedelta(days=-1))
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL, service_cancel_time=past_month)
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL, service_cancel_time=future_month)
        # 2件目の契約
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL, service_cancel_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL, service_cancel_time=first_day)
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL, service_cancel_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL, service_cancel_time=past_month)
        ContractServiceInfoFactory(subscription=contract_info, state=TRIAL, service_cancel_time=future_month)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        billings = BillingInfo.objects.all()
        self.assertEqual(billings.count(), 0)
        billing_details = BillingDetailInfo.objects.all()
        self.assertEqual(billing_details.count(), 0)

    # def test_create_active_and_service_started_and_inactive_and_cancel_current_month(self):
    #     """
    #     ・契約状態がアクティブかつ、サービス手配完了日時がバッチ実行日時より未来日付
    #     ・契約状態がインアクティブかつ、サービス解約手配完了日時の年月がバッチ実行日時の年月と一致
    #     両方のパターンが混在する場合に、想定通りの請求データが生成されることをテストする
    #     :return:
    #     """
    #
    #     now = DateTimeUtil.utc_now_aware()
    #     first_day = now.replace(day=1)
    #     if now.month == 1:
    #         past_month = now.replace(month=12, year=now.year - 1)
    #     else:
    #         past_month = now.replace(month=now.month - 1, day=10)
    #     if now.month == 12:
    #         future_month = now.replace(month=1, year=now.year + 1, day=10)
    #     else:
    #         future_month = now.replace(month=now.month + 1, day=10)
    #     past_date = now + timedelta(days=-1)
    #     future_date = now + timedelta(days=1)
    #     target_ym = now.strftime('%Y%m')
    #
    #     # 1件目の契約 ACTIVE
    #     contract_info = ContractInfoFactory()
    #     ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date)
    #     ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now)
    #     ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=future_date)
    #
    #     # 2件目の契約 INACTIVE
    #     contract_info = ContractInfoFactory()
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=now)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
    #                                service_cancel_time=first_day + timedelta(days=-1))
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=past_month)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=future_month)
    #
    #     # 3件目の契約 ACTIVE INACTIVE混在
    #     contract_info = ContractInfoFactory()
    #     ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date)
    #     ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=now)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
    #                                service_cancel_time=first_day + timedelta(days=-1))
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=past_month)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=future_month)
    #
    #     # 4件目の契約 お試し契約
    #     contract_info = ContractInfoFactory(contract_code=None)
    #     ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date)
    #     ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=now)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
    #                                service_cancel_time=first_day + timedelta(days=-1))
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=past_month)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=future_month)
    #
    #     # 5件目の契約 お試し契約
    #     contract_info = ContractInfoFactory(contract_code='')
    #     ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date)
    #     ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=now)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
    #                                service_cancel_time=first_day + timedelta(days=-1))
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=past_month)
    #     ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=future_month)
    #
    #     out = StringIO()
    #     call_command(COMMAND, stdout=out)
    #
    #     billings = BillingInfo.objects.all()
    #     # ヘッダは請求情報レコードが3件、プロフィットシェア料金情報レコード3件登録されてるはず
    #     self.assertEqual(billings.count(), 3 + 3)
    #     # 対象月度が正しく登録されていることを確認
    #     for billing in billings:
    #         self.assertEqual(target_ym, billing.target_month)
    #         self.assertEqual(NEW, billing.state)
    #
    #     # 明細は請求情報レコードが6件、プロフィットシェア料金情報レコード36件登録されてるはず
    #     billing_details = BillingDetailInfo.objects.all()
    #     self.assertEqual(billing_details.count(), 6 + 36)
    #
    #     for detail in billings:
    #         self.assertEqual(target_ym, detail.target_month)

    def __special_date_common_test(self):
        """
        特殊な日付のテストで共通して使い回すテストロジック
        :return:
        """
        now = DateTimeUtil.utc_now_aware()
        first_day = now.replace(day=1)
        if now.month == 1:
            past_month = now.replace(month=12, year=now.year - 1)
        else:
            past_month = now.replace(month=now.month - 1, day=10)
        if now.month == 12:
            future_month = now.replace(month=1, year=now.year + 1, day=10)
        else:
            future_month = now.replace(month=now.month + 1, day=10)
        past_date = now + timedelta(days=-1)
        future_date = now + timedelta(days=1)
        target_ym = now.strftime('%Y%m')

        # 1件目の契約 ACTIVE
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=future_date)

        # 2件目の契約 INACTIVE
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day + timedelta(days=-1))
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=past_month)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=future_month)

        # 3件目の契約 ACTIVE INACTIVE混在
        contract_info = ContractInfoFactory()
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day + timedelta(days=-1))
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=past_month)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=future_month)

        # 4件目の契約 お試し契約
        contract_info = ContractInfoFactory(contract_code=None)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day + timedelta(days=-1))
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=past_month)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=future_month)

        # 5件目の契約 お試し契約
        contract_info = ContractInfoFactory(contract_code='')
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=past_date)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=now)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=first_day + timedelta(days=-1))
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=past_month)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE, service_cancel_time=future_month)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        print(future_month)
        print(past_date)
        print(future_date)
        billings = BillingInfo.objects.all()
        # ヘッダは6件登録されてるはず
        self.assertEqual(billings.count(), 6)
        # 対象月度が正しく登録されていることを確認
        for billing in billings:
            self.assertEqual(target_ym, billing.target_month)
            self.assertEqual(NEW, billing.state)

        # 明細は請求情報レコードが6件、プロフィットシェア料金情報レコード36件登録されてるはず
        billing_details = BillingDetailInfo.objects.all()
        self.assertEqual(billing_details.count(), 6 + 36)

        for detail in billings:
            self.assertEqual(target_ym, detail.target_month)

    # @freezegun.freeze_time('2020-02-29 14:00:00')
    # def test_create_active_and_service_started_and_inactive_and_cancel_current_month_leap_year(self):
    #     """
    #     閏年の2/29にバッチを実行しても正常に請求データが生成されることをテストする
    #     :return:
    #     """
    #     self.__special_date_common_test()
    #
    # @freezegun.freeze_time('2020-01-31 23:00:00')
    # def test_create_active_and_service_started_and_inactive_and_cancel_current_month_january(self):
    #     """
    #     1月にバッチを実行(先月は前年になる)しても正常に請求データが生成されることをテストする
    #     :return:
    #     """
    #     self.__special_date_common_test()
    #
    # @freezegun.freeze_time('2018-12-31 23:00:00')
    # def test_create_active_and_service_started_and_inactive_and_cancel_current_month_december(self):
    #     """
    #     12月にバッチを実行(翌月は来年になる)しても正常に請求データが生成されることをテストする
    #     :return:
    #     """
    #     self.__special_date_common_test()
    #
    @mock.patch('logging.Logger.error')
    def test_logging_exists_billing_info(self, mock_logger):
        """
        請求情報テーブルに既にレコードが存在していた場合にエラーログが出力されることをテストする
        :return:
        """

        now = DateTimeUtil.utc_now_aware()
        past_date = now + timedelta(days=-1)
        future_date = now + timedelta(days=1)
        target_month = DateTimeUtil.get_current_ym()

        # 1件目の契約 サブスクリプションID：１の請求データが生成済み
        contract_info = ContractInfoFactory(subscription_id=1)
        BillingInfoFactory(subscription=contract_info, target_month=target_month)
        billings = BillingInfo.objects.all()
        self.assertEqual(billings.count(), 1)

        product1 = ProductInfoFactory(product_code="prod1")
        product2 = ProductInfoFactory(product_code="prod2")
        product3 = ProductInfoFactory(product_code="prod3")

        BillingDetailInfoFactory(subscription=contract_info, product_code=product1, target_month=target_month)
        billing_details = BillingDetailInfo.objects.all()
        self.assertEqual(billing_details.count(), 1)

        profitshare_contract_info = ContractInfoFactory(subscription_id='1G')
        profitshare_product1 = ProductInfoFactory(product_code="prod1C6")
        BillingInfoFactory(subscription=profitshare_contract_info, target_month=target_month)
        BillingDetailInfoFactory(subscription=profitshare_contract_info, product_code=profitshare_product1, target_month=target_month)

        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE,
                                   service_start_time=past_date, product_code=product1)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE,
                                   service_start_time=now, product_code=product2)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE,
                                   service_start_time=future_date, product_code=product3)
        # 2件目の契約
        contract_info = ContractInfoFactory(subscription_id=2)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE,
                                   service_start_time=past_date, product_code=product1)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE,
                                   service_start_time=now, product_code=product2)
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE,
                                   service_start_time=future_date, product_code=product3)

        out = StringIO()
        call_command(COMMAND, stdout=out)
        mock_logger.assert_has_calls([
            call('subscription_id 1 is already exists in billing_info'),
            call('subscription_id 1G is already exists in billing_info'),
            call('subscription_id 1 and product_code prod1 is already exists in billing_info_detail'),
            call('subscription_id 1G and product_code prod1C6 is already exists in billing_info_detail'),
        ])

        billings = BillingInfo.objects.all()
        # ヘッダは1件から4件に増えるはず
        self.assertEqual(billings.count(), 4)

        # サブスクリプションID：1については、product1の登録はスキップされるがproduct2はスキップされない。
        # https://soldev-env.fujixerox.co.jp/redmine/issues/51312
        # 請求情報レコードが6件、プロフィットシェア料金情報レコードが36件登録されるはず
        billing_details = BillingDetailInfo.objects.all()
        self.assertEqual(billing_details.count(), 6 + 36)

    def test_csi_start_time_than_csi_cancel_time(self):
        """
        WPSS商品でユーザー追加オプション（5ユーザー利用パック）の無料期間中に純解約が発生した場合、
        ユーザー追加オプションの契約サービス情報において、サービス開始手配完了日時>サービス解約手配完了日時になった場合、
        請求情報レコードが生成されない。
        :return:
        """
        now = DateTimeUtil.utc_now_aware()
        start_time = now + timedelta(days=100)
        cancel_time = now + timedelta(days=30)
        contract_info = ContractInfoFactory(subscription_id=1)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_start_time=start_time, service_cancel_time=cancel_time)
        out = StringIO()
        call_command(COMMAND, stdout=out)
        billings = BillingInfo.objects.all()
        self.assertEqual(billings.count(), 0)
        billing_details = BillingDetailInfo.objects.all()
        self.assertEqual(billing_details.count(), 0)

    def test_futrue_csi_cancel_time(self):
        """
        サービス解約手配完了日時に1ヶ月以上先の未来日が指定されている場合に請求対象レコードが生成される。
        :return:
        """
        now = DateTimeUtil.utc_now_aware()
        start_time = now
        cancel_time = now + timedelta(days=100)
        contract_info = ContractInfoFactory(subscription_id=1)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_start_time=start_time, service_cancel_time=cancel_time)
        out = StringIO()
        call_command(COMMAND, stdout=out)
        billings = BillingInfo.objects.all()
        self.assertEqual(billings.count(), 2)
        billing_details = BillingDetailInfo.objects.all()
        self.assertEqual(billing_details.count(), 7)

    def test_specify_target_month(self):
        """
        請求情報レコード生成バッチにおいて、テスト時など対象月度を指定して実行したい場合に、指定して実行できる。
        :return:
        """
        target_month = '209901'
        now = DateTimeUtil.utc_now_aware()
        start_time = now
        cancel_time = now.replace(year=2099, month=1, day=31, hour=14)
        contract_info = ContractInfoFactory(subscription_id=1)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_start_time=start_time, service_cancel_time=cancel_time)
        out = StringIO()
        call_command(COMMAND, target_month=target_month, stdout=out)
        billings = BillingInfo.objects.all()
        self.assertEqual(billings.count(), 2)
        billing_details = BillingDetailInfo.objects.all()
        self.assertEqual(billing_details.count(), 7)
        for billing_detail in billing_details:
            self.assertEqual(billing_detail.target_month, target_month)
