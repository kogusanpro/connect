"""
<copyright file="tests_create_billing_csv.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import boto3
import csv
import freezegun
import glob
from io import StringIO
from moto import mock_s3
import os
import os.path
from unittest import mock
from unittest.mock import call
import xml.etree.ElementTree as ET

from django.core.management import call_command, CommandError
from django.test import TestCase

from batch.services import query_billing_csv_target, get_tmp_dir
from subscriptions.factory_boy import BillingInfoFactory, BillingDetailInfoFactory, BillingUsageDetailInfoFactory, \
    ContractInfoFactory, ProductInfoFactory
from lib.const.billing_info_state import NEW, COMPLETED
from lib.utils import DateTimeUtil


COMMAND = 'create_billing_csv'


class CreateBillingCsvTests(TestCase):

    def __create_bucket(self):
        s3 = boto3.client('s3')
        for bucket_name in ['S3_FOR_BILLING_CSV_BUCKET', 'S3_FOR_PROFITSHARE_CSV_BUCKET']:
            bucket_name = os.getenv(bucket_name)
            s3.create_bucket(Bucket=bucket_name, CreateBucketConfiguration={'LocationConstraint': 'ap-northeast-1'})

    def setUp(self):
        os.environ['S3_FOR_BILLING_CSV_BUCKET'] = 'test_bucket'
        os.environ['S3_FOR_PROFITSHARE_CSV_BUCKET'] = 'test_bucket2'

    def tearDown(self):
        tmp_dir = get_tmp_dir()
        file_list = glob.glob(os.path.join(tmp_dir, '*.csv'))
        for file in file_list:
            os.remove(file)

    def test_environ_var_not_set(self):
        """
        環境変数にS3バケットの情報がセットされていない場合に例外が発生することをテストする
        :return:
        """

        del os.environ['S3_FOR_BILLING_CSV_BUCKET']

        out = StringIO()
        with self.assertRaises(CommandError):
            call_command(COMMAND,  stdout=out)

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_non_exists_bucket(self, mock_logger):
        """
        S3バケットが存在しない場合にエラーログが出力されることをテストする
        :return:
        """

        target_month = DateTimeUtil.get_prev_ym()
        contract1 = ContractInfoFactory(subscription_id=1, opco_code='FX')
        product1 = ProductInfoFactory()
        BillingInfoFactory(subscription=contract1, target_month=target_month, state=COMPLETED)
        BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product1)

        out = StringIO()
        call_command(COMMAND,  stdout=out)
        mock_logger.assert_called()

    @mock_s3
    def test_not_create_csv_if_trial_contract_only(self):
        """
        お試し契約のみの場合にCSVファイルが生成されないことをテストする
        :return:
        """

        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract1 = ContractInfoFactory(subscription_id=1, opco_code='FX', contract_code=None)
        contract2 = ContractInfoFactory(subscription_id=2, opco_code='FX', contract_code='')
        product1 = ProductInfoFactory()
        BillingInfoFactory(subscription=contract1, target_month=target_month, state=COMPLETED)
        BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product1)
        BillingInfoFactory(subscription=contract2, target_month=target_month, state=COMPLETED)
        BillingDetailInfoFactory(subscription=contract2, target_month=target_month, product_code=product1)

        out = StringIO()
        call_command(COMMAND,  stdout=out)

        tmp_dir = get_tmp_dir()
        file_list = glob.glob(os.path.join(tmp_dir, '*.csv'))
        self.assertEqual(len(file_list), 0)

    @mock_s3
    def test_create_csv_not_trial_contract_only(self):
        """
        お試し契約と通常の契約が混在した場合に通常の契約に対してのみCSVファイルが生成されることをテストする
        :return:
        """

        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract1 = ContractInfoFactory(subscription_id=1, opco_code='FX', contract_code='1')
        contract2 = ContractInfoFactory(subscription_id=2, opco_code='FX', contract_code='')
        product1 = ProductInfoFactory()
        bi1 = BillingInfoFactory(subscription=contract1, target_month=target_month, state=COMPLETED)
        bdi1 = BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product1)
        BillingInfoFactory(subscription=contract2, target_month=target_month, state=COMPLETED)
        BillingDetailInfoFactory(subscription=contract2, target_month=target_month, product_code=product1)

        out = StringIO()
        call_command(COMMAND,  stdout=out)
        # 1レコード生成されるはず
        filename = os.path.join(get_tmp_dir(), 'billing_FX.csv')
        with open(filename, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            prd1_data = next(f)
            self.assertEqual(prd1_data['#subscription_id'], '1')
            self.assertEqual(prd1_data['target_month'], target_month)
            self.assertEqual(prd1_data['opco_code'], contract1.opco_code)
            self.assertEqual(prd1_data['start_date'], str(bi1.start_date))
            self.assertEqual(prd1_data['end_date'], str(bi1.end_date))
            self.assertEqual(prd1_data['billing'], str(bi1.billing))
            self.assertEqual(prd1_data['product_code'], bdi1.product_code.product_code)
            self.assertEqual(prd1_data['license_quantity'], str(bdi1.license_quantity))
            self.assertEqual(prd1_data['billing_for_product_code'], str(bdi1.billing))
            self.assertEqual(prd1_data['quantity'], str(bdi1.quantity))
            self.assertEqual(prd1_data['unit_of_money'], bi1.unit_of_money)
            self.assertEqual(prd1_data['statements'], '')

            s3 = boto3.client('s3')
            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FX/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FX/{target_month[0:4]}/billing_FX_{target_month}.csv')

    @mock_s3
    def test_one_opco_code_one_detail_non_usage(self):
        """
        仕向け地:1、請求情報:1、請求明細:1、利用明細:0の場合のテスト
        :return:
        """

        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract1 = ContractInfoFactory(subscription_id=1, opco_code='FX')
        product1 = ProductInfoFactory()
        bi = BillingInfoFactory(subscription=contract1, target_month=target_month, state=COMPLETED)
        bdi = BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product1)

        out = StringIO()
        call_command(COMMAND,  stdout=out)

        # 1レコード生成されるはず
        filename = os.path.join(get_tmp_dir(), 'billing_FX.csv')
        with open(filename, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            prd1_data = next(f)
            self.assertEqual(prd1_data['#subscription_id'], '1')
            self.assertEqual(prd1_data['target_month'], target_month)
            self.assertEqual(prd1_data['opco_code'], contract1.opco_code)
            self.assertEqual(prd1_data['start_date'], str(bi.start_date))
            self.assertEqual(prd1_data['end_date'], str(bi.end_date))
            self.assertEqual(prd1_data['billing'], str(bi.billing))
            self.assertEqual(prd1_data['product_code'], bdi.product_code.product_code)
            self.assertEqual(prd1_data['license_quantity'], str(bdi.license_quantity))
            self.assertEqual(prd1_data['billing_for_product_code'], str(bdi.billing))
            self.assertEqual(prd1_data['quantity'], str(bdi.quantity))
            self.assertEqual(prd1_data['unit_of_money'], bi.unit_of_money)
            self.assertEqual(prd1_data['statements'], '')

            s3 = boto3.client('s3')
            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FX/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FX/{target_month[0:4]}/billing_FX_{target_month}.csv')

    @mock_s3
    def test_one_opco_code_one_detail_one_usage(self):
        """
        仕向け地:1、請求情報:1、請求明細:1、利用明細:1の場合のテスト
        :return:
        """

        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract1 = ContractInfoFactory(subscription_id=1, opco_code='FX')
        product1 = ProductInfoFactory()
        bi = BillingInfoFactory(subscription=contract1, target_month=target_month, state=COMPLETED)
        bdi = BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract1, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=100, quantity=10)
        out = StringIO()
        call_command(COMMAND,  stdout=out)

        # 1レコード生成されるはず
        filename = os.path.join(get_tmp_dir(), 'billing_FX.csv')
        with open(filename, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            prd1_data = next(f)
            self.assertEqual(prd1_data['#subscription_id'], '1')
            self.assertEqual(prd1_data['target_month'], target_month)
            self.assertEqual(prd1_data['opco_code'], contract1.opco_code)
            self.assertEqual(prd1_data['start_date'], str(bi.start_date))
            self.assertEqual(prd1_data['end_date'], str(bi.end_date))
            self.assertEqual(prd1_data['billing'], str(bi.billing))
            self.assertEqual(prd1_data['product_code'], bdi.product_code.product_code)
            self.assertEqual(prd1_data['license_quantity'], str(bdi.license_quantity))
            self.assertEqual(prd1_data['billing_for_product_code'], str(bdi.billing))
            self.assertEqual(prd1_data['quantity'], str(bdi.quantity))
            self.assertEqual(prd1_data['unit_of_money'], bi.unit_of_money)

            xml = ET.fromstring(prd1_data['statements'])
            statements = list(xml)
            self.assertEqual(1, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user01')
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')

            s3 = boto3.client('s3')
            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FX/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FX/{target_month[0:4]}/billing_FX_{target_month}.csv')

    @mock_s3
    def test_one_opco_code_multi_detail_multi_usage_per_detail(self):
        """
        仕向け地:1、請求情報:1、請求明細:N、利用明細:Nの場合のテスト
        :return:
        """
        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract1 = ContractInfoFactory(subscription_id=1, opco_code='FX')
        product1 = ProductInfoFactory()
        product2 = ProductInfoFactory()
        product3 = ProductInfoFactory()
        bi1 = BillingInfoFactory(subscription=contract1, target_month=target_month, state=COMPLETED)
        bdi1 = BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract1, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=100, quantity=10)
        BillingUsageDetailInfoFactory(subscription=contract1, target_month=target_month,
                                      product_code=product1, license_user='user02', billing=999, quantity=1)

        bdi2 = BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product2)
        BillingUsageDetailInfoFactory(subscription=contract1, target_month=target_month,
                                      product_code=product2, license_user='user03', billing=2222, quantity=2)
        BillingUsageDetailInfoFactory(subscription=contract1, target_month=target_month,
                                      product_code=product2, license_user='user04', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract1, target_month=target_month,
                                      product_code=product2, license_user='user05', billing=5000, quantity=1)

        bdi3 = BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product3)

        out = StringIO()
        call_command(COMMAND,  stdout=out)

        # 3レコード生成されるはず
        filename = os.path.join(get_tmp_dir(), 'billing_FX.csv')
        with open(filename, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            prd1_data = next(f)
            self.assertEqual(prd1_data['#subscription_id'], '1')
            self.assertEqual(prd1_data['target_month'], target_month)
            self.assertEqual(prd1_data['opco_code'], contract1.opco_code)
            self.assertEqual(prd1_data['start_date'], str(bi1.start_date))
            self.assertEqual(prd1_data['end_date'], str(bi1.end_date))
            self.assertEqual(prd1_data['billing'], str(bi1.billing))
            self.assertEqual(prd1_data['product_code'], bdi1.product_code.product_code)
            self.assertEqual(prd1_data['license_quantity'], str(bdi1.license_quantity))
            self.assertEqual(prd1_data['billing_for_product_code'], str(bdi1.billing))
            self.assertEqual(prd1_data['quantity'], str(bdi1.quantity))
            self.assertEqual(prd1_data['unit_of_money'], bi1.unit_of_money)

            xml = ET.fromstring(prd1_data['statements'])
            statements = list(xml)
            self.assertEqual(2, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user01')
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user02')
            self.assertEqual(statement.find('billing').text, '999')
            self.assertEqual(statement.find('quantity').text, '1')

            prd2_data = next(f)
            self.assertEqual(prd2_data['#subscription_id'], '1')
            self.assertEqual(prd2_data['target_month'], target_month)
            self.assertEqual(prd2_data['opco_code'], contract1.opco_code)
            self.assertEqual(prd2_data['start_date'], str(bi1.start_date))
            self.assertEqual(prd2_data['end_date'], str(bi1.end_date))
            self.assertEqual(prd2_data['billing'], str(bi1.billing))
            self.assertEqual(prd2_data['product_code'], bdi2.product_code.product_code)
            self.assertEqual(prd2_data['license_quantity'], str(bdi2.license_quantity))
            self.assertEqual(prd2_data['billing_for_product_code'], str(bdi2.billing))
            self.assertEqual(prd2_data['quantity'], str(bdi2.quantity))
            self.assertEqual(prd2_data['unit_of_money'], bi1.unit_of_money)
            xml = ET.fromstring(prd2_data['statements'])
            statements = list(xml)
            self.assertEqual(3, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '2222')
            self.assertEqual(statement.find('quantity').text, '2')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[2]
            self.assertEqual(statement.find('license-user').text, 'user05')
            self.assertEqual(statement.find('billing').text, '5000')
            self.assertEqual(statement.find('quantity').text, '1')

            prd3_data = next(f)
            self.assertEqual(prd3_data['#subscription_id'], '1')
            self.assertEqual(prd3_data['target_month'], target_month)
            self.assertEqual(prd3_data['opco_code'], contract1.opco_code)
            self.assertEqual(prd3_data['start_date'], str(bi1.start_date))
            self.assertEqual(prd3_data['end_date'], str(bi1.end_date))
            self.assertEqual(prd3_data['billing'], str(bi1.billing))
            self.assertEqual(prd3_data['product_code'], bdi3.product_code.product_code)
            self.assertEqual(prd3_data['license_quantity'], str(bdi3.license_quantity))
            self.assertEqual(prd3_data['billing_for_product_code'], str(bdi3.billing))
            self.assertEqual(prd3_data['quantity'], str(bdi3.quantity))
            self.assertEqual(prd3_data['unit_of_money'], bi1.unit_of_money)
            self.assertEqual(prd3_data['statements'], '')

            s3 = boto3.client('s3')
            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FX/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FX/{target_month[0:4]}/billing_FX_{target_month}.csv')

    @mock_s3
    def test_multi_opco_code_one_detail_one_usage_per_detail(self):
        """
        仕向け地:N、請求情報:1、請求明細:1、利用明細:1の場合のテスト
        :return:
        """
        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract_FX = ContractInfoFactory(subscription_id=1, opco_code='FX')
        product1 = ProductInfoFactory()
        fx_bi = BillingInfoFactory(subscription=contract_FX, target_month=target_month, state=COMPLETED)
        fx_bdi = BillingDetailInfoFactory(subscription=contract_FX, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract_FX, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=100, quantity=10)

        contract_FXS = ContractInfoFactory(subscription_id=2, opco_code='FXS')
        product2 = ProductInfoFactory()
        fxs_bi = BillingInfoFactory(subscription=contract_FXS, target_month=target_month, state=COMPLETED)
        fxs_bdi = BillingDetailInfoFactory(subscription=contract_FXS, target_month=target_month, product_code=product2)
        BillingUsageDetailInfoFactory(subscription=contract_FXS, target_month=target_month,
                                      product_code=product2, license_user='user02', billing=2222, quantity=2)

        out = StringIO()
        call_command(COMMAND,  stdout=out)

        # 2レコード生成されるはず
        file_name = os.path.join(get_tmp_dir(), 'billing_FX.csv')
        with open(file_name, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '1')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi.unit_of_money)

            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(1, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user01')
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')

            s3 = boto3.client('s3')
            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FX/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FX/{target_month[0:4]}/billing_FX_{target_month}.csv')

        file_name = os.path.join(get_tmp_dir(), 'billing_FXS.csv')
        with open(file_name, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            fxs_data = next(f)
            self.assertEqual(fxs_data['#subscription_id'], '2')
            self.assertEqual(fxs_data['target_month'], target_month)
            self.assertEqual(fxs_data['opco_code'], contract_FXS.opco_code)
            self.assertEqual(fxs_data['start_date'], str(fxs_bi.start_date))
            self.assertEqual(fxs_data['end_date'], str(fxs_bi.end_date))
            self.assertEqual(fxs_data['billing'], str(fxs_bi.billing))
            self.assertEqual(fxs_data['product_code'], fxs_bdi.product_code.product_code)
            self.assertEqual(fxs_data['license_quantity'], str(fxs_bdi.license_quantity))
            self.assertEqual(fxs_data['billing_for_product_code'], str(fxs_bdi.billing))
            self.assertEqual(fxs_data['quantity'], str(fxs_bdi.quantity))
            self.assertEqual(fxs_data['unit_of_money'], fxs_bi.unit_of_money)
            xml = ET.fromstring(fxs_data['statements'])
            statements = list(xml)
            self.assertEqual(1, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user02')
            self.assertEqual(statement.find('billing').text, '2222')
            self.assertEqual(statement.find('quantity').text, '2')

            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FXS/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FXS/{target_month[0:4]}/billing_FXS_{target_month}.csv')

    @mock_s3
    def test_multi_opco_code_one_detail_multi_usage_per_detail(self):
        """
        仕向け地:N、請求情報:1、請求明細:1、利用明細:Nの場合のテスト
        :return:
        """
        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract_FX = ContractInfoFactory(subscription_id=1, opco_code='FX')
        product1 = ProductInfoFactory()
        fx_bi = BillingInfoFactory(subscription=contract_FX, target_month=target_month, state=COMPLETED)
        fx_bdi = BillingDetailInfoFactory(subscription=contract_FX, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract_FX, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=100, quantity=10)
        BillingUsageDetailInfoFactory(subscription=contract_FX, target_month=target_month,
                                      product_code=product1, license_user='user02', billing=200, quantity=2)

        contract_FXS = ContractInfoFactory(subscription_id=2, opco_code='FXS')
        product2 = ProductInfoFactory()
        fxs_bi = BillingInfoFactory(subscription=contract_FXS, target_month=target_month, state=COMPLETED)
        fxs_bdi = BillingDetailInfoFactory(subscription=contract_FXS, target_month=target_month, product_code=product2)
        BillingUsageDetailInfoFactory(subscription=contract_FXS, target_month=target_month,
                                      product_code=product2, license_user='user03', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract_FXS, target_month=target_month,
                                      product_code=product2, license_user='user04', billing=4444, quantity=4)
        BillingUsageDetailInfoFactory(subscription=contract_FXS, target_month=target_month,
                                      product_code=product2, license_user='user05', billing=5555, quantity=5)

        out = StringIO()
        call_command(COMMAND,  stdout=out)
        file_name = os.path.join(get_tmp_dir(), 'billing_FX.csv')
        with open(file_name, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '1')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi.unit_of_money)

            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(2, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user01')
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user02')
            self.assertEqual(statement.find('billing').text, '200')
            self.assertEqual(statement.find('quantity').text, '2')

            s3 = boto3.client('s3')
            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FX/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FX/{target_month[0:4]}/billing_FX_{target_month}.csv')

        file_name = os.path.join(get_tmp_dir(), 'billing_FXS.csv')
        with open(file_name, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            fxs_data = next(f)
            self.assertEqual(fxs_data['#subscription_id'], '2')
            self.assertEqual(fxs_data['target_month'], target_month)
            self.assertEqual(fxs_data['opco_code'], contract_FXS.opco_code)
            self.assertEqual(fxs_data['start_date'], str(fxs_bi.start_date))
            self.assertEqual(fxs_data['end_date'], str(fxs_bi.end_date))
            self.assertEqual(fxs_data['billing'], str(fxs_bi.billing))
            self.assertEqual(fxs_data['product_code'], fxs_bdi.product_code.product_code)
            self.assertEqual(fxs_data['license_quantity'], str(fxs_bdi.license_quantity))
            self.assertEqual(fxs_data['billing_for_product_code'], str(fxs_bdi.billing))
            self.assertEqual(fxs_data['quantity'], str(fxs_bdi.quantity))
            self.assertEqual(fxs_data['unit_of_money'], fxs_bi.unit_of_money)

            xml = ET.fromstring(fxs_data['statements'])
            statements = list(xml)
            self.assertEqual(3, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '4444')
            self.assertEqual(statement.find('quantity').text, '4')
            statement = statements[2]
            self.assertEqual(statement.find('license-user').text, 'user05')
            self.assertEqual(statement.find('billing').text, '5555')
            self.assertEqual(statement.find('quantity').text, '5')

            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FXS/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FXS/{target_month[0:4]}/billing_FXS_{target_month}.csv')



    @mock_s3
    def test_multi_opco_code_multi_detail_multi_usage_per_detail(self):
        """
        仕向け地:N、請求情報:1、請求明細:N、利用明細:Nの場合のテスト
        :return:
        """
        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract_FX = ContractInfoFactory(subscription_id=1, opco_code='FX')
        product1 = ProductInfoFactory()
        product2 = ProductInfoFactory()
        product3 = ProductInfoFactory()
        fx_bi = BillingInfoFactory(subscription=contract_FX, target_month=target_month, state=COMPLETED)
        fx_bdi1 = BillingDetailInfoFactory(subscription=contract_FX, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract_FX, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=100, quantity=10)
        BillingUsageDetailInfoFactory(subscription=contract_FX, target_month=target_month,
                                      product_code=product1, license_user='user02', billing=200, quantity=2)
        fx_bdi2 = BillingDetailInfoFactory(subscription=contract_FX, target_month=target_month, product_code=product2)
        fx_bdi3 = BillingDetailInfoFactory(subscription=contract_FX, target_month=target_month, product_code=product3)
        BillingUsageDetailInfoFactory(subscription=contract_FX, target_month=target_month,
                                      product_code=product3, license_user='user03', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract_FX, target_month=target_month,
                                      product_code=product3, license_user='user04', billing=4444, quantity=4)
        BillingUsageDetailInfoFactory(subscription=contract_FX, target_month=target_month,
                                      product_code=product3, license_user='user05', billing=5555, quantity=5)

        contract_FXS = ContractInfoFactory(subscription_id=2, opco_code='FXS')
        fxs_bi = BillingInfoFactory(subscription=contract_FXS, target_month=target_month, state=COMPLETED)
        fxs_bdi1 = BillingDetailInfoFactory(subscription=contract_FXS, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract_FXS, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=1000, quantity=1)

        fxs_bdi2 = BillingDetailInfoFactory(subscription=contract_FXS, target_month=target_month, product_code=product2)
        BillingUsageDetailInfoFactory(subscription=contract_FXS, target_month=target_month,
                                      product_code=product2, license_user='user03', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract_FXS, target_month=target_month,
                                      product_code=product2, license_user='user04', billing=4444, quantity=4)

        out = StringIO()
        call_command(COMMAND,  stdout=out)
        file_name = os.path.join(get_tmp_dir(), 'billing_FX.csv')
        with open(file_name, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '1')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi1.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi1.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi1.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi1.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi.unit_of_money)
            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(2, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user01')
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user02')
            self.assertEqual(statement.find('billing').text, '200')
            self.assertEqual(statement.find('quantity').text, '2')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '1')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi2.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi2.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi2.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi2.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi.unit_of_money)
            self.assertEqual(fx_data['statements'], '')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '1')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi3.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi3.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi3.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi3.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi.unit_of_money)
            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(3, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '4444')
            self.assertEqual(statement.find('quantity').text, '4')
            statement = statements[2]
            self.assertEqual(statement.find('license-user').text, 'user05')
            self.assertEqual(statement.find('billing').text, '5555')
            self.assertEqual(statement.find('quantity').text, '5')

            s3 = boto3.client('s3')
            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FX/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FX/{target_month[0:4]}/billing_FX_{target_month}.csv')

        file_name = os.path.join(get_tmp_dir(), 'billing_FXS.csv')
        with open(file_name, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            fxs_data = next(f)
            self.assertEqual(fxs_data['#subscription_id'], '2')
            self.assertEqual(fxs_data['target_month'], target_month)
            self.assertEqual(fxs_data['opco_code'], contract_FXS.opco_code)
            self.assertEqual(fxs_data['start_date'], str(fxs_bi.start_date))
            self.assertEqual(fxs_data['end_date'], str(fxs_bi.end_date))
            self.assertEqual(fxs_data['billing'], str(fxs_bi.billing))
            self.assertEqual(fxs_data['product_code'], fxs_bdi1.product_code.product_code)
            self.assertEqual(fxs_data['license_quantity'], str(fxs_bdi1.license_quantity))
            self.assertEqual(fxs_data['billing_for_product_code'], str(fxs_bdi1.billing))
            self.assertEqual(fxs_data['quantity'], str(fxs_bdi1.quantity))
            self.assertEqual(fxs_data['unit_of_money'], fxs_bi.unit_of_money)

            xml = ET.fromstring(fxs_data['statements'])
            statements = list(xml)
            self.assertEqual(1, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user01')
            self.assertEqual(statement.find('billing').text, '1000')
            self.assertEqual(statement.find('quantity').text, '1')

            fxs_data = next(f)
            self.assertEqual(fxs_data['#subscription_id'], '2')
            self.assertEqual(fxs_data['target_month'], target_month)
            self.assertEqual(fxs_data['opco_code'], contract_FXS.opco_code)
            self.assertEqual(fxs_data['start_date'], str(fxs_bi.start_date))
            self.assertEqual(fxs_data['end_date'], str(fxs_bi.end_date))
            self.assertEqual(fxs_data['billing'], str(fxs_bi.billing))
            self.assertEqual(fxs_data['product_code'], fxs_bdi2.product_code.product_code)
            self.assertEqual(fxs_data['license_quantity'], str(fxs_bdi2.license_quantity))
            self.assertEqual(fxs_data['billing_for_product_code'], str(fxs_bdi2.billing))
            self.assertEqual(fxs_data['quantity'], str(fxs_bdi2.quantity))
            self.assertEqual(fxs_data['unit_of_money'], fxs_bi.unit_of_money)

            xml = ET.fromstring(fxs_data['statements'])
            statements = list(xml)
            self.assertEqual(2, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '4444')
            self.assertEqual(statement.find('quantity').text, '4')

            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FXS/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FXS/{target_month[0:4]}/billing_FXS_{target_month}.csv')

    @mock_s3
    def test_multi_opco_code_multi_contract_multi_detail_multi_usage_per_detail(self):
        """
        仕向け地:N、請求情報:N、請求明細:N、利用明細:Nの場合のテスト
        :return:
        """
        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract_FX1 = ContractInfoFactory(subscription_id=1, opco_code='FX')
        product1 = ProductInfoFactory()
        product2 = ProductInfoFactory()
        product3 = ProductInfoFactory()
        product4 = ProductInfoFactory()
        product5 = ProductInfoFactory()
        fx_bi1 = BillingInfoFactory(subscription=contract_FX1, target_month=target_month, state=COMPLETED)
        fx_bdi1 = BillingDetailInfoFactory(subscription=contract_FX1, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract_FX1, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=100, quantity=10)
        BillingUsageDetailInfoFactory(subscription=contract_FX1, target_month=target_month,
                                      product_code=product1, license_user='user02', billing=200, quantity=2)
        fx_bdi2 = BillingDetailInfoFactory(subscription=contract_FX1, target_month=target_month, product_code=product2)
        fx_bdi3 = BillingDetailInfoFactory(subscription=contract_FX1, target_month=target_month, product_code=product3)
        BillingUsageDetailInfoFactory(subscription=contract_FX1, target_month=target_month,
                                      product_code=product3, license_user='user03', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract_FX1, target_month=target_month,
                                      product_code=product3, license_user='user04', billing=4444, quantity=4)
        BillingUsageDetailInfoFactory(subscription=contract_FX1, target_month=target_month,
                                      product_code=product3, license_user='user05', billing=5555, quantity=5)

        contract_FXS1 = ContractInfoFactory(subscription_id=2, opco_code='FXS')
        fxs_bi1 = BillingInfoFactory(subscription=contract_FXS1, target_month=target_month, state=COMPLETED)
        fxs_bdi1 = BillingDetailInfoFactory(subscription=contract_FXS1, target_month=target_month,
                                            product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract_FXS1, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=1000, quantity=1)

        fxs_bdi2 = BillingDetailInfoFactory(subscription=contract_FXS1, target_month=target_month,
                                            product_code=product2)
        BillingUsageDetailInfoFactory(subscription=contract_FXS1, target_month=target_month,
                                      product_code=product2, license_user='user03', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract_FXS1, target_month=target_month,
                                      product_code=product2, license_user='user04', billing=4444, quantity=4)

        contract_FX2 = ContractInfoFactory(subscription_id=3, opco_code='FX')
        fx_bi2 = BillingInfoFactory(subscription=contract_FX2, target_month=target_month, state=COMPLETED)
        fx_bdi4 = BillingDetailInfoFactory(subscription=contract_FX2, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract_FX2, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=100, quantity=10)
        fx_bdi5 = BillingDetailInfoFactory(subscription=contract_FX2, target_month=target_month, product_code=product2)
        BillingUsageDetailInfoFactory(subscription=contract_FX2, target_month=target_month,
                                      product_code=product2, license_user='user03', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract_FX2, target_month=target_month,
                                      product_code=product2, license_user='user04', billing=4444, quantity=4)
        fx_bdi6 = BillingDetailInfoFactory(subscription=contract_FX2, target_month=target_month, product_code=product3)
        BillingUsageDetailInfoFactory(subscription=contract_FX2, target_month=target_month,
                                      product_code=product3, license_user='user03', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract_FX2, target_month=target_month,
                                      product_code=product3, license_user='user04', billing=4444, quantity=4)
        BillingUsageDetailInfoFactory(subscription=contract_FX2, target_month=target_month,
                                      product_code=product3, license_user='user05', billing=5555, quantity=5)

        contract_FXS2 = ContractInfoFactory(subscription_id=4, opco_code='FXS')
        fxs_bi2 = BillingInfoFactory(subscription=contract_FXS2, target_month=target_month, state=COMPLETED)
        fxs_bdi3 = BillingDetailInfoFactory(subscription=contract_FXS2, target_month=target_month,
                                            product_code=product1)
        fxs_bdi4 = BillingDetailInfoFactory(subscription=contract_FXS2, target_month=target_month,
                                            product_code=product2)
        BillingUsageDetailInfoFactory(subscription=contract_FXS2, target_month=target_month,
                                      product_code=product2, license_user='user03', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract_FXS2, target_month=target_month,
                                      product_code=product2, license_user='user04', billing=4444, quantity=4)

        out = StringIO()
        call_command(COMMAND,  stdout=out)
        file_name = os.path.join(get_tmp_dir(), 'billing_FX.csv')
        with open(file_name, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '1')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX1.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi1.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi1.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi1.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi1.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi1.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi1.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi1.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi1.unit_of_money)
            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(2, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user01')
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user02')
            self.assertEqual(statement.find('billing').text, '200')
            self.assertEqual(statement.find('quantity').text, '2')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '1')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX1.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi1.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi1.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi1.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi2.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi2.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi2.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi2.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi1.unit_of_money)
            self.assertEqual(fx_data['statements'], '')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '1')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX1.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi1.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi1.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi1.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi3.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi3.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi3.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi3.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi1.unit_of_money)
            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(3, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '4444')
            self.assertEqual(statement.find('quantity').text, '4')
            statement = statements[2]
            self.assertEqual(statement.find('license-user').text, 'user05')
            self.assertEqual(statement.find('billing').text, '5555')
            self.assertEqual(statement.find('quantity').text, '5')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '3')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX1.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi2.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi2.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi2.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi4.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi4.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi4.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi4.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi2.unit_of_money)
            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(1, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user01')
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '3')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX1.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi2.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi2.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi2.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi5.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi5.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi5.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi5.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi2.unit_of_money)
            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(2, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '4444')
            self.assertEqual(statement.find('quantity').text, '4')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '3')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX1.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi2.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi2.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi2.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi6.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi6.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi6.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi6.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi2.unit_of_money)
            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(3, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '4444')
            self.assertEqual(statement.find('quantity').text, '4')
            statement = statements[2]
            self.assertEqual(statement.find('license-user').text, 'user05')
            self.assertEqual(statement.find('billing').text, '5555')
            self.assertEqual(statement.find('quantity').text, '5')

            s3 = boto3.client('s3')
            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FX/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FX/{target_month[0:4]}/billing_FX_{target_month}.csv')

        file_name = os.path.join(get_tmp_dir(), 'billing_FXS.csv')
        with open(file_name, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            fxs_data = next(f)
            self.assertEqual(fxs_data['#subscription_id'], '2')
            self.assertEqual(fxs_data['target_month'], target_month)
            self.assertEqual(fxs_data['opco_code'], contract_FXS1.opco_code)
            self.assertEqual(fxs_data['start_date'], str(fxs_bi1.start_date))
            self.assertEqual(fxs_data['end_date'], str(fxs_bi1.end_date))
            self.assertEqual(fxs_data['billing'], str(fxs_bi1.billing))
            self.assertEqual(fxs_data['product_code'], fxs_bdi1.product_code.product_code)
            self.assertEqual(fxs_data['license_quantity'], str(fxs_bdi1.license_quantity))
            self.assertEqual(fxs_data['billing_for_product_code'], str(fxs_bdi1.billing))
            self.assertEqual(fxs_data['quantity'], str(fxs_bdi1.quantity))
            self.assertEqual(fxs_data['unit_of_money'], fxs_bi1.unit_of_money)

            xml = ET.fromstring(fxs_data['statements'])
            statements = list(xml)
            self.assertEqual(1, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user01')
            self.assertEqual(statement.find('billing').text, '1000')
            self.assertEqual(statement.find('quantity').text, '1')

            fxs_data = next(f)
            self.assertEqual(fxs_data['#subscription_id'], '2')
            self.assertEqual(fxs_data['target_month'], target_month)
            self.assertEqual(fxs_data['opco_code'], contract_FXS1.opco_code)
            self.assertEqual(fxs_data['start_date'], str(fxs_bi1.start_date))
            self.assertEqual(fxs_data['end_date'], str(fxs_bi1.end_date))
            self.assertEqual(fxs_data['billing'], str(fxs_bi1.billing))
            self.assertEqual(fxs_data['product_code'], fxs_bdi2.product_code.product_code)
            self.assertEqual(fxs_data['license_quantity'], str(fxs_bdi2.license_quantity))
            self.assertEqual(fxs_data['billing_for_product_code'], str(fxs_bdi2.billing))
            self.assertEqual(fxs_data['quantity'], str(fxs_bdi2.quantity))
            self.assertEqual(fxs_data['unit_of_money'], fxs_bi1.unit_of_money)
            xml = ET.fromstring(fxs_data['statements'])
            statements = list(xml)
            self.assertEqual(2, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '4444')
            self.assertEqual(statement.find('quantity').text, '4')

            fxs_data = next(f)
            self.assertEqual(fxs_data['#subscription_id'], '4')
            self.assertEqual(fxs_data['target_month'], target_month)
            self.assertEqual(fxs_data['opco_code'], contract_FXS2.opco_code)
            self.assertEqual(fxs_data['start_date'], str(fxs_bi2.start_date))
            self.assertEqual(fxs_data['end_date'], str(fxs_bi2.end_date))
            self.assertEqual(fxs_data['billing'], str(fxs_bi2.billing))
            self.assertEqual(fxs_data['product_code'], fxs_bdi3.product_code.product_code)
            self.assertEqual(fxs_data['license_quantity'], str(fxs_bdi3.license_quantity))
            self.assertEqual(fxs_data['billing_for_product_code'], str(fxs_bdi3.billing))
            self.assertEqual(fxs_data['quantity'], str(fxs_bdi3.quantity))
            self.assertEqual(fxs_data['unit_of_money'], fxs_bi2.unit_of_money)
            self.assertEqual(fxs_data['statements'], '')

            fxs_data = next(f)
            self.assertEqual(fxs_data['#subscription_id'], '4')
            self.assertEqual(fxs_data['target_month'], target_month)
            self.assertEqual(fxs_data['opco_code'], contract_FXS2.opco_code)
            self.assertEqual(fxs_data['start_date'], str(fxs_bi2.start_date))
            self.assertEqual(fxs_data['end_date'], str(fxs_bi2.end_date))
            self.assertEqual(fxs_data['billing'], str(fxs_bi2.billing))
            self.assertEqual(fxs_data['product_code'], fxs_bdi4.product_code.product_code)
            self.assertEqual(fxs_data['license_quantity'], str(fxs_bdi4.license_quantity))
            self.assertEqual(fxs_data['billing_for_product_code'], str(fxs_bdi4.billing))
            self.assertEqual(fxs_data['quantity'], str(fxs_bdi4.quantity))
            self.assertEqual(fxs_data['unit_of_money'], fxs_bi2.unit_of_money)
            xml = ET.fromstring(fxs_data['statements'])
            statements = list(xml)
            self.assertEqual(2, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '4444')
            self.assertEqual(statement.find('quantity').text, '4')

            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FXS/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FXS/{target_month[0:4]}/billing_FXS_{target_month}.csv')

    @mock_s3
    @freezegun.freeze_time('2020-02-29 23:00:00')
    def test_leap_year(self):
        """
        閏年の2/29にバッチが実行されても正常に処理できることをテストする
        :return:
        """
        self.__common_special_date_test()

    @mock_s3
    @freezegun.freeze_time('2018-01-31 23:00:00')
    def test_january(self):
        """
        1/31(前月が去年)にバッチが実行されても正常に処理できることをテストする
        :return:
        """
        self.__common_special_date_test()

    @mock_s3
    @freezegun.freeze_time('2020-12-31 23:00:00')
    def test_december(self):
        """
        12/31(翌月が来年)にバッチが実行されても正常に処理できることをテストする
        :return:
        """
        self.__common_special_date_test()

    def __common_special_date_test(self):
        """
        特殊な日付のテストケースで使い回す共通のアサーション
        :return:
        """
        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract_FX1 = ContractInfoFactory(subscription_id=1, opco_code='FX')
        product1 = ProductInfoFactory()
        product2 = ProductInfoFactory()
        product3 = ProductInfoFactory()
        product4 = ProductInfoFactory()
        product5 = ProductInfoFactory()
        fx_bi1 = BillingInfoFactory(subscription=contract_FX1, target_month=target_month, state=COMPLETED)
        fx_bdi1 = BillingDetailInfoFactory(subscription=contract_FX1, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract_FX1, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=100, quantity=10)
        BillingUsageDetailInfoFactory(subscription=contract_FX1, target_month=target_month,
                                      product_code=product1, license_user='user02', billing=200, quantity=2)
        fx_bdi2 = BillingDetailInfoFactory(subscription=contract_FX1, target_month=target_month, product_code=product2)
        fx_bdi3 = BillingDetailInfoFactory(subscription=contract_FX1, target_month=target_month, product_code=product3)
        BillingUsageDetailInfoFactory(subscription=contract_FX1, target_month=target_month,
                                      product_code=product3, license_user='user03', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract_FX1, target_month=target_month,
                                      product_code=product3, license_user='user04', billing=4444, quantity=4)
        BillingUsageDetailInfoFactory(subscription=contract_FX1, target_month=target_month,
                                      product_code=product3, license_user='user05', billing=5555, quantity=5)

        contract_FXS1 = ContractInfoFactory(subscription_id=2, opco_code='FXS')
        fxs_bi1 = BillingInfoFactory(subscription=contract_FXS1, target_month=target_month, state=COMPLETED)
        fxs_bdi1 = BillingDetailInfoFactory(subscription=contract_FXS1, target_month=target_month,
                                            product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract_FXS1, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=1000, quantity=1)

        fxs_bdi2 = BillingDetailInfoFactory(subscription=contract_FXS1, target_month=target_month,
                                            product_code=product2)
        BillingUsageDetailInfoFactory(subscription=contract_FXS1, target_month=target_month,
                                      product_code=product2, license_user='user03', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract_FXS1, target_month=target_month,
                                      product_code=product2, license_user='user04', billing=4444, quantity=4)

        contract_FX2 = ContractInfoFactory(subscription_id=3, opco_code='FX')
        fx_bi2 = BillingInfoFactory(subscription=contract_FX2, target_month=target_month, state=COMPLETED)
        fx_bdi4 = BillingDetailInfoFactory(subscription=contract_FX2, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract_FX2, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=100, quantity=10)
        fx_bdi5 = BillingDetailInfoFactory(subscription=contract_FX2, target_month=target_month, product_code=product2)
        BillingUsageDetailInfoFactory(subscription=contract_FX2, target_month=target_month,
                                      product_code=product2, license_user='user03', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract_FX2, target_month=target_month,
                                      product_code=product2, license_user='user04', billing=4444, quantity=4)
        fx_bdi6 = BillingDetailInfoFactory(subscription=contract_FX2, target_month=target_month, product_code=product3)
        BillingUsageDetailInfoFactory(subscription=contract_FX2, target_month=target_month,
                                      product_code=product3, license_user='user03', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract_FX2, target_month=target_month,
                                      product_code=product3, license_user='user04', billing=4444, quantity=4)
        BillingUsageDetailInfoFactory(subscription=contract_FX2, target_month=target_month,
                                      product_code=product3, license_user='user05', billing=5555, quantity=5)

        contract_FXS2 = ContractInfoFactory(subscription_id=4, opco_code='FXS')
        fxs_bi2 = BillingInfoFactory(subscription=contract_FXS2, target_month=target_month, state=COMPLETED)
        fxs_bdi3 = BillingDetailInfoFactory(subscription=contract_FXS2, target_month=target_month,
                                            product_code=product1)
        fxs_bdi4 = BillingDetailInfoFactory(subscription=contract_FXS2, target_month=target_month,
                                            product_code=product2)
        BillingUsageDetailInfoFactory(subscription=contract_FXS2, target_month=target_month,
                                      product_code=product2, license_user='user03', billing=3333, quantity=3)
        BillingUsageDetailInfoFactory(subscription=contract_FXS2, target_month=target_month,
                                      product_code=product2, license_user='user04', billing=4444, quantity=4)

        out = StringIO()
        call_command(COMMAND,  stdout=out)
        file_name = os.path.join(get_tmp_dir(), 'billing_FX.csv')
        with open(file_name, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '1')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX1.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi1.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi1.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi1.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi1.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi1.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi1.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi1.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi1.unit_of_money)
            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(2, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user01')
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user02')
            self.assertEqual(statement.find('billing').text, '200')
            self.assertEqual(statement.find('quantity').text, '2')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '1')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX1.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi1.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi1.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi1.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi2.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi2.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi2.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi2.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi1.unit_of_money)
            self.assertEqual(fx_data['statements'], '')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '1')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX1.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi1.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi1.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi1.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi3.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi3.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi3.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi3.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi1.unit_of_money)
            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(3, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '4444')
            self.assertEqual(statement.find('quantity').text, '4')
            statement = statements[2]
            self.assertEqual(statement.find('license-user').text, 'user05')
            self.assertEqual(statement.find('billing').text, '5555')
            self.assertEqual(statement.find('quantity').text, '5')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '3')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX1.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi2.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi2.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi2.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi4.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi4.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi4.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi4.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi2.unit_of_money)
            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(1, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user01')
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '3')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX1.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi2.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi2.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi2.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi5.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi5.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi5.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi5.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi2.unit_of_money)
            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(2, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '4444')
            self.assertEqual(statement.find('quantity').text, '4')

            fx_data = next(f)
            self.assertEqual(fx_data['#subscription_id'], '3')
            self.assertEqual(fx_data['target_month'], target_month)
            self.assertEqual(fx_data['opco_code'], contract_FX1.opco_code)
            self.assertEqual(fx_data['start_date'], str(fx_bi2.start_date))
            self.assertEqual(fx_data['end_date'], str(fx_bi2.end_date))
            self.assertEqual(fx_data['billing'], str(fx_bi2.billing))
            self.assertEqual(fx_data['product_code'], fx_bdi6.product_code.product_code)
            self.assertEqual(fx_data['license_quantity'], str(fx_bdi6.license_quantity))
            self.assertEqual(fx_data['billing_for_product_code'], str(fx_bdi6.billing))
            self.assertEqual(fx_data['quantity'], str(fx_bdi6.quantity))
            self.assertEqual(fx_data['unit_of_money'], fx_bi2.unit_of_money)
            xml = ET.fromstring(fx_data['statements'])
            statements = list(xml)
            self.assertEqual(3, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '4444')
            self.assertEqual(statement.find('quantity').text, '4')
            statement = statements[2]
            self.assertEqual(statement.find('license-user').text, 'user05')
            self.assertEqual(statement.find('billing').text, '5555')
            self.assertEqual(statement.find('quantity').text, '5')

            s3 = boto3.client('s3')
            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FX/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FX/{target_month[0:4]}/billing_FX_{target_month}.csv')

        file_name = os.path.join(get_tmp_dir(), 'billing_FXS.csv')
        with open(file_name, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            fxs_data = next(f)
            self.assertEqual(fxs_data['#subscription_id'], '2')
            self.assertEqual(fxs_data['target_month'], target_month)
            self.assertEqual(fxs_data['opco_code'], contract_FXS1.opco_code)
            self.assertEqual(fxs_data['start_date'], str(fxs_bi1.start_date))
            self.assertEqual(fxs_data['end_date'], str(fxs_bi1.end_date))
            self.assertEqual(fxs_data['billing'], str(fxs_bi1.billing))
            self.assertEqual(fxs_data['product_code'], fxs_bdi1.product_code.product_code)
            self.assertEqual(fxs_data['license_quantity'], str(fxs_bdi1.license_quantity))
            self.assertEqual(fxs_data['billing_for_product_code'], str(fxs_bdi1.billing))
            self.assertEqual(fxs_data['quantity'], str(fxs_bdi1.quantity))
            self.assertEqual(fxs_data['unit_of_money'], fxs_bi1.unit_of_money)

            xml = ET.fromstring(fxs_data['statements'])
            statements = list(xml)
            self.assertEqual(1, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user01')
            self.assertEqual(statement.find('billing').text, '1000')
            self.assertEqual(statement.find('quantity').text, '1')

            fxs_data = next(f)
            self.assertEqual(fxs_data['#subscription_id'], '2')
            self.assertEqual(fxs_data['target_month'], target_month)
            self.assertEqual(fxs_data['opco_code'], contract_FXS1.opco_code)
            self.assertEqual(fxs_data['start_date'], str(fxs_bi1.start_date))
            self.assertEqual(fxs_data['end_date'], str(fxs_bi1.end_date))
            self.assertEqual(fxs_data['billing'], str(fxs_bi1.billing))
            self.assertEqual(fxs_data['product_code'], fxs_bdi2.product_code.product_code)
            self.assertEqual(fxs_data['license_quantity'], str(fxs_bdi2.license_quantity))
            self.assertEqual(fxs_data['billing_for_product_code'], str(fxs_bdi2.billing))
            self.assertEqual(fxs_data['quantity'], str(fxs_bdi2.quantity))
            self.assertEqual(fxs_data['unit_of_money'], fxs_bi1.unit_of_money)
            xml = ET.fromstring(fxs_data['statements'])
            statements = list(xml)
            self.assertEqual(2, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '4444')
            self.assertEqual(statement.find('quantity').text, '4')

            fxs_data = next(f)
            self.assertEqual(fxs_data['#subscription_id'], '4')
            self.assertEqual(fxs_data['target_month'], target_month)
            self.assertEqual(fxs_data['opco_code'], contract_FXS2.opco_code)
            self.assertEqual(fxs_data['start_date'], str(fxs_bi2.start_date))
            self.assertEqual(fxs_data['end_date'], str(fxs_bi2.end_date))
            self.assertEqual(fxs_data['billing'], str(fxs_bi2.billing))
            self.assertEqual(fxs_data['product_code'], fxs_bdi3.product_code.product_code)
            self.assertEqual(fxs_data['license_quantity'], str(fxs_bdi3.license_quantity))
            self.assertEqual(fxs_data['billing_for_product_code'], str(fxs_bdi3.billing))
            self.assertEqual(fxs_data['quantity'], str(fxs_bdi3.quantity))
            self.assertEqual(fxs_data['unit_of_money'], fxs_bi2.unit_of_money)
            self.assertEqual(fxs_data['statements'], '')

            fxs_data = next(f)
            self.assertEqual(fxs_data['#subscription_id'], '4')
            self.assertEqual(fxs_data['target_month'], target_month)
            self.assertEqual(fxs_data['opco_code'], contract_FXS2.opco_code)
            self.assertEqual(fxs_data['start_date'], str(fxs_bi2.start_date))
            self.assertEqual(fxs_data['end_date'], str(fxs_bi2.end_date))
            self.assertEqual(fxs_data['billing'], str(fxs_bi2.billing))
            self.assertEqual(fxs_data['product_code'], fxs_bdi4.product_code.product_code)
            self.assertEqual(fxs_data['license_quantity'], str(fxs_bdi4.license_quantity))
            self.assertEqual(fxs_data['billing_for_product_code'], str(fxs_bdi4.billing))
            self.assertEqual(fxs_data['quantity'], str(fxs_bdi4.quantity))
            self.assertEqual(fxs_data['unit_of_money'], fxs_bi2.unit_of_money)
            xml = ET.fromstring(fxs_data['statements'])
            statements = list(xml)
            self.assertEqual(2, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '3333')
            self.assertEqual(statement.find('quantity').text, '3')
            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, 'user04')
            self.assertEqual(statement.find('billing').text, '4444')
            self.assertEqual(statement.find('quantity').text, '4')

            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FXS/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FXS/{target_month[0:4]}/billing_FXS_{target_month}.csv')

    @mock_s3
    @mock.patch('logging.Logger.error')
    def test_non_completed_billing(self, mock_logger):
        """
        全請求情報の状態が計算完了になっていない場合のテスト
        :return:
        """

        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract1 = ContractInfoFactory(subscription_id=1, opco_code='FX')
        product1 = ProductInfoFactory()
        BillingInfoFactory(subscription=contract1, target_month=target_month, state=NEW)
        BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product1)

        out = StringIO()
        call_command(COMMAND,  stdout=out)
        mock_logger.assert_called_once_with(
            f'billing state is invalid... skip output billing info  '
            f'subscription_id:1 target_month:{target_month} state:{NEW}'
        )

    @mock_s3
    @mock.patch('logging.Logger.error')
    def test_non_completed_billing_multi_detail(self, mock_logger):
        """
        全請求情報の状態が計算完了になっていない場合のテスト
        複数の明細が紐づいた場合でも、エラーログが１回しか出力されないことを
        テストする
        https://soldev-env.fujixerox.co.jp/redmine/issues/55405
        :return:
        """

        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract1 = ContractInfoFactory(subscription_id=1, opco_code='FX')
        product1 = ProductInfoFactory()
        product2 = ProductInfoFactory()
        BillingInfoFactory(subscription=contract1, target_month=target_month, state=NEW)
        BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product1)
        BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product2)

        out = StringIO()
        call_command(COMMAND,  stdout=out)
        mock_logger.assert_called_once_with(
            f'billing state is invalid... skip output billing info  '
            f'subscription_id:1 target_month:{target_month} state:{NEW}'
        )

    @mock_s3
    @mock.patch('logging.Logger.error')
    def test_non_completed_billing_and_completed_billing(self, mock_logger):
        """
        請求情報の状態に計算完了と計算完了以外が混在している場合のテスト
        :return:
        """

        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract1 = ContractInfoFactory(subscription_id=1, opco_code='FX')
        product1 = ProductInfoFactory()
        BillingInfoFactory(subscription=contract1, target_month=target_month, state=NEW)
        BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract1, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=100, quantity=10)

        contract2 = ContractInfoFactory(subscription_id=2, opco_code='FX')
        bi1 = BillingInfoFactory(subscription=contract2, target_month=target_month, state=COMPLETED)
        bdi1 = BillingDetailInfoFactory(subscription=contract2, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract2, target_month=target_month,
                                      product_code=product1, license_user='user02', billing=200, quantity=2)

        contract3 = ContractInfoFactory(subscription_id=3, opco_code='FX')
        bi2 = BillingInfoFactory(subscription=contract3, target_month=target_month, state=COMPLETED)
        bdi2 = BillingDetailInfoFactory(subscription=contract3, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract3, target_month=target_month,
                                      product_code=product1, license_user='user03', billing=300, quantity=3)

        contract4 = ContractInfoFactory(subscription_id=4, opco_code='FX')
        BillingInfoFactory(subscription=contract4, target_month=target_month, state=NEW)
        BillingDetailInfoFactory(subscription=contract4, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract4, target_month=target_month,
                                      product_code=product1, license_user='user04', billing=100, quantity=10)

        contract5 = ContractInfoFactory(subscription_id=5, opco_code='FX')
        BillingInfoFactory(subscription=contract5, target_month=target_month, state=NEW)
        BillingDetailInfoFactory(subscription=contract5, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract5, target_month=target_month,
                                      product_code=product1, license_user='user05', billing=100, quantity=10)

        out = StringIO()
        call_command(COMMAND,  stdout=out)
        mock_logger.assert_has_calls([
            call(f'billing state is invalid... skip output billing info  '
                 f'subscription_id:1 target_month:{target_month} state:{NEW}'),
            call(f'billing state is invalid... skip output billing info  '
                 f'subscription_id:4 target_month:{target_month} state:{NEW}'),
            call(f'billing state is invalid... skip output billing info  '
                 f'subscription_id:5 target_month:{target_month} state:{NEW}')
        ])

        # 2レコード生成されるはず
        file_name = os.path.join(get_tmp_dir(), 'billing_FX.csv')
        with open(file_name, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            csv_record = next(f)
            self.assertEqual(csv_record['#subscription_id'], '2')
            self.assertEqual(csv_record['target_month'], target_month)
            self.assertEqual(csv_record['opco_code'], contract2.opco_code)
            self.assertEqual(csv_record['start_date'], str(bi1.start_date))
            self.assertEqual(csv_record['end_date'], str(bi1.end_date))
            self.assertEqual(csv_record['billing'], str(bi1.billing))
            self.assertEqual(csv_record['product_code'], bdi1.product_code.product_code)
            self.assertEqual(csv_record['license_quantity'], str(bdi1.license_quantity))
            self.assertEqual(csv_record['billing_for_product_code'], str(bdi1.billing))
            self.assertEqual(csv_record['quantity'], str(bdi1.quantity))
            self.assertEqual(csv_record['unit_of_money'], bi1.unit_of_money)

            xml = ET.fromstring(csv_record['statements'])
            statements = list(xml)
            self.assertEqual(1, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user02')
            self.assertEqual(statement.find('billing').text, '200')
            self.assertEqual(statement.find('quantity').text, '2')

            csv_record = next(f)
            self.assertEqual(csv_record['#subscription_id'], '3')
            self.assertEqual(csv_record['target_month'], target_month)
            self.assertEqual(csv_record['opco_code'], contract3.opco_code)
            self.assertEqual(csv_record['start_date'], str(bi2.start_date))
            self.assertEqual(csv_record['end_date'], str(bi2.end_date))
            self.assertEqual(csv_record['billing'], str(bi2.billing))
            self.assertEqual(csv_record['product_code'], bdi2.product_code.product_code)
            self.assertEqual(csv_record['license_quantity'], str(bdi2.license_quantity))
            self.assertEqual(csv_record['billing_for_product_code'], str(bdi2.billing))
            self.assertEqual(csv_record['quantity'], str(bdi2.quantity))
            self.assertEqual(csv_record['unit_of_money'], bi2.unit_of_money)
            xml = ET.fromstring(csv_record['statements'])
            statements = list(xml)
            self.assertEqual(1, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '300')
            self.assertEqual(statement.find('quantity').text, '3')

            s3 = boto3.client('s3')
            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FX/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FX/{target_month[0:4]}/billing_FX_{target_month}.csv')

    @mock_s3
    def test_xml_special_char_escape(self):
        """
        利用明細にXMLでのエスケープ処理が必要な文字列があった場合に
        適切にエスケープ処理されることをテストする
        :return:
        """

        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract1 = ContractInfoFactory(subscription_id=1, opco_code='FX')
        product1 = ProductInfoFactory()
        bi = BillingInfoFactory(subscription=contract1, target_month=target_month, state=COMPLETED)
        bdi = BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract1, target_month=target_month,
                                      product_code=product1, license_user='"', billing=100, quantity=10)
        BillingUsageDetailInfoFactory(subscription=contract1, target_month=target_month,
                                      product_code=product1, license_user='&', billing=100, quantity=10)
        BillingUsageDetailInfoFactory(subscription=contract1, target_month=target_month,
                                      product_code=product1, license_user="'", billing=100, quantity=10)
        BillingUsageDetailInfoFactory(subscription=contract1, target_month=target_month,
                                      product_code=product1, license_user='<', billing=100, quantity=10)
        BillingUsageDetailInfoFactory(subscription=contract1, target_month=target_month,
                                      product_code=product1, license_user='>', billing=100, quantity=10)


        out = StringIO()
        call_command(COMMAND,  stdout=out)

        # 1レコード生成されるはず
        filename = os.path.join(get_tmp_dir(), 'billing_FX.csv')
        with open(filename, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            prd1_data = next(f)
            self.assertEqual(prd1_data['#subscription_id'], '1')
            self.assertEqual(prd1_data['target_month'], target_month)
            self.assertEqual(prd1_data['opco_code'], contract1.opco_code)
            self.assertEqual(prd1_data['start_date'], str(bi.start_date))
            self.assertEqual(prd1_data['end_date'], str(bi.end_date))
            self.assertEqual(prd1_data['billing'], str(bi.billing))
            self.assertEqual(prd1_data['product_code'], bdi.product_code.product_code)
            self.assertEqual(prd1_data['license_quantity'], str(bdi.license_quantity))
            self.assertEqual(prd1_data['billing_for_product_code'], str(bdi.billing))
            self.assertEqual(prd1_data['quantity'], str(bdi.quantity))
            self.assertEqual(prd1_data['unit_of_money'], bi.unit_of_money)

            xml = ET.fromstring(prd1_data['statements'])
            statements = list(xml)
            self.assertEqual(5, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, '"')
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')

            statement = statements[1]
            self.assertEqual(statement.find('license-user').text, '&')
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')

            statement = statements[2]
            self.assertEqual(statement.find('license-user').text, "'")
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')

            statement = statements[3]
            self.assertEqual(statement.find('license-user').text, '<')
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')

            statement = statements[4]
            self.assertEqual(statement.find('license-user').text, '>')
            self.assertEqual(statement.find('billing').text, '100')
            self.assertEqual(statement.find('quantity').text, '10')

            s3 = boto3.client('s3')
            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FX/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FX/{target_month[0:4]}/billing_FX_{target_month}.csv')

    @mock_s3
    def test_billing_and_profitshare(self):
        """
        請求情報とプロフィットシェア料金情報が出力される場合のテスト
        :return:
        """

        self.__create_bucket()
        target_month = DateTimeUtil.get_prev_ym()
        contract1 = ContractInfoFactory(subscription_id='1G', opco_code='FX')
        product1 = ProductInfoFactory()
        bi1 = BillingInfoFactory(subscription=contract1, target_month=target_month, state=COMPLETED)
        bdi1 = BillingDetailInfoFactory(subscription=contract1, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract1, target_month=target_month,
                                      product_code=product1, license_user='user01', billing=100, quantity=10)

        contract2 = ContractInfoFactory(subscription_id=2, opco_code='FX')
        bi2 = BillingInfoFactory(subscription=contract2, target_month=target_month, state=COMPLETED)
        bdi2 = BillingDetailInfoFactory(subscription=contract2, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract2, target_month=target_month,
                                      product_code=product1, license_user='user02', billing=200, quantity=2)

        contract3 = ContractInfoFactory(subscription_id=3, opco_code='FX')
        bi3 = BillingInfoFactory(subscription=contract3, target_month=target_month, state=COMPLETED)
        bdi3 = BillingDetailInfoFactory(subscription=contract3, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract3, target_month=target_month,
                                      product_code=product1, license_user='user03', billing=300, quantity=3)

        contract4 = ContractInfoFactory(subscription_id='4G', opco_code='FX')
        bi4 = BillingInfoFactory(subscription=contract4, target_month=target_month, state=COMPLETED)
        bdi4 = BillingDetailInfoFactory(subscription=contract4, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract4, target_month=target_month,
                                      product_code=product1, license_user='user04', billing=100, quantity=10)

        contract5 = ContractInfoFactory(subscription_id='5G', opco_code='FX')
        bi5 = BillingInfoFactory(subscription=contract5, target_month=target_month, state=COMPLETED)
        bdi5 = BillingDetailInfoFactory(subscription=contract5, target_month=target_month, product_code=product1)
        BillingUsageDetailInfoFactory(subscription=contract5, target_month=target_month,
                                      product_code=product1, license_user='user05', billing=100, quantity=10)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        file_name = os.path.join(get_tmp_dir(), 'billing_FX.csv')
        with open(file_name, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            csv_record = next(f)
            self.assertEqual(csv_record['#subscription_id'], '2')
            self.assertEqual(csv_record['target_month'], target_month)
            self.assertEqual(csv_record['opco_code'], contract2.opco_code)
            self.assertEqual(csv_record['start_date'], str(bi2.start_date))
            self.assertEqual(csv_record['end_date'], str(bi2.end_date))
            self.assertEqual(csv_record['billing'], str(bi2.billing))
            self.assertEqual(csv_record['product_code'], bdi2.product_code.product_code)
            self.assertEqual(csv_record['license_quantity'], str(bdi2.license_quantity))
            self.assertEqual(csv_record['billing_for_product_code'], str(bdi2.billing))
            self.assertEqual(csv_record['quantity'], str(bdi2.quantity))
            self.assertEqual(csv_record['unit_of_money'], bi2.unit_of_money)
            xml = ET.fromstring(csv_record['statements'])
            statements = list(xml)
            self.assertEqual(1, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user02')
            self.assertEqual(statement.find('billing').text, '200')
            self.assertEqual(statement.find('quantity').text, '2')

            csv_record = next(f)
            self.assertEqual(csv_record['#subscription_id'], '3')
            self.assertEqual(csv_record['target_month'], target_month)
            self.assertEqual(csv_record['opco_code'], contract3.opco_code)
            self.assertEqual(csv_record['start_date'], str(bi3.start_date))
            self.assertEqual(csv_record['end_date'], str(bi3.end_date))
            self.assertEqual(csv_record['billing'], str(bi3.billing))
            self.assertEqual(csv_record['product_code'], bdi3.product_code.product_code)
            self.assertEqual(csv_record['license_quantity'], str(bdi3.license_quantity))
            self.assertEqual(csv_record['billing_for_product_code'], str(bdi3.billing))
            self.assertEqual(csv_record['quantity'], str(bdi3.quantity))
            self.assertEqual(csv_record['unit_of_money'], bi3.unit_of_money)
            xml = ET.fromstring(csv_record['statements'])
            statements = list(xml)
            self.assertEqual(1, len(xml))
            statement = statements[0]
            self.assertEqual(statement.find('license-user').text, 'user03')
            self.assertEqual(statement.find('billing').text, '300')
            self.assertEqual(statement.find('quantity').text, '3')

            s3 = boto3.client('s3')
            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_BILLING_CSV_BUCKET'),
                Prefix=f'FX/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FX/{target_month[0:4]}/billing_FX_{target_month}.csv')

        file_name = os.path.join(get_tmp_dir(), 'profitshare_FX.csv')
        with open(file_name, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')

            csv_record = next(f)
            self.assertEqual(csv_record['#subscription_id'], '1G')
            self.assertEqual(csv_record['target_month'], target_month)
            self.assertEqual(csv_record['opco_code'], contract1.opco_code)
            self.assertEqual(csv_record['start_date'], str(bi1.start_date))
            self.assertEqual(csv_record['end_date'], str(bi1.end_date))
            self.assertEqual(csv_record['billing'], str(bi1.billing))
            self.assertEqual(csv_record['product_code'], bdi1.product_code.product_code)
            self.assertEqual(csv_record['license_quantity'], str(bdi1.license_quantity))
            self.assertEqual(csv_record['billing_for_product_code'], str(bdi1.billing))
            self.assertEqual(csv_record['quantity'], str(bdi1.quantity))
            self.assertEqual(csv_record['unit_of_money'], bi1.unit_of_money)
            self.assertEqual(csv_record['statements'], '')

            csv_record = next(f)
            self.assertEqual(csv_record['#subscription_id'], '4G')
            self.assertEqual(csv_record['target_month'], target_month)
            self.assertEqual(csv_record['opco_code'], contract4.opco_code)
            self.assertEqual(csv_record['start_date'], str(bi4.start_date))
            self.assertEqual(csv_record['end_date'], str(bi4.end_date))
            self.assertEqual(csv_record['billing'], str(bi4.billing))
            self.assertEqual(csv_record['product_code'], bdi4.product_code.product_code)
            self.assertEqual(csv_record['license_quantity'], str(bdi4.license_quantity))
            self.assertEqual(csv_record['billing_for_product_code'], str(bdi4.billing))
            self.assertEqual(csv_record['quantity'], str(bdi4.quantity))
            self.assertEqual(csv_record['unit_of_money'], bi4.unit_of_money)
            self.assertEqual(csv_record['statements'], '')

            csv_record = next(f)
            self.assertEqual(csv_record['#subscription_id'], '5G')
            self.assertEqual(csv_record['target_month'], target_month)
            self.assertEqual(csv_record['opco_code'], contract5.opco_code)
            self.assertEqual(csv_record['start_date'], str(bi5.start_date))
            self.assertEqual(csv_record['end_date'], str(bi5.end_date))
            self.assertEqual(csv_record['billing'], str(bi5.billing))
            self.assertEqual(csv_record['product_code'], bdi5.product_code.product_code)
            self.assertEqual(csv_record['license_quantity'], str(bdi5.license_quantity))
            self.assertEqual(csv_record['billing_for_product_code'], str(bdi5.billing))
            self.assertEqual(csv_record['quantity'], str(bdi5.quantity))
            self.assertEqual(csv_record['unit_of_money'], bi5.unit_of_money)
            self.assertEqual(csv_record['statements'], '')

            s3 = boto3.client('s3')
            res = s3.list_objects(
                Bucket=os.getenv('S3_FOR_PROFITSHARE_CSV_BUCKET'),
                Prefix=f'FX/{target_month[0:4]}'
            )
            self.assertEqual(res['Contents'][0]['Key'], f'FX/{target_month[0:4]}/profitshare_FX_{target_month}.csv')