"""
<copyright file="tests_bulkinsert.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from dateutil import parser
from pytz import timezone
from django.core.management import call_command
from django.test import TestCase
from unittest import mock
from unittest.mock import call

from lib.const.opco_code import OPCO_TIMEZONE
from status.models import CsvBatchProcessInfo
from subscriptions.models import ContractInfo, UsageInfo
from moto import mock_s3
import boto3
from botocore.exceptions import ClientError
from hashlib import md5
from datetime import datetime
from freezegun import freeze_time
from mock import patch
from lib.utils import DateTimeUtil, convert_datetime_format
from lib.const.s3_for_usage import CSV_DIR_IN, CSV_DIR_PROCESSING, CSV_DIR_OUT

COMMAND = 'bulkinsert'
BUCKET = 'bucket123'
REQUEST_ID = 'test123456'
KEY = 'IN/test123456'
KEY_WITHOUT_PREFIX = KEY.replace(CSV_DIR_IN + '/', '', 1)
CSV_HEADER = '#"subscription_id","product_code","target_month","start_date_time","end_date_time","quantity","user","free_item1","free_item2"'
CSV = f'''{CSV_HEADER}
"sub1","pro1","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10","001","testfreeitem1","testfreeitem2"
"sub2","pro2","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10"'''
utc = 'UTC'

class BulkinsertTests(TestCase):
    def setUp(self):
        self.mock = mock_s3()
        self.mock.start()

        self.s3 = boto3.resource('s3')
        self.s3.create_bucket(Bucket=BUCKET)
        self.s3.Object(BUCKET, KEY).put(Body=CSV)

        CsvBatchProcessInfo.objects.create(
            request_id=REQUEST_ID,
            requested_time=DateTimeUtil.utc_now_aware(),
            content_md5=md5(CSV.encode()).hexdigest(),
            process_result='NotProcessed',
        )

        self.sub1 = ContractInfo.objects.create(
            subscription_id='sub1',
            opco_code='FX',
            closing_day=1
        )

        self.sub2 = ContractInfo.objects.create(
            subscription_id='sub2',
            opco_code='FX',
            closing_day=2
        )

    def tearDown(self):
        self.mock.stop()

    def __put_to_s3_and_update_md5_then_call_command(self, csv):
        self.s3.Object(BUCKET, KEY).put(Body=csv)
        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        batch_process_info.content_md5 = md5(csv.encode()).hexdigest()
        batch_process_info.save()
        with self.assertRaises(SystemExit):
            call_command(COMMAND, BUCKET, KEY)

    def __convert_timezone(self, zone, time):
        check_time = parser.parse(time).astimezone(timezone(zone))
        return check_time

    def test_not_found_that_key_in_csv_batch_process_info(self):
        """
        呼び出されたキー(リクエストID)がCSV処理管理情報テーブルに存在しない
        """
        CsvBatchProcessInfo.objects.get(pk=REQUEST_ID).delete()
        with self.assertRaises(CsvBatchProcessInfo.DoesNotExist):
            call_command(COMMAND, BUCKET, KEY)

    def test_wrong_md5(self):
        """
        CSV処理管理情報テーブルのMD5が正しくない場合、エラーコードAを返すか
        """
        wrongs_md5 = 'aaaa123'
        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        batch_process_info.content_md5 = wrongs_md5
        batch_process_info.save()

        with self.assertRaises(SystemExit):
            call_command(COMMAND, BUCKET, KEY)

        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        assert batch_process_info.process_result == 'Fail'
        assert batch_process_info.error_code == 'A'

    def test_not_utf_8_csv(self):
        """
        UTF-8以外のCSVファイルの場合、エラーコードB1を返すか
        """
        wrong_encoded_csv = CSV.encode('utf-16')
        self.s3.Object(BUCKET, KEY).put(Body=wrong_encoded_csv)
        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        batch_process_info.content_md5 = md5(wrong_encoded_csv).hexdigest()
        batch_process_info.save()

        with self.assertRaises(SystemExit):
                call_command(COMMAND, BUCKET, KEY)

        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        assert batch_process_info.process_result == 'Fail'
        assert batch_process_info.error_code == 'B1'

    def test_not_LF(self):
        """
        改行コードがLF以外のCSVファイルの場合、エラーコードB2を返すか
        """
        cr_csv = CSV.replace('\n', '\r\n')
        self.__put_to_s3_and_update_md5_then_call_command(cr_csv)

        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        assert batch_process_info.process_result == 'Fail'
        assert batch_process_info.error_code == 'B2'

    def test_no_header(self):
        """
        ヘッダーのないCSVファイルの場合、エラーコードB3を返すか
        """
        rows = CSV.split('\n')
        no_header_csv = '\n'.join(rows[1:])
        self.__put_to_s3_and_update_md5_then_call_command(no_header_csv)

        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        assert batch_process_info.process_result == 'Fail'
        assert batch_process_info.error_code == 'B3'

    def test_not_quoted_with_doublequote(self):
        """
        ダブルクォーテーションで囲まれていないCSVファイルの場合、エラーコードB4を返すか
        """
        singlequoted_csv = CSV.replace('"', "'")
        self.__put_to_s3_and_update_md5_then_call_command(singlequoted_csv)

        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        assert batch_process_info.process_result == 'Fail'
        assert batch_process_info.error_code == 'B4'

    def test_0_row(self):
        """
        ヘッダを除いた行が0行のCSVファイルの場合、エラーコードB5を返すか
        """
        only_header_csv = CSV.split('\n')[0]
        self.__put_to_s3_and_update_md5_then_call_command(only_header_csv)

        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        assert batch_process_info.process_result == 'Fail'
        assert batch_process_info.error_code == 'B5'

    def test_1001_row(self):
        """
        ヘッダを除いた行が1001行のCSVファイルの場合、エラーコードB5を返すか
        """
        thousand_one_csv = '#"subscription_id","product_code","target_month","start_date_time","end_date_time","quantity","user","free_item1","free_item2"'
        for index in range(1001):
            thousand_one_csv += f'''\n"sub{index}","pro{index}","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10"'''
        self.__put_to_s3_and_update_md5_then_call_command(thousand_one_csv)

        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        assert batch_process_info.process_result == 'Fail'
        assert batch_process_info.error_code == 'B5'

    def test_invalid_time(self):
        """
        特定行の利用月、利用開始日時、または利用終了日時のデータフォーマットが不適切な場合、
        エラーコードC{N}を返すか
        """
        invalid_time_rows = [
            f'''\n"sub1","pro00","notmonth","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10"''',
            f'''\n"sub1","pro01","{datetime.now().strftime('%Y%m')}","200001010101","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10"''',
            f'''\n"sub1","pro02","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","200001010101","10"'''
        ]

        for invalid_time_row in invalid_time_rows:
            has_invalid_time_csv = CSV_HEADER + invalid_time_row
            self.__put_to_s3_and_update_md5_then_call_command(has_invalid_time_csv)

            batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
            assert batch_process_info.process_result == 'Fail'
            assert batch_process_info.error_code == 'C1'

    def test_duplicate_rows(self):
        """
        CSVファイル内に重複した行がある場合、エラーコードDを返すか
        """
        duplicate_row = f'''\n"sub0","pro00","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10"'''
        has_duplicate_csv = CSV + duplicate_row + duplicate_row
        self.__put_to_s3_and_update_md5_then_call_command(has_duplicate_csv)

        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        assert batch_process_info.process_result == 'Fail'
        assert batch_process_info.error_code == 'D'

    def test_no_required_item(self):
        """
        必須項目が空の場合に、エラーコードEを返すか
        """
        no_required_item_rows = [
            # f'''\n"","pro00","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10"''',
            f'''\n"sub1","","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10"''',
            # f'''\n"sub1","pro00","","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10"''',
            f'''\n"sub1","pro00","{datetime.now().strftime('%Y%m')}","","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10"''',
            f'''\n"sub1","pro00","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","","10"''',
            f'''\n"sub1","pro00","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}",""''',
        ]

        for no_required_item_row in no_required_item_rows:
            has_no_required_item_csv = CSV_HEADER + no_required_item_row
            self.__put_to_s3_and_update_md5_then_call_command(has_no_required_item_csv)

            batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
            assert batch_process_info.process_result == 'Fail'
            assert batch_process_info.error_code == 'E1'

    @patch('time.sleep', return_value=None)
    def test_rollback(self, *args, **keywargs):

        """
         重複したリクエストidをS3においている、エラーコードGを返すか
        """
        ContractInfo.objects.create(
            subscription_id='sub3',
            opco_code='FX',
            closing_day=1
        )
        duplicate_row = f'''\n"sub3","pro0","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10"'''
        self.__put_to_s3_and_update_md5_then_call_command(CSV_HEADER + duplicate_row)
        assert UsageInfo.objects.all().count() == 1
        self.__put_to_s3_and_update_md5_then_call_command(CSV + duplicate_row)
        assert UsageInfo.objects.all().count() == 1

        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        assert batch_process_info.process_result == 'Fail'
        assert batch_process_info.error_code == 'F'

    @freeze_time('2000-01-01 02:00:00', tz_offset=-9)
    def test_success(self):
        """
        正しいデータを流した場合、成功するか
        """
        rows = [
            f'''\n"sub1","pro00","200001","19990101T000000Z","19990131T000000Z","10","001","testfreeitem1","testfreeitem2"''',
            f'''\n"sub2","pro00","200001","19990101T000000Z","20000101T000000Z","10"''',
        ]

        for row in rows:
            csv = CSV_HEADER + row
            self.__put_to_s3_and_update_md5_then_call_command(csv)

            batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
            assert batch_process_info.process_result == 'Success'
            assert batch_process_info.error_code == 'S'
            assert batch_process_info.records == 1
            assert batch_process_info.csv_link.startswith(
                f'https://s3-ap-northeast-1.amazonaws.com/{BUCKET}/{CSV_DIR_OUT}')

        usage_infos = UsageInfo.objects.all()
        assert usage_infos.count() == 2
        assert usage_infos[0].subscription == self.sub1
        assert usage_infos[0].usage_id == 'sub1_pro00_19990101T000000Z_19990131T000000Z_10_001'
        assert usage_infos[0].product_code == 'pro00'
        assert usage_infos[0].target_month == '200001'
        assert usage_infos[0].start_time.timestamp() == self.__convert_timezone(utc, '19990101T000000Z').timestamp()
        assert usage_infos[0].end_time.timestamp() == self.__convert_timezone(utc, '19990131T000000Z').timestamp()
        assert usage_infos[0].quantity == '10'
        assert usage_infos[0].license_user == '001'
        assert usage_infos[0].free_item1 == 'testfreeitem1'
        assert usage_infos[0].free_item2 == 'testfreeitem2'
        assert usage_infos[1].subscription == self.sub2
        assert usage_infos[1].usage_id == 'sub2_pro00_19990101T000000Z_20000101T000000Z_10'
        assert usage_infos[1].product_code == 'pro00'
        assert usage_infos[1].target_month == '200001'
        assert usage_infos[1].start_time.timestamp() == self.__convert_timezone(utc, '19990101T000000Z').timestamp()
        assert usage_infos[1].end_time.timestamp() == self.__convert_timezone(utc, '20000101T000000Z').timestamp()
        assert usage_infos[1].quantity == '10'
        assert usage_infos[1].license_user is None
        assert usage_infos[1].free_item1 is None
        assert usage_infos[1].free_item2 is None

    def test_special_characters(self):
        """
        カンマや改行が含まれたCSVを流した場合、成功するか
        """
        rows = [
            f'''\n"sub1","pro0","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10","t,e,s,t,f,reeitem1","test\nfr\neei\ntem2"'''
        ]

        for row in rows:
            csv = CSV_HEADER + row
            self.__put_to_s3_and_update_md5_then_call_command(csv)

            batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
            assert batch_process_info.process_result == 'Success'
            assert batch_process_info.error_code == 'S'

    def test_1000_rows_csv(self):
        """
        1000行のCSV流した場合、成功するか
        """
        rows = ''
        contract_infos = []
        for i in range(1000):
            contract_infos.append(ContractInfo(
                subscription_id=f'subscription{i}',
                opco_code='FX',
                closing_day=1
            ))
            rows += f'''\n"subscription{i}","pro","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10"'''
        ContractInfo.objects.bulk_create(contract_infos)

        csv = CSV_HEADER + rows
        self.__put_to_s3_and_update_md5_then_call_command(csv)

        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        assert batch_process_info.process_result == 'Success'
        assert batch_process_info.error_code == 'S'
        assert batch_process_info.records == 1000

    def test_exists_csv_file_in_processing_bucket_when_failed(self):
        """
        処理が失敗した際、処理用プレフィックス配下にCSVファイルが存在するか
        また、処理前・処理後プレフィックス配下にCSVファイルが存在しないか
        """
        self.__put_to_s3_and_update_md5_then_call_command(CSV_HEADER)
        assert self.s3.Object(BUCKET, CSV_DIR_PROCESSING + '/' + KEY_WITHOUT_PREFIX).get()
        with self.assertRaises(ClientError) as err:
            self.s3.Object(BUCKET, KEY).get()
        assert err.exception.response['Error']['Code'] == 'NoSuchKey'
        with self.assertRaises(ClientError) as err:
            self.s3.Object(BUCKET, CSV_DIR_OUT + '/' + KEY_WITHOUT_PREFIX).get()
        assert err.exception.response['Error']['Code'] == 'NoSuchKey'

    def test_exists_csv_file_in_out_bucket_when_success(self):
        """
        処理が成功した際、処理済みプレフィックス配下にCSVファイルが存在するか
        また、処理前・処理中プレフィックス配下にCSVファイルが存在しないか
        """
        self.__put_to_s3_and_update_md5_then_call_command(CSV)
        assert self.s3.Object(BUCKET, CSV_DIR_OUT + '/' + KEY_WITHOUT_PREFIX).get()
        with self.assertRaises(ClientError) as err:
            self.s3.Object(BUCKET, KEY).get()
        assert err.exception.response['Error']['Code'] == 'NoSuchKey'
        with self.assertRaises(ClientError) as err:
            self.s3.Object(BUCKET, CSV_DIR_PROCESSING + '/' + KEY_WITHOUT_PREFIX).get()
        assert err.exception.response['Error']['Code'] == 'NoSuchKey'

    def test_duplicate_csv_file_in_s3(self):
        """
        同名のCSVファイルが移動先にすでに存在する場合、
        ファイル名を変更して移動されるかどうか
        """
        self.s3.Object(BUCKET, CSV_DIR_PROCESSING + '/' + KEY_WITHOUT_PREFIX).put(Body=CSV)
        self.__put_to_s3_and_update_md5_then_call_command(CSV)
        assert len(list(self.s3.Bucket(BUCKET).objects.all())) == 2

        ContractInfo.objects.create(
            subscription_id='sub3',
            opco_code='aaa',
            closing_day=1
        )
        self.s3.Object(BUCKET, CSV_DIR_OUT + '/' + KEY_WITHOUT_PREFIX).put(Body=CSV)
        csv = CSV_HEADER + f'''\n"sub3","pro","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10"'''
        self.__put_to_s3_and_update_md5_then_call_command(csv)
        assert len(list(self.s3.Bucket(BUCKET).objects.all())) == 3

    @mock.patch('logging.Logger.error')
    def test_not_exist_subscription(self, mock_logger):
        """
        DBに存在しないsubscription_idがCSVに入っていた場合、エラーログを吐きつつ登録できるかどうか
        """

        not_found_subscription_id = "sub99999"
        row = f'''\n"{not_found_subscription_id}","pro","{datetime.now().strftime('%Y%m')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","{datetime.now().strftime('%Y%m%dT%H%M%SZ')}","10"'''

        self.__put_to_s3_and_update_md5_then_call_command(CSV_HEADER + row)

        assert UsageInfo.objects.all().count() == 0

    def test_not_in_prefix(self):
        """
        処理前プレフィックス以外のキーで叩かれた場合、何もせず終了する
        """

        KEY = CSV_DIR_PROCESSING + '/' + KEY_WITHOUT_PREFIX
        self.s3.Object(BUCKET, KEY).put(Body=CSV)

        with self.assertRaises(SystemExit):
            call_command(COMMAND, BUCKET, KEY)

        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        assert batch_process_info.process_result == 'NotProcessed'

    def test_strip_license_user(self):
        """
        license_user文字列の前後に空白があった場合、トリムしてDBに保存し、usage_idも空白を含まないようになっているか
        """
        rows = [
            f'''\n"sub1","pro00","200001","19990101T000000Z","20000101T000000Z","10"," 001"''',
            f'''\n"sub1","pro00","200001","19990101T000000Z","20000101T000000Z","10","001 "''',
            f'''\n"sub1","pro00","200001","19990101T000000Z","20000101T000000Z","10","　001"''',
            f'''\n"sub1","pro00","200001","19990101T000000Z","20000101T000000Z","10","001　"''',
        ]

        for row in rows:
            csv = CSV_HEADER + row
            self.__put_to_s3_and_update_md5_then_call_command(csv)

            batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
            assert batch_process_info.process_result == 'Success'
            assert batch_process_info.error_code == 'S'

            usage_infos = UsageInfo.objects.all()
            assert usage_infos[0].license_user == '001'
            assert usage_infos[0].usage_id == 'sub1_pro00_19990101T000000Z_20000101T000000Z_10_001'
            usage_infos = UsageInfo.objects.all().delete()

    def test_upper_md5(self):
        """
        大文字でCSVを格納した場合でも、正常に登録ができるか
        """
        self.s3.Object(BUCKET, KEY).put(Body=CSV)
        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        batch_process_info.content_md5 = md5(CSV.encode()).hexdigest().upper()
        batch_process_info.save()
        with self.assertRaises(SystemExit):
            call_command(COMMAND, BUCKET, KEY)

        batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
        assert batch_process_info.process_result == 'Success'
        assert batch_process_info.error_code == 'S'

    @freeze_time('2000-01-01 02:00:00', tz_offset=-9)
    def test_complement_target_month_with_end_time_success(self):
        """
        対象月度target_monthがNoneまたは空文字の場合、end_timeで補完して、成功するか
        """
        rows = [
            f'''\n"sub1","pro00",,"19990101T000000Z","19990131T000000Z","10","001","testfreeitem1","testfreeitem2"''',
            f'''\n"sub2","pro00"," ","19990101T000000Z","20000101T000000Z","10"''',
        ]

        for row in rows:
            csv = CSV_HEADER + row
            self.__put_to_s3_and_update_md5_then_call_command(csv)

            batch_process_info = CsvBatchProcessInfo.objects.get(pk=REQUEST_ID)
            assert batch_process_info.process_result == 'Success'
            assert batch_process_info.error_code == 'S'
            assert batch_process_info.records == 1
            assert batch_process_info.csv_link.startswith(
                f'https://s3-ap-northeast-1.amazonaws.com/{BUCKET}/{CSV_DIR_OUT}')

        usage_infos = UsageInfo.objects.all()
        assert usage_infos.count() == 2
        assert usage_infos[0].subscription == self.sub1
        assert usage_infos[0].usage_id == 'sub1_pro00_19990101T000000Z_19990131T000000Z_10_001'
        assert usage_infos[0].product_code == 'pro00'
        assert usage_infos[0].target_month == '199901'
        assert usage_infos[0].start_time.timestamp() == self.__convert_timezone(utc, '19990101T000000Z').timestamp()
        assert usage_infos[0].end_time.timestamp() == self.__convert_timezone(utc, '19990131T000000Z').timestamp()
        assert usage_infos[0].quantity == '10'
        assert usage_infos[0].license_user == '001'
        assert usage_infos[0].free_item1 == 'testfreeitem1'
        assert usage_infos[0].free_item2 == 'testfreeitem2'
        assert usage_infos[1].subscription == self.sub2
        assert usage_infos[1].usage_id == 'sub2_pro00_19990101T000000Z_20000101T000000Z_10'
        assert usage_infos[1].product_code == 'pro00'
        assert usage_infos[1].target_month == '200001'
        assert usage_infos[1].start_time.timestamp() == self.__convert_timezone(utc, '19990101T000000Z').timestamp()
        assert usage_infos[1].end_time.timestamp() == self.__convert_timezone(utc, '20000101T000000Z').timestamp()
        assert usage_infos[1].quantity == '10'
        assert usage_infos[1].license_user is None
        assert usage_infos[1].free_item1 is None
        assert usage_infos[1].free_item2 is None
