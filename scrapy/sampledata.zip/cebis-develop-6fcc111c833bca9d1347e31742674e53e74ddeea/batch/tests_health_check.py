"""
<copyright file="tests_health_check.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import boto3
import freezegun
from io import StringIO
from unittest import mock
from unittest.mock import call
import os
from moto import mock_s3

from django.core.management import call_command
from django.core.management.base import CommandError
from django.utils.timezone import timedelta
from django.test import TestCase

from batch.management.commands.health_check import Command
from subscriptions.factory_boy import ContractInfoFactory, ContractServiceInfoFactory,\
    ProductInfoFactory, UsageInfoFactory
from subscriptions.models import ContractInfo
from lib.const.contract_service_state import ACTIVE, INACTIVE, TRIAL
from lib.const.s3_for_usage import CSV_DIR_IN, CSV_DIR_PROCESSING
from lib.utils import DateTimeUtil

COMMAND = 'health_check'


class HealthCheckTests(TestCase):

    BUCKET_CREATED = False
    BUCKET_NAME = 'mock'

    def __fixture(self, create_dir=True):
        """
        テストに必要なS3バケットとオブジェクトを生成する
        :return:
        """
        s3 = boto3.client('s3')
        s3.create_bucket(Bucket=HealthCheckTests.BUCKET_NAME)

        if create_dir is False:
            return

        s3.put_object(
            Bucket=HealthCheckTests.BUCKET_NAME,
            Body='',
            Key=f'{CSV_DIR_IN}/'
        )
        s3.put_object(
            Bucket=HealthCheckTests.BUCKET_NAME,
            Body='',
            Key=f'{CSV_DIR_PROCESSING}/'
        )

    def setUp(self):
        os.environ[Command.ENV_KEY_S3_BUCKET] = HealthCheckTests.BUCKET_NAME

    def test_no_environ_var(self):
        """
        必要な環境変数が設定されていない場合に例外が発生することをテストする
        :return:
        """
        del os.environ[Command.ENV_KEY_S3_BUCKET]
        with self.assertRaises(CommandError):
            out = StringIO()
            call_command(COMMAND, stdout=out)

    @mock.patch('logging.Logger.fatal')
    @mock_s3
    def test_no_s3bucket(self, mock_logger):
        """
        S3バケットが存在しない場合にエラーログが出力されることをテストする
        :param mock_logger:
        :return:
        """
        self.__fixture()
        os.environ[Command.ENV_KEY_S3_BUCKET] = 'none_exists_bucket'
        out = StringIO()
        call_command(COMMAND, stdout=out)
        mock_logger.assert_called()

    @mock.patch('logging.Logger.warning')
    @mock_s3
    def test_no_s3dir(self, mock_logger):
        """
        CSV保存場所が存在しない場合にエラーログが出力されることをテストする
        :param mock_logger:
        :return:
        """
        self.__fixture(False)
        out = StringIO()
        call_command(COMMAND, stdout=out)
        mock_logger.assert_has_calls([
            call(f'S3 Subdir {CSV_DIR_IN}/ Not Exists'),
            call(f'S3 Subdir {CSV_DIR_PROCESSING}/ Not Exists'),
        ])

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_no_csv(self, mock_logger):
        """
        処理エラーCSVファイルも処理漏れCSVファイルも無い場合にエラーログが出力されないことをテストする
        :param mock_logger:
        :return:
        """
        self.__fixture()
        out = StringIO()
        call_command(COMMAND, stdout=out)
        mock_logger.assert_not_called()

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_error_csv_one(self, mock_logger):
        """
        処理エラーCSVファイルを検知した時にエラーログが出力されることをテストする
        CSV1件でテスト
        :param mock_logger:
        :return:
        """
        self.__fixture()
        s3 = boto3.client('s3')
        s3_key = f'{CSV_DIR_PROCESSING}/file'
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key, Body='xxx')
        out = StringIO()
        call_command(COMMAND, stdout=out)

        mock_logger.assert_has_calls([
            call(f'error csv file exists...Object Key:{s3_key}')
        ])

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_error_csv_multi(self, mock_logger):
        """
        処理エラーCSVファイルを検知した時にエラーログが出力されることをテストする
        CSV複数件でテスト
        :param mock_logger:
        :return:
        """

        self.__fixture()
        s3 = boto3.client('s3')
        s3_key1 = f'{CSV_DIR_PROCESSING}/file1'
        s3_key2 = f'{CSV_DIR_PROCESSING}/file2'
        s3_key3 = f'{CSV_DIR_PROCESSING}/file3'
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key1, Body='xxx')
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key2, Body='xxx')
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key3, Body='xxx')
        out = StringIO()
        call_command(COMMAND, stdout=out)

        mock_logger.assert_has_calls([
            call(f'error csv file exists...Object Key:{s3_key1}'),
            call(f'error csv file exists...Object Key:{s3_key2}'),
            call(f'error csv file exists...Object Key:{s3_key3}')
        ])

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_leakage_csv_one(self, mock_logger):
        """
        処理漏れCSVファイルを検知した時にエラーログが出力されることをテストする
        CSV1件でテスト
        :param mock_logger:
        :return:
        """
        self.__fixture()
        s3 = boto3.client('s3')
        s3_key = f'{CSV_DIR_IN}/file'
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key, Body='xxx')
        out = StringIO()
        call_command(COMMAND, stdout=out)

        mock_logger.assert_has_calls([
            call(f'leakage csv file exists...Object Key:{s3_key}')
        ])

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_leakage_csv_multi(self, mock_logger):
        """
        処理漏れCSVファイルを検知した時にエラーログが出力されることをテストする
        CSV複数件でテスト
        :param mock_logger:
        :return:
        """

        self.__fixture()
        s3 = boto3.client('s3')
        s3_key1 = f'{CSV_DIR_IN}/file1'
        s3_key2 = f'{CSV_DIR_IN}/file2'
        s3_key3 = f'{CSV_DIR_IN}/file3'
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key1, Body='xxx')
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key2, Body='xxx')
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key3, Body='xxx')
        out = StringIO()
        call_command(COMMAND, stdout=out)

        mock_logger.assert_has_calls([
            call(f'leakage csv file exists...Object Key:{s3_key1}'),
            call(f'leakage csv file exists...Object Key:{s3_key2}'),
            call(f'leakage csv file exists...Object Key:{s3_key3}')
        ])

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_leakage_and_error_csv_multi(self, mock_logger):
        """
        処理エラーCSVファイルと処理漏れCSVファイルを検知した時にエラーログが出力されることをテストする
        CSV複数件でテスト
        :param mock_logger:
        :return:
        """

        self.__fixture()
        s3 = boto3.client('s3')
        s3_key1 = f'{CSV_DIR_IN}/file1'
        s3_key2 = f'{CSV_DIR_IN}/file2'
        s3_key3 = f'{CSV_DIR_IN}/file3'
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key1, Body='xxx')
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key2, Body='xxx')
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key3, Body='xxx')
        s3_key4 = f'{CSV_DIR_PROCESSING}/file4'
        s3_key5 = f'{CSV_DIR_PROCESSING}/file5'
        s3_key6 = f'{CSV_DIR_PROCESSING}/file6'
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key4, Body='xxx')
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key5, Body='xxx')
        s3.put_object(Bucket=HealthCheckTests.BUCKET_NAME, Key=s3_key6, Body='xxx')

        out = StringIO()
        call_command(COMMAND, stdout=out)
        mock_logger.assert_has_calls([
            call(f'leakage csv file exists...Object Key:{s3_key1}'),
            call(f'leakage csv file exists...Object Key:{s3_key2}'),
            call(f'leakage csv file exists...Object Key:{s3_key3}'),
            call(f'error csv file exists...Object Key:{s3_key4}'),
            call(f'error csv file exists...Object Key:{s3_key5}'),
            call(f'error csv file exists...Object Key:{s3_key6}')
        ])


    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_active_and_service_start_date_null_one(self, mock_logger):
        """
        契約状態がアクティブかつ、サービス手配完了日時がNULLのレコードが見つかった場合に
        エラーログが出力されることをテストする
        :return:
        """

        self.__fixture()

        contract_info = ContractInfoFactory(subscription_id=1)
        product = ProductInfoFactory(product_code='prd01')
        ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE, service_start_time=None,
                                   product_code=product)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        mock_logger.assert_has_calls([
            call(f'Illegality contract service detected!!... this contract state is active,but service_start_time is'
                 f' null subscription_id:1 product_code:prd01')
        ])

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_active_and_service_start_date_not_null_one(self, mock_logger):
        """
        契約状態がアクティブかつ、サービス手配完了日時が設定されているレコードしか存在しない場合に
        エラーログが出力され無いことをテストする
        :return:
        """

        self.__fixture()
        for i in range(0, 1000):
            ContractServiceInfoFactory(state=ACTIVE)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        mock_logger.assert_not_called()

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_inactive_and_has_usage_after_cancel(self, mock_logger):
        """
        直近1時間以内に登録された従量データの中に、契約状態が「Inactive」かつ
        解約手配完了日時が請求対象期間開始日よりも前の従量データが存在する場合に
        エラーログが出力されることをテストする

        契約サービスの状態が「Inactive」にも関わらず、サービス解約手配完了日時以降に利用があった場合に
        エラーログが出力されることをテストする
        :return:
        """

        self.__fixture()
        created_time = DateTimeUtil.utc_now_aware().replace(minute=0, second=0, microsecond=0)
        created_time = created_time - timedelta(minutes=59)
        contract_info = ContractInfoFactory(subscription_id=1)
        product1 = ProductInfoFactory(product_code='prd01')
        product2 = ProductInfoFactory(product_code='prd02')
        product3 = ProductInfoFactory(product_code='prd03')
        now = DateTimeUtil.utc_now_aware()
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=now,
                                   product_code=product1)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=now,
                                   product_code=product2)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=now,
                                   product_code=product3)

        UsageInfoFactory(subscription=contract_info, product_code=product1.product_code,
                         start_time=now, created_time=created_time)
        UsageInfoFactory(subscription=contract_info, product_code=product2.product_code,
                         start_time=now + timedelta(seconds=1), created_time=created_time)
        UsageInfoFactory(subscription=contract_info, product_code=product3.product_code,
                         start_time=now + timedelta(seconds=-1), created_time=created_time)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        mock_logger.assert_has_calls([
            call(f'Illegality contract service detected!!... this contract state is all inactive,but start_time '
                 f'grather than service_cancel_time subscription_id:1 product_code:prd02 '
                 f'service_cancel_time:{DateTimeUtil.format_iso8601_utc(now)} '
                 f'start_time:{DateTimeUtil.format_iso8601_utc(now + timedelta(seconds=1))}')
        ])

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_inactive_and_has_usage_before_over_1hour(self, mock_logger):
        """
        契約サービスの状態が「Inactive」にも関わらず、サービス解約手配完了日時以降に利用があるが、
        バッチ実行時より１時間超前の場合にエラーログが出力されないことをテストする
        :return:
        """

        self.__fixture()
        created_time = DateTimeUtil.utc_now_aware().replace(minute=0, second=0, microsecond=0)
        created_time = created_time - timedelta(minutes=61)
        contract_info = ContractInfoFactory(subscription_id=1)
        product1 = ProductInfoFactory(product_code='prd01')
        now = DateTimeUtil.utc_now_aware()
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=now,
                                   product_code=product1)
        UsageInfoFactory(subscription=contract_info, product_code=product1.product_code,
                         start_time=now + timedelta(seconds=1), created_time=created_time)

        out = StringIO()
        call_command(COMMAND, stdout=out)

        mock_logger.assert_not_called()

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_all_inactive_and_has_usage_after_cancel(self, mock_logger):
        """
        契約サービスの状態が「Inactive」でも、サービス解約手配完了日時以降に利用が無い場合は
        エラーログが出力され無いことテストする
        :return:
        """

        self.__fixture()

        contract_info = ContractInfoFactory(subscription_id=1)
        product1 = ProductInfoFactory(product_code='prd01')
        product2 = ProductInfoFactory(product_code='prd02')
        product3 = ProductInfoFactory(product_code='prd03')
        now = DateTimeUtil.utc_now_aware()
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=now,
                                   product_code=product1)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=now,
                                   product_code=product2)
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=now,
                                   product_code=product3)

        UsageInfoFactory(subscription=contract_info, product_code=product1.product_code,
                         start_time=now + timedelta(microseconds=-1))
        UsageInfoFactory(subscription=contract_info, product_code=product2.product_code,
                         start_time=now + timedelta(milliseconds=-1))
        UsageInfoFactory(subscription=contract_info, product_code=product3.product_code,
                         start_time=now + timedelta(seconds=-1))

        out = StringIO()
        call_command(COMMAND, stdout=out)
        mock_logger.assert_not_called()

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_no_subscription_in_contract_info(self, mock_logger):
        """
        DB上で存在しない契約情報を持った従量データを作成し、規定のエラーが変えるか
        :return:
        """

        not_exist_contract_info = ContractInfo(
            subscription_id='aaa',
            contract_code='yyy',
            spf_tenant_id='spf0000000001',
            opco_code='FX',
            closing_day=30,
        )
        error_usage_info = UsageInfoFactory(
            subscription=not_exist_contract_info,
            product_code='prd1',
            start_time=DateTimeUtil.utc_now_aware(),
            created_time=DateTimeUtil.utc_now_aware()
        )

        out = StringIO()
        call_command(COMMAND, stdout=out)

        mock_logger.assert_has_calls([
            call(f'Illegality usage info detected!!... '
                 f'The usage info\'s subscription does not exist '
                 f'id:{error_usage_info.id}, subscription_id:{error_usage_info.subscription_id}, usage_id:{error_usage_info.usage_id}')
        ])

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_no_subscription_in_contract_info_before_over_1hour_skip_log(self, mock_logger):
        """
        対応する契約情報が存在しない従量データでも、バッチ実行日時より１時間超前に
        生成されたデータに関してはエラーログが出力されないことをテストする
        :return:
        """

        contract_info = ContractInfo()
        past_time = DateTimeUtil.utc_now_aware().replace(minute=0, second=0, microsecond=0
                                                         ) - timedelta(hours=1) - timedelta(seconds=1)
        UsageInfoFactory(subscription=contract_info, created_time=past_time)

        out = StringIO()
        call_command(COMMAND, stdout=out)
        mock_logger.assert_not_called()

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_no_subscription_in_contract_info_and_deleted_skip_log(self, mock_logger):
        """
        対応する契約情報が存在しない従量データでも、論理削除：TRUEの場合は
        エラーログが出力されないことをテストする
        :return:
        """

        not_exist_contract_info = ContractInfo(
            subscription_id='aaa',
            contract_code='yyy',
            spf_tenant_id='spf0000000001',
            opco_code='FX',
            closing_day=30,
        )
        start_time = DateTimeUtil.utc_now_aware() + timedelta(minutes=10)
        UsageInfoFactory(subscription=not_exist_contract_info, product_code='prd1',
                         start_time=start_time, deleted=True)

        out = StringIO()
        call_command(COMMAND, stdout=out)
        mock_logger.assert_not_called()

    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_inactive_and_has_usage_before_one_hour_and_deleted_skip_logs(self, mock_logger):
        """
        契約サービスの状態が「Inactive」かつ、サービス解約手配完了日時以降に利用がある場合でも
        論理削除：TRUEの場合はエラーログが出力されないことをテストする
        :return:
        """

        self.__fixture()

        contract_info = ContractInfoFactory()
        product1 = ProductInfoFactory()
        now = DateTimeUtil.utc_now_aware()
        ContractServiceInfoFactory(subscription=contract_info, state=INACTIVE,
                                   service_cancel_time=now,
                                   product_code=product1)
        UsageInfoFactory(subscription=contract_info, product_code=product1.product_code,
                         start_time=now + timedelta(minutes=10), deleted=True)

        out = StringIO()
        call_command(COMMAND, stdout=out)
        mock_logger.assert_not_called()

    @freezegun.freeze_time('2020-02-29 12:00:00')
    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_leap_year(self, mock_logger):
        """
        閏年の2/29に実行しても正常に実行できるかのテスト
        :param mock_logger:
        :return:
        """
        self.__fixture()

        out = StringIO()
        call_command(COMMAND, stdout=out)
        mock_logger.assert_not_called()

    @freezegun.freeze_time('2018-12-31 23:00:00')
    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_december(self, mock_logger):
        """
        12/31(翌日は来年)に実行しても正常に実行できるかのテスト
        :param mock_logger:
        :return:
        """
        self.__fixture()

        out = StringIO()
        call_command(COMMAND, stdout=out)
        mock_logger.assert_not_called()

    @freezegun.freeze_time('2018-01-01 01:00:00')
    @mock.patch('logging.Logger.error')
    @mock_s3
    def test_december(self, mock_logger):
        """
        1/1(前日は前年)に実行しても正常に実行できるかのテスト
        :param mock_logger:
        :return:
        """
        self.__fixture()

        out = StringIO()
        call_command(COMMAND, stdout=out)
        mock_logger.assert_not_called()
