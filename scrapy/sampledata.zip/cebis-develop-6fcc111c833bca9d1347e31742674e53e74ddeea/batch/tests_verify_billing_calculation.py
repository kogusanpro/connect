"""
<copyright file="tests_create_usage_download_url_csv.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""
from datetime import timedelta
from io import StringIO
from unittest import mock

from django.core.management import call_command, CommandError
from django.test import TestCase
from mock import call

from lib.const.billing_info_state import NEW, COMPLETED
from lib.utils import DateTimeUtil
from subscriptions.factory_boy import UsageInfoFactory, BillingInfoFactory, BillingDetailInfoFactory, \
    ContractInfoFactory, ProductInfoFactory, ContractServiceInfoFactory
from lib.const.contract_service_state import ACTIVE, INACTIVE, TRIAL
from subscriptions.models import UsageInfo, BillingInfo, BillingDetailInfo, ProductInfo, ContractInfo, \
    ContractServiceInfo

COMMAND = 'verify_billing_calculation'


class VerifyBillingCalculationTests(TestCase):

    def setUp(self):
        self.subscription_id1 = 'dpa_70015100'
        self.subscription_id2 = 'dpa_70015101'
        self.contract1 = ContractInfoFactory(subscription_id=self.subscription_id1)
        self.contract2 = ContractInfoFactory(subscription_id=self.subscription_id2)
        self.target_month = DateTimeUtil.get_prev_ym()

        self.product_code1 = 'ABCD1001'
        self.product_code2 = 'ABCD1002'
        self.product1 = ProductInfoFactory(product_code=self.product_code1)
        self.product2 = ProductInfoFactory(product_code=self.product_code2)

        self.csi_start_time = DateTimeUtil.utc_now_aware() - timedelta(minutes=10)
        self.csi_end_time = DateTimeUtil.utc_now_aware() + timedelta(minutes=10)

        ContractServiceInfoFactory(
            subscription=self.contract1,
            product_code=self.product1,
            service_start_time=self.csi_start_time,
            service_cancel_time=self.csi_end_time
        )

        ContractServiceInfoFactory(
            subscription=self.contract2,
            product_code=self.product2,
            service_start_time=self.csi_start_time,
            service_cancel_time=self.csi_end_time
        )

        UsageInfoFactory(
            subscription=self.contract1,
            usage_id='test_usage_id1',
            target_month=self.target_month,
            product_code=self.product_code1,
            quantity='1000',
            deleted=False
        )
        UsageInfoFactory(
            subscription=self.contract1,
            usage_id='test_usage_id2',
            target_month=self.target_month,
            product_code=self.product_code1,
            quantity='2000',
            deleted=False
        )
        UsageInfoFactory(
            subscription=self.contract2,
            usage_id='test_usage_id3',
            target_month=self.target_month,
            product_code=self.product_code2,
            quantity='4000',
            deleted=False
        )
        UsageInfoFactory(
            subscription=self.contract2,
            usage_id='test_usage_id4',
            target_month=self.target_month,
            product_code=self.product_code2,
            quantity='5000',
            deleted=False
        )
        BillingInfoFactory(
            subscription=self.contract1,
            target_month=self.target_month,
            state=COMPLETED
        )
        BillingInfoFactory(
            subscription=self.contract2,
            target_month=self.target_month,
            state=COMPLETED
        )
        BillingDetailInfoFactory(
            subscription=self.contract1,
            target_month=self.target_month,
            product_code=self.product1,
            quantity='3000'
        )
        BillingDetailInfoFactory(
            subscription=self.contract2,
            target_month=self.target_month,
            product_code=self.product2,
            quantity='9000'
        )

    def tearDown(self):
        ContractInfo.objects.all().delete()
        UsageInfo.objects.all().delete()
        ProductInfo.objects.all().delete()
        BillingInfo.objects.all().delete()
        BillingDetailInfo.objects.all().delete()

    @mock.patch('logging.Logger.info')
    def test_01_success(self, mock_logger):
        """
        正常終了のテスト
        """
        out = StringIO()
        call_command(COMMAND, last_month=self.target_month, stdout=out)
        mock_logger.assert_has_calls(
            [call('Start verify billing calculation'),
             call('size of billing_info in 202001 : 2'),
             call('quantity is VALID: (subscription_id: dpa_70015100 product_code: ABCD1001 target_month: 202001)'),
             call('quantity is VALID: (subscription_id: dpa_70015101 product_code: ABCD1002 target_month: 202001)'),
             call('End verify billing calculation')]
        )

    @mock.patch('logging.Logger.info')
    @mock.patch('logging.Logger.error')
    def test_02_billing_info_state_not_completed(self, mock_logger_error, mock_logger_info):
        """
        請求情報の「計算状態」が「計算完了」(completed)以外のテスト
        """
        BillingInfo.objects.filter(subscription_id=self.contract1, target_month=self.target_month).update(
            state=NEW)
        out = StringIO()
        call_command(COMMAND, last_month=self.target_month, stdout=out)
        mock_logger_info.assert_has_calls(
            [call('Start verify billing calculation'),
             call('size of billing_info in 202001 : 2'),
             call('quantity is VALID: (subscription_id: dpa_70015101 product_code: ABCD1002 target_month: 202001)'),
             call('End verify billing calculation')]
        )
        mock_logger_error.assert_has_calls(
            [call('billing calculation for (dpa_70015100, ABCD1001, 202001) is NOT FINISHED.')]
        )

    @mock.patch('logging.Logger.info')
    @mock.patch('logging.Logger.error')
    def test_03_sum_total_quantity_failed(self, mock_logger_error, mock_logger_info):
        """
        利用量の集計処理でエラーが返るテスト
        """
        quantity_null = "abc"
        UsageInfo.objects.filter(subscription_id=self.contract1, usage_id='test_usage_id1').update(
            quantity=quantity_null)
        out = StringIO()
        call_command(COMMAND, last_month=self.target_month, stdout=out)
        mock_logger_info.assert_has_calls(
            [call('Start verify billing calculation'),
             call('size of billing_info in 202001 : 2'),
             call('quantity is VALID: (subscription_id: dpa_70015101 product_code: ABCD1002 target_month: 202001)'),
             call('End verify billing calculation')]
        )
        mock_logger_error.assert_has_calls(
            [call('target_quantity for (dpa_70015100, ABCD1001, 202001) is None.')]
        )

    @mock.patch('logging.Logger.info')
    @mock.patch('logging.Logger.error')
    def test_04_usage_info_not_found(self, mock_logger_error, mock_logger_info):
        """
        従量データが一つも見つからない場合のテスト
        """
        UsageInfo.objects.all().delete()
        out = StringIO()
        call_command(COMMAND, last_month=self.target_month, stdout=out)
        mock_logger_info.assert_has_calls(
            [call('Start verify billing calculation'),
             call('size of billing_info in 202001 : 2'),
             call('dpa_70015100 usage for "ABCD1001" on 202001 not found.'),
             call('dpa_70015101 usage for "ABCD1002" on 202001 not found.'),
             call('End verify billing calculation')]
        )
        mock_logger_error.assert_has_calls(
            [call('quantity is INVALID: (subscription_id: dpa_70015100 product_code: ABCD1001 target_month: 202001)'),
             call('quantity is INVALID: (subscription_id: dpa_70015101 product_code: ABCD1002 target_month: 202001)')]
        )

    @mock.patch('logging.Logger.info')
    @mock.patch('logging.Logger.error')
    def test_05_quantity_not_same(self, mock_logger_error, mock_logger_info):
        """
        利用量の合計値が不一致のテスト
        """
        BillingDetailInfo.objects.filter(subscription=self.contract1,
                                        target_month=self.target_month,
                                        product_code=self.product1).update(quantity="1500")
        out = StringIO()
        call_command(COMMAND, last_month=self.target_month, stdout=out)
        mock_logger_info.assert_has_calls(
            [call('Start verify billing calculation'),
             call('size of billing_info in 202001 : 2'),
             call('quantity is VALID: (subscription_id: dpa_70015101 product_code: ABCD1002 target_month: 202001)'),
             call('End verify billing calculation')]
        )
        mock_logger_error.assert_has_calls(
            [call('quantity is INVALID: (subscription_id: dpa_70015100 product_code: ABCD1001 target_month: 202001)')]
        )

    @mock.patch('logging.Logger.info')
    @mock.patch('logging.Logger.error')
    def test_06_usageEndTime_exceeds_contractEndTime(self, mock_logger_error, mock_logger_info):
        """
        従量情報完了日は契約手配完了日より、大きくなる場合
        """
        UsageInfo.objects.filter(subscription_id=self.contract1, usage_id='test_usage_id1').update(
            end_time=self.csi_end_time+timedelta(minutes=100))
        out = StringIO()
        call_command(COMMAND,last_month=self.target_month, stdout=out)
        mock_logger_info.assert_has_calls(
            [call('Start verify billing calculation'),
             call('size of billing_info in 202001 : 2'),
             call('quantity is VALID: (subscription_id: dpa_70015101 product_code: ABCD1002 target_month: 202001)'),
             call('End verify billing calculation')]
        )
        mock_logger_error.assert_has_calls(
            []
        )