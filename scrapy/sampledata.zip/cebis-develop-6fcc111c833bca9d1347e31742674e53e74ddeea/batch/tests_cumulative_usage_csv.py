"""
<copyright file="tests_cumulative_usage_csv.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""
import csv
from io import StringIO

import boto3
from coverage.annotate import os
from django.core.management import call_command
from django.test import TestCase
from django.utils.timezone import timedelta
from pytz import timezone, UTC

from batch.services import get_tmp_dir
from lib.const.contract_service_state import ACTIVE
from lib.shortcuts import get_object_or_None
from lib.utils import DateTimeUtil
from subscriptions.factory_boy import ContractInfoFactory, ContractServiceInfoFactory, ProductInfoFactory, \
    UsageInfoFactory
from subscriptions.models import ProductInfo, CalculatedUsageInfo, ContractServiceInfo, UsageInfo

COMMAND = 'cumulative_usage_csv'


class UsageUpdateAndCsvTests(TestCase):

    def setUp(self):
        """
        テスト用初期化
        """
        self.requested_time = DateTimeUtil.utc_now_aware()
        self.requested_time_jp = self.requested_time.astimezone(timezone('Asia/Tokyo'))
        self.the_day_before_batch_run_day = self.requested_time_jp - timedelta(days=1)
        self.csv_filename_prefix = 'daily_usage'
        self.bucket_name = os.environ.get('S3_CUMULATIVE_USAGE_BUCKET')
        self.contract_info_list = list()
        self.product_code_list = list()
        self.target_day_list = list()
        self.contract_info_number_list = list()
        self.product_code_number_list = list()
        self._make_test_contract_service_info()

    def test_01_range_usage_info(self):
        """
        subscription_idとproduct_code無しで正常に範囲検索してCSVアップロード出来ることをテスト
        """
        s3_folder_year = self.the_day_before_batch_run_day.year
        s3_folder_date = self.the_day_before_batch_run_day.strftime("%Y%m")
        s3_file_name = f'daily_usage_{self.the_day_before_batch_run_day.strftime("%Y%m%d")}.csv'
        s3_key = f'daily_usage/{s3_folder_year}/{s3_folder_date}/{s3_file_name}'

        out = StringIO()
        call_command(COMMAND, executed_date="20190711", stdout=out)
        self.assertEqual(CalculatedUsageInfo.objects.all().count(), 99)
        # 対象月度が正しく登録されていることを確認
        for usage in CalculatedUsageInfo.objects.all():
            self.assertIn(usage.subscription_id_id, self.contract_info_list)
            self.assertIn(usage.product_code_id, self.product_code_list)
        filename = os.path.join(get_tmp_dir(), s3_file_name)
        with open(filename, 'rU') as f:
            f = csv.DictReader(f, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')
            target_day_data = next(f)
            self.assertIn(target_day_data['subscription_id'], self.contract_info_list)
            self.assertIn(target_day_data['product_code'], self.product_code_list)
        s3 = boto3.client('s3')

        res = s3.list_objects(
            Bucket=os.getenv('S3_CUMULATIVE_USAGE_BUCKET'),
            Prefix=f'daily_usage/{s3_folder_year}/{s3_folder_date}/'
        )
        self.assertEqual(res['Contents'][-1]['Key'], s3_key)

    def test_02_range_usage_info_with_null(self):
        """
        UsageInfoのquantityはnullです
        """
        UsageInfo.objects.filter(subscription_id=self.contract_info_number_list[0],
                                 product_code=self.product_code_number_list[0],
                                 end_time=self.target_day_list[2]).update(quantity='abc')
        out = StringIO()
        call_command(COMMAND, executed_date="20190711", stdout=out)
        confirm_date = CalculatedUsageInfo.objects.filter(subscription_id=self.contract_info_number_list[0],
                                                          product_code=self.product_code_number_list[0],
                                                          target_day__gt=self.target_day_list[2].strftime('%Y%m%d'))
        for confirm_item in confirm_date:
            self.assertEqual(confirm_item.cumulative_usage, None)

    def test_03_none_usage(self):
        """
        UsageInfoはnullです
        """
        UsageInfo.objects.all().delete()
        out = StringIO()
        call_command(COMMAND, executed_date="20190711", stdout=out)

    def test_04_none_contract(self):
        """
        UsageInfoとContractServiceInfoはnullです
        """
        UsageInfo.objects.all().delete()
        ContractServiceInfo.objects.all().delete()
        out = StringIO()
        call_command(COMMAND, executed_date="20190711", stdout=out)

    def test_05_del_three_month(self):
        """
        20190701 delete three month
        """
        out = StringIO()
        call_command(COMMAND, executed_date="20190701", stdout=out)
        result = CalculatedUsageInfo.objects.filter(target_day__lt='20190401')
        self.assertEqual(len(result), 0)

    def _make_test_contract_service_info(self):
        """
        試験用作成の完全量データ
        """
        contract_info_counts = 3
        product_code_counts = 3
        before_days = 15
        now = DateTimeUtil.utc_now_aware()
        for contract_info_num in range(contract_info_counts):
            contract_info = ContractInfoFactory(subscription_id="dp_" + str(contract_info_num), opco_code="FX")
            self.contract_info_number_list.append("dp_" + str(contract_info_num))
            self.contract_info_list.append("dp_" + str(contract_info_num))
            for product_code_item in range(product_code_counts):
                if get_object_or_None(ProductInfo, product_code='prd' + str(product_code_item)):
                    product = ProductInfo.objects.get(product_code='prd' + str(product_code_item))
                    self.product_code_number_list.append('prd' + str(product_code_item))
                    self.product_code_list.append('prd' + str(product_code_item))
                else:
                    product = ProductInfoFactory(product_code='prd' + str(product_code_item), flat_rate=False)
                ContractServiceInfoFactory(subscription=contract_info, state=ACTIVE,
                                           service_start_time=now + timedelta(days=-300),
                                           service_cancel_time=None, product_code=product)
                for before_day in range(before_days):
                    service_start_time = now.replace(tzinfo=UTC) + timedelta(days=-before_day - 1)
                    service_cancel_time = now.replace(tzinfo=UTC) + timedelta(days=-before_day)
                    UsageInfoFactory(subscription=contract_info, product_code=product.product_code,
                                     start_time=service_start_time, end_time=service_cancel_time,
                                     target_month=service_cancel_time.astimezone(timezone('Asia/Tokyo')).strftime(
                                         "%Y%m"))
                    self.target_day_list.append(service_cancel_time)
