"""
<copyright file="tests_create_usage_download_url_csv.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""

from io import StringIO
from unittest import mock

from django.core.management import call_command, CommandError
from django.test import TestCase
from mock import call

from lib.const.billing_info_state import NEW, COMPLETED
from lib.utils import DateTimeUtil
from subscriptions.factory_boy import UsageInfoFactory, BillingInfoFactory, BillingDetailInfoFactory, \
    ContractInfoFactory, ProductInfoFactory
from subscriptions.models import UsageInfo, BillingInfo, BillingDetailInfo, ProductInfo, ContractInfo

COMMAND = 'change_calc_state_to_new_for_esker'


class ChangeCalculateStateToNewForEsker(TestCase):

    def setUp(self):
        self.subscription_id1 = '20190620ESKR0001'
        self.subscription_id2 = '20190620ESKR0002'
        self.contract1 = ContractInfoFactory(subscription_id=self.subscription_id1)
        self.contract2 = ContractInfoFactory(subscription_id=self.subscription_id2)
        self.subscription_id1 = '20190620ESKR0001G'
        self.subscription_id2 = '20190620ESKR0002G'
        self.contract1G = ContractInfoFactory(subscription_id=self.subscription_id1)
        self.contract2G = ContractInfoFactory(subscription_id=self.subscription_id2)
        self.target_month = DateTimeUtil.get_prev_ym()

        self.product_code1 = 'MVAR2200'
        self.product_code2 = 'MVAR2203'
        self.product1 = ProductInfoFactory(product_code=self.product_code1)
        self.product2 = ProductInfoFactory(product_code=self.product_code2)

        BillingInfoFactory(
            subscription=self.contract1,
            target_month=self.target_month,
            state=COMPLETED
        )
        BillingInfoFactory(
            subscription=self.contract2,
            target_month=self.target_month,
            state=COMPLETED
        )
        BillingInfoFactory(
            subscription=self.contract1G,
            target_month=self.target_month,
            state=COMPLETED
        )
        BillingInfoFactory(
            subscription=self.contract2G,
            target_month=self.target_month,
            state=COMPLETED
        )
        BillingDetailInfoFactory(
            subscription=self.contract1,
            target_month=self.target_month,
            product_code=self.product1
        )
        BillingDetailInfoFactory(
            subscription=self.contract1,
            target_month=self.target_month,
            product_code=self.product2
        )
        BillingDetailInfoFactory(
            subscription=self.contract2,
            target_month=self.target_month,
            product_code=self.product1
        )
        BillingDetailInfoFactory(
            subscription=self.contract2,
            target_month=self.target_month,
            product_code=self.product2
        )
        BillingDetailInfoFactory(
            subscription=self.contract1G,
            target_month=self.target_month,
            product_code=self.product1
        )
        BillingDetailInfoFactory(
            subscription=self.contract1G,
            target_month=self.target_month,
            product_code=self.product2
        )
        BillingDetailInfoFactory(
            subscription=self.contract2G,
            target_month=self.target_month,
            product_code=self.product1
        )
        BillingDetailInfoFactory(
            subscription=self.contract2G,
            target_month=self.target_month,
            product_code=self.product2
        )

    def tearDown(self):
        ContractInfo.objects.all().delete()
        ProductInfo.objects.all().delete()
        BillingInfo.objects.all().delete()
        BillingDetailInfo.objects.all().delete()

    @mock.patch('logging.Logger.info')
    def test_01_success(self, mock_logger):
        """
        正常終了のテスト
        """
        out = StringIO()
        call_command(COMMAND, last_month=self.target_month, stdout=out)

        mock_logger.assert_has_calls(
            [call('Start change calculation state to "new" for Esker products'),
             call(
                 'The Esker billing calculation: (subscription_id: 20190620ESKR0001 target_month: 201905)'
                 ' has been returned back to new.'),
             call(
                 'The Esker profit share billing calculation: (subscription_id: 20190620ESKR0001G target_month: 201905)'
                 ' has been returned back to new.'),
             call(
                 'The Esker billing calculation: (subscription_id: 20190620ESKR0002 target_month: 201905)'
                 ' has been returned back to new.'),
             call(
                 'The Esker profit share billing calculation: (subscription_id: 20190620ESKR0002G target_month: 201905)'
                 ' has been returned back to new.'),
             call('End change calculation state to "new" for Esker products')]
        )

    @mock.patch('logging.Logger.info')
    def test_02_part_of_esker_billing_state_are_new(self, mock_logger):
        """
        Esker請求情報の一部分「計算状態」が「New」のテスト
        """
        BillingInfo.objects.filter(subscription=self.contract1,
                                   target_month=self.target_month).update(state=NEW)
        BillingInfo.objects.filter(subscription=self.contract1G,
                                   target_month=self.target_month).update(state=NEW)
        out = StringIO()
        call_command(COMMAND, last_month=self.target_month, stdout=out)
        mock_logger.assert_has_calls(
            [call('Start change calculation state to "new" for Esker products'),
             call(
                 'The Esker billing calculation: (subscription_id: 20190620ESKR0002 target_month: 201905)'
                 ' has been returned back to new.'),
             call(
                 'The Esker profit share billing calculation: (subscription_id: 20190620ESKR0002G target_month: 201905)'
                 ' has been returned back to new.'),
             call('End change calculation state to "new" for Esker products')]
        )
