"""
<copyright file="create_usage_download_url_csv.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.core.management.base import CommandError
from batch.management.batch_command_base import BatchCommandBase
from batch.csv_generator_for_usage_download_url \
    import CsvGeneratorForUsageDownloadUrl
from subscriptions.models import UsageInfo
from status.models import CsvBatchProcessInfo
from lib.utils import DateTimeUtil
from lib.validator.datetime_validator import DateTimeValidator
from botocore.exceptions import ClientError
from lib.utils import check_date_ymd_format, check_datetime_format
import os
import boto3
from django.conf import settings


class Command(BatchCommandBase):
    help = 'This Command Create Csv For Usagedownloadurl'

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.batch_name = 'create csv for usagedownloadurl'

    def add_arguments(self, parser):
        parser.add_argument('request_id', type=str)
        parser.add_argument('filename', type=str)
        parser.add_argument('--from_created_date', type=str, default="",)
        parser.add_argument('--to_created_date', type=str, default="",)
        parser.add_argument('--time_zone', type=str, default="",)
        parser.add_argument('--from_created_datetime', type=str, default="",)
        parser.add_argument('--to_created_datetime', type=str, default="",)
        parser.add_argument(
            '--internal_calc', action='store_true'
        )
        parser.add_argument(
            '--subscription_id', type=str, default=False,
        )
        parser.add_argument(
            '--product_code', type=str, default=False,
        )
        parser.add_argument(
            '--include_trial_data', action='store_true',
        )

    def main_process(self, *args, **options):
        """
        従量データ一括取得用URL作成バッチメイン処理
        :param args:
        :param options:
        :return:
        """

        csv_generator = CsvGeneratorForUsageDownloadUrl(
            filename=options['filename']
        )
        offset = 0
        while True:
            usage_data = self.get_usage_data(
                options=self.filter_input_data(options=options),
                limit=settings.USAGE_DOWNLOAD_QUERY_LIMIT,
                offset=offset
            )
            csv_generator.generate_csv_to_local(
                data=usage_data,
                internal_calc=options['internal_calc']
            )
            if len(list(usage_data)) == 0:
                break
            offset = offset + settings.USAGE_DOWNLOAD_QUERY_LIMIT

        try:
            csv_generator.upload_csv_to_s3()
            CsvBatchProcessInfo.objects.filter(
                request_id=options['request_id']).update(
                content_md5=csv_generator.get_md5(),
                process_result='Success',
                error_code='S',
                records=csv_generator.counting_process)
        except ClientError as e:
            self.logger.error(e)
            CsvBatchProcessInfo.objects.filter(
                request_id=options['request_id']).update(
                process_result='Fail',
                error_code='G',
                records=0)

    def do_validate(self, *args, **options):
        """
        引数等のバリデーション処理
        :param args:
        :param options:
        :return:
        """

        if options['from_created_date'] and options['to_created_date']:
            if options['from_created_datetime'] or options['to_created_datetime']:
                raise CommandError(
                    f'Either from_created_date, to_created_date or '
                    f'from_created_datetime, to_created_datetime must be specified')

            if not DateTimeValidator.is_valid_timezone(options['time_zone']):
                raise CommandError(f'time_zone was invalid format in this request body')

            if not check_date_ymd_format(datetime=options['from_created_date']):
                raise CommandError(
                    f'from_created_date was invalid format in this request body')

            if not check_date_ymd_format(datetime=options['to_created_date']):
                raise CommandError(
                    f'to_created_date was invalid format in this request body')

            if int(options['from_created_date']) > int(options['to_created_date']):
                raise CommandError(
                    f'from_created_date was greater than to_created_date in this request body')

        elif (options['from_created_date'] and not options['to_created_date']) \
                or (not options['from_created_date'] and options['to_created_date']):
            raise CommandError(
                f'from_created_date and to_created_date are specified as a pair')

        else:
            if options['from_created_datetime'] and options['to_created_datetime']:
                if options['time_zone']:
                    raise CommandError(
                        f'If from_created_datetime and to_created_datetime are specified, '
                        f'time_zone must not be specified')

                if not check_datetime_format(datetime=options['from_created_datetime']):
                    raise CommandError(
                        f'from_created_datetime was invalid format in this request body')

                if not check_datetime_format(datetime=options['to_created_datetime']):
                    raise CommandError(
                        f'to_created_datetime was invalid format in this request body')

                if DateTimeUtil.YmdTHMSZ_utc_to_YmdHMS_utc(options['from_created_datetime']) > \
                        DateTimeUtil.YmdTHMSZ_utc_to_YmdHMS_utc(options['to_created_datetime']):
                    raise CommandError(
                        f'from_created_datetime was greater than to_created_datetime in this request body')

            elif (options['from_created_datetime'] and not options['to_created_datetime']) \
                    or (not options['from_created_datetime'] and options['to_created_datetime']):
                raise CommandError(
                    f'from_created_datetime and to_created_datetime are specified as a pair')

            else:
                raise CommandError(
                    f'Either from_created_date, to_created_date or '
                    f'from_created_datetime, to_created_datetime must be specified')

        try:
            CsvBatchProcessInfo.objects.get(
                request_id=options['request_id']
            )
        except CsvBatchProcessInfo.DoesNotExist:
            raise CommandError(f'Invalid request_id')

        try:
            boto3.client(
                's3', endpoint_url=settings.AWS_S3_ENDPOINT).head_object(
                Bucket=os.environ['S3_USAGE_DOWNLOAD_BUCKET'],
                Key=options['filename']
            )
        except ClientError:
            raise CommandError(
                f'Please upload file for csv before executing this batch')

    def filter_input_data(self, options):
        """
        入力データをDBで扱える形式に変換
        :param args:
        :param options:
        :return:
        """
        from_created_date = options['from_created_date']
        to_created_date = options['to_created_date']
        from_created_datetime = options['from_created_datetime']
        to_created_datetime = options['to_created_datetime']
        time_zone = options['time_zone']

        from_created = None
        to_created = None

        try:
            if from_created_date and to_created_date:
                from_created = DateTimeUtil.convert_date_format_000000(
                    from_created_date)
                to_created = DateTimeUtil.convert_date_format_235959(
                    to_created_date)

                if time_zone == 'UTC':
                    from_created = DateTimeUtil.replace_utc(from_created)
                    to_created = DateTimeUtil.replace_utc(to_created)

                else:
                    from_created = DateTimeUtil.replace_aware_utc(
                        DateTimeUtil.replace_jst(from_created))
                    to_created = DateTimeUtil.replace_aware_utc(
                        DateTimeUtil.replace_jst(to_created))

            if from_created_datetime and to_created_datetime:
                from_created = DateTimeUtil.YmdTHMSZ_utc_to_YmdHMS_utc(
                    from_created_datetime)
                to_created = DateTimeUtil.YmdTHMSZ_utc_to_YmdHMS_utc(
                    to_created_datetime)

        except ValueError as e:
            self.logger.error(e)
            raise CommandError(e)

        return {
            'from_created_date': from_created.strftime("%Y-%m-%d %H:%M:%S"),
            'to_created_date': to_created.strftime("%Y-%m-%d %H:%M:%S"),
            'time_zone': time_zone,
            'subscription_id': options['subscription_id'],
            'product_code': options['product_code'],
            'include_trial_data': options['include_trial_data']
        }

    def get_usage_data(self, options, limit, offset):
        """
        CSV用のデータを抽出する
        :param args:
        :param options:
        :return:
        """
        if options['from_created_date'] and options['to_created_date']:
            from_created_date = options['from_created_date']
            to_created_date = options['to_created_date']
        else:
            from_created_date = options['from_created_datetime']
            to_created_date = options['to_created_datetime']

        try:
            if options.get('include_trial_data') is True:
                sql = \
                    "SELECT usage_info.id, usage_info.subscription_id," \
                    " usage_info.usage_id, usage_info.product_code," \
                    " usage_info.target_month, usage_info.start_time," \
                    " usage_info.end_time, usage_info.quantity," \
                    " usage_info.license_user, usage_info.deleted," \
                    " usage_info.free_item1, usage_info.free_item2," \
                    " usage_info.created_time, usage_info.updated_time" \
                    " FROM usage_info INNER JOIN contract_info ON" \
                    " (usage_info.subscription_id = contract_info.subscription_id)" \
                    " WHERE usage_info.created_time >= %s" \
                    " AND usage_info.created_time < %s" \
                    " AND usage_info.deleted = 0" \
                    " AND NOT (contract_info.contract_code IS NULL OR contract_info.contract_code = '')"
            else:
                # Fixed #79687
                #      sql = \
                # "SELECT usage_info.id, usage_info.subscription_id,"\
                #     " usage_info.usage_id, usage_info.product_code,"\
                #     " usage_info.target_month, usage_info.start_time,"\
                #     " usage_info.end_time, usage_info.quantity,"\
                #     " usage_info.license_user, usage_info.deleted,"\
                #     " usage_info.free_item1, usage_info.free_item2,"\
                #     " usage_info.created_time, usage_info.updated_time"\
                # " FROM usage_info INNER JOIN contract_info ON"\
                #     " (usage_info.subscription_id = contract_info.subscription_id)"\
                #     " INNER JOIN ("\
                #         " SELECT contract_service_info.subscription_id,"\
                #         " MAX(contract_service_info.service_start_time) service_start_time"\
                #         " FROM contract_service_info"\
                #         " WHERE contract_service_info.product_type ='basic'"\
                #         " GROUP BY contract_service_info.subscription_id)"\
                #     " contract_service_info ON"\
                #     " (usage_info.subscription_id = contract_service_info.subscription_id)"\
                # " WHERE usage_info.created_time >= %s"\
                #     " AND usage_info.created_time <= %s"\
                #     " AND NOT (contract_info.contract_code IS NULL"\
                #     " OR contract_info.contract_code = '')"\
                #     " AND usage_info.start_time >= contract_service_info.service_start_time"\
                #     " AND usage_info.deleted = 0"
                sql = "SELECT usage_info.id, usage_info.subscription_id," \
                      " usage_info.usage_id, usage_info.product_code," \
                      " usage_info.target_month, usage_info.start_time," \
                      " usage_info.end_time, usage_info.quantity," \
                      " usage_info.license_user, usage_info.deleted," \
                      " usage_info.free_item1, usage_info.free_item2," \
                      " usage_info.created_time, usage_info.updated_time" \
                      " FROM usage_info " \
                      " INNER JOIN" \
                      "  ( SELECT" \
                      "      contract_service_info.subscription_id" \
                      "    , contract_service_info.product_code" \
                      "    , MAX(contract_service_info.service_start_time) service_start_time" \
                      "    FROM contract_service_info" \
                      "    GROUP BY" \
                      "      contract_service_info.product_code" \
                      "    , contract_service_info.subscription_id" \
                      "  ) contract_service_info" \
                      " ON" \
                      "  (" \
                      "    usage_info.subscription_id  = contract_service_info.subscription_id" \
                      "  AND usage_info.product_code   = contract_service_info.product_code" \
                      "  )" \
                      " INNER JOIN" \
                      "   contract_info " \
                      " ON" \
                      "  ( contract_info.subscription_id = contract_service_info.subscription_id" \
                      "  )" \
                      " WHERE" \
                      "  usage_info.created_time >= %s AND usage_info.created_time < %s " \
                      " AND NOT (" \
                      "    contract_info.contract_code IS  NULL" \
                      "  OR  contract_info.contract_code = ''" \
                      "  ) " \
                      " AND usage_info.start_time >= contract_service_info.service_start_time" \
                      " AND usage_info.deleted = 0"

            param = [
                from_created_date,
                to_created_date
            ]
            if options['subscription_id']:
                sql += " AND usage_info.subscription_id = %s"
                param.append(options['subscription_id'])

            if options['product_code']:
                sql += " AND usage_info.product_code = %s"
                param.append(options['product_code'])
            sql += " ORDER BY usage_info.created_time ASC LIMIT %s OFFSET %s ;"
            param.append(limit)
            param.append(offset)

            usage_info = UsageInfo.objects.raw(sql, param)
            return usage_info
        except UsageInfo.DoesNotExist:
            return False
