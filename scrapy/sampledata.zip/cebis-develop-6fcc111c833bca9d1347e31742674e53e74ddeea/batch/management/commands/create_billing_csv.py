"""
<copyright file="create_billing_csv.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import boto3
from botocore.exceptions import ClientError
from boto3.exceptions import S3UploadFailedError
from bs4 import BeautifulSoup
import copy
from collections import Counter
import os
from types import SimpleNamespace

from django.core.management.base import CommandError
from django.db import transaction

from batch.csv_file_pool import CsvFilePool
from batch.services import query_billing_csv_target, get_tmp_dir
from batch.management.batch_command_base import BatchCommandBase
from subscriptions.models import BillingDetailInfo
from lib.const.billing_info_state import COMPLETED
from lib.utils import DateTimeUtil
from lib.xml_utils import XmlUtils
from lib.const.create_billing_csv_process_timing import PROCESS_TIMING_LIST


class Command(BatchCommandBase):
    help = 'This Command Create Billing CSV FIle'
    ENV_KEY_S3_BUCKET = 'S3_FOR_BILLING_CSV_BUCKET'

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.batch_name = 'create billing csv file batch'
        self.error_records = list()

    def add_arguments(self, parser):
        """
        実行時に指定可能なパラメータの引数への追加処理
        :param parser:
        :return:
        """
        # テストや動作検証のため、last_monthオプションを外部から指定できるようにする
        parser.add_argument('--target_month', type=str,
                            default=DateTimeUtil.get_prev_ym())  # 初期値はバッチ実行日時の前年月
        #[#109529請求情報CSV連携タイミングを２回にする]対応
        parser.add_argument('--process_timing', type=str, default=None)

    def __add_statement(self, record, statements):
        """
        利用明細のXMLに項目を追加する
        :param record:
        :param statements:
        :return:
        """
        # 利用明細がない場合はXMLを生成しない
        if record.license_user is None:
            return
        # xml.etree.ElementTreeだと"と'がエスケープ出来ないので、BeautifulSoupで自力でXMLを生成
        soup = BeautifulSoup()
        statement = soup.new_tag('statement')
        license_user = soup.new_tag('license-user')
        license_user.string = XmlUtils.esc_include_quot(record.license_user)
        statement.append(license_user)
        billing = soup.new_tag('billing')
        billing.string = XmlUtils.esc_include_quot(record.billing_usage_detail)
        statement.append(billing)
        quantity = soup.new_tag('quantity')
        quantity.string = XmlUtils.esc_include_quot(record.billing_usage_quantity)
        statement.append(quantity)
        statements.append(statement)

    def __create_header(self)->list:
        """
        CSVファイルのヘッダ行を生成する
        :return:
        """

        header = list()
        header.append('#subscription_id')
        header.append('target_month')
        header.append('contract_code')
        header.append('opco_code')
        header.append('start_date')
        header.append('end_date')
        header.append('billing')
        header.append('product_code')
        header.append('license_quantity')
        header.append('billing_for_product_code')
        header.append('quantity')
        header.append('unit_of_money')
        header.append('statements')

        return header

    def __logging_state_error(self, record, error_msg):

        # 既にエラーログ出力済みの請求データの場合はスキップ
        if any(
                record.target_month == err_rec.target_month and record.subscription_id == err_rec.subscription_id
                for err_rec in self.error_records):
            return

        self.error_records.append(record)
        self.logger.error(
            error_msg+
            f' subscription_id:{record.subscription_id} '
            f'target_month:{record.target_month} '
            f'state:{record.state} '
            f'product_code_id:{record.product_code_id} '
            f'product_info_free_item1:{record.product_info_free_item1}')

    def __upload_files_to_s3(self, collection, target_month: str, bucket_name: str, filename_prefix: str):
        """
        生成したCSVファイルをS3バケットにUPする
        :type collection: Counter
        :param collection:
        :type target_month: str
        :param target_month:
        :type bucket_name: str
        :param bucket_name
        :type filename_prefix: str
        :param filename_prefix
        :return:
        """

        self.logger.info('Start Upload Files To S3Bucket...')
        s3 = boto3.client('s3')
        year = target_month[:4]
        tmp_dir = get_tmp_dir()
        for key in collection.keys():
            local_file = os.path.join(tmp_dir, f'{filename_prefix}_{key}.csv')
            obj_key = f'{key}/{year}/{filename_prefix}_{key}_{target_month}.csv'
            self.logger.info(f'Start Upload CSV File: {local_file} to s3://{bucket_name}/{obj_key}')
            try:
                s3.upload_file(local_file, bucket_name, obj_key)
            except (ClientError, S3UploadFailedError) as e:
                self.logger.error(f'Upload CSV File Failed... {e}')
            self.logger.info(f'Complete Upload CSV File: {local_file} to s3://{bucket_name}/{obj_key}')

        self.logger.info(f'Complete Upload All CSV Files')

    def __write_csv_line(self, writer, record, statements_tag):
        """
        CSVファイルに１レコードの書き込みを行う
        :param writer:
        :param record:
        :param xml_elm:
        :return:
        """
        csv_row = list()
        csv_row.append(record.subscription_id)                      # サブスクリプションID
        csv_row.append(record.target_month)                         # 対象月度
        csv_row.append(record.contract_code)                        # 契約連番
        csv_row.append(record.opco_code)                            # 仕向け地
        csv_row.append(record.start_date)                           # 請求対象期間開始日
        csv_row.append(record.end_date)                             # 請求対象期間終了日
        csv_row.append(record.billing)                              # 請求金額(総額)
        csv_row.append(record.product_code_id)                      # 商品コード
        csv_row.append(record.license_quantity)                     # ライセンス数
        csv_row.append(record.billing_for_product_code)             # 商品コード別請求金額
        csv_row.append(record.quantity)                             # 合計利用量
        csv_row.append(record.unit_of_money)                        # 通貨

        if statements_tag.statement is None:
            statements = ''
        else:
            statements = statements_tag.decode(formatter=None)

        csv_row.append(statements)    # 利用明細

        return writer.writerow(csv_row)

    def __validate_processing_timing_parameter(self,record,process_timing):
        """
        商品情報のfree_item1 およびprocessing_timingの合理性チェック
        return False:処理対象外 True:処理対象
        """
        if not record.product_info_free_item1:
            self.__logging_state_error(record,
                                       'free_item1 of product_info is invalid because it is null or empty... skip output billing info ')
            return False

        process_timing_list = [timing for timing in PROCESS_TIMING_LIST if timing in record.product_info_free_item1]
        if len(list(process_timing_list)) > 1:
            self.__logging_state_error(record,
                                       'free_item1 of product_info is invalid because it have both [1st] and [2nd] character strings... skip output billing info ')
            return False

        if process_timing not in record.product_info_free_item1:
            return False

        return True

    def do_validate(self, *args, **options):
        """
        引数等のバリデーション処理
        :param args:
        :param options:
        :return:
        """
        if os.getenv(Command.ENV_KEY_S3_BUCKET) is None:
            raise CommandError(f'Please Set Environment Variable: {Command.ENV_KEY_S3_BUCKET}')

        # [#109529請求情報CSV連携タイミングを２回にする]対応
        if options['process_timing'] is None:
            raise CommandError(f'please set parameter variable: process_timing(1st or 2nd...)')


    @transaction.atomic()
    def main_process(self, *args, **options):
        """
        請求情報CSV出力バッチメイン処理
        :param args:
        :param options:
        :return:
        """

        csv_contexts = {}

        BILLING = 'billing'
        PROFITSHARE = 'profitshare'
        outputs = [BILLING, PROFITSHARE]
        for output in outputs:
            soup = BeautifulSoup()
            csv_contexts[output] = SimpleNamespace(
                pool=None,
                counter=Counter(),
                is_first=True,
                soup=soup,
                statements=soup.new_tag('statements'),
                prev_record=None,
                billing_detail=BillingDetailInfo()
            )

        target_month = options['target_month']
        # [#109529請求情報CSV連携タイミングを２回にする]対応
        process_timing = options['process_timing']

        records = query_billing_csv_target(target_month)

        with CsvFilePool(BILLING, self.__create_header(), get_tmp_dir()) as billing_file_pool, CsvFilePool(PROFITSHARE, self.__create_header(), get_tmp_dir()) as profitshare_file_pool:
            csv_contexts[BILLING].pool = billing_file_pool
            csv_contexts[PROFITSHARE].pool = profitshare_file_pool

            for record in records:

                # [#109529請求情報CSV連携タイミングを２回にする]対応
                if not self.__validate_processing_timing_parameter(record,process_timing):
                    continue

                if record.subscription_id[-1] == 'G':
                    csv_context = csv_contexts[PROFITSHARE]

                    # プロフィットシェア料金情報の利用明細(statements)は常にNullにする
                    record.license_user = None
                else:
                    csv_context = csv_contexts[BILLING]

                before_billing_detail = copy.deepcopy(csv_context.billing_detail)
                csv_context.billing_detail = BillingDetailInfo(
                    subscription_id=record.subscription_id,
                    target_month=record.target_month,
                    product_code_id=record.product_code_id)

                if record.state != COMPLETED:
                    self.__logging_state_error(record,'billing state is invalid because it is not completed... skip output billing info ')
                    continue

                # 別の請求明細に移ったら書き込み
                if csv_context.is_first is False and csv_context.billing_detail.is_same_key(before_billing_detail) is False:
                    writer = csv_context.pool.get_writer(csv_context.prev_record.opco_code)
                    self.__write_csv_line(writer, csv_context.prev_record, csv_context.statements)
                    csv_context.counter[csv_context.prev_record.opco_code] += 1
                    csv_context.statements = soup.new_tag('statements')

                self.__add_statement(record, csv_context.statements)
                csv_context.is_first = False
                csv_context.prev_record = copy.deepcopy(record)

            for csv_context in csv_contexts.values():
                if csv_context.prev_record is not None:
                    writer = csv_context.pool.get_writer(csv_context.prev_record.opco_code)
                    self.__write_csv_line(writer, csv_context.prev_record, csv_context.statements)
                    csv_context.counter[csv_context.prev_record.opco_code] += 1

        for csv_context_name, csv_context in csv_contexts.items():
            for key, val in csv_context.counter.items():
                self.logger.info(f'Successfully created {csv_context_name} csv... opco_code:{key} number of records:{val}')

            if len(csv_context.counter.keys()) != 0:
                self.__upload_files_to_s3(csv_context.counter, target_month, os.getenv(f'S3_FOR_{csv_context_name.upper()}_CSV_BUCKET'), csv_context_name)
