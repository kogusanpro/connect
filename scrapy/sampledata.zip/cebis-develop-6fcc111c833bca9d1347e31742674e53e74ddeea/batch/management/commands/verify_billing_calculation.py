"""
<copyright file="verify_billing_calculation.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2020. All rights reserved.
</copyright>
"""

from batch.management.batch_command_base import BatchCommandBase
from lib.const.billing_info_state import COMPLETED
from lib.utils import DateTimeUtil
from subscriptions.models import BillingInfo, BillingDetailInfo, UsageInfo, ContractServiceInfo, ContractInfo, ProductInfo
from django.core.management.base import CommandError
from lib.const.create_billing_csv_process_timing import PROCESS_TIMING_LIST

class Command(BatchCommandBase):
    HELP = 'This command verifies the billing calculation result.'

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.batch_name = 'verify billing calculation'

    def __validate_processing_timing_parameter(self,product_code,process_timing):
        """
        商品情報のfree_item1 およびprocessing_timingの合理性チェック
        return False:処理対象外 Ture:処理対象
        """
        product_info = ProductInfo.objects.get(product_code=product_code)
        if not product_info.free_item1:
            self.logger.error(
                'free_item1 of product_info is invalid because it is null or empty... skip output billing info'
                f' product_code:{product_code} '
                f' free_item1:{product_info.free_item1} ')
            return False

        process_timing_list = [timing for timing in PROCESS_TIMING_LIST if timing in product_info.free_item1]
        if len(list(process_timing_list)) > 1:
            self.logger.error(
                'free_item1 of product_info is invalid because it have both [1st] and [2nd] character strings... skip output billing info '
                f' product_code:{product_code} '
                f' free_item1:{product_info.free_item1} ')
            return False

        if process_timing not in product_info.free_item1:
            return False

        return True

    def add_arguments(self, parser):
        """
        実行時に指定可能なパラメータの引数への追加処理
        :param parser:
        :return:
        """

        # テストや動作検証のため、last_monthオプションを外部から指定できるようにする
        parser.add_argument('--last_month', type=str,
                            default=DateTimeUtil.get_prev_ym())  # 初期値はバッチ実行日時の前月の年月
        #[#109529請求情報CSV連携タイミングを２回にする]対応
        parser.add_argument('--process_timing', type=str, default=None)

    def do_validate(self, *args, **options):
        """
        引数のバリデーション処理
        :param args:
        :param options:
        :return:
        """

        # [#109529請求情報CSV連携タイミングを２回にする]対応
        if options['process_timing'] is None:
            raise CommandError(f'please set parameter variable: process_timing(1st or 2nd...)')

    def main_process(self, *args, **options):
        """
        請求金額検算バッチメイン処理
        :param args:
        :param options:
        :return:
        """
        self.last_month = options['last_month']

        # [#109529請求情報CSV連携タイミングを２回にする]対応
        process_timing = options['process_timing']

        billing_infos = BillingInfo.objects.filter(target_month=self.last_month)
        self.logger.info(f'size of billing_info in {self.last_month} : {billing_infos.count()}')

        billing_details_in_last_month = BillingDetailInfo.objects.filter(target_month=self.last_month)
        for billing_detail in billing_details_in_last_month:
            if not billing_detail.subscription_id.lower().endswith('g'):
                try:
                    subscription_id = billing_detail.subscription_id  # サブスクリプションID
                    product_code = billing_detail.product_code.pk  # プロダクトコード
                    target_month = billing_detail.target_month  # 対象月度

                    # [#109529請求情報CSV連携タイミングを２回にする]対応
                    if not self.__validate_processing_timing_parameter(product_code, process_timing):
                        continue

                    # AR90019 Added contract_infos references
                    try:
                        contract_info = ContractInfo.objects.get(
                                                    subscription_id=subscription_id)
                        contract_service_info = ContractServiceInfo.objects.get(
                                                    subscription_id=subscription_id,
                                                    product_code=product_code)
                    except Exception as e:
                        self.logger.fatal(f'contract_info is not found : {subscription_id}')
                        continue

                    if self.__contract_is_trial(contract_info):
                        # do nothing
                        continue

                    service_start_time = contract_service_info.service_start_time
                    service_cancel_time = contract_service_info.service_cancel_time


                    billing_info = billing_infos.get(subscription_id=subscription_id,
                                                     target_month=target_month)
                    if billing_info.state != COMPLETED:
                        self.logger.error(f'billing calculation for '
                                          f'({subscription_id}, {product_code}, {target_month}) is NOT FINISHED.')
                    else:
                        # AR90019 Added service_start_time and cancel_time for sum calculation
                        target_quantity = self.__sum_total_quantity(subscription_id, product_code, target_month,
                                                                    service_start_time, service_cancel_time)
                        if target_quantity is not None:
                            self.__check_quantity_consistency(billing_detail, target_quantity)
                        else:
                            self.logger.error(
                                f'target_quantity for ({subscription_id}, {product_code}, {target_month}) is None.')

                except Exception as e:
                    self.logger.fatal(e)

    def __sum_total_quantity(self, subscription_id, product_code, target_month, service_start_time, service_cancel_time):
        
        # AR90019 Added service_start_time and cancel_time to usage filter condition
        if service_cancel_time is None:
            usages = UsageInfo.objects.filter(subscription_id=subscription_id,
                                            product_code=product_code,
                                            target_month=target_month,
                                            deleted=0,
                                            start_time__gte=service_start_time)
        else:
            usages = UsageInfo.objects.filter(subscription_id=subscription_id,
                                            product_code=product_code,
                                            target_month=target_month,
                                            deleted=0,
                                            start_time__gte=service_start_time,
                                            end_time__lte=service_cancel_time)

        total_quantity = 0
        if 0 < usages.count():
            try:
                from django.db.models import Sum
                total_quantity = usages.aggregate(Sum('quantity'))['quantity__sum']
            except Exception as e:
                self.logger.fatal(e)
                total_quantity = None
        else:
            self.logger.info(f'usage not found: {subscription_id}, {product_code}.')
        return total_quantity

    def __check_quantity_consistency(self, billing, target_quantity):
        import math
        quantity_are_same = math.isclose(float(billing.quantity), float(target_quantity))
        if quantity_are_same:
            self.logger.info(f'quantity is VALID: '
                             f'(subscription_id: {billing.subscription_id} '
                             f'product_code: {billing.product_code.pk} '
                             f'target_month: {billing.target_month})')
        else:
            self.logger.error(f'quantity is INVALID: '
                              f'(subscription_id: {billing.subscription_id} '
                              f'product_code: {billing.product_code.pk} '
                              f'target_month: {billing.target_month})')
        return 0

    def __contract_is_trial(self, contract_info):
        if not contract_info.contract_code: # is null or empty
            return True
        return False