"""
<copyright file="change_calc_state_to_new.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""

from batch.management.batch_command_base import BatchCommandBase
from lib.const.esker_product_code_list import ESKER_PRODUCT_CODE_LIST
from lib.const.billing_info_state import NEW, COMPLETED
from lib.utils import DateTimeUtil
from subscriptions.models import BillingInfo, BillingDetailInfo


class Command(BatchCommandBase):
    HELP = 'This command change calculation state to new products.'

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.batch_name = 'change calculation state to "new" products'

    def add_arguments(self, parser):
        """
        実行時に指定可能なパラメータの引数への追加処理
        :param parser:
        :return:
        """
        # テストや動作検証のため、last_monthオプションを外部から指定できるようにする
        parser.add_argument('--last_month', type=str,
                            default=DateTimeUtil.get_prev_ym())  # 初期値はバッチ実行日時の前月の年月

    def do_validate(self, *args, **options):
        """
        引数のバリデーション処理
        :param args:
        :param options:
        :return:
        """

    def main_process(self, *args, **options):
        """
        Esker商品群向け請求情報計算状態変更バッチメイン処理
        :param args:
        :param options:
        :return:
        """
        self.last_month = options['last_month']

        try:
            # 対象月度がバッチ実行日時（JST）の前月度の年月である請求明細情報を取得する。
            billing_details_infos = BillingDetailInfo.objects.filter(target_month=self.last_month)
            # 請求明細情報を繰り返す。
            errorlist = []
            for billing_detail_info in billing_details_infos:
                # 商品コードがEsker商品群の商品コードと一致する場合
                if billing_detail_info.product_code.pk in ESKER_PRODUCT_CODE_LIST:
                    # 請求情報を取得する。
                    billing_info = BillingInfo.objects.filter(
                        subscription_id=billing_detail_info.subscription_id,
                        target_month=billing_detail_info.target_month,
                        state=COMPLETED)
                    profit_share_billing_info = BillingInfo.objects.filter(
                        subscription_id=billing_detail_info.subscription_id + "G",
                        target_month=billing_detail_info.target_month,
                        state=COMPLETED)
                    # 請求情報を取得した場合
                    if len(billing_info) and len(profit_share_billing_info) :
                        # 請求情報の計算状態を「未計算」(new)に変更する。
                        billing_info.update(state=NEW)
                        profit_share_billing_info.update(state=NEW)
                        self.logger.info(f'The billing calculation: '
                                         f'(subscription_id: {billing_detail_info.subscription_id} '
                                         f'target_month: {billing_detail_info.target_month}) '
                                         f'has been returned back to new.')
                        self.logger.info(f'The profit share billing calculation: '
                                         f'(subscription_id: {billing_detail_info.subscription_id + "G"} '
                                         f'target_month: {billing_detail_info.target_month}) '
                                         f'has been returned back to new.')
                    elif billing_info:
                        if billing_detail_info.subscription_id not in errorlist:
                            self.logger.fatal(f'The profit share billing calculation: '
                                             f'(subscription_id: {billing_detail_info.subscription_id + "G"} '
                                             f'target_month: {billing_detail_info.target_month} '
                                             f'state: completed )'
                                             f'has not exist.')
                            errorlist.append(billing_detail_info.subscription_id)
                    elif profit_share_billing_info:
                        if billing_detail_info.subscription_id+"G" not in errorlist:
                            self.logger.fatal(f'The profit share billing calculation: '
                                             f'(subscription_id: {billing_detail_info.subscription_id} '
                                             f'target_month: {billing_detail_info.target_month} '
                                             f'state: completed )'
                                             f'has not exist.')
                            errorlist.append(billing_detail_info.subscription_id+"G")

        except Exception as e:
            self.logger.fatal(e)
