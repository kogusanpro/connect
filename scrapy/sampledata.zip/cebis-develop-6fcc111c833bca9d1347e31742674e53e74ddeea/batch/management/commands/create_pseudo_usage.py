"""
<copyright file="create_pseudo_usage.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.core.management.base import CommandError
from django.db import transaction
from django.db.utils import IntegrityError
from django.utils.timezone import datetime

from batch.services import query_pseudo_usage_target
from batch.management.batch_command_base import BatchCommandBase
from subscriptions.models import BillingDetailInfo, ContractServiceInfo, UsageInfo
from lib.const.usage_info import FREE_ITEM_FOR_PSEUDO_RECORD
from lib.const.pseudo import BATCH_EXEC_TIME
from lib.const.contract_service_state import ACTIVE
from lib.utils import DateTimeUtil, check_date_ym_format
from pytz import UTC


class Command(BatchCommandBase):
    help = 'This Command Create Pseudo Usage info'

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.batch_name = 'create pseudo usage info batch'

    def add_arguments(self, parser):
        # バッチ実行日時(JST)
        parser.add_argument('--target_ym', type=str,default=DateTimeUtil.get_current_ym())

    def do_validate(self, *args, **options):
        """
        継承先で任意で実装するバリデーション処理
        :param args:
        :param options:
        :return:
        """
        self.target_ym=options['target_ym']
        if not check_date_ym_format(self.target_ym):
            raise CommandError(
                f'target_ym was invalid format in this request body')


    def __create_usage_info(self, contract_service: ContractServiceInfo)->UsageInfo:
        """
        契約サービス情報から擬似従量データのレコードを生成して返す
        :type contract_service: ContractServiceInfo
        :param contract_service: 契約サービス情報
        :rtype: BillingDetailInfo
        :return: 擬似従量データ
        """

        if contract_service.state == ACTIVE:
            # 127484 (ライセンス型定額課金の請求計算に必要なデータ生成バッチである対象疑似データが作成されない)対応
            date_time = self.__get_batch_exec_time_from_yyyymm(self.target_ym)            
        else:
            date_time = contract_service.service_cancel_time

        now = DateTimeUtil.utc_now_aware()
        usage_info = UsageInfo()
        usage_info.subscription_id = contract_service.subscription_id           # サブスクリプションID
        usage_info.product_code = contract_service.product_code_id              # 商品コード
        usage_info.target_month = self.target_ym                                # 対象年月
        usage_info.start_time = date_time                                       # 利用開始日時
        usage_info.end_time = date_time                                         # 利用終了日時
        usage_info.quantity = contract_service.license_quantity                 # 利用量
        usage_info.license_user = None                                          # ユーザー
        usage_info.deleted = False                                              # 論理削除
        usage_info.free_item1 = FREE_ITEM_FOR_PSEUDO_RECORD                     # 自由入力1
        usage_info.free_item2 = None                                            # 自由入力2
        usage_info.created_time = now                                           # 作成日時
        usage_info.updated_time = now                                           # 更新日時
        usage_info.usage_id = usage_info.create_usage_id()                      # 従量ID

        return usage_info

    def __exists_usage_info(self, subscription_id, usage_id):
        """
        指定されたサブスクリプションID,従量IDの従量データが登録済みかをチェックして返す
        登録済みの場合はエラーログの出力も合わせて行う
        :type subscription_id int
        :param subscription_id:
        :type usage_id str
        :param usage_id:
        :rtype : bool
        :return:
        """
        try:
            UsageInfo.objects.get(subscription_id=subscription_id, usage_id=usage_id)
            self.logger.error(f'subscription_id {subscription_id} and usage_id {usage_id} is '
                              f'already exists in usage_info')
            return True
        except UsageInfo.DoesNotExist:
            return False

    def __get_lastday_from_yyyymm(self,target_ym):
        """
        target_ym
        :param target_ym:
        :return:
        """
        # 127484 (ライセンス型定額課金の請求計算に必要なデータ生成バッチである対象疑似データが作成されない)対応
        exec_date = DateTimeUtil.utc_now_aware().replace(year=int(target_ym[0:4]),
                                                    month=int(target_ym[4:6]))
        exec_date = DateTimeUtil.get_end_of_the_month(exec_date)
        return exec_date

    def __get_batch_exec_time_from_yyyymm(self,target_ym):
        """
        target_ym文字列からタイムスタンプ取得する
        :param date:
        :return:
        """
        # 127484 (ライセンス型定額課金の請求計算に必要なデータ生成バッチである対象疑似データが作成されない)対応
        date=self.__get_lastday_from_yyyymm(target_ym).strftime('%Y-%m-%d') + ' ' + BATCH_EXEC_TIME
        return datetime.strptime(date, '%Y-%m-%d %H:%M:%S').replace(tzinfo=UTC)

    @transaction.atomic()
    def main_process(self, *args, **options):
        """
        擬似従量データ作成バッチメイン処理
        :param args:
        :param options:
        :return:
        """
        # 127484 (ライセンス型定額課金の請求計算に必要なデータ生成バッチである対象疑似データが作成されない)対応
        last_day =self.__get_lastday_from_yyyymm(self.target_ym)
        begin_of_month = last_day.replace(day=1,hour=0, minute=0, second=0, microsecond=0)
        begin_of_next_month = DateTimeUtil.get_begin_of_next_month(last_day)
        records = query_pseudo_usage_target(last_day, begin_of_month, begin_of_next_month)

        try:
            rec_cnt = 0
            for record in records:
                usage = self.__create_usage_info(record)
                if not self.__exists_usage_info(usage.subscription_id, usage.usage_id):
                    usage.save()
                    rec_cnt += 1
        except IntegrityError as e:
            self.logger.error(e)
            raise e

        self.logger.info('Successfully Created Pseudo Usage info')
        self.logger.info(f'Pseudo Usage info created {rec_cnt} records')
