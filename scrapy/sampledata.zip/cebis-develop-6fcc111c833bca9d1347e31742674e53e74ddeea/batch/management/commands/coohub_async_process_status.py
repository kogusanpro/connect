"""
<copyright file="coohub_async_process_status.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2020. All rights reserved.
</copyright>
"""
import os

from batch.management.batch_command_base import BatchCommandBase
from django.utils.timezone import datetime, timedelta
from lib.utils import ServerUtil
from lib.const.coohub_k5_tenants import K5_TENANTS
from pytz import UTC, timezone


class Command(BatchCommandBase):
    help = 'This Command Get Asynchronous Process Status'

    def __init__(self):
        """
        グローバル変数を初期化する
        """
        super().__init__()

        # バッチ名
        self.batch_name = 'coohub async process status batch'

        # バッチ実行日時(JST)の年月日
        self.executed_date = None

        # k5のホストアドレスのURL
        self.k5_api_endpoint = None

        # 「非同期処理状況を取得する」APIのURL
        self.async_process_status_url = None

        # 「非同期処理のエラー情報を取得する」APIのURL
        self.async_process_error_information_api_url = None

        # エラー情報のリスト
        self.error_information_list = None

    def add_arguments(self, parser):
        """
        実行時に指定可能なパラメータの引数への追加処理
        :param parser:
        :return:
        """
        # バッチ実行日時(JST)
        parser.add_argument('--executed_date', type=str,
                            default=datetime.utcnow().replace(tzinfo=UTC).astimezone(timezone('Asia/Tokyo')))

        # k5のホストアドレス
        parser.add_argument('--k5_api_endpoint', type=str, default=os.environ['K5_API_ENDPOINT'])

        # 「非同期処理状況を取得する」APIのURL
        parser.add_argument('--async_process_status_url', type=str, default=os.environ['K5_ASYNC_PROCESS_STATUS_URL'])

        # 「非同期処理のエラー情報を取得する」APIのURL
        parser.add_argument('--async_process_error_information_url', type=str,
                            default=os.environ['K5_ASYNC_PROCESS_ERROR_INFORMATION_URL'])

    def __init_global_param(self, options):
        """
        グローバル変数を初期化する
        :return:
        """
        # バッチ実行日時(JST)の年月日
        # バッチ実行日時に渡されるパラメーター
        self.executed_date = options.get("executed_date")
        if not isinstance(self.executed_date, datetime):
            # 手動実行(JST)
            parameter_year = self.executed_date[0:4]
            parameter_month = self.executed_date[4:6]
            parameter_day = self.executed_date[6:8]
            self.executed_date = datetime(int(parameter_year), int(parameter_month), int(parameter_day), 10)\
                .replace(tzinfo=timezone('Asia/Tokyo'))
        else:
            # 自動実行
            self.executed_date = options.get("executed_date")

        self.logger.info(f'Executed date is {self.executed_date.strftime("%Y-%m-%d")} (JST)...')

        # k5のホストアドレス
        self.k5_api_endpoint = options.get("k5_api_endpoint")

        # 「非同期処理状況を取得する」APIのURL
        self.async_process_status_url = options.get("async_process_status_url")

        # 「非同期処理のエラー情報を取得する」APIのURL
        self.async_process_error_information_api_url = options.get("async_process_error_information_url")

        # エラー情報のリスト
        self.error_information_list = list()

    def main_process(self, *args, **options):
        """
        従量計算システムが定期的に内部実行するバッチ処理(利用料計算バッチ、利用実績登録バッチ等)
        の処理ステータスを定期的に監視し、失敗を検知した場合にアラートメールを送信する
        :param args: システムパラメータ
        :param options: システムパラメータ
        :return:
        """

        # グローバル変数を初期化する
        self.__init_global_param(options)

        for k5_tenant in K5_TENANTS:
            # 非同期処理状況取得する
            async_process_status = self.__get_async_process_status(k5_tenant)
            # 非同期処理状況エラーの詳細を取得する
            self.__check_async_process_status(async_process_status, k5_tenant)

        #　エラーログを出力する
        self.__output_error_log()

    def __get_async_process_status(self, k5_tenant: dict()):
        """
        非同期処理状況を取得する
        :return:　async_process_status_response_list :非同期処理状況を取得するAPIの戻り値リスト
        """
        self.logger.info('get async process status from K5 ...')

        # バッチ実行日時(JST)の前日の年月日
        params = {'from_date': (self.executed_date - timedelta(days=1)).strftime("%Y%m%d")}

        self.logger.info(f'Start execte "/API/v2/api/asyncprocessstatus"API(K5)... params={params}')

        # 「非同期処理状況を取得する」APIを実行する
        process_status_response = ServerUtil(self).get_k5_response(
            url=self.k5_api_endpoint + self.async_process_status_url,
            params=params,
            method='GET',
            allow_token_time_out_minutes=5,
            data=dict(),
            k5_tenant=k5_tenant)

        process_status_response_json=process_status_response.json()
        self.logger.info(f'Response status_code={process_status_response.status_code}')
        self.logger.info(f'Response body ={process_status_response_json}')

        if process_status_response.status_code is 200:
            return process_status_response_json.get('async_process_status')
        elif process_status_response.status_code == 404:
            # K5の動作がないため、状態がNOT FOUND 正常に扱いにする
            self.logger.info(
                f'Got async process status NOT FOUND from k5 server. k5_client_id:{k5_tenant.get("client_id")} ...')
            self.logger.info(f' URL={self.k5_api_endpoint + self.async_process_status_url}')
            return None
        else:
            # 仕様書での記載によって、処理結果一覧の取得に失敗した場合、異常終了する必要がある。
            # しかし、K5サーバーが複数存在する場合、１台のK5サーバーの取得操作に失敗したら、
            # その他のK5サーバーの取得操作を影響しないはずだということを考慮して、
            # ここは、プログラムを異常終了させず、ただエラーログを出力するようにしている。
            self.logger.error(
                f'Got async process status failed from k5 server. k5_client_id:{k5_tenant.get("client_id")} ...')
            self.logger.info(f'Failed URL={self.k5_api_endpoint + self.async_process_status_url}')
            return None

    def __check_async_process_status(self, async_process_status: list, k5_tenant: dict):
        """
        同期処理状況結果をチェックする
        :param async_process_status: 非同期処理状況を取得するAPIの戻り値
        """
        self.logger.info('get async error information from K5 ...')
        if async_process_status is not None:
            for process_status in async_process_status:
                if process_status.get('process_status') != '10':
                    receipt_code = process_status.get('receipt_code')
                    self.logger.info(f'receipt_code is{receipt_code}')
                    if process_status.get('process_status') == '00':
                        self.logger.error(f'process_status is 00 ,message: not processed')
                    if process_status.get('process_status') == '01':
                        self.logger.error(f'process_status is 01 ,message: processing')
                    if process_status.get('process_status') == '05':
                        self.logger.error(f'process_status is 05 ,message: processing, include warning')
                    if process_status.get('process_status') == '50':
                        self.logger.error(f'process_status is 50 ,message: warning finished')
                    if process_status.get('process_status') == '99':
                        self.logger.error(f'process_status is 99 ,message: error finished')
                    # ERROR詳細情報を取得して、表示する
                    self.error_information_list.extend(
                        self.__request_get_async_process_error_information(
                            process_status.get('receipt_code'),
                            k5_tenant))

    def __request_get_async_process_error_information(self, receipt_code: str, k5_tenant: dict):
        """
        非同期処理エラー詳細情報取得する
        :param receipt_code:検索したエラー情報の単位(受付ID)
        :param k5_tenant:K5サーバー情報
        """
        params = {"receipt_code": receipt_code}

        self.logger.info(f'Start execte "/API/v2/api/asyncerror"API(K5)... params={params}')

        # サービス契約を検索するAPIを実行する
        error_info_response = ServerUtil(self).get_k5_response(
            url=self.k5_api_endpoint + self.async_process_error_information_api_url,
            params=params,
            method='GET',
            allow_token_time_out_minutes=5, data=dict(),
            k5_tenant=k5_tenant)

        error_info_response_json=error_info_response.json()
        self.logger.info(f'Response status_code={error_info_response.status_code}')
        self.logger.info(f'Response body ={error_info_response_json}')

        if error_info_response.status_code is 200:
            return error_info_response_json.get('async_processing_error_information_list')
        else:
            self.logger.info(
                f'Got async process error information failed from k5 server.'
                f'k5_client_id:{k5_tenant.get("client_id")} ...')
            self.logger.info(f'Failed receipt_code {receipt_code}')
            self.logger.info(f'Failed URL={self.k5_api_endpoint + self.async_process_error_information_api_url}')

    def __output_error_log(self):
        """
        エラーログを出力して処理
        """
        if len(self.error_information_list).__gt__(0):
            for error_info in self.error_information_list:
                self.logger.info(error_info.get('async_process_error_information'))
