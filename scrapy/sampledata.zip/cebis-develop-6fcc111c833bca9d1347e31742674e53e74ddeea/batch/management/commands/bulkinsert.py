"""
<copyright file="bulkinsert.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""

from django.db import transaction, Error

from lib.const.opco_code import OPCO_TIMEZONE
from status.models import CsvBatchProcessInfo
from batch.management.batch_command_base import BatchCommandBase
from subscriptions.models import UsageInfo, ContractInfo
from subscriptions.serializers import SubscriptionsUsagePostSerializer, SubscriptionsValidationError
from datetime import datetime, date
from pytz import timezone
from lib.utils import check_datetime_format, check_date_ym_format, convert_datetime_format, logger
import boto3
from botocore.exceptions import ClientError
import sys
import hashlib
import time
import uuid
from lib.const.s3_for_usage import CSV_DIR_IN, CSV_DIR_PROCESSING, CSV_DIR_OUT
import csv
from io import StringIO
from dateutil import parser
from rest_framework import status


@transaction.atomic()
class Command(BatchCommandBase):
    help = 'This Command Bulk Insert From CSV File'

    def add_arguments(self, parser):
        parser.add_argument('bucket', type=str)
        parser.add_argument('key', type=str)

    def main_process(self, *args, **options):
        if not options['key'].startswith(CSV_DIR_IN):
            sys.exit(0)

        s3 = boto3.resource('s3')
        in_s3_obj = s3.Object(options['bucket'], options['key'])
        csv_bytes = in_s3_obj.get()['Body'].read()

        key_without_prefix = options['key'].replace(CSV_DIR_IN + '/', '', 1)

        def ExitWithErrorCode(error_code):
            csv_batch_process_info.process_result = 'Fail'
            csv_batch_process_info.error_code = error_code
            csv_batch_process_info.save()
            sys.exit(1)

        def try_put_to_s3(prefix):
            s3_obj = s3.Object(options['bucket'], prefix + '/' + key_without_prefix)
            try:
                s3_obj.get()
            except ClientError as err:
                if err.response['Error']['Code'] == 'NoSuchKey':
                    try:
                        s3_obj.put(Body=csv_bytes)
                        return s3_obj
                    except:
                        ExitWithErrorCode('G')
                else:
                    ExitWithErrorCode('G')
            except:
                    ExitWithErrorCode('G')
            else:
                try:
                    s3_obj = s3.Object(options['bucket'], prefix + '/' + key_without_prefix + str(uuid.uuid4()))
                    s3_obj.put()
                    return s3_obj
                except:
                    ExitWithErrorCode('G')

        processing_s3_obj = try_put_to_s3(CSV_DIR_PROCESSING)
        in_s3_obj.delete()

        csv_batch_process_info = CsvBatchProcessInfo.objects.get(
            pk=key_without_prefix)
        csv_batch_process_info.process_result = 'Processing'
        csv_batch_process_info.csv_link = \
            f'https://s3-ap-northeast-1.amazonaws.com/{processing_s3_obj.bucket_name}/{processing_s3_obj.key}'
        csv_batch_process_info.save()

        csv_md5 = hashlib.md5(csv_bytes).hexdigest()
        if csv_md5 != csv_batch_process_info.content_md5:
            ExitWithErrorCode('A')

        decoded_csv = None
        try:
            decoded_csv = csv_bytes.decode('utf-8')
        except UnicodeDecodeError:
            ExitWithErrorCode('B1')

        if decoded_csv.find('\r') > 0:
            ExitWithErrorCode('B2')

        if decoded_csv[0] != '#':
            ExitWithErrorCode('B3')

        split_csv = list(csv.reader(StringIO(decoded_csv)))[1:]
        csv_row_count = len(split_csv)
        if not 1 <= csv_row_count <= 1000:
            ExitWithErrorCode('B5')

        if not decoded_csv[1] == '"':
            ExitWithErrorCode('B4')

        str_split_csv = list(map(lambda x: str(x), split_csv))
        if len(str_split_csv) != len(set(str_split_csv)):
            ExitWithErrorCode('D')

        row_dicts = list()
        for index, row in enumerate(split_csv):
            row_dict = {
                'subscription_id': row[0],
                'product_code': row[1],
                'target_month': row[2],
                'start_time': row[3],
                'end_time': row[4],
                'quantity': row[5]
            }

            try:
                row_dict['license_user'] = row[6]
                row_dict['free_item1'] = row[7]
                row_dict['free_item2'] = row[8]
            except IndexError:
                pass

            try:
                contract_info = ContractInfo.objects.get(subscription_id=row_dict['subscription_id'])
                opco_code = contract_info.opco_code.strip()
                target_timezone = OPCO_TIMEZONE.get(opco_code)
            except Exception as e:
                self.logger.fatal(e)
                ExitWithErrorCode('G')

            if row_dict['target_month'] is None or len(row_dict['target_month'].strip()) == 0:
                row_dict['target_month'] = parser.parse(row_dict['end_time']).astimezone(
                    timezone(target_timezone)).strftime('%Y%m')

            if '' in row[0:2] + row[3:6]:
                ExitWithErrorCode(f'E{index+1}')

            if check_date_ym_format(row_dict['target_month']) is False \
                    or check_datetime_format(row_dict['start_time']) is False \
                    or check_datetime_format(row_dict['end_time']) is False:
                ExitWithErrorCode(f'C{index+1}')

            # JST_NOW = datetime.now(timezone('Asia/Tokyo'))
            # DAY1_OF_THIS_MONTH = \
            #     timezone('Asia/Tokyo').localize(datetime(JST_NOW.year, JST_NOW.month, 1))
            # FIRST_OF_MONTH_0400 = \
            #     timezone('Asia/Tokyo').localize(datetime(JST_NOW.year, JST_NOW.month, 1, 4))

            # target_month = timezone('Asia/Tokyo').localize(
            #     datetime.strptime(row_dict['target_month'], '%Y%m'))
            # end_datetime = timezone('Asia/Tokyo').localize(
            #     datetime.strptime(row_dict['end_time'], '%Y%m%dT%H%M%SZ'))
            # if target_month < DAY1_OF_THIS_MONTH and \
            #         end_datetime < DAY1_OF_THIS_MONTH and \
            #         JST_NOW >= FIRST_OF_MONTH_0400:
            #     ExitWithErrorCode(f'H{index+1}')

            try:
                local_end_time = parser.parse(row_dict['end_time']).astimezone(
                    timezone(target_timezone))
                target_month_dt = datetime.strptime(row_dict['target_month'], '%Y%m')
                if date(local_end_time.year, local_end_time.month, 1) > date(
                        target_month_dt.year, target_month_dt.month, 1):
                    raise SubscriptionsValidationError(
                        'Contradiction occurs',
                        status.HTTP_403_FORBIDDEN
                    )
            except Exception as e:
                self.logger.fatal(e)
                ExitWithErrorCode('G')

            contract_info_not_found = False
            try:
                row_dict['subscription'] = ContractInfo.objects.get(pk=row_dict['subscription_id'])
            except ContractInfo.DoesNotExist:
                contract_info_not_found = True
                row_dict['subscription'] = ContractInfo(subscription_id=row_dict['subscription_id'])
            
            if row_dict.get('license_user'):
                row_dict['license_user'] = row_dict['license_user'].strip()
            row_dict['usage_id'] = SubscriptionsUsagePostSerializer.generate_usage_id(
                None,
                row_dict['subscription_id'],
                row_dict['product_code'],
                row_dict['start_time'],
                row_dict['end_time'],
                row_dict['quantity'],
                row_dict.get('license_user')
            )
            row_dict['start_time'] = convert_datetime_format(row_dict['start_time']) + '+00:00'
            row_dict['end_time'] = convert_datetime_format(row_dict['end_time']) + '+00:00'
            row_dict['deleted'] = False

            row_dicts.append(row_dict)

        try:
            with transaction.atomic():
                for row_dict in row_dicts:
                    for i in range(6):
                        try:
                            usage_info = UsageInfo.objects.create(**row_dict)
                            if contract_info_not_found:
                                self.logger.error(f'The usage info(usage_id={usage_info.usage_id})\'s subscription_id({row_dict["subscription_id"]}) does not found in ContractInfo')
                            break
                        except Error as e:
                            if i == 5:
                                raise
                            time.sleep(60)
        except Error:
            ExitWithErrorCode('F')

        out_s3_obj = try_put_to_s3(CSV_DIR_OUT)
        processing_s3_obj.delete()

        csv_batch_process_info.process_result = 'Success'
        csv_batch_process_info.error_code = 'S'
        csv_batch_process_info.records = len(row_dicts)
        csv_batch_process_info.csv_link = \
            f'https://s3-ap-northeast-1.amazonaws.com/{out_s3_obj.bucket_name}/{out_s3_obj.key}'
        csv_batch_process_info.save()

        sys.exit(0)
