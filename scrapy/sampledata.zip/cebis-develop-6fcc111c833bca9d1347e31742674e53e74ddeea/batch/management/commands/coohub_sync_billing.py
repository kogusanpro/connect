"""
<copyright file="coohub_billing_data_sync.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2019-2020. All rights reserved.
</copyright>
"""
import os
import sys
import pytz
import calendar
import json
from decimal import Decimal
from datetime import timedelta, datetime
from lib.utils import ServerUtil
from lib.const.opco_code import OPCO_CURRENCY
from lib.const.coohub_k5_tenants import K5_TENANTS
from batch.management.batch_command_base import BatchCommandBase
from lib.const.create_billing_csv_process_timing import PROCESS_TIMING_LIST
from subscriptions.models import ProductInfo

class Command(BatchCommandBase):
    help = 'This batch is used to synchronize the billing data between Fujitsu k5 and Cebis'

    # tomorrow同時スレッドの数
    thread_number = 10

    def __init__(self):
        """
        コンストラクタ
        """

        super().__init__()

        self.batch_name = 'Synchronize billing data (Coohub)'
        self.executed_date = None
        self.k5_tenant = None
        self.k5_customer_id = None
        self.k5_api_endpoint = None
        self.service_contracts_table = None
        self.k5_service_contract_url = None
        self.k5_credit_url = None
        self.k5_credit_detail_url = None
        self.product_code_specification_enabled = None
        self.cebis_api_endpoint = None
        self.cebis_subscriptions_url = None
        self.cebis_calculation_system_api_key = None

    def add_arguments(self, parser):
        """
        実行時に指定可能なパラメータの引数への追加処理
        :param parser: システムパラメータ
        :return:
        """
        parser.add_argument('--executed_date', type=str,
                            default=datetime.utcnow().replace(tzinfo=pytz.UTC).astimezone(pytz.timezone('Asia/Tokyo')))

        parser.add_argument('--k5_customer_id', type=str, default=os.environ.get('K5_CUSTOMER_ID'))

        parser.add_argument('--k5_api_endpoint', type=str, default=os.environ.get('K5_API_ENDPOINT'))

        parser.add_argument('--k5_service_contract_url', type=str, default=os.environ.get('K5_SERVICE_CONTRACT_URL'))

        parser.add_argument('--k5_credit_url', type=str, default=os.environ.get('K5_CREDIT_URL'))

        parser.add_argument('--k5_credit_detail_url', type=str, default=os.environ.get('K5_CREDIT_DETAIL_URL'))

        parser.add_argument('--cebis_api_endpoint', type=str, default=os.environ.get('CEBIS_API_ENDPOINT'))

        parser.add_argument('--cebis_subscriptions_url', type=str, default=os.environ.get('CEBIS_SUBSCRIPTIONS_URL'))

        parser.add_argument('--cebis_calculation_system_api_key', type=str,
                            default=os.environ.get('CEBIS_CALCULATION_SYSTEM_API_KEY'))

        parser.add_argument('--product_code_specification_enabled', type=str, default=os.environ.get('PRODUCT_CODE_SPECIFICATION_ENABLED'))
        #[#130532 【QA環境】請求情報同期（日本時間の毎月1日 13時0分）で1stの同期対象データが一部同期されない]対応
        parser.add_argument('--process_timing', type=str, default=None)

    def __init_global_param(self, options):
        """
        グローバル変数を初期化する
        :return:
        """
        self.k5_customer_id = options.get('k5_customer_id')
        self.k5_api_endpoint = options.get('k5_api_endpoint')
        self.k5_service_contract_url = options.get('k5_service_contract_url')
        self.k5_credit_url = options.get('k5_credit_url')
        self.k5_credit_detail_url = options.get('k5_credit_detail_url')
        self.product_code_specification_enabled = options.get('product_code_specification_enabled')
        self.cebis_api_endpoint = options.get('cebis_api_endpoint')
        self.cebis_subscriptions_url = options.get('cebis_subscriptions_url')
        self.cebis_calculation_system_api_key = options.get('cebis_calculation_system_api_key')

        self.executed_date = options.get("executed_date")
        if not isinstance(self.executed_date, datetime):
            # 手動実行(JST)
            parameter_year = self.executed_date[0:4]
            parameter_month = self.executed_date[4:6]
            parameter_day = self.executed_date[6:8]
            self.executed_date = datetime(int(parameter_year), int(parameter_month), int(parameter_day), 13)\
                .replace(tzinfo=pytz.timezone('Asia/Tokyo'))
        else:
            # 自動実行
            self.executed_date = options.get("executed_date")

        # バッチ実行日時(JST)の前月月末の年月日
        self.business_date = datetime(self.executed_date.year, self.executed_date.month, 1, 0,
                                      tzinfo=pytz.timezone('Asia/Tokyo')) - timedelta(days=1)
        self.logger.info(f'Executed date is {self.executed_date} ...')

    def main_process(self, *args, **options):
        """
        従量計算システムから前月度分の請求情報を取得し、従量データ収集基盤へ同期する
        :param args: システムパラメータ
        :param options: システムパラメータ
        :return:
        """
        # [#130532 【QA環境】請求情報同期（日本時間の毎月1日 13時0分）で1stの同期対象データが一部同期されない]対応
        self.process_timing = options['process_timing']

        # グローバル変数を初期化する
        self.__init_global_param(options)

        # 全テナント
        for k5_tenant in K5_TENANTS:
            self.k5_tenant = k5_tenant
            # サービス契約一覧を取得し、サービス対応表を作成
            self.__get_service_contracts_table()
            # 請求情報を収集基盤から取得
            basic_billing_data_list = self.__get_basic_billing_data()
            # 請求情報詳細情報をK5から取得
            basic_detail_billing_data_list, service_contract_list, basic_billing_data_list_target_month = \
                self._get_basic_detail_billing_data(basic_billing_data_list)
            # 請求情報を従量データ収集基盤へ登録
            self.__register_billing_data_list(basic_detail_billing_data_list,
                                              service_contract_list, basic_billing_data_list_target_month)

    #[#130532 【QA環境】請求情報同期（日本時間の毎月1日 13時0分）で1stの同期対象データが一部同期されない]対応
    def __validate_processing_timing_parameter(self,product_code,process_timing):
        """
        商品情報のfree_item1 およびprocessing_timingの合理性チェック
        return False:処理対象外 Ture:処理対象
        """
        try:
            product_info = ProductInfo.objects.get(product_code=product_code)
        except:
            return False

        if not product_info.free_item1:
            self.logger.error(
                'free_item1 of product_info is invalid because it is null or empty... skip output billing info'
                f' product_code:{product_code} '
                f' free_item1:{product_info.free_item1} ')
            return False

        process_timing_list = [timing for timing in PROCESS_TIMING_LIST if timing in product_info.free_item1]
        if len(list(process_timing_list)) > 1:
            self.logger.error(
                'free_item1 of product_info is invalid because it have both [1st] and [2nd] character strings... skip output billing info '
                f' product_code:{product_code} '
                f' free_item1:{product_info.free_item1} ')
            return False

        if process_timing not in product_info.free_item1:
            return False

        return True

    def __get_service_contracts_table(self):
        """
        「サービス契約を検索する」APIを実行してサービス契約一覧を取得
        サービス対応表の作成
        :return service_contracts_table: サービス対応表
        """
        # 本次开发，首先获得サービス対応表
        # サービス契約を検索API参数的初始化
        params = {
            'sort_item1': 'free_item1',
            'sort1': 0,
            'sort_item2': 'free_item4',
            'sort2': 0
        }

        self.logger.info('Start getting service contracts from fujitsu k5 ...')
        get_service_contracts_table_start_time = datetime.now()

        # サービス契約を検索APIを実行して
        response_for_get_service_contracts = ServerUtil(self).get_k5_response(
            url=self.k5_api_endpoint + self.k5_service_contract_url,
            params=params,
            method='GET',
            allow_token_time_out_minutes=1,
            data={},
            k5_tenant=self.k5_tenant
        )

        if response_for_get_service_contracts.status_code == 200:
            # サービス契約を検索API的结果，按照需要，转化为dict
            service_contracts_table = self.__make_service_contracts_table(response_for_get_service_contracts)
            if len(service_contracts_table) == 0:
                self.logger.fatal('Failed to get service price plan from Fujitsu k5 server ...')
                self.logger.fatal('System exit ...')
                sys.exit(1)
            get_service_contracts_table_end_time = datetime.now()
            get_service_contracts_table_total_time = (
                    get_service_contracts_table_start_time - get_service_contracts_table_end_time).seconds
            self.logger.info('Successfully get service contracts ...')
            self.logger.info(f'Ran for {get_service_contracts_table_total_time} seconds ...')
            self.logger.info(f'The number of service contracts is {len(service_contracts_table)} ...')
            self.service_contracts_table = service_contracts_table
        else:
            self.logger.fatal('Failed to get service price plan from Fujitsu k5 server ...')
            self.logger.info(f'Failed status_code {response_for_get_service_contracts.status_code}')
            self.logger.info(f'Failed parameters={params}')
            self.logger.info(f'Failed message={response_for_get_service_contracts.content}')
            self.logger.info(f'Failed URL={self.k5_api_endpoint + self.k5_service_contract_url}')
            self.logger.fatal('System exit ...')
            sys.exit(1)

    def __make_service_contracts_table(self, service_contracts_response):
        """
        サービス契約を検索API的结果，按照需要，转化为dict
        :return service_contracts: サービス契約を検索API的结果的dict
        """

        # サービス契約一覧を取得
        contract_information_list = \
            service_contracts_response.json().get('customer_appoint_service_contract_information_list')

        service_contracts = {}

        # サービス対応表を作成する
        # service_contract_id为キー
        # キー値または値がNULLまたは空の場合は、エラーログを出力して処理を続行する。
        for service_information in contract_information_list:
            if service_information.get('service_contract_id') is not None:
                service_contract_id = service_information.get('service_contract_id')
            else:
                self.logger.error(f'Get service price plan failed, because service contract id is null. ')
                continue
            if service_information.get('free_item5') is not None:
                license_quantity = service_information.get('free_item5')
            else:
                self.logger.error(f'Get service price plan failed, because license quantity is null. '
                                  f'service_contract_id is {service_contract_id}...')
                continue
            if service_information.get('free_item4') is not None:
                product_code = service_information.get('free_item4')
            else:
                self.logger.error(f'Get service price plan failed, because product code is null. '
                                  f'service_contract_id is {service_contract_id}...')
                continue

            if service_information.get('charging_start_date') is not None:
                charging_start_date = service_information.get('charging_start_date')
            else:
                self.logger.error(f'Get service price plan failed, because charging start date is null. '
                                  f'service_contract_id is {service_contract_id}...')
                continue

            if service_information.get('free_item1') is not None:
                subscription_id = service_information.get('free_item1')
            else:
                self.logger.error(f'Get service price plan failed, because subscription_id is null. '
                                  f'service_contract_id is {service_contract_id}...')
                continue

            if service_information.get('free_item2') is not None:
                product_type = service_information.get('free_item2')
            else:
                self.logger.error(f'Get service price plan failed, because product type is null. '
                                  f'service_contract_id is {service_contract_id}...')
                continue

            if service_information.get('free_item3') is not None:
                opco_code = service_information.get('free_item3')
            else:
                self.logger.error(f'Get service price plan failed, because opco code is null. '
                                  f'service_contract_id is {service_contract_id}...')
                continue

            if service_information.get('apply_start_date') is not None:
                apply_start_date = service_information.get('apply_start_date')
            else:
                self.logger.error(f'Get service price plan failed, because apply_start_date is null. '
                                  f'subscription_id is {subscription_id}, product_code is {product_code} ...')
                continue

            service_contract = {
                'license_quantity': license_quantity,
                'product_code': product_code,
                'charging_start_date': charging_start_date,
                'subscription_id': subscription_id,
                'product_type': product_type,
                'apply_start_date': apply_start_date,
                'opco_code': opco_code
            }

            # キー サブスクリプションID_商品コード
            service_contract_key = service_contract_id
            service_contracts.update({service_contract_key: service_contract})

        # 返回サービス対応表
        return service_contracts

    def __get_basic_billing_data(self):
        """
        「債権を検索する」API を実行して、
        請求情報を従量計算システムから取得する。
        :return billing_data: K5から債権情報のリスト
        """

        # 債権を検索APIパラメータのインストール
        customer_id = self.k5_customer_id
        business_date = self.business_date.strftime('%Y%m%d')
        params = {
            'customer_id': customer_id,
            'business_date': business_date
        }
        self.logger.info(f'Start getting billing data from K5 ...')
        self.logger.info(f'customer id = {customer_id} , business date = {business_date}')

        # Fujitsu K5の債権を検索APIへのアクセス
        response_for_basic_billing_data = ServerUtil(self).get_k5_response(
            url=self.k5_api_endpoint + self.k5_credit_url,
            params=params,
            method='GET',
            allow_token_time_out_minutes=5,
            data={},
            k5_tenant=self.k5_tenant
        )

        # 債権情報のリストを取得する
        # 債権明細を検索する
        if response_for_basic_billing_data.status_code == 200:
            # 債権の一覧を取得する
            basic_billing_data = response_for_basic_billing_data.json().get(
                'charge_adjustment_information_list')

            # 「債権を検索する」APIの結果、請求情報一覧が0件だった場合は、エラーログを出力して処理を中断する。
            if len(basic_billing_data) == 0:
                self.logger.fatal('Failed to get charge adjustment information list from Fujitsu k5 server ...')
                self.logger.fatal('System exit ...')
                sys.exit(1)

            # Javaコードのコンテンツ
            # APIのパラメータでソートできないため実装でソート処理
            # 配列内のbilling_to_idを昇順でソート
            basic_billing_data.sort(key=lambda x: x['billing_to_id'])

            # 「債権明細を検索する」APIを実行して
            # self.__sync_billing_data(basic_billing_data)
            return basic_billing_data;
        else:
            self.logger.fatal('Failed to get billing data from K5 ...')
            self.logger.info(f'Failed status_code {response_for_basic_billing_data.status_code}')
            self.logger.info(f'Failed parameters={params}')
            self.logger.info(f'Failed message={response_for_basic_billing_data.content}')
            self.logger.info(f'Failed URL={self.k5_api_endpoint + self.k5_credit_url}')
            self.logger.fatal('System exit ...')
            sys.exit(0)

    def _get_basic_detail_billing_data(self, basic_billing_data_list: list):
        """
        「債権明細を検索する」APIを実行して、
        請求情報を従量計算システムから取得する。
        :return billing_data: K5から債権情報のリスト
        """
        basic_detail_billing_data_list = list()
        service_contract_list = list()
        basic_billing_data_list_target_month = list()
        self.logger.info('Start getting billing detail data list ...')
        for basic_billing_data in basic_billing_data_list:
            if basic_billing_data.get('target_month') == self.business_date.strftime('%Y%m'):
                basic_detail_billing_data, service_contract = self.__get_detailed_billing_data_parallel(basic_billing_data)
                if basic_detail_billing_data != 'skip':
                    basic_detail_billing_data_list.append(basic_detail_billing_data)
                    service_contract_list.append(service_contract)
                    basic_billing_data_list_target_month.append(basic_billing_data)
        self.logger.info('Finished getting billing detail data list ...')
        return basic_detail_billing_data_list, service_contract_list, basic_billing_data_list_target_month

    def __get_detailed_billing_data_parallel(self, basic_billing_data: dict):
        """
        「債権明細を検索する」APIを実行して、
        請求情報を従量データ収集基盤へ登録
        10個のスレッドが同時に動作します
        :return: sync_service_result
        """
        sync_result = {'skip': False, 'service': None}
        # 債権明細取得API调用，取得請求明細情報
        response_for_get_credit_detail = ServerUtil(self).get_k5_response(
            url=self.k5_api_endpoint + self.k5_credit_detail_url + basic_billing_data.get('credit_id'),
            params={},
            method='GET',
            allow_token_time_out_minutes=1,
            data={},
            k5_tenant=self.k5_tenant
        )

        # 請求明細情報の取得に失敗した場合は、エラーログを出力して処理を続行する。
        if response_for_get_credit_detail.status_code != 200:
            self.logger.error('Failed to get credit detail : response_code = ' + 
                              f'{response_for_get_credit_detail.status_code}' + 
                              '  credit_id = ' +
                              f'{basic_billing_data.get("credit_id")}')
            self.logger.info(f'Failed status_code {response_for_get_credit_detail.status_code}')
            self.logger.info(f'Failed message={response_for_get_credit_detail.content}')
            self.logger.info(f'Failed URL={self.k5_api_endpoint + self.k5_credit_detail_url + basic_billing_data.get("credit_id")}')
            sync_result['credit_id'] = basic_billing_data.get('credit_id')
            return sync_result

        # 債権明細结果中credit_detail_information_list的实例
        detail_credit_data_list \
            = response_for_get_credit_detail.json().get('credit_detail_information_list')

        # 請求明細情報
        # 遍历債権明細中的service_contract_id取得サーベス契约
        # 按照product_code制作請求明細情報
        server_contract, sync_billing_data_list = self.create_billing_detail_data_for_sync(detail_credit_data_list)

        if not server_contract or not sync_billing_data_list:
            sync_result['skip'] = 'SKIP'
            return sync_result

        return sync_billing_data_list, server_contract

    def create_billing_detail_data_for_sync(self, detail_credit_data_list: list):
        """
        更新する請求情報を作成する
        :return: sync_service_result
        """
        sync_billing_data_list = {}
        for credit_detail_data in detail_credit_data_list:
            service_contract_id = credit_detail_data.get('service_contract_id')
            service_contract = self.service_contracts_table.get(service_contract_id)
            if service_contract is None:
                self.logger.error(f'Failed to get service contract {service_contract_id} ...')
                return None, None

            # 商品コード
            product_code = service_contract.get('product_code')
            # 商品種別
            product_type = service_contract.get('product_type')

            # 請求同期対象商品の商品コード的判断
            # 指定が無い場合は、すべての商品コードの請求情報を同期対象とする。
            if self.product_code_specification_enabled is not None and self.product_code_specification_enabled == 'true':
                # [#130532 【QA環境】請求情報同期（日本時間の毎月1日 13時0分）で1stの同期対象データが一部同期されない]対応
                if not self.__validate_processing_timing_parameter(product_code, self.process_timing):
                    return None, None
                else:
                    self.logger.info(f'Because of 1st setting sync billing info of the following product code : {product_code} ...')

            register_billing_data = {
                'detail': credit_detail_data,
                'license_quantity': service_contract.get('license_quantity'),
                'product_code': service_contract.get('product_code'),
                'end_date': credit_detail_data.get("closing_date_end"),
                'start_date': credit_detail_data.get('closing_date_start'),
                'subscription_id': service_contract.get('subscription_id'),
                'product_type': service_contract.get('product_type'),
                'opco_code': service_contract.get('opco_code'),
            }

            # 定額料金
            if credit_detail_data.get('credit_detail_incidental_information_list') is None:
                register_billing_data['computational_element_division'] = "01"
            # 従量料金
            else:
                register_billing_data['computational_element_division'] = "03"

            if sync_billing_data_list.get(product_code) is None:
                sync_billing_data_list[product_code] = []
            # 商品コードごとに振り分ける
            sync_billing_data_list.get(product_code).append(register_billing_data)
        return service_contract, sync_billing_data_list

    def __register_billing_data_list(self, basic_billing_data_dict: list,
                                     service_contract_list: list, basic_billing_data_list: list):
        """
        請求情報を従量データ収集基盤へ登録
        :return: sync_service_result
        """
        succeedno = 0
        failedno = 0
        for index, service_contract in enumerate(service_contract_list):
            try:
                sync_billing_data_result = self.__register_billing_data_init(
                    basic_billing_data_dict[index], service_contract, basic_billing_data_list[index])
                if sync_billing_data_result is not None and sync_billing_data_result.get('success') is True:
                    succeedno += 1
                else:
                    failedno += 1
            except Exception as e:
                self.logger.error(e)
                continue

        self.logger.info(f'Succeeded sync billing data = {succeedno}')
        self.logger.info(f'Failed sync billing data = {failedno} ')

    def __register_billing_data_init(self, sync_billing_data_list: dict, server_contract: dict,
                                     basic_billing_data: dict):
        """
        請求情報を従量データ収集基盤へ登録
        :return: sync_service_result
        """
        try:
            charging_start_date = server_contract.get('charging_start_date')[0:6]
            billing = {}

            # 式样中start_date是対象サブスクリプションで取得した請求明細情報一覧のうち締日開始年月日(closing_date_start)
            # が一番古い日付の年月日
            # 課金開始年月日と、業務日付が同年月の場合

            start_date,end_date = self.__get_startdate_and_enddate(sync_billing_data_list)

            if charging_start_date == self.business_date.strftime('%Y%m'):
                # 課金開始年月日
                billing['start_date'] = server_contract.get('charging_start_date')
            else:
                # 業務日付の月初を設定
                billing['start_date'] = start_date

            # 式样中end_date是対象サブスクリプションで取得した請求明細情報一覧のうち締日終了年月日 (closing_date_end)
            # が一番古い日付の年月日
            billing['end_date'] = end_date

            # 対象サブスクリプションで取得した債権情報の債権金額 (credit_charge)の値
            # 小数点以下がゼロパディングされていた場合はゼロを削除して整形する
            credit_charge = basic_billing_data.get('credit_charge')
            credit_charge = int(credit_charge) if credit_charge == int(credit_charge) else credit_charge
            billing['billing'] = credit_charge

            # 通貨情報
            opco_code = server_contract.get('opco_code')
            billing['unit_of_money'] = OPCO_CURRENCY.get(opco_code).get('CURRENCY')

            # 固定completed
            billing['state'] = "completed"
            billing_details = self.__billing_details_init(sync_billing_data_list)
            billing['billing_details'] = billing_details

            return self.__register_billing_data(billing, server_contract.get('subscription_id'))
        except Exception as e:
            self.logger.error(e)

    def __billing_details_init(self, sync_billing_data_list: dict):
        """
        billing_detailsの初期化
        :return: billing_details
        """
        billing_details = []
        for product_code, billing_data_list in sync_billing_data_list.items():
            # 定額の明細
            flat = None
            # 従量の明細
            pay_per_use = None

            for billing_data in billing_data_list:
                if billing_data.get('detail').get('credit_detail_incidental_information_list') is None:
                    flat = billing_data
                else:
                    if pay_per_use is not None:
                        self.logger.info('credit_detail_incidental_information_list duplicate ...')
                        sys.exit(0)
                    pay_per_use = billing_data

            summary = Decimal(0)
            # 合算
            if flat is not None and flat.get('detail').get('credit_detail_charge') is not None:
                summary = summary + Decimal(flat.get('detail').get('credit_detail_charge'))
            if pay_per_use is not None and pay_per_use.get('detail').get('credit_detail_charge') is not None:
                summary = summary + Decimal(pay_per_use.get('detail').get('credit_detail_charge'))

            # 小数点末端の0を削除する（数値としては同値）
            summary = int(summary.to_integral()) if summary == summary.to_integral() else float(summary.normalize())

            billing_detail = {
                'billing': summary,
                'product_code': product_code,
                'license_quantity': int(billing_data_list[0].get('license_quantity'))
            }
            if pay_per_use is not None and pay_per_use.get('detail').get('credit_detail_incidental_information_list'):
                bd_use_volume = Decimal(
                    pay_per_use.get('detail').get('credit_detail_incidental_information_list')[0].get(
                        'use_volume'))
                # 小数点末端の0を削除する（数値としては同値）
                billing_detail["quantity"] = int(bd_use_volume.to_integral()) \
                    if bd_use_volume == bd_use_volume.to_integral() else float(bd_use_volume.normalize())
            else:
                billing_detail["quantity"] = 0
            billing_detail['billing_usage_details'] = None
            billing_details.append(billing_detail)
        return billing_details

    def __register_billing_data(self, billing: dict, subscription_id: str):

        requesturl = self.cebis_api_endpoint + self.cebis_subscriptions_url + '/' + subscription_id + '/billing/'\
                     + self.business_date.strftime('%Y%m')
        # 請求情報を登録APIを実行して
        service_contracts_response = ServerUtil(self).get_cebis_response(
            url=requesturl,
            params={},
            method='POST',
            data=json.dumps(billing),
            api_key=self.cebis_calculation_system_api_key
        )
        self.logger.info(f'final billing data = {billing}')
        if service_contracts_response.status_code == 200:
            self.logger.info('Billing register Succeeded  ...subscription_id = '
                              f'{subscription_id}'
                              ' status_code = '
                              f'{service_contracts_response.status_code}'
                              ' error_message = '
                              f'{service_contracts_response.content}')
            self.logger.info(f'Succeeded  status_code {service_contracts_response.status_code}')
            self.logger.info(f'Succeeded  parameters={billing}')
            self.logger.info(f'Succeeded  message={service_contracts_response.content}')
            self.logger.info(f'Succeeded  URL={requesturl}')
            return {'success': True, 'subscription_id': subscription_id}
        else:
            self.logger.error('Billing register failed ...subscription_id = '
                              f'{subscription_id}'
                              ' status_code = '
                              f'{service_contracts_response.status_code}'
                              ' error_message = '
                              f'{service_contracts_response.content}')
            self.logger.info(f'Failed status_code {service_contracts_response.status_code}')
            self.logger.info(f'Failed parameters={billing}')
            self.logger.info(f'Failed message={service_contracts_response.content}')
            self.logger.info(f'Failed URL={requesturl}')
            return {'success': False, 'subscription_id': subscription_id}

    def __get_startdate_and_enddate(self, sync_billing_data_list: dict) :
        # 式样中end_date是対象サブスクリプションで取得した請求明細情報一覧のうち締日終了年月日 (closing_date_end) 一番新しい
        # 式样中start_date是対象サブスクリプションで取得した請求明細情報一覧のうち締日開始年月日(closing_date_start)　一番古い
        startdate = ""
        enddate = ""
        index = 0
        for key in sync_billing_data_list:
            for billing in sync_billing_data_list.get(key):
                if index == 0:
                    startdate = billing.get("start_date")
                    enddate = billing.get("end_date")
                else:
                    if startdate > billing.get("start_date"):
                        startdate = billing.get("start_date")
                    if enddate < billing.get("end_date"):
                        enddate = billing.get("end_date")
            index = index + 1

        return startdate, enddate