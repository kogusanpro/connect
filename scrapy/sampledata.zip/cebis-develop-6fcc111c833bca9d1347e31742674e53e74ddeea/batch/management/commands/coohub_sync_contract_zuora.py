"""
<copyright file="coohub_contract_sync_zuora.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2019-2020. All rights reserved.
</copyright>
"""
import json
import os
import sys
from concurrent.futures import Future, ThreadPoolExecutor
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

import dateutil.parser
import pytz
import requests
from batch.management.batch_command_base import BatchCommandBase
from django.core.management.base import CommandError
from lib.const.coohub_zuora_tenant import ZUORA_TENANT
from lib.const.opco_code import OPCO_TIMEZONE
from lib.const.product_type import BASIC
from lib.contract_info_util import filter_zuora_data
from lib.shortcuts import get_object_or_None
from lib.utils import ServerUtil, check_date_ymd_format, check_datetime_format
from subscriptions.models import ContractInfo


class Command(BatchCommandBase):
    help = 'This batch is used to synchronize the contracts between Zuora and Cebis'

    # APIを実行するスレッド数
    API_THREAD_NUMBER = 10


    def __init__(self) -> None:
        '''コンストラクタ'''
        super().__init__()

        self.batch_name = 'Synchronize contract information with Zuora'


    def add_arguments(self, parser) -> None:
        '''バッチオプション引数取得

        Args:
            parser: 引数パーサー
        '''
        # バッチ実行日時
        parser.add_argument('--executed_date', type=str, default='')

        # 同期対象データの日時
        parser.add_argument('--from_updated_datetime', type=str, default='')
        parser.add_argument('--to_updated_datetime', type=str, default='')

        # Cebis API関連
        parser.add_argument('--cebis_api_endpoint', type=str, default=os.environ.get('CEBIS_API_ENDPOINT'))  # エンドポイントURL
        parser.add_argument('--cebis_calculation_system_api_key', type=str, default=os.environ.get('CEBIS_CALCULATION_SYSTEM_API_KEY'))  # APIキー
        parser.add_argument('--cebis_subscriptions_url', type=str, default=os.environ.get('CEBIS_SUBSCRIPTIONS_URL'))  # 契約情報一括取得URL

        # Zuora API関連
        parser.add_argument('--zuora_api_endpoint', type=str, default=os.environ.get('ZUORA_API_ENDPOINT'))  # エンドポイントURL
        parser.add_argument('--zuora_rateplancharge_url', type=str, default=os.environ.get('ZUORA_RATEPLANCHARGE_URL'))  # RatePlanCharge URL


    def do_validate(self, *args: Tuple[Any], **options: Dict[str, Any]) -> None:
        '''引数のバリデーション処理

        Args:
            args (Tuple[Any]): 引数（未使用）
            options (Dict[str, Any]): キーワード引数

        Raises:
            CommandError: バリデーションエラー
        '''
        # [executed_date]のフォーマットチェック
        if options['executed_date'] and not check_date_ymd_format(datetime=options['executed_date']):
            raise CommandError('executed_date was invalid format in this batch parameter')

        if options['from_updated_datetime'] and options['to_updated_datetime']:
            # [from_updated_datetime]のフォーマットチェック
            if not check_datetime_format(datetime=options['from_updated_datetime']):
                raise CommandError('from_updated_datetime was invalid format in this batch parameter')

            # [to_updated_datetime]のフォーマットチェック
            if not check_datetime_format(datetime=options['to_updated_datetime']):
                raise CommandError('to_updated_datetime was invalid format in this batch parameter')

            # [from_updated_datetime] > [to_updated_datetime] のチェック
            if options['from_updated_datetime'] > options['to_updated_datetime']:
                raise CommandError('from_updated_datetime was greater than to_updated_datetime in this batch parameter')

        elif (options['from_updated_datetime'] and not options['to_updated_datetime']) \
                or (not options['from_updated_datetime'] and options['to_updated_datetime']):
            # [from_updated_datetime]か[to_updated_datetime]のどちらかが存在しない
            raise CommandError('from_updated_datetime and to_updated_datetime are specified as a pair')


    def main_process(self, *args: Any, **options: Any) -> None:
        '''Cebisから契約情報一覧を取得し、Zuoraへ同期する

        Args:
            args (Any): 引数（未使用）
            options (Any): キーワード引数
        '''
        # バッチ実行日時（JST）の年月日
        executed_datetime = datetime.utcnow().astimezone(pytz.timezone('Asia/Tokyo'))
        executed_date = options.get('executed_date')
        if len(executed_date) > 0:
            # 本バッチのオプション引数で指定した場合はその日付で上書き
            executed_datetime = pytz.timezone('Asia/Tokyo').localize(
                datetime(
                    year=int(executed_date[0:4]),
                    month=int(executed_date[4:6]),
                    day=int(executed_date[6:8]),
                    hour=4,
                )
            )
        self.logger.info(f'executed_datetime is {executed_datetime.strftime("%Y-%m-%d %H:%M:%S")} (JST)...')

        # バッチ実行日の年月日（UTC、yyyyMMddTHHmmssZ形式）
        executed_datetime_utc: str = executed_datetime.astimezone(pytz.UTC).strftime('%Y%m%dT%H%M%SZ')

        # 同期対象データ（開始日）
        from_updated_datetime: str = options.get('from_updated_datetime')
        if len(from_updated_datetime) == 0:
            # 本バッチのオプション引数で指定していない場合（バッチ実行前日の15時（UTC））
            from_updated_datetime = (executed_datetime - timedelta(days=1)).astimezone(pytz.UTC).replace(hour=15, minute=0, second=0).strftime('%Y%m%dT%H%M%SZ')
        self.logger.info(f'from_updated_datetime is {from_updated_datetime}')

        # 同期対象データ（終了日）
        to_updated_datetime: str = options.get('to_updated_datetime')
        if len(to_updated_datetime) == 0:
            # 本バッチのオプション引数で指定していない場合（バッチ実行当日の15時（UTC））
            to_updated_datetime = executed_datetime.astimezone(pytz.UTC).replace(hour=15, minute=0, second=0).strftime('%Y%m%dT%H%M%SZ')
        self.logger.info(f'to_updated_datetime is {to_updated_datetime}')

        server_util = ServerUtil(self, zuora_tenant=ZUORA_TENANT)

        # Cebisの[契約情報一括取得]APIを実行する関数
        def _get_contractinfo_from_cebis(offset: int) -> Optional[requests.Response]:
            api_url: str = options.get('cebis_api_endpoint') + options.get('cebis_subscriptions_url')
            api_key: str = options.get('cebis_calculation_system_api_key')
            api_params = {
                'from_updated_time': from_updated_datetime,
                'to_updated_time': to_updated_datetime,
                'internal_calc': 'false',  # Zuoraの場合は必ず「false」を指定する
                'offset': offset,
            }
            try:
                response: requests.Response = server_util.get_cebis_response(
                    url=api_url,
                    params=api_params,
                    method='GET',
                    data=None,
                    api_key=api_key,
                )
                return response
            except Exception as e:
                self.logger.error(e)
                return None

        # Cebisの[契約情報一括取得]APIを実行（初回）
        self.logger.info('Start getting contracts from cebis ...')
        response = _get_contractinfo_from_cebis(offset=1)
        if response is None:
            self.logger.error('Error occurred when getting list of contracts from cebis ...')
            self.logger.info('System exit ...')
            sys.exit(0)

        response_json: Dict[str, Any] = response.json()
        if response.status_code == 404:
            self.logger.info('No contract info to synchronize to Zuora ...')
            return
        elif response.status_code != 200 or response_json.get('success') == False:
            self.logger.error('Failed to get list of contracts from cebis ...')
            self.logger.info(f'Response = [{response_json}] ...')
            self.logger.info('System exit ...')
            sys.exit(0)

        # 契約情報の対象データと対象データの全体件数を取得
        contract_info_list: List[Dict[str, Any]] = response_json.get('subscriptions')
        target_data_cnt: int = response_json.get('count')

        # Zuora対象の契約情報のみ抽出
        zuora_only_contract_info_list = filter_zuora_data(contract_info_list)

        # 対象データの全体件数が100件より多い場合は追加で契約情報を取得する
        if target_data_cnt > 100:
            # マルチスレッドで[契約情報一括取得]APIを実行
            start_time = datetime.now()
            with ThreadPoolExecutor(max_workers=Command.API_THREAD_NUMBER) as executor:
                futures: List[Future] = []
                for offset in range(101, target_data_cnt + 1, 100):
                    futures.append(executor.submit(_get_contractinfo_from_cebis, offset))
                results: List[Optional[requests.Response]] = [f.result() for f in futures]
            end_time = datetime.now()

            # 契約情報がすべて正常に取得できたかチェック
            all_success = True
            for result in results:
                if result is None:
                    self.logger.error('Error occurred when getting list of contracts from cebis ...')
                    all_success = False
                    continue

                result_json: Dict[str, Any] = result.json()
                if result.status_code != 200 or result_json.get('success') == False:
                    self.logger.error('Failed to get list of contracts from cebis ...')
                    self.logger.info(f'Response = [{result_json}]')
                    all_success = False

            if not all_success:
                self.logger.info('System exit ...')
                sys.exit(0)

            # 追加で一括取得した契約情報を加える
            for result in results:
                # Zuora対象の契約情報のみ抽出
                contract_info_list = result.json().get('subscriptions')
                zuora_only_contract_info_list.extend(filter_zuora_data(contract_info_list))

            self.logger.info('Successfully obtained contracts from Cebis ...')
            self.logger.info(f'Ran for {(end_time - start_time).seconds} seconds ...')
        else:
            self.logger.info('Successfully obtained contracts from Cebis, and contracts count is less than or equal to 100 ...')

        if len(zuora_only_contract_info_list) == 0:
            self.logger.info('No contract info to synchronize to Zuora ...')
            return

        # Cebisの各契約情報をZuora上の契約情報に反映する
        for cebis_contract_info in zuora_only_contract_info_list:
            # Cebis側のサブスクリプションID
            cebis_subscription_id: str = cebis_contract_info['subscription_id']

            # Cebis側の契約連番を取得
            # TODO: ※Cebisの[契約情報一括取得]]APIでは契約連番を取得できないため、DBの契約情報から直接取得している（今後の課題）
            contract_info: Optional[ContractInfo] = get_object_or_None(ContractInfo, pk=cebis_subscription_id)
            if contract_info is None:
                self.logger.error(f'subscription_id = [{cebis_subscription_id}] record not found in contract_info table ...')
                continue
            cebis_contract_code: str = contract_info.contract_code

            # Zuoraのサブスクリプション番号
            subscription_number: str = cebis_contract_info['subscription_number']

            self.logger.info(f'Checking subscription_id = [{cebis_subscription_id}], subscription_number = [{subscription_number}] ...')

            # 同サブスクリプションIDで契約している商品情報
            cebis_product_list: List[Dict[str, Any]] = cebis_contract_info['products']

            # 仕向け地とそのタイムゾーンの取得
            opco_code: str = cebis_contract_info['opco_code']
            local_timezone: Optional[str] = OPCO_TIMEZONE.get(opco_code)
            if local_timezone is None:
                self.logger.error(f'Opco timezone not found in Cebis. opco_code = [{opco_code}]')
                continue

            # 仕向け地のタイムゾーンが正しく取得できるかチェック
            try:
                pytz.timezone(local_timezone)
            except:
                self.logger.error(f'Unknown timezone in opco_code = [{opco_code}] and timezone = [{local_timezone}] ...')
                continue

            # Zuoraの各商品の契約情報を取得
            cebis_product_code_list: List[str] = [product['product_code'] for product in cebis_product_list]
            query = f"""
                SELECT
                  *
                FROM
                  (
                    SELECT
                      sub.name AS subscription_number,  -- Zuoraサブスクリプション番号
                      FORMAT_DATETIME(sub.contracteffectivedate, 'yyyyMMdd') AS contract_effective_date,  -- ContractEffectiveDate
                      FORMAT_DATETIME(sub.serviceactivationdate, 'yyyyMMdd') AS service_activation_date,  -- ServiceActivationDate
                      FORMAT_DATETIME(sub.termstartdate, 'yyyyMMdd') AS term_start_date,  -- 契約開始日
                      FORMAT_DATETIME(sub.termenddate, 'yyyyMMdd') AS term_end_date,  -- 契約終了日
                      rpc.erpcontractcode__c AS contract_code,  -- 契約連番
                      rpc.kakinsubscriptionid__c AS subscription_id,  -- サブスクリプションID
                      FIRST_VALUE(FORMAT_DATETIME(rpc.effectivestartdate, 'yyyyMMdd')) OVER(PARTITION BY sub.name, prpc.productcode__c ORDER BY oa.createddate) AS effective_start_date,  -- 契約開始日（Zuoraサブスクリプション番号、商品コードの単位で初回のEffectiveStartDate）
                      LAST_VALUE(FORMAT_DATETIME(rpc.effectiveenddate, 'yyyyMMdd')) OVER(PARTITION BY sub.name, prpc.productcode__c ORDER BY oa.createddate) AS effective_end_date,  -- 契約終了日（Zuoraサブスクリプション番号、商品コードの単位で最新のEffectiveEndDate）
                      FORMAT_DATETIME(rpc.triggerdate, 'yyyyMMdd') AS trigger_date,  -- トリガー日付
                      rpc.chargemodel AS charge_model,  -- 料金区分（定額、従量など）
                      rpc.chargenumber AS charge_number,  -- チャージ番号
                      rpc.id AS rate_plan_charge_id,  -- RatePlanCharge ID
                      prpc.productcode__c AS product_code,  -- 商品コード
                      rpc.quantity AS quantity,  -- 数量
                      oa.type AS order_action_type,  -- 契約変更の内容
                      ROW_NUMBER() OVER (PARTITION BY sub.name, prpc.productcode__c ORDER BY oa.createddate DESC) AS row_num  -- Zuoraサブスクリプション番号、商品コードの単位でOrderAction更新日付が新しい順に振られる連番（1～）
                    FROM
                      rateplancharge rpc
                      INNER JOIN productrateplancharge prpc ON prpc.id = rpc.productrateplanchargeid
                      INNER JOIN rateplan rp ON rp.id = rpc.rateplanid
                      INNER JOIN orderactionrateplan oarp ON oarp.rateplanid = rp.id
                      INNER JOIN orderaction oa ON oa.id = oarp.orderactionid
                      INNER JOIN subscription sub ON sub.id = oa.subscriptionid
                    WHERE
                      sub.name = '{subscription_number}'
                      AND prpc.productcode__c IN({', '.join(["'" + product_code + "'" for product_code in cebis_product_code_list])})
                      AND rpc.islastsegment = TRUE
                  )
                WHERE
                  row_num = 1  -- 各商品の一番新しい契約変更のレコードのみ抽出
                ORDER BY
                  product_code
            """
            query_result = server_util.get_zuora_data_query_result(query)
            if query_result is None:
                self.logger.error('Error occurred when getting contract info from Zuora.')
                self.logger.info(f'    Zuora data query = [{query}]')
                continue
            elif len(query_result) == 0:
                self.logger.error(f'No contract info returned from Zuora. cebis_product_code_list = [{cebis_product_code_list}]')
                self.logger.info(f'    Zuora data query = [{query}]')
                continue

            # CebisとZuoraの契約情報の整合性チェックを行う

            is_valid = True  # バリデーションOKかどうかのフラグ

            # Cebisの基本プランのサービス開始手配完了日時で一番古い日付を取得
            oldest_service_start_date: str = min(
                [cebis_product['service_start_time'] for cebis_product in cebis_product_list if cebis_product['product_type'] == BASIC]
            )

            # 上記のサービス開始手配完了日時をローカル時間に変換
            local_oldest_service_start_date: str = dateutil.parser.parse(oldest_service_start_date).astimezone(pytz.timezone(local_timezone)).strftime('%Y%m%d')

            # ①Cebisのサービス開始手配完了日とZuoraのContractEffectiveDateを比較
            # TODO: チェックはするが何もしない
            contract_effective_date: Optional[str] = query_result[0]['contract_effective_date']
            if contract_effective_date is None:
                # ContractEffectiveDateが設定されていない場合
                pass
            elif contract_effective_date != local_oldest_service_start_date:
                # サービス開始手配完了日が一致しない場合
                pass

            # ②Cebisのサービス開始手配完了日とZuoraのServiceActivationDateを比較
            # TODO: チェックはするが何もしない
            service_activation_date: Optional[str] = query_result[0]['service_activation_date']
            if service_activation_date is None:
                # ServiceActivationDateが設定されていない場合
                pass
            elif service_activation_date != local_oldest_service_start_date:
                # サービス開始手配完了日が一致しない場合
                pass

            zuora_product_code_list: List[str] = [result['product_code'] for result in query_result]
            for cebis_product in cebis_product_list:
                cebis_product_code: str = cebis_product['product_code']

                self.logger.info(f'Checking data of product_code = [{cebis_product_code}]')

                if cebis_product_code not in zuora_product_code_list:
                    # Cebisの契約商品がZuoraの契約情報内に存在しない場合は次のCebisの契約商品チェックへ
                    is_valid = False
                    self.logger.error(f'No Cebis product found in Zuora. product code = [{cebis_product_code}]')
                    continue

                # Cebisの契約情報に対応するZuoraの契約情報
                zuora_contract_info: Dict[str, Any] = [result for result in query_result if result['product_code'] == cebis_product_code][0]

                # ③契約連番の比較
                if zuora_contract_info['contract_code'] is not None and zuora_contract_info['contract_code'] != cebis_contract_code:
                    self.logger.error(f"Contract codes are not same. Zuora contract code = [{zuora_contract_info['contract_code']}]")
                    is_valid = False

                # ④サブスクリプションIDの比較
                if zuora_contract_info['subscription_id'] is not None and zuora_contract_info['subscription_id'] != cebis_subscription_id:
                    self.logger.error(f"Subscription IDs are not same. Zuora subscription ID = [{zuora_contract_info['subscription_id']}]")
                    is_valid = False

                # OrderActionType
                order_action_type: str = zuora_contract_info['order_action_type']

                # Cebisの商品が契約中かどうか
                cebis_is_active = cebis_product['service_cancel_time'] is None or executed_datetime_utc < cebis_product['service_cancel_time']

                # ⑤契約状態の比較１（Cebis上で契約中状態なのにZuora上では契約中状態でない場合）
                zuora_active_order_action_type = ['CreateSubscription', 'AddProduct', 'UpdateProduct']  # Zuora上で契約中を表すOrder Action Type
                if cebis_is_active and order_action_type not in zuora_active_order_action_type:
                    self.logger.warn('Cebis contract state is "active", but Zuora contract state is "inactive". product_code = [{cebis_product_code}]')

                # ⑥契約状態の比較２（Cebis上で解約状態なのにZuora上では解約状態でない場合）
                zuora_inactive_order_action_type = ['RemoveProduct', 'CancelSubscription']  # Zuora上で解約済みを表すOrder Action Type
                if (not cebis_is_active) and order_action_type not in zuora_inactive_order_action_type:
                    self.logger.warn('Cebis contract state is "inactive", but Zuora contract state is "active". product_code = [{cebis_product_code}]')

                # ⑦OrderActionに想定外の値があった場合
                if order_action_type not in (zuora_active_order_action_type + zuora_inactive_order_action_type):
                    self.logger.warn(f'Unexpected order action type in Zuora. order_action_type = [{order_action_type}]')

                # Cebisのサービス開始手配完了日（ローカル時間、YYYYMMDD形式）
                cebis_service_start_date = dateutil.parser.parse(cebis_product['service_start_time']).astimezone(pytz.timezone(local_timezone)).strftime('%Y%m%d')

                # ⑧サービス開始手配完了日が一致するか
                if cebis_service_start_date != zuora_contract_info['effective_start_date']:
                    self.logger.warn(f"Service start date does not match. Cebis = [{cebis_service_start_date}] and Zuora = [{zuora_contract_info['effective_start_date']}]")

                # ⑨サービス解約手配完了日が一致するか
                cebis_service_end_date: Optional[str] = None
                if cebis_product['service_cancel_time'] is not None:
                    cebis_service_end_date = dateutil.parser.parse(cebis_product['service_cancel_time']).astimezone(pytz.timezone(local_timezone)).strftime('%Y%m%d')  # ローカル日付に変換
                if cebis_service_end_date != zuora_contract_info['effective_end_date']:
                    self.logger.warn(f"Service end date does not match. Cebis = [{cebis_service_end_date}] and Zuora = [{zuora_contract_info['effective_end_date']}]")

                # ⑩トリガー日付がサービス開始手配完了日が一致するか
                zuora_trigger_date: Optional[str] = zuora_contract_info['trigger_date']
                if zuora_trigger_date is not None and zuora_trigger_date != cebis_service_start_date:
                    self.logger.error(f'Cebis service_start_date and Zuora trigger_date does not match. Cebis = [{cebis_service_start_date}] and Zuora = [{zuora_trigger_date}]')
                    is_valid = False

                # ⑪商品の数量の比較
                # ※Zuora上の従量商品は数量が入らないため比較対象外
                if zuora_contract_info['charge_model'] != 'Volume Pricing':
                    if cebis_product['license_quantity'] != zuora_contract_info['quantity']:
                        self.logger.error(f"Quantity does not match. Cebis = [{cebis_product['license_quantity']}] and Zuora = [{zuora_contract_info['quantity']}]")
                        is_valid = False

            if not is_valid:
                # バリデーションエラーの時はデータを更新をせず次の契約情報のチェック
                self.logger.error(f'Validation error in Zuora contract info. Zuora subscription number = [{subscription_number}] and Cebis subscription id = [{cebis_subscription_id}]')
                continue

            # RatePlanCharge項目を更新
            for zuora_contract_info in query_result:
                rate_plan_charge_update_data: Dict[str, Any] = dict()  # RatePlanChargeの更新対象項目データを格納

                # 契約連番（カスタムフィールド）が空の場合に更新
                zuora_contract_code: Optional[str] = zuora_contract_info['contract_code']
                if not zuora_contract_code:
                    rate_plan_charge_update_data['ErpContractCode__c'] = cebis_contract_code

                # サブスクリプションID（カスタムフィールド）が空の場合に更新
                zuora_subscription_id: Optional[str] = zuora_contract_info['subscription_id']
                if not zuora_subscription_id:
                    rate_plan_charge_update_data['KakinSubscriptionId__c'] = cebis_subscription_id

                # トリガー日付が空の場合に更新
                zuora_trigger_date: Optional[str] = zuora_contract_info['trigger_date']
                if not zuora_trigger_date:
                    # Cebisの対応サービスのサービス開始手配日完了日（ローカル時間、YYYY-MM-DD形式）を取得
                    cebis_product = [cebis_product for cebis_product in cebis_product_list if cebis_product['product_code'] == zuora_contract_info['product_code']][0]
                    cebis_service_start_date = dateutil.parser.parse(cebis_product['service_start_time']).astimezone(pytz.timezone(local_timezone)).strftime('%Y-%m-%d')

                    rate_plan_charge_update_data['TriggerEvent'] = 'SpecificDate'  # トリガー日付を特定の日付で設定するために必要な項目
                    rate_plan_charge_update_data['TriggerDate'] = cebis_service_start_date

                # 更新
                if len(rate_plan_charge_update_data) > 0:
                    # RatePlanChargeID
                    rate_plan_charge_id: str = zuora_contract_info['rate_plan_charge_id']

                    # RatePlanCharge更新API URL
                    api_url = options['zuora_api_endpoint'] \
                              + options['zuora_rateplancharge_url'] \
                              + '/' + rate_plan_charge_id

                    # API実行
                    data = json.dumps(rate_plan_charge_update_data)
                    put_rate_plan_charge_response: requests.Response = server_util.execute_zuora_api(
                        url=api_url,
                        method='PUT',
                        params=dict(),
                        data=data,
                    )
                    status_code = put_rate_plan_charge_response.status_code
                    is_success: bool = put_rate_plan_charge_response.json().get('Success')
                    if status_code == 200 and is_success == True:
                        self.logger.info(f'Update Zuora RatePlanCharge succeeded. data = [{data}]')
                    else:
                        self.logger.error(f'Update Zuora RatePlanCharge failed. data = [{data}]')
