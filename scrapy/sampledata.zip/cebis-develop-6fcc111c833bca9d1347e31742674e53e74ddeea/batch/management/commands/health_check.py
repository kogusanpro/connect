"""
<copyright file="health_check.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import boto3
import os

from django.core.management.base import CommandError

from batch.management.batch_command_base import BatchCommandBase
from batch.services import query_illegality_contract_service, query_inactive_and_usage_after_cancel, query_no_subscription_in_contract_info
from lib.const.s3_for_usage import CSV_DIR_PROCESSING, CSV_DIR_IN
from lib.utils import DateTimeUtil


class Command(BatchCommandBase):
    HELP = 'This Command Execute Health Check'
    ENV_KEY_S3_BUCKET = 'S3_SUBSCRIPTION_USAGE_BUCKET'

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.batch_name = 'health check'
        self.s3_bucket = ''
        # AWS Batchが起動する前にEC2やECS起動のタイムラグがあるため、バッチの実行間隔が1時間を超えたり、1時間未満になる可能性がある。
        # チェックに使う時刻は間隔が1時間になるようにここで調整する
        self.now = DateTimeUtil.utc_now_aware().replace(minute=0, second=0, microsecond=0)

    def __check_csv(self, prefix, csv_type):
        """
        従量データ一括登録用のS3バケットに、指定されたプレフィックスの
        オブジェクトが存在するかチェックする
        :param prefix:
        :param csv_type:
        :return:
        """

        s3 = boto3.client('s3')
        try:
            res = s3.list_objects(
                Bucket=self.s3_bucket,
                Prefix=prefix
            )
        except Exception as e:
            self.logger.fatal(e)
            return

        if 'Contents' not in res:
            self.logger.warning(f'S3 Subdir {prefix} Not Exists')
            return

        # ディレクトリのみ存在する場合は問題なし
        if len(res['Contents']) == 1:
            return

        for cont in res['Contents']:
            if cont['Key'] == prefix:
                continue
            self.logger.error(f'{csv_type} csv file exists...Object Key:{cont["Key"]}')

    def __check_leakage_csv(self):
        """
        処理漏れCSVファイルの検知処理
        :return:
        """
        prefix = f'{CSV_DIR_IN}/'
        self.__check_csv(prefix, 'leakage')

    def __check_error_csv(self):
        """
        処理エラーCSVファイルの検知処理
        :return:
        """

        prefix = f'{CSV_DIR_PROCESSING}/'
        self.__check_csv(prefix, 'error')

    def __check_illegality_contract(self):
        """
        不正契約の従量データ検知を行う
        :return:
        """

        records = query_no_subscription_in_contract_info(self.now)
        for record in records:
            self.logger.error(f'Illegality usage info detected!!... '
                              f'The usage info\'s subscription does not exist '
                              f'id:{record.id}, subscription_id:{record.subscription_id}, usage_id:{record.usage_id}')

        records = query_inactive_and_usage_after_cancel(self.now)
        for record in records:
            service_cancel_time = DateTimeUtil.format_iso8601_utc(record.service_cancel_time)
            start_time = DateTimeUtil.format_iso8601_utc(record.start_time)
            self.logger.error(f'Illegality contract service detected!!... '
                              f'this contract state is all inactive,but start_time grather than service_cancel_time '
                              f'subscription_id:{record.subscription_id} product_code:{record.product_code_id} '
                              f'service_cancel_time:{service_cancel_time} start_time:{start_time}')

        records = query_illegality_contract_service()
        for record in records:
            self.logger.error(f'Illegality contract service detected!!... '
                              f'this contract state is active,but service_start_time is null '
                              f'subscription_id:{record.subscription_id} product_code:{record.product_code_id}')

    def do_validate(self, *args, **options):
        """
        引数のバリデーション処理
        :param args:
        :param options:
        :return:
        """
        if os.getenv(Command.ENV_KEY_S3_BUCKET) is None:
            raise CommandError(f'Please Set Environment Variable: {Command.ENV_KEY_S3_BUCKET}')

    def main_process(self, *args, **options):
        """
        ヘルスチェックバッチメイン処理
        :param args:
        :param options:
        :return:
        """

        self.s3_bucket = os.getenv(Command.ENV_KEY_S3_BUCKET)

        self.__check_leakage_csv()
        self.__check_error_csv()
        self.__check_illegality_contract()
