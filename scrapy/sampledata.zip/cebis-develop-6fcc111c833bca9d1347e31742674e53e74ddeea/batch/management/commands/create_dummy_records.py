"""
<copyright file="create_dummy_records.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.utils.timezone import datetime, timedelta

from batch.management.batch_command_base import BatchCommandBase
from subscriptions.factory_boy import *
from subscriptions.models import *
from lib.utils import DateTimeUtil

import random


class Command(BatchCommandBase):
    help = 'This Command Create Dummy Records For Stress Test'

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.batch_name = 'create dummy records'
        self.non_flat_products = {}
        self.flat_products = {}

    def __create_prod_inf(self):
        """

        :return:
        """

        # 商品マスタ総件数は数百件
        # 定額課金（TRUE）:定額課金（FALSE） = 1:9の想定
        for i in range(0, 100):
            ProductInfoFactory(flat_rate=True)
        for i in range(0, 900):
            ProductInfoFactory(flat_rate=False)

        self.flat_products[1] = ProductInfo.objects.get(product_code='prd0000001')
        self.flat_products[2] = ProductInfo.objects.get(product_code='prd0000002')
        self.flat_products[3] = ProductInfo.objects.get(product_code='prd0000003')
        self.flat_products[4] = ProductInfo.objects.get(product_code='prd0000004')
        self.flat_products[5] = ProductInfo.objects.get(product_code='prd0000005')

        self.non_flat_products[1] = ProductInfo.objects.get(product_code='prd0000101')
        self.non_flat_products[2] = ProductInfo.objects.get(product_code='prd0000102')
        self.non_flat_products[3] = ProductInfo.objects.get(product_code='prd0000103')
        self.non_flat_products[4] = ProductInfo.objects.get(product_code='prd0000104')
        self.non_flat_products[5] = ProductInfo.objects.get(product_code='prd0000105')

    def main_process(self, *args, **options):
        """
        擬似従量データ作成バッチメイン処理
        :param args:
        :param options:
        :return:
        """

        self.__create_prod_inf()

        now = datetime.now()
        now.replace(month=now.month - 1)

        # for i in range(-5, 5):
        for i in range(-2, 2):
            target_date = now.replace(year=now.year + i)
            self.create_tran_records_per_year(target_date)

    def create_tran_records_per_year(self, target_date):
        for i in range(1, 12):
            self.create_tran_records(target_date.replace(month=i))

    def create_tran_records(self, target_date):
        # 請求情報CSVの最大行数は契約情報数になります。
        # 契約情報は、代表1商品の契約数の見積が、2019年度時点でも6000件弱、2020年度で13000件弱です。
        # なので、想定最大件数を10万レコード程度としてください。
        target_month = target_date.strftime('%Y%m')
        for i in range(0, 10000):
            ci = ContractInfoFactory()
            if target_date > datetime.now() - timedelta(days=-30):
                state = NEW
            else:
                state = COMPLETED

            bi = BillingInfoFactory(subscription=ci, target_month=target_month, state=state)
            # 請求情報明細は１〜5明細程度に分布させる
            for j in range(1, random.randint(1, 5)):
                product = self.non_flat_products[j]
                csi = ContractServiceInfoFactory(subscription=ci, product_code=product)
                bdi = BillingDetailInfoFactory(subscription=ci, target_month=target_month, product_code=product)

                # 利用明細はあったりなかったり
                for k in range(0, random.randint(0, 5)):
                    budi = BillingUsageDetailInfoFactory(subscription=ci, target_month=target_month, product_code=product,
                                                     license_user=f'user{k}')
                ui = UsageInfoFactory(product_code=product.product_code, subscription=ci)
