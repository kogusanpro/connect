"""
<copyright file="cumulative_usage_csv.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""
import math
import os
import sys
from datetime import timedelta, datetime

import boto3
from boto3.exceptions import S3UploadFailedError
from botocore.exceptions import ClientError
from dateutil.relativedelta import relativedelta
from django.conf import settings
from django.core.management.base import CommandError
from pytz import timezone, UTC

from batch.csv_file_pool import CsvFilePool
from batch.management.batch_command_base import BatchCommandBase
from batch.services import get_tmp_dir, query_daily_usage_calculation_target
from lib.const.opco_code import OPCO_TIMEZONE
from subscriptions.models.calculated_usage_info import CalculatedUsageInfo
from subscriptions.models.contract_service_Info import ContractServiceInfo
from subscriptions.serializers import CalculatedUsageInfoSerializer


class Command(BatchCommandBase):
    help = 'This Command update calculated_usage_info and create daily_usage csv file.'

    def add_arguments(self, parser):
        """
        実行時に指定可能なパラメータの引数への追加処理
        :param parser:
        :return:
        """
        parser.add_argument('--executed_date', type=str,
                            default=datetime.now().replace(tzinfo=UTC).astimezone(timezone('Asia/Tokyo')))

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.executed_date = None
        self.the_day_before_batch_run_day = None
        self.batch_name = 'update calculated_usage_info and update daily_usage csv file'
        self.csv_filename_prefix = 'daily_usage'
        self.bucket_name = os.environ.get('S3_FOR_CUMULATIVE_USAGE_BUCKET')

    def main_process(self, *args, **options):
        """
        サブスクリプションIDと商品コードのペアごとに、今月度分の日次利用量と累積利用量を集計し、利用量集計情報テーブルを更新する
        対象月度が3ヶ月以上前の利用量集計情報を利用量集計情報テーブルから削除する
        集計した利用量情報の一覧をCSVファイルとしてエクスポートし格納場所に保存する
        :param args:
        :param options:
        :return:
        """
        batch_run_time_start = datetime.now()
        self.logger.info(options['executed_date'])
        self._init_global_param(options)
        self._delete_calculated_usage_three_months_ago()
        # 契約サービス情報テーブルを検索し、集計対象の契約サービスを特定する。
        # 集計対象の従量データを従量データテーブルから検索する
        self.__filter_input_data_and_save(self.__get_calculated_usage_data(self.__get_contract_subscription_list()))
        # 利用量集計情報テーブルの情報を対象年月日別でCSVファイルに書き込む。
        self.__csv_file_init()
        # CSVをS3にアップする
        self.__upload_csv_to_s3()
        batch_run_time_end = datetime.now()
        self.logger.info(f'batch running time is {batch_run_time_end - batch_run_time_start}')

    def _init_global_param(self, options):
        """
        グローバル変数を初期化する
        :return:
        """
        if not isinstance(options['executed_date'], datetime):
            parameter_year = options['executed_date'][0:4]
            parameter_month = options['executed_date'][4:6]
            parameter_day = options['executed_date'][6:8]
            self.executed_date = datetime(int(parameter_year), int(parameter_month), int(parameter_day), 3,
                                          tzinfo=timezone('Asia/Tokyo'))
        else:
            self.executed_date = options['executed_date']
        self.logger.info(f'executed date is {self.executed_date.strftime("%Y-%m-%d")} (JST)...')
        self.the_day_before_batch_run_day = self.executed_date - timedelta(days=1)
        self.logger.info(f'collect data before {self.the_day_before_batch_run_day.strftime("%Y-%m-%d")} (JST)...')

    def _delete_calculated_usage_three_months_ago(self):
        """
        対象月度が3ヶ月以上前の利用量集計情報を利用量集計情報テーブルから削除する
        :return:
        """
        if self.executed_date.day == 1:
            three_months_ago = (self.executed_date + relativedelta(months=-3))
            now = datetime.now().replace(tzinfo=UTC).astimezone(timezone('Asia/Tokyo'))
            if (now - three_months_ago).days > 88:
                deleting_targets = CalculatedUsageInfo.objects.filter(
                    target_day__lte=three_months_ago.strftime('%Y%m%d'))
                if 0 < deleting_targets.count():
                    delete_count = str(deleting_targets.count())
                    deleting_targets.delete()
                    self.logger.info(f'{delete_count} records have been deleted before '
                                     f'{three_months_ago.strftime("%Y-%m-%d")} (JST)...')
                else:
                    self.logger.info(f'Any records are not deleted.')

    def __get_contract_subscription_list(self):
        """
        集計対象の契約サービスを特定する
        :return: list<contract_subscription_list>
        """
        try:
            contract_subscription_list = query_daily_usage_calculation_target(self.executed_date)
            if 0 == len(list(contract_subscription_list)):
                self.logger.info(f'none contract are queried from the database...')
                sys.exit(0)
            self.contract_subscription_list = list(contract_subscription_list)
            return contract_subscription_list
        except Exception as e:
            self.logger.error(e)
            sys.exit(1)

    def __get_calculated_usage_data(self, contract_subscription_list):
        """
        利用量集計情報の更新のデータ取得する
        :param contract_subscription_list:
        :return: list<usage_subscription_list>
        """
        # 集計対象契約サービスのサブスクリプションIDと一致する
        # お試し契約は集計対象にしない
        # 従量データの「論理削除」がFALSE
        # 定額課金商品は集計対象にしない
        # 対象月度がバッチ実行日時（JST）の前日の年月と一致する
        try:
            usage_subscription_list = ContractServiceInfo.objects.raw(f'''
                SELECT DISTINCT
                    ui.id,
                    ui.subscription_id,
                    ui.product_code,
                    ui.target_month,
                    ui.end_time,
                    ui.quantity,
                    csi.service_start_time,
                    ci.opco_code
                FROM usage_info ui
                    INNER JOIN product_info pi ON pi.product_code = ui.product_code
                    INNER JOIN contract_info ci ON ci.subscription_id = ui.subscription_id
                    INNER JOIN contract_service_info csi ON (csi.subscription_id = ui.subscription_id 
                        AND csi.product_code = ui.product_code)
                WHERE 
                    ui.subscription_id IN ({",".join(
                map(lambda x: "'%s'" % x.subscription_id, contract_subscription_list))})
                    AND ci.contract_code IS NOT NULL
                    AND ui.deleted IS FALSE
                    AND pi.flat_rate IS FALSE
                    AND ui.target_month = '{self.the_day_before_batch_run_day.strftime("%Y%m")}'
                    AND ui.start_time >= csi.service_start_time
                    AND ((ui.end_time <= csi.service_cancel_time) OR (csi.service_cancel_time IS NULL))
                    AND DATE_FORMAT(DATE_ADD(ui.end_time, INTERVAL 9 HOUR), '%%Y%%m%%d') 
                    <= {self.the_day_before_batch_run_day.strftime("%Y%m%d")}
                ORDER BY 
                    ui.product_code, ui.subscription_id, ui.end_time
            ''')
            if 0 == len(list(usage_subscription_list)):
                self.logger.info(f'none usages are queried from the database...')
                # 111619 利用量集計バッチがS3にcsvファイル作成されない
                # sys.exit(0)
            return list(usage_subscription_list)
        except Exception as e:
            self.logger.error(e)
            sys.exit(1)

    def __filter_input_data_and_save(self, usage_data_list):
        """
        日次および累積利用量の集計
        :param usage_data_list:
        :return:
        """
        try:
            subscription_and_product_list = self.__get_subscription_and_product_list(self.contract_subscription_list)
            for subscription, product_code_list in subscription_and_product_list.items():
                for product_code in product_code_list:
                    subscription_and_product = [subscription_and_product for subscription_and_product
                                                in self.contract_subscription_list
                                                if subscription_and_product.product_code_id == product_code
                                                and subscription_and_product.subscription_id == subscription]
                    local_end_time_list = self.__get_local_end_time_list(subscription_and_product)
                    for local_end_time in local_end_time_list:
                        target_month = local_end_time[0:6]
                        try:
                            local_end_time_usage = [float(local_end_time_usage.quantity) for local_end_time_usage
                                                    in usage_data_list
                                                    if local_end_time_usage.product_code_id == product_code
                                                    and local_end_time_usage.subscription_id == subscription
                                                    and self.__convert_to_local_time(
                                    local_end_time_usage.end_time, local_end_time_usage.opco_code).strftime(
                                    "%Y%m%d") == local_end_time]
                            usage_quantity = sum(local_end_time_usage)
                        except ValueError:
                            self.logger.error(
                                f'{subscription} {product_code} {local_end_time} usage is invalid ...')
                            usage_quantity = None
                        try:
                            month_quantity = sum([float(daily_usage.quantity) for daily_usage
                                                  in usage_data_list
                                                  if daily_usage.product_code_id == product_code
                                                  and daily_usage.subscription_id == subscription
                                                  and local_end_time_list[0] <= self.__convert_to_local_time(
                                    daily_usage.end_time, daily_usage.opco_code).strftime("%Y%m%d") <= local_end_time])
                        except ValueError:
                            self.logger.error(
                                f'{subscription} {product_code} {target_month} usage is invalid ...')
                            month_quantity = None

                        cui_single_record = CalculatedUsageInfo.objects.filter(subscription_id=subscription,
                                                                               product_code=product_code,
                                                                               target_day=local_end_time)
                        if len(cui_single_record) == 0:  # レコードが見つかれない場合
                            calculated_usage_info_data = {
                                "subscription_id": subscription,
                                "product_code": product_code,
                                "target_month": target_month,
                                "target_day": local_end_time,
                                "daily_usage": usage_quantity,
                                "cumulative_usage": month_quantity}
                            calculated_usage_info = CalculatedUsageInfoSerializer(data=calculated_usage_info_data)
                            if not calculated_usage_info.is_valid():
                                self.logger.error(
                                    f'{subscription} {product_code} {local_end_time} usage is invalid...')
                                return False
                            calculated_usage_info.save()
                        elif len(cui_single_record) == 1:  # レコードが見つかった場合
                            cui_single_record[0].target_month = target_month
                            cui_single_record[0].daily_usage = usage_quantity
                            cui_single_record[0].cumulative_usage = month_quantity
                            cui_single_record[0].save()
                        else:
                            self.logger.error(
                                f'{subscription} {product_code} {local_end_time} multiple usages records found...')
                            return False
        except ValueError as e:
            self.logger.error(
                f'update {subscription} {product_code} {local_end_time} usage is failed...')
            self.logger.error(e)
            raise CommandError(e)

    @staticmethod
    def __format_number(float_number):
        """
        整数に変換
        :param float_number:
        :return: int_number
        """
        if float_number is None or isinstance(float_number, str):
            return float_number
        else:
            return float_number if math.modf(float_number)[0] > 0 else int(float_number)

    @staticmethod
    def __convert_to_local_time(data_time, location):
        """
        現地時間に変換
        :param data_time:
        :param location:
        :return:
        """
        data_time = data_time.replace(tzinfo=UTC)
        local_timezone = timezone(OPCO_TIMEZONE[location])

        return data_time.astimezone(local_timezone)

    def __csv_file_init(self):
        """
        利用量集計情報テーブルの情報を対象年月日別でCSVファイルに書き込む。
        :return:
        """
        records = CalculatedUsageInfo.objects.filter(
            target_month=self.the_day_before_batch_run_day.strftime("%Y%m")).order_by(
            'subscription_id', 'product_code', 'target_day')
        with CsvFilePool(self.csv_filename_prefix, self.__create_header(), get_tmp_dir()) as daily_usage_pool:
            for record in records:
                writer = daily_usage_pool.get_writer(self.the_day_before_batch_run_day.strftime("%Y%m%d"))
                self.__write_csv_line(writer, record)

    @staticmethod
    def __create_header() -> list:
        """
        CSVファイルのヘッダ行を生成する
        :return: header
        """
        header = list()
        header.append('#subscription_id')
        header.append('product_code')
        header.append('target_month')
        header.append('target_day')
        header.append('daily_usage')
        header.append('cumulative_usage')
        return header

    def __write_csv_line(self, writer, record):
        """
        CSVファイルに１レコードの書き込みを行う
        :param writer:
        :param record:
        :return: writer
        """
        csv_row = list()
        csv_row.append(self.__write_csv_line_check_null(record.subscription_id_id))
        csv_row.append(self.__write_csv_line_check_null(record.product_code_id))
        csv_row.append(self.__write_csv_line_check_null(record.target_month))
        csv_row.append(self.__write_csv_line_check_null(record.target_day))
        csv_row.append(self.__write_csv_line_check_null(self.__format_number(record.daily_usage)))
        csv_row.append(self.__write_csv_line_check_null(self.__format_number(record.cumulative_usage)))

        return writer.writerow(csv_row)

    @staticmethod
    def __write_csv_line_check_null(record_item):
        """
        CSV String Null create
        :param record_item:
        :return: str:
        """
        if record_item is None:
            return 'NULL'
        return record_item

    def __get_local_end_time_list(self, subscription_and_product):
        """
        現在の時刻リストを月の初めまで取得する
        :param subscription_and_product:
        :return:list<datetime>
        """
        if len(subscription_and_product) != 0:
            subscription_and_product = subscription_and_product[0]
            end_of_calculation_day = subscription_and_product.service_cancel_time if (
                    subscription_and_product.service_cancel_time is not None and self.the_day_before_batch_run_day
                    >= subscription_and_product.service_cancel_time
            ) else self.the_day_before_batch_run_day
            begin_of_month = self.__get_begin_of_month(end_of_calculation_day).strftime("%Y%m%d")
            contract_service_start_time_jst = subscription_and_product.service_start_time.replace(
                tzinfo=UTC).astimezone(
                timezone('Asia/Tokyo')).strftime("%Y%m%d")
            start_day = contract_service_start_time_jst if (
                    subscription_and_product.service_start_time.strftime(
                        "%Y%m%d") >= begin_of_month) else begin_of_month
            date_list = list()

        while end_of_calculation_day.strftime("%Y%m%d") >= start_day:
            date_list.append(end_of_calculation_day.strftime("%Y%m%d"))
            end_of_calculation_day += timedelta(days=-1)

        date_list.sort()
        return date_list

    @staticmethod
    def __get_subscription_and_product_list(usage_data):
        """
        「subscription」と「product」の組み合わせリストを取得する
        :return:
        """
        subscription_and_product_list = dict()
        for subscription_and_product in usage_data:
            if subscription_and_product_list.get(subscription_and_product.subscription_id) is None:
                subscription_and_product_temp = set()
                subscription_and_product_temp.add(subscription_and_product.product_code_id)
                subscription_and_product_list[
                    subscription_and_product.subscription_id] = subscription_and_product_temp
            subscription_and_product_list[subscription_and_product.subscription_id].add(
                subscription_and_product.product_code_id)
        return subscription_and_product_list

    @staticmethod
    def __get_begin_of_month(base_date) -> datetime:
        """
        引数で渡された日付の1日の00:00:00を表すdatetimeオブジェクトを返す
        :return:
        """
        return base_date.replace(month=base_date.month, day=1, hour=0, minute=0, second=0, microsecond=0)

    def __upload_csv_to_s3(self):
        """
         CSVをS3にアップする
         :return: :void:
        """
        s3 = boto3.resource('s3', endpoint_url=settings.AWS_S3_ENDPOINT).meta.client
        key = f'{self.csv_filename_prefix}_{self.the_day_before_batch_run_day.strftime("%Y%m%d")}.csv'
        local_file = os.path.join(get_tmp_dir(), key)

        s3_folder_year = self.the_day_before_batch_run_day.year
        s3_folder_date = self.the_day_before_batch_run_day.strftime("%Y%m")
        obj_key = f'{self.csv_filename_prefix}/{s3_folder_year}/{s3_folder_date}/{key}'
        self.logger.info(f'Start Upload CSV File: {local_file} to s3://{self.bucket_name}/{obj_key}')

        try:
            s3.upload_file(local_file, self.bucket_name, obj_key)
            if os.path.exists(local_file):
                os.remove(local_file)
                self.logger.info(f'temporary file {local_file} has been deleted')
        except (ClientError, S3UploadFailedError) as e:
            self.logger.error(f'Upload CSV File Failed... {e}')
        self.logger.info(f'Complete Upload CSV File: {local_file} to s3://{self.bucket_name}/{obj_key}')
