"""
<copyright file="cumulative_usage_csv_sftp_put.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""
import datetime
import os
import sys
import tempfile

import boto3
from botocore.exceptions import ClientError
from django.conf import settings
from paramiko import SSHClient, AutoAddPolicy, SSHException
from pytz import timezone

from batch.management.batch_command_base import BatchCommandBase
from batch.services import get_tmp_dir
from lib.utils import DateTimeUtil


class Command(BatchCommandBase):
    help = 'This Command upload cumulative usage CSV file to sFtp'

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.batch_name = 'sending cumulative usage csv files to SFTP Server'
        self.csv_filename_prefix = 'daily_usage'
        self.the_day_before_batch_run_day = (DateTimeUtil.utc_now_aware() - datetime.timedelta(days=1)).astimezone(
            timezone('Asia/Tokyo'))
        self.file_name = f'{self.csv_filename_prefix}_{self.the_day_before_batch_run_day.strftime("%Y%m%d")}.csv'
        self.path_year = self.the_day_before_batch_run_day.strftime("%Y")
        self.path_year_and_month = self.the_day_before_batch_run_day.strftime("%Y%m")
        self.file_path = f'{self.csv_filename_prefix}/{self.path_year}/{self.path_year_and_month}/{self.file_name}'
        self.s3 = boto3.client('s3', endpoint_url=settings.AWS_S3_ENDPOINT)

    def add_arguments(self, parser):
        """
        実行時に指定可能なパラメータの引数への追加処理
        :param parser:
        :return:
        """

        parser.add_argument('--sftp_host_name', type=str,
                            default=settings.SFTP['HOST'])
        parser.add_argument('--sftp_user', type=str,
                            default=settings.SFTP['USER'])
        parser.add_argument('--sftp_password', type=str,
                            default=settings.SFTP['PASSWORD'])
        parser.add_argument('--sftp_remote_path', type=str,
                            default=os.environ['CUMULATIVE_USAGE_SFTP_REMOTE_PATH'])

    def main_process(self, *args, **options):
        """
        SFTP送信バッチメイン処理
        :param args:
        :param options:
        :return:
        """
        self.logger.info(f'start collect csv files of {self.the_day_before_batch_run_day}.')
        self.sftp_host_name = options['sftp_host_name']
        self.sftp_user = options['sftp_user']
        self.sftp_password = options['sftp_password']
        self.sftp_remote_path = options['sftp_remote_path']
        self._put_files_to_sftp(
            bucket=os.environ.get('S3_FOR_CUMULATIVE_USAGE_BUCKET')
        )

    def _put_files_to_sftp(self, bucket):
        file = self._get_csv_files(bucket)
        if not file:
            self.logger.error(f'Target file does not exists')
            return True
        self.logger.info(f'S3 file has been successful achieved. path is {file}.')
        temp_csv_file = tempfile.NamedTemporaryFile()
        try:
            s3 = boto3.resource('s3', endpoint_url=settings.AWS_S3_ENDPOINT)
            s3.Bucket(bucket).download_file(
                Key=self.file_path,
                Filename=temp_csv_file.name,
            )
            self.__send_sftp(
                local_file=temp_csv_file.name,
                remote_file=self.file_name
            )
        except ClientError as e:
            self.logger.info(f'csv file sftp put error...')
            self.logger.error(e)
            sys.exit(1)

    def _get_csv_files(self, bucket):
        try:
            s3_target_file = self.s3.get_object(
                Bucket=bucket,
                Key=self.file_path
            )
            self.logger.info(f'csv file path is {self.file_path}')
        except ClientError as e:
            self.logger.info(f'S3 client error.')
            self.logger.error(e)
            sys.exit(1)
        return s3_target_file

    def __send_sftp(self, local_file, remote_file):
        try:
            self.logger.info(f'start to put csv file to sftp...')
            ssh = SSHClient()
            ssh.set_missing_host_key_policy(AutoAddPolicy())
            ssh.connect(
                hostname=self.sftp_host_name,
                port=settings.SFTP['PORT'],
                username=self.sftp_user,
                password=self.sftp_password,
            )
            remote_path = self.sftp_remote_path
            self.logger.info(f'the sftp path is {remote_path}')
            sftp = ssh.open_sftp()
            remote_files = sftp.listdir(remote_path)

            if remote_file not in remote_files:
                sftp.put(local_file, remote_path + remote_file)
                self.logger.info(f'{remote_file} has been uploaded to the sftp server.')
            else:
                old_remote_file = remote_file + '.old'
                if old_remote_file in remote_files:
                    count = 0
                    while True:
                        try:
                            count += 1
                            count_old_remote_file = old_remote_file + '.' + str(count)
                            if count_old_remote_file not in remote_files:
                                sftp.rename(
                                    oldpath=remote_path + old_remote_file,
                                    newpath=remote_path + count_old_remote_file
                                )
                                sftp.rename(
                                    oldpath=remote_path + remote_file,
                                    newpath=remote_path + old_remote_file
                                )
                                sftp.put(local_file, remote_path + remote_file)
                                self.logger.info(f'{remote_file} has been uploaded to the sftp server.')
                                break
                        except FileNotFoundError as e:
                            self.logger.error(e)
                            sys.exit(1)
                else:
                    sftp.rename(
                        oldpath=remote_path + remote_file,
                        newpath=remote_path + old_remote_file
                    )
                    sftp.put(local_file, remote_path + remote_file)
                    self.logger.info(f'{remote_file} has been uploaded to the sftp server.')
                sftp.put(local_file, remote_path + remote_file)
            fen_base_path = get_tmp_dir()
            fen_file_name = f'{self.csv_filename_prefix}_{self.the_day_before_batch_run_day.strftime("%Y%m%d")}.fen'
            self.logger.info(f'{self.csv_filename_prefix}_{self.the_day_before_batch_run_day.strftime("%Y%m%d")}.fen'
                             f' has been successfully created')
            if fen_base_path is not None:
                fen_file_path = os.path.join(fen_base_path, fen_file_name)
            file = open(fen_file_path, 'w')
            file.close()
            sftp.put(fen_file_path, remote_path + "/" + fen_file_name)
            sftp.close()
            ssh.close()
        except (SSHException, FileNotFoundError, PermissionError, TimeoutError) as e:
            self.logger.error(e)
            sys.exit(1)
