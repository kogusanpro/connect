"""
<copyright file="coohub_contract_sync.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2019-2020. All rights reserved.
</copyright>
"""
import os
import sys
import pytz
import json
from datetime import timedelta, datetime
from concurrent.futures import ThreadPoolExecutor
from lib.const.coohub_k5_tenants import K5_TENANTS
from lib.utils import ServerUtil
from lib.contract_info_util import is_zuora_data
from batch.management.batch_command_base import BatchCommandBase
from lib.utils import check_datetime_format, DateTimeUtil
from django.core.management.base import CommandError

class Command(BatchCommandBase):
    help = 'This batch is used to synchronize the contracts between Fujitsu k5 and Cebis'
    thread_number = 10

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.executed_date = None
        self.from_updated_datetime = None
        self.to_updated_datetime = None

        self.the_day_before_batch_run_day = None
        self.service_price_plan_code_table = None

        self.cebis_api_endpoint = None
        self.cebis_subscriptions_url = None
        self.cebis_calculation_system_api_key = None

        self.k5_customer_id = None
        self.administration_number = None
        self.entry_id = None
        self.k5_api_endpoint = None
        self.k5_price_master_url = None
        self.k5_basic_contract_url = None
        self.k5_service_contract_url = None
        self.classification_of_contract = None

        self.batch_name = 'Synchronize contract information (Coohub)'

    def add_arguments(self, parser):
        """
        実行時に指定可能なパラメータの引数への追加処理
        :param parser: システムパラメータ
        :return:
        """
        # 外部設定のパラメーター、JST時間
        # 今回の開発の終了日時はexecuted_dateに基づいて計算したため、開始日時＝終了日時-1日
        parser.add_argument('--executed_date', type=str,
                            default=datetime.utcnow().replace(tzinfo=pytz.UTC).astimezone(pytz.timezone('Asia/Tokyo')))

        parser.add_argument('--from_updated_datetime', type=str, default="", )

        parser.add_argument('--to_updated_datetime', type=str, default="", )

        parser.add_argument('--k5_customer_id', type=str, default=os.environ.get('K5_CUSTOMER_ID'))

        parser.add_argument('--cebis_api_endpoint', type=str, default=os.environ.get('CEBIS_API_ENDPOINT'))

        parser.add_argument('--cebis_subscriptions_url', type=str, default=os.environ.get('CEBIS_SUBSCRIPTIONS_URL'))

        parser.add_argument('--cebis_calculation_system_api_key', type=str,
                            default=os.environ.get('CEBIS_CALCULATION_SYSTEM_API_KEY'))

        parser.add_argument('--k5_api_endpoint', type=str, default=os.environ.get('K5_API_ENDPOINT'))

        parser.add_argument('--k5_price_master_url', type=str, default=os.environ.get('K5_PRICE_MASTER_URL'))

        parser.add_argument('--k5_basic_contract_url', type=str, default=os.environ.get('K5_BASIC_CONTRACT_URL'))

        parser.add_argument('--k5_service_contract_url', type=str, default=os.environ.get('K5_SERVICE_CONTRACT_URL'))

        parser.add_argument('--entry_id', type=str, default=os.environ.get('ENTRY_ID'))

        parser.add_argument('--administration_number', type=str, default=os.environ.get('ADMINISTRATION_NUMBER'))

        parser.add_argument('--classification_of_contract', type=str, default=os.environ.get('CLASSIFICATION_OF_CONTRACT'))

    def __init_global_param(self, options):
        """
        グローバル変数を初期化する
        :return:
        """
        # バッチ実行日時(JST)の年月日
        self.executed_date = options.get("executed_date")

        if not isinstance(self.executed_date, datetime):
            # 手動実行(JST)
            parameter_year = self.executed_date[0:4]
            parameter_month = self.executed_date[4:6]
            parameter_day = self.executed_date[6:8]
            self.executed_date = datetime(int(parameter_year), int(parameter_month), int(parameter_day), 4)\
                .replace(tzinfo=pytz.timezone('Asia/Tokyo'))
        else:
            # 自動実行
            self.executed_date = options.get("executed_date")

        self.the_day_before_batch_run_day = self.executed_date - timedelta(days=1)
        self.cebis_api_endpoint = options.get('cebis_api_endpoint')
        self.cebis_subscriptions_url = options.get('cebis_subscriptions_url')
        self.cebis_calculation_system_api_key = options.get('cebis_calculation_system_api_key')

        self.k5_customer_id = options.get('k5_customer_id')
        self.k5_api_endpoint = options.get('k5_api_endpoint')
        self.k5_price_master_url = options.get('k5_price_master_url')
        self.k5_basic_contract_url = options.get('k5_basic_contract_url')
        self.k5_service_contract_url = options.get('k5_service_contract_url')
        self.administration_number = options.get('administration_number')
        self.classification_of_contract = options.get('classification_of_contract')
        self.entry_id = options.get('entry_id')

        self.from_updated_datetime = options.get('from_updated_datetime')
        self.to_updated_datetime = options.get('to_updated_datetime')

        self.logger.info(f'Executed date is {self.executed_date} ...')
        self.logger.info(f'Entry id is {self.entry_id}...')

    def main_process(self, *args, **options):
        """
        従量データ収集基盤から契約情報一覧を取得し、従量計算システムへ同期する
        :param args: システムパラメータ
        :param options: システムパラメータ
        :return:
        """

        self.__init_global_param(options)
        # Cebisの契約情報取得インターフェイスから契約情報リストを取得する
        cebis_contracts = self.__handle_contracts_from_cebis()

        # 料金プランコード表を作成する
        self.service_price_plan_code_table = self.__create_price_plan_code_table_from_k5()

        # 「サブスクリプション番号」の有無でK5商品かZuora商品かを判別
        cebis_k5_contracts = []
        for contract in cebis_contracts:
            if not is_zuora_data(contract):
                cebis_k5_contracts.append(contract)

        # 富士通k5とcebis間の契約エントリの同期
        self.__sync_base_and_service_contracts(cebis_k5_contracts)

    def do_validate(self, *args, **options):
        """
        引数等のバリデーション処理
        :param args:
        :param options:
        :return:
        """
        if options['from_updated_datetime'] and options['to_updated_datetime']:
            if not check_datetime_format(datetime=options['from_updated_datetime']):
                raise CommandError(
                    f'from_updated_datetime was invalid format in this request body')

            if not check_datetime_format(datetime=options['to_updated_datetime']):
                raise CommandError(
                    f'to_updated_datetime was invalid format in this request body')

            if DateTimeUtil.YmdTHMSZ_utc_to_YmdHMS_utc(options['from_updated_datetime']) > \
                    DateTimeUtil.YmdTHMSZ_utc_to_YmdHMS_utc(options['to_updated_datetime']):
                raise CommandError(
                    f'from_updated_datetime was greater than to_updated_datetime in this request body')

        elif (options['from_updated_datetime'] and not options['to_updated_datetime']) \
                or (not options['from_updated_datetime'] and options['to_updated_datetime']):
            raise CommandError(f'from_updated_datetime and to_updated_datetime are specified as a pair')

    def __handle_contracts_from_cebis(self):
        """
        Cebisから契約のリストを取得する
        :return contract_list: Cebisから取得した契約のリスト
        """
        self.logger.info('Start getting contracts from cebis ...')
        response_for_getting_subscriptions = self.__get_subscriptions(0)
        # 契約リストの取得を成功する場合
        if response_for_getting_subscriptions.status_code == 200:
            json_data_of_getting_subscriptions = response_for_getting_subscriptions.json()
            contract_list: list = json_data_of_getting_subscriptions.get('subscriptions')
            contracts_count = int(json_data_of_getting_subscriptions.get('count') / 2)
            if contracts_count > 50:
                start_time_for_getting_contract = datetime.now()
                executor = ThreadPoolExecutor(max_workers=self.thread_number)
                contract_list_calculate_by_offset = [executor.submit(self.__get_subscriptions,offset) for offset in
                                                     range(1, int(contracts_count / 50 + 1))]
                executor.shutdown()
                cebis_contract_list = [contract.result().json().get('subscriptions') for contract in
                                       contract_list_calculate_by_offset]
                end_time_for_getting_contract = datetime.now()
                for contract in cebis_contract_list:
                    contract_list.extend(contract)
                self.logger.info('Successfully obtained contracts from cebis ...')
                self.logger.info(
                    f'Ran for {(end_time_for_getting_contract - start_time_for_getting_contract).seconds} seconds ...')
            else:
                self.logger.info('Successfully obtained contracts from cebis, and contracts count is less than 50 ...')

            for i, contract in enumerate(contract_list):
                self.logger.info(f'Cebis contract[{i}] : subscription_id = {contract.get("subscription_id")}')

            return contract_list
        else:
            self.logger.fatal('Failed to get list of contracts from cebis ...')
            self.logger.fatal('System exit ...')
            sys.exit(0)

    def __get_subscriptions(self, offset):
        """
        マルチスレッドで契約情報の一括取得
        tomorrowデコレータを使用します
        同時実行性は10です
        :param offset: 取得契约的开始位置
        :return response_for_getting_subscriptions: Cebisから契約情報一括取得APIで取得した契約情報
        """
        # from_updated_time
        # バッチ実行日時(JST)の前日の年月日。時分秒は000000とする
        # isoタイムスタンプに変換されている。
        # つまり、渡される時間はバッチ実行日時(JST)の前日 00:00:00をUTC時間以降のisoタイムスタンプに変換する。
        self.logger.info(f'Start Execete __get_subscriptions  offset= {offset}')

        from_updated_time = self.the_day_before_batch_run_day \
            .astimezone(pytz.UTC) \
            .replace(hour=15, minute=0, second=0) \
            .strftime('%Y%m%dT%H%M%SZ')

        # to_updated_time
        # バッチ実行日時(JST)の年月日。時分秒は000000とする。
        to_updated_time = self.executed_date \
            .astimezone(pytz.UTC) \
            .replace(hour=15, minute=0, second=0) \
            .strftime('%Y%m%dT%H%M%SZ')
        # AR99144の修正として、インシデント対応時にfrom/toの年月日時分秒を指定できるようにした
        if self.from_updated_datetime and self.to_updated_datetime:
            from_updated_time = self.from_updated_datetime
            to_updated_time = self.to_updated_datetime
            self.logger.info(f'using the specification time...')

        params = {
            'from_updated_time': from_updated_time,
            'to_updated_time': to_updated_time,
            'internal_calc': 'true',
            'offset': offset * 50 + 1
        }

        self.logger.info(f'Start execute"/subscriptions"API(get_cebis_response:GET)...params={params}')

        # 契約情報一括取得API
        response_for_getting_subscriptions = ServerUtil(self).get_cebis_response(
            url=self.cebis_api_endpoint + self.cebis_subscriptions_url,
            params=params,
            method='GET',
            data={},
            api_key=self.cebis_calculation_system_api_key
        )

        self.logger.info(f'End execute"/subscriptions"API(get_cebis_response:GET)...params={params}')
        response_json = response_for_getting_subscriptions.json()
        self.logger.info(f'Response status_code={response_for_getting_subscriptions.status_code}')
        self.logger.info(f'Response body ={response_json}')

        if response_for_getting_subscriptions.status_code != 200:
            self.logger.info('Failed to get list of contracts from cebis ...')
            self.logger.info(f'Failed status_code {response_for_getting_subscriptions.status_code}')
            self.logger.info(f'Failed message {response_for_getting_subscriptions.content}')
            self.logger.info(f'Failed parameters {params}')
            self.logger.info(f'Failed URL {self.cebis_api_endpoint + self.cebis_subscriptions_url}')
            self.logger.info(f'Failed api_key {self.cebis_calculation_system_api_key}')
            self.logger.info('System exit ...')
            sys.exit(0)
        return response_for_getting_subscriptions

    def __create_price_plan_code_table_from_k5(self):
        """
        サービス料金情報一覧を取得する
        料金プランコード表の作成
        :return service_price_plan_table: 料金プランコード表
        """
        # サービス料金情報を検索APIパラメータのインストール
        params = {'charge_info_retrieval_flg': 1}

        self.logger.info('Start getting service price plan from fujitsu k5 ...')
        get_service_price_plan_start_time = datetime.now()
        service_price_plan_list = {}

        # 全テナントのサービス対応表のサイクル
        for k5_tenant in K5_TENANTS:
            self.logger.info(f'Start execute"/API/v2/api/servicepricemaster"API(get_k5_response:GET)...params={params}')
            # 富士通K5のサービスを訪問する料金情報を検索API　
            service_price_plan_response = ServerUtil(self).get_k5_response(
                url=self.k5_api_endpoint + self.k5_price_master_url,
                params=params,
                method='GET',
                allow_token_time_out_minutes=5,
                data={},
                k5_tenant=k5_tenant
            )
            self.logger.info(f'End execute"/API/v2/api/servicepricemaster"API(get_k5_response:GET)...params={params}')
            self.logger.info(f'Response status_code={service_price_plan_response.status_code}')

            # サービス料金情報を成功に取得する検索APIの場合
            if service_price_plan_response.status_code == 200:
                # サービス料金情報のリスト
                service_price_plan = service_price_plan_response.json().get('service_master_information_list')
                service_price_plan = self.__create_price_plan_code_table_by_tenant(service_price_plan,
                                                                                   k5_tenant.get('client_id'))

                # サービス料金情報テーブル作成
                service_price_plan_list = dict(service_price_plan_list, **service_price_plan)

                get_service_price_plan_end_time = datetime.now()
                get_service_price_plan_total_time = (
                        get_service_price_plan_end_time - get_service_price_plan_start_time).seconds
                self.logger.info('Successfully obtained service price plan from Fujitsu k5 server ...')
                self.logger.info(f'Ran for {get_service_price_plan_total_time} seconds ...')
                self.logger.info(f'The number of service price plan on cebis is {len(service_price_plan_list)} ...')
            else:
                self.logger.fatal('Failed to get service price plan from Fujitsu k5 server ...')
                self.logger.info(f'Failed status_code {service_price_plan_response.status_code}')
                self.logger.info(f'Failed message {service_price_plan_response.content}')
                self.logger.info(f'Failed parameters {params}')
                self.logger.info(f'Failed URL {self.k5_api_endpoint + self.k5_price_master_url}')
                self.logger.fatal('System exit ...')
                sys.exit(1)
        return service_price_plan_list

    def __create_price_plan_code_table_by_tenant(self, service_price_plan_list: list, client_id: str):
        """
        料金プランコード表作成
        :param service_price_plan_list: サービス料金情報のリスト
        :param client_id: client_id
        :return price_plan_code_table: 料金プランコード表
        """
        # 料金プランコードテーブルの初期化
        price_plan_code_table = {}

        # キー値または値がNULLまたは空の場合は、エラーログを出力して処理を続行する。
        # service_price_plan_listを循環し，料金プランコード表を作成する
        for service_price_plan in service_price_plan_list:
            if service_price_plan.get('free_item1') is not None:
                product_code = service_price_plan.get('free_item1')
            else:
                self.logger.error('Get service price plan failed, because product code is null.'
                                  f'client_id is {client_id} ...')

                continue

            if service_price_plan.get('free_item2') is not None:
                product_type = service_price_plan.get('free_item2')
            else:
                self.logger.error('Get service price plan failed, because product type is null. '
                                  f'product_code is {product_code}, '
                                  f'client_id is {client_id} ...'
                                  )
                continue

            if service_price_plan.get('free_item3') is not None:
                opco_code = service_price_plan.get('free_item3')
            else:
                self.logger.error(f'Get service price plan failed, because product opco is null. '
                                  f'product_code is {product_code}, '
                                  f'product_type is {product_type} ,'
                                  f'client_id is {client_id} ...')
                continue

            if service_price_plan.get('service_code') is not None:
                service_code = service_price_plan.get('service_code')
            else:
                self.logger.error(f'Get service price plan failed, because service code is null. '
                                  f'product_code is {product_code}, '
                                  f'product_type is {product_type}, '
                                  f'client_id is {client_id} ...')
                continue

            apply_start_date = service_price_plan.get('apply_start_date')
            apply_end_date = service_price_plan.get('apply_end_date')

            if service_price_plan.get('price_plan_list') is not None:
                price_plan_list = service_price_plan.get('price_plan_list')
                price_plan_code = price_plan_list[0].get('price_plan_code')
            else:
                self.logger.error(f'Get service price plan failed, because price_plan_list is null. '
                                  f'product_code is {product_code}, '
                                  f'product_type is {product_type}, '
                                  f'client_id is {client_id} ...')
                continue

            price_plan_code_table_value = {
                'product_code': product_code,
                'product_type': product_type,
                'opco_code': opco_code,
                'service_code': service_code,
                'apply_start_date': apply_start_date,
                'apply_end_date': apply_end_date,
                'price_plan_code': price_plan_code,
                'price_plan_list': price_plan_list
            }

            # javaコードの形式に従って、料金プランコード表のkeyはclient id _ product code _ opco code
            price_plan_code_table_key = client_id + "_" + product_code + "_" + opco_code

            price_plan_code_table.update({price_plan_code_table_key: price_plan_code_table_value})
        return price_plan_code_table

    def __sync_base_and_service_contracts(self, cebis_k5_contracts: list):
        """
        :param cebis_k5_contracts: CebisのK5契約情報
        基本契约のマルチスレッドの呼び出し
        基本契約の同期処理には、サービス契約の処理が含まれます
        """

        self.logger.info('Start synchronization basic contract ...')
        start_time_for_sync = datetime.now()
        executor = ThreadPoolExecutor(max_workers=self.thread_number)

        # 基本契約情報とサービス契約情報の同期
        basic_contract_list_by_cebis_contracts = [
            executor.submit(self.__handle_base_and_service_contracts_sync_parallel,contract) for contract in cebis_k5_contracts
        ]
        executor.shutdown()
        end_time_for_sync = datetime.now()
        total_time = (end_time_for_sync - start_time_for_sync).seconds

        self.logger.info('Contract synchronization completed ...')
        self.logger.info(f'Ran for {total_time} seconds ...')

    def __handle_base_and_service_contracts_sync_parallel(self, contract):
        """
        基本契約とサービス契約を同期する
        :param contract: Cebisから取得した契約情報
        :return sync_result: 契約同期の結果
        """

        k5_tenant = max([
            k5_tenant for k5_tenant in K5_TENANTS
            if k5_tenant.get('standard_value') < int(contract.get('subscription_id')[0: 8])])

        # 基本契約がK5に見つからなければ新規作成する
        if not self.__base_contract_found(contract=contract, k5_tenant=k5_tenant):
            basic_service_products = [product for product in contract.get('products') if product.get('product_type') == 'basic']
            eldest_basic_service_product = min(basic_service_products, key=lambda x: x.get('service_start_time'))
            bc_register_response = self.__register_base_contract(
                contract=contract,
                k5_tenant=k5_tenant,
                eldest_basic_service_product=eldest_basic_service_product)

        # 基本契約情報を取得する
        base_contract_param = {
            'free_item1': contract.get('subscription_id')
        }
        self.logger.info(f'Start execute"/API/v2/api/basiccontract"API(get_k5_response:GET)...params={base_contract_param}')

        base_contract_response = ServerUtil(self).get_k5_response(
            url=self.k5_api_endpoint + self.k5_basic_contract_url,
            params=base_contract_param,
            method='GET',
            allow_token_time_out_minutes=1,
            data={},
            k5_tenant=k5_tenant
        )
        self.logger.info(f'End execute"/API/v2/api/basiccontract"API(get_k5_response:GET)...params={base_contract_param}')
        response_json = base_contract_response.json()
        self.logger.info(f'Response status_code={base_contract_response.status_code}')
        self.logger.info(f'Response body ={response_json}')

        basic_contract_list_found = base_contract_response.json().get('basic_contract_list') is not None
        products_found = len(contract.get('products')) > 0
        if basic_contract_list_found:
            if products_found:
                # サービス契約を同期する
                basic_contract_list_from_k5 = base_contract_response.json().get('basic_contract_list')
                self.__sync_service_contract(contract=contract,
                                              k5_tenant=k5_tenant,
                                              basic_contract_list_from_k5=basic_contract_list_from_k5)
            else:
                subscription_id_log = contract.get("subscription_id")
                self.logger.error('Service contract count is less than 0  ...'
                             f'subscription_id is {subscription_id_log}  ...' )
                self.logger.info(f'Failed URL = {self.k5_api_endpoint + self.k5_basic_contract_url}')
                self.logger.info(f'Failed status_code {base_contract_response.status_code}')
                self.logger.info(f'Failed parameters = {base_contract_param}')
                self.logger.info(f'Failed message = {base_contract_response.content}')
        else:
            self.logger.error(f'The basic contract is unknown status : {contract.get("subscription_id")}')

    def __base_contract_found(self, contract: dict, k5_tenant: dict):

        params_for_get_basic_contract = {
            'free_item1': contract.get('subscription_id')
        }

        self.logger.info(f'Start execute"/API/v2/api/basiccontract"API(get_k5_response:GET)...params={params_for_get_basic_contract}')
        response = ServerUtil(self).get_k5_response(
            url=self.k5_api_endpoint + self.k5_basic_contract_url,
            params=params_for_get_basic_contract,
            method='GET',
            allow_token_time_out_minutes=1,
            data={},
            k5_tenant=k5_tenant
        )
        self.logger.info(f'End execute"/API/v2/api/basiccontract"API(get_k5_response:GET)...params={params_for_get_basic_contract}')
        response_json = response.json()
        self.logger.info(f'Response status_code={response.status_code}')
        self.logger.info(f'Response body ={response_json}')

        if response.status_code == 200:
            self.logger.info(f'The basic contract has already registered : {contract.get("subscription_id")}')
            return True
        elif response.status_code == 404:
            self.logger.info(f'The basic contract has not registered : {contract.get("subscription_id")}')
            return False
        else:
            self.logger.error(f'The basic contract synchronization failed : {contract.get("subscription_id")}')
            self.logger.info(f'Failed status_code {response.status_code}')
            self.logger.info(f'Failed message {response.content}')
            self.logger.info(f'Failed parameters {params_for_get_basic_contract}')
            self.logger.info(f'Failed URL {self.k5_api_endpoint + self.k5_basic_contract_url}')
            return False

    def __register_base_contract(self, contract: dict, k5_tenant: dict, eldest_basic_service_product: dict):
        """
        基本契約の登録
        :param contract: Cebisの契約情報
        :param k5_tenant: k5_tenant
        :return: sync_result
        """

        # 基本契約作成時に指定するリクエストボディ
        request_body = {
            'entry_id': self.entry_id,
            'administration_number': self.administration_number,
            'customer_id': self.k5_customer_id,
            'classification_of_contract': self.classification_of_contract,
            'apply_start_date': self.__convert_iso_timestamp_to_jst_date(
                eldest_basic_service_product.get('service_start_time')).strftime('%Y%m%dT%H%M%SZ')[0:8],
            'free_item1': contract.get('subscription_id'),
            # apply_end_dateは未指定とする
            # 基本契約には契約終了日は設定しない。
            'apply_end_date': None
            # "group_id": "12345678"

        }

        self.logger.info(f'Start execute"/API/v2/api/basiccontract"API(get_k5_response:POST)...data={request_body}')
        bc_register_response = ServerUtil(self).get_k5_response(
            url=self.k5_api_endpoint + self.k5_basic_contract_url,
            params={},
            method='POST',
            allow_token_time_out_minutes=1,
            data=json.dumps(request_body),
            k5_tenant=k5_tenant
        )
        self.logger.info(f'End execute"/API/v2/api/basiccontract"API(get_k5_response:POST)...data={request_body}')
        response_json = bc_register_response.json()
        self.logger.info(f'Response status_code={bc_register_response.status_code}')
        self.logger.info(f'Response body ={response_json}')
        if bc_register_response.status_code == 200 and \
                bc_register_response.json()['result_information']['result'] == 'OK':
            self.logger.info(f'The basic contract registration succeeds : {contract.get("subscription_id")}')
        else:
            self.logger.error(f'The basic contract registration fails : {contract.get("subscription_id")}')
            self.logger.error(f'basic contract sync failed ...'
                          f'content is {bc_register_response.json()["result_information"]}')
            self.logger.error(f'basic contract sync failed ...'
                              f'request_body is {request_body}')
            self.logger.info(f'Failed status_code {bc_register_response.status_code}')
            self.logger.info(f'Failed URL {self.k5_api_endpoint + self.k5_basic_contract_url}')

        return bc_register_response

    def __sync_service_contract(self, contract: dict, k5_tenant: dict, basic_contract_list_from_k5: list):

        for product in contract.get('products'):
            # service price plan情報を検索する。
            service_price_plan_key = k5_tenant.get('client_id').strip() + "_" + \
                                     product.get('product_code').strip() + "_" + \
                                     contract.get('opco_code').strip()

            # サービス料金表を取得すると照合しサービス料金表が見つからない場合は、エラーログを出力する
            service_price_plan = self.service_price_plan_code_table.get(service_price_plan_key)
            if service_price_plan is None:
                self.logger.error(f'Failed to get service price plan by the following key : {service_price_plan_key}  ...')
                continue

            self.__service_contract_register_and_edit(
                contract=contract,
                product=product,
                service_price_plan=service_price_plan,
                k5_tenant=k5_tenant,
                basic_contract_list_from_k5=basic_contract_list_from_k5)

    def __service_contract_register_and_edit(self, contract: dict, product: dict, service_price_plan: dict,
                                           k5_tenant: dict, basic_contract_list_from_k5: list):
        service_contract_params = {
            'free_item1': contract.get('subscription_id'),
            'free_item4': product.get('product_code'),
        }

        self.logger.info(f'Start execute"/API/v2/api/servicecontracts"API(get_k5_response:GET)...params={service_contract_params}')
        # サービス契約を検索APIをコールし、k5で本契约が存在するかどうかを検索する。
        response_for_service_contract = ServerUtil(self).get_k5_response(
            url=self.k5_api_endpoint + self.k5_service_contract_url,
            params=service_contract_params,
            method='GET',
            allow_token_time_out_minutes=1,
            data={},
            k5_tenant=k5_tenant
        )
        self.logger.info(f'End execute"/API/v2/api/servicecontracts"API(get_k5_response:GET)...params={service_contract_params}')
        response_json = response_for_service_contract.json()
        self.logger.info(f'Response status_code={response_for_service_contract.status_code}')
        self.logger.info(f'Response body ={response_json}')

        customer_appoint_service_contract_information_list = \
            response_for_service_contract.json().get('customer_appoint_service_contract_information_list')

        # 404の場合は新規作成
        if response_for_service_contract.status_code == 404:
            self.logger.info(f'Trying to create service contract : ' + \
                f'subscription_id = {contract.get("subscription_id")}  ' + \
                f'product_code = {product.get("product_code")} ...')
        elif response_for_service_contract.status_code == 200:
            if self.__service_contract_changes(customer_appoint_service_contract_information_list,product):
                self.logger.info(f'Trying to edit service contract : ' + \
                    f'subscription_id = {contract.get("subscription_id")}  ' + \
                    f'product_code = {product.get("product_code")} ...')
            else:
                self.logger.info(f'No changes service contract : ' +
                     f'subscription_id = {contract.get("subscription_id")}  ' + \
                    f'product_code = {product.get("product_code")} ...')
                return
        else:
            self.logger.error(f'Unknown service contract state : ' + \
                f'subscription_id = {contract.get("subscription_id")}  ' + \
                f'product_code = {product.get("product_code")} ...')
            self.logger.info(f'Failed URL {self.k5_api_endpoint + self.k5_service_contract_url}')
            self.logger.info(f'Failed status_code {response_for_service_contract.status_code}')
            return
        if customer_appoint_service_contract_information_list is not None:
            service_contract_param = self.__build_service_contract_request_body(
                contract=contract,
                basic_contract_from_k5=basic_contract_list_from_k5[0],
                service_price_plan=service_price_plan,
                product=product,
                customer_appoint_service_contract_information=customer_appoint_service_contract_information_list[0]
            )
        else:
            service_contract_param = self.__build_service_contract_request_body(
                contract=contract,
                basic_contract_from_k5=basic_contract_list_from_k5[0],
                service_price_plan=service_price_plan,
                product=product,
                customer_appoint_service_contract_information=customer_appoint_service_contract_information_list
            )

        self.__register_service_contract(service_contract_param, product, k5_tenant)

    def __service_contract_changes(self,customer_appoint_service_contract_information_list,product):
        # 新規や更新を検証する
          if customer_appoint_service_contract_information_list[0].get('free_item5') \
                    != product.get('license_quantity') \
                    or customer_appoint_service_contract_information_list[0].get('service_end_application_date') \
                    != product.get('service_cancel_time')[0: 8]:
                    return True
          else:
              return False

    def __build_service_contract_request_body(self, contract: dict, basic_contract_from_k5: dict, service_price_plan: dict,
                                      product: dict, customer_appoint_service_contract_information: dict):
        # リクエストボディの初期値
        request_body = {
            'entry_id': self.entry_id, # entry_id
            'customer_id': self.k5_customer_id, # 固定
            'administration_number': self.administration_number #固定
        }

        end_ymd = None
        if product.get('service_cancel_time') != None:
            service_cancel_time_jst = self.__convert_iso_timestamp_to_jst_date(product.get('service_cancel_time'))
            end_ymd = service_cancel_time_jst.strftime('%Y%m%d')

        if customer_appoint_service_contract_information is not None:
            version_info = customer_appoint_service_contract_information.get('version_info')
            service_contract_id = customer_appoint_service_contract_information.get('service_contract_id')
            # #122436(契約情報同期のサービス契約の編集処理でapply_start_dateの設定値が不正)
            number_of_contracts = customer_appoint_service_contract_information.get('number_of_contracts')
            start_ymd = customer_appoint_service_contract_information.get('apply_start_date')
        else:
            version_info = None
            service_contract_id = None
            # #122436(契約情報同期のサービス契約の編集処理でapply_start_dateの設定値が不正)
            number_of_contracts = '1'
            # 年月日の補正処理
            service_start_time_jst = self.__convert_iso_timestamp_to_jst_date(product.get('service_start_time'))
            start_ymd = service_start_time_jst.strftime('%Y%m%d')

        # サービス契約情報
        service_contract_edition = {
            'version_info': version_info,
            'service_contract_id':service_contract_id,
            'service_code': service_price_plan.get('service_code'),
            'number_of_contracts': number_of_contracts,
            'service_application_date': start_ymd,
            'service_end_application_date': end_ymd,
            'apply_start_date': start_ymd,
            'apply_end_date': end_ymd,
            'charging_start_date': start_ymd,
            'charging_end_date': end_ymd,
            'price_plan_code': service_price_plan.get('price_plan_code'),
            'bill_to_id': basic_contract_from_k5.get('bill_to_id'),
            'free_item1': contract.get('subscription_id'),
            'free_item2': product.get('product_type'),
            'free_item3': contract.get('opco_code'),
            'free_item4': product.get('product_code'),
            'free_item5': product.get('license_quantity')
        }

        # null要素があるとK5の「サービス契約を編集する」で500エラー(setInterfaceDataFromBody_ERROR)が発生する
        # そのため、null値の要素を削除する

        service_contract_edition = {k: v for k, v in service_contract_edition.items() if v is not None}

        # リクエストボディ
        request_body['individualized_service_contract_edition_list'] = [service_contract_edition]

        return request_body

    def __register_service_contract(self, contract_data, option_product, k5_tenant):
        """
        サービス契約の登録
        :return: sync_service_result
        """
        self.logger.info(f'Start execute"/API/v2/api/servicecontracts"API(get_k5_response:POST)...data={json.dumps(contract_data)}')

        sc_register_response = ServerUtil(self).get_k5_response(
            url=self.k5_api_endpoint + self.k5_service_contract_url,
            params={},
            method='POST',
            allow_token_time_out_minutes=1,
            data=json.dumps(contract_data),
            k5_tenant=k5_tenant)
        self.logger.info(f'End execute"/API/v2/api/servicecontracts"API(get_k5_response:POST)...data={json.dumps(contract_data)}')
        response_json = sc_register_response.json()
        self.logger.info(f'Response status_code={sc_register_response.status_code}')
        self.logger.info(f'Response body ={response_json}')
        # 成功した場合
        if sc_register_response.status_code == 200 and \
                sc_register_response.json()['result_information']['result'] == 'OK':
            self.logger.info(f"The service contract registration succeeds : {option_product.get('product_code')}")
        # 失敗した場合
        else:
            self.logger.error(f'Service contract sync failed ...'
                          f'content is {sc_register_response.json()["result_information"]}')
            self.logger.error(f"The service contract registration fails : {option_product.get('product_code')}")
            self.logger.error(f"The service contract request_body is : {contract_data}")
            self.logger.info(f'Failed status_code {sc_register_response.status_code}')
            self.logger.info(f'Failed message={sc_register_response.content}')
            self.logger.info(f'Failed URL={self.k5_api_endpoint + self.k5_service_contract_url}')

    @staticmethod
    def validate_register_service_contract(check_mode, customer_appoint_service_contract_information_list: list,
                                        product: dict, service_price_plan: dict, basic_contract_list: list,
                                        eldest_basic_service_product: dict):
        """
        サービス契約を更新する前に確認する
        仕様は記載されていません
        参照されたJavaコード
        :return: bool
        """
        # 商品の service_start_time
        service_start_time = product.get('service_start_time')[0:8]

        # 編集のみ
        if check_mode == 'edit':
            for customer_appoint_service_contract_information in customer_appoint_service_contract_information_list:
                # 適用中のサービス(サービス契約で適用開始日が入っているもの)
                if customer_appoint_service_contract_information.get('apply_start_date') is not None:
                    # ignore 編集時、適用開始日がすでに入っている場合はチェックしない、
                    # service_start_timeはK5既存の開始日に置き換える
                    service_start_time = customer_appoint_service_contract_information.get('apply_start_date')[0:8]
                else:
                    # 適用前に適用終了年月日を設定できません
                    if product.get('service_cancel_time') is not None:
                        return False
        # 登録のみ
        else:
            # 業務日付( UTC)
            system_ym = datetime.utcnow().replace(tzinfo=pytz.UTC).strftime('%Y%m')
            service_start_ym = product.get('service_start_time')[0:6]
            # 適用開始年月が、業務日付と比較して過去年月とならないこと
            if system_ym < service_start_ym:
                return False

        # 共通
        # サービスマスタが適用開始年月日の期間で有効でない
        if (service_start_time < service_price_plan.get('apply_start_date')) \
                or (service_price_plan.get('apply_end_date') is not None
                    and service_start_time > service_price_plan.get('apply_end_date')):
            return False

        # 料金プランマスタが適用開始年月日の期間で有効でない
        if service_price_plan.get('price_plan_list'):
            for price_plan in service_price_plan.get('price_plan_list'):
                if service_start_time < price_plan.get('apply_start_date') \
                        or (price_plan.get('apply_end_date')
                            and service_start_time > price_plan.get('apply_end_date')):
                    return False

        if basic_contract_list:
            for basic_contract in basic_contract_list:
                # 基本契約が適用開始年月日の期間で有効でない"
                if service_start_time < basic_contract.get('apply_start_date') \
                        or (basic_contract.get('apply_end_date') is not None
                            and service_start_time > basic_contract.get('apply_end_date')):
                    return False

        else:
            # 基本契約が適用開始年月日の期間で有効でない
            if service_start_time < eldest_basic_service_product.get('service_start_time'):
                return False
        return True

    @staticmethod
    def __convert_iso_timestamp_to_jst_date(iso_timestamp):
        """
        ISOタイムスタンプを日本時間に変換する
        :return datetime: 日本時間
        """
        iso_date = iso_timestamp[0: 8]
        iso_time = iso_timestamp[9:15]
        return datetime(int(iso_date[0:4]), int(iso_date[4:6]), int(iso_date[6:8]), int(iso_time[0:2]),
                        int(iso_time[2:4]), int(iso_time[4:6])).replace(tzinfo=pytz.UTC).astimezone(pytz.timezone('Asia/Tokyo'))
