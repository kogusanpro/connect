"""
<copyright file="coohub_sync_usage_data_zuora.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2019-2020. All rights reserved.
</copyright>
"""
import copy
import csv
import hashlib
import os
import sys
import time
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, List, Optional, Set, Tuple

import boto3
import dateutil.parser
import dateutil.relativedelta
import pytz
import requests
from batch.management.batch_command_base import BatchCommandBase
from batch.services import get_tmp_dir
from django.core.management.base import CommandError
from lib.const.coohub_zuora_tenant import ZUORA_TENANT
from lib.const.opco_code import OPCO_TIMEZONE
from lib.shortcuts import get_object_or_None
from lib.utils import ServerUtil, check_date_ymd_format, check_datetime_format
from subscriptions.models import ContractInfo, ContractServiceInfo


class Command(BatchCommandBase):
    help = 'This Command Synchronize Usage Data to Zuora'

    # Cebisの従量データCSVファイル作成確認リトライ回数
    CEBIS_CSV_CREATION_CHECK_RETRY_TIME = 30

    # Cebisの従量データCSVファイル作成確認リトライ間隔（秒）
    CEBIS_CSV_CREATION_WAIT_INTERVAL = 60

    # Cebisの従量データCSVファイルダウンロードリトライ回数
    CEBIS_USAGE_FILE_READ_RETRY_TIME = 3

    # Cebisの従量データCSVファイルダウンロードリトライ間隔（秒）
    CEBIS_USAGE_FILE_READ_WAIT_INTERVAL = 60

    # Zuoraの従量データCSVファイル取り込み確認リトライ回数
    ZUORA_CSV_IMPORT_CHECK_RETRY_TIME = 30

    # Zuoraの従量データCSVファイル取り込み確認リトライ間隔（秒）
    ZUORA_CSV_IMPORT_WAIT_INTERVAL = 60


    def __init__(self) -> None:
        '''コンストラクタ'''
        super().__init__()

        self.batch_name = 'synchronize usage data to Zuora'


    def add_arguments(self, parser) -> None:
        '''バッチオプション引数取得

        Args:
            parser: 引数パーサー
        '''
        # バッチ実行日時（JST）の年月日
        parser.add_argument('--executed_date', type=str, default='')

        # 同期対象データの日時（UTC）
        parser.add_argument('--from_created_datetime', type=str, default='')
        parser.add_argument('--to_created_datetime', type=str, default='')

        # Cebis API関連
        parser.add_argument('--cebis_api_endpoint', type=str, default=os.environ.get('CEBIS_API_ENDPOINT'))  # エンドポイントURL
        parser.add_argument('--cebis_calculation_system_api_key', type=str, default=os.environ.get('CEBIS_CALCULATION_SYSTEM_API_KEY'))  # APIキー
        parser.add_argument('--cebis_usage_download_url', type=str, default=os.environ.get('CEBIS_USAGE_DOWNLOAD_URL'))  # 従量データ一括取得用URL取得URL
        parser.add_argument('--cebis_check_usage_csv_creation_url', type=str, default=os.environ.get('CEBIS_CHECK_USAGE_CSV_CREATION_URL'))  # 一括処理ステータス確認URL

        # Zuora API関連
        parser.add_argument('--zuora_api_endpoint', type=str, default=os.environ.get('ZUORA_API_ENDPOINT'))  # エンドポイントURL
        parser.add_argument('--zuora_usage_url', type=str, default=os.environ.get('ZUORA_USAGE_URL'))  # 従量データ登録用URL

        # AWS関連
        parser.add_argument('--s3_for_zuora_usage_csv_bucket', type=str, default=os.environ.get('S3_FOR_ZUORA_USAGE_CSV_BUCKET'))  # CSVアップロード先S3バケット


    def do_validate(self, *args, **options):
        '''引数のバリデーション処理

        Args:
            args (Tuple[Any]): 引数（未使用）
            options (Dict[str, Any]): キーワード引数

        Raises:
            CommandError: バリデーションエラー
        '''
        # [executed_date]のフォーマットチェック
        if options['executed_date'] and not check_date_ymd_format(datetime=options['executed_date']):
            raise CommandError('executed_date was invalid format in this batch parameter')

        if options['from_created_datetime'] and options['to_created_datetime']:
            # [from_created_datetime]のフォーマットチェック
            if not check_datetime_format(datetime=options['from_created_datetime']):
                raise CommandError('from_created_datetime was invalid format in this batch parameter')

            # [to_created_datetime]のフォーマットチェック
            if not check_datetime_format(datetime=options['to_created_datetime']):
                raise CommandError('to_created_datetime was invalid format in this batch parameter')

            # [from_created_datetime] > [to_created_datetime] のチェック
            if options['from_created_datetime'] > options['to_created_datetime']:
                raise CommandError('from_created_datetime was greater than to_created_datetime in this batch parameter')

        elif (options['from_created_datetime'] and not options['to_created_datetime']) \
                or (not options['from_created_datetime'] and options['to_created_datetime']):
            # [from_created_datetime]か[to_created_datetime]のどちらかが存在しない
            raise CommandError('from_created_datetime and to_created_datetime are specified as a pair')


    def __validate_usage_data(self, usage_csv_data: Dict[str, str]) -> bool:
        '''Cebisから取得した従量CSVデータのバリデーションを行う

        バリデーション内容については機能仕様書を参照。

        Args:
            usage_csv_data (Dict[str, str]): Cebisから取得した従量CSVデータ

        Returns:
            bool: バリデーションOKであればTrue、NGであればFalse
        '''
        # サブスクリプションID
        subscription_id = usage_csv_data['subscription_id']

        # 商品コード
        product_code = usage_csv_data['product_code']

        # 従量データの[対象月度]の取得
        target_month = usage_csv_data['target_month']

        # 仕向け地タイムゾーン
        opco_code = usage_csv_data['opco_code']
        local_tz = pytz.timezone(OPCO_TIMEZONE.get(opco_code))

        # 従量データの[利用終了日]の取得
        end_date_time = usage_csv_data['end_date_time']
        end_date_time_utc = dateutil.parser.parse(end_date_time).astimezone(pytz.UTC)  # UTC
        end_date_time_local = dateutil.parser.parse(end_date_time).astimezone(local_tz)  # ローカル時間

        # 契約サービス情報の取得
        # TODO: ※[契約情報単体取得]APIはCebisから実行できないため、DBから直接契約サービス情報を取得している（今後の課題）
        contract_service_info: Optional[ContractServiceInfo] = get_object_or_None(
            ContractServiceInfo,
            subscription_id=subscription_id,
            product_code=product_code,
        )
        if contract_service_info is None:
            self.logger.error(f'subscription_id = [{subscription_id}] and product_code = [{product_code}] record not found in contract_service_info table ...')
            return False

        # [サービス開始手配完了日時]、[サービス解約手配完了日時]の取得
        service_start_time_utc = contract_service_info.service_start_time.astimezone(pytz.UTC)
        service_cancel_time_utc: Optional[datetime] = None
        if contract_service_info.service_cancel_time:
            service_cancel_time_utc = contract_service_info.service_cancel_time.astimezone(pytz.UTC)

        # バリデーションOKかどうか
        is_valid = True

        # 利用終了日時（ローカル時間）と対象月度の年月が一致しているかどうか
        end_date_time_local_yyyymm = end_date_time_local.strftime('%Y%m')
        if target_month != end_date_time_local_yyyymm:
            self.logger.error('Validation error ...')
            self.logger.info(f'subscription_id = [{subscription_id}] does not match "end_date_time" and "target_month"')
            self.logger.info(f'    end_date_time = {end_date_time_local_yyyymm}')
            self.logger.info(f'    target_month = {target_month}')
            is_valid = False

        # 「利用終了日時 > サービス開始手配完了日時」かどうか
        if end_date_time_utc <= service_start_time_utc:
            self.logger.error('Validation error ...')
            self.logger.info(f'subscription_id = [{subscription_id}] was "end_date_time" < "service_start_time"')
            self.logger.info(f'    end_date_time = {end_date_time_utc}')
            self.logger.info(f'    service_start_time = {service_start_time_utc}')
            is_valid = False

        # サービス解約手配完了日時が設定されていた場合、「利用終了日 <= サービス解約手配完了日時」かどうか
        if service_cancel_time_utc:
            if end_date_time_utc > service_cancel_time_utc:
                self.logger.error('Validation error ...')
                self.logger.info(f'subscription_id = [{subscription_id}] was "end_date_time" > "service_cancel_time"')
                self.logger.info(f'    end_date_time = {end_date_time_utc}')
                self.logger.info(f'    service_cancel_time = {service_cancel_time_utc}')
                is_valid = False

        return is_valid


    def main_process(self, *args: Any, **options: Any) -> None:
        '''Cebisから従量データ一覧を取得し、Zuoraへ従量CSVファイルを連携する

        Args:
            args (Any): 引数（未使用）
            options (Any): キーワード引数
        '''
        # バッチ実行日時（JST）の年月日
        executed_datetime = datetime.utcnow().astimezone(pytz.timezone('Asia/Tokyo'))
        executed_date = options.get('executed_date')
        if len(executed_date) > 0:
            # 本バッチのオプション引数で指定した場合はその日付で上書き
            executed_datetime = pytz.timezone('Asia/Tokyo').localize(
                datetime(
                    year=int(executed_date[0:4]),
                    month=int(executed_date[4:6]),
                    day=int(executed_date[6:8]),
                    hour=4,
                )
            )
        self.logger.info(f'executed_datetime is {executed_datetime.strftime("%Y-%m-%d %H:%M:%S")} (JST)...')

        # 同期対象データ（開始日）
        from_created_datetime: str = options.get('from_created_datetime')
        if len(from_created_datetime) == 0:
            # 本バッチのオプション引数で指定していない場合（バッチ実行前日の19時（UTC））
            from_created_datetime = (executed_datetime - timedelta(days=1)).astimezone(pytz.UTC).replace(hour=19, minute=0, second=0).strftime('%Y%m%dT%H%M%SZ')
        self.logger.info(f'from_created_datetime is {from_created_datetime}')

        # 同期対象データ（終了日）
        to_created_datetime: str = options.get('to_created_datetime')
        if len(to_created_datetime) == 0:
            # 本バッチのオプション引数で指定していない場合（バッチ実行当日の19時（UTC））
            to_created_datetime = executed_datetime.astimezone(pytz.UTC).replace(hour=19, minute=0, second=0).strftime('%Y%m%dT%H%M%SZ')
        self.logger.info(f'to_created_datetime is {to_created_datetime}')

        server_util = ServerUtil(self, zuora_tenant=ZUORA_TENANT)

        # Cebisの[従量データ一括取得用URL取得]APIを実行し、同期対象従量CSVファイルの作成依頼を行う
        api_url: str = options.get('cebis_api_endpoint') + options.get('cebis_usage_download_url')
        api_key: str = options.get('cebis_calculation_system_api_key')
        api_params = {
            'from_created_datetime': from_created_datetime,
            'to_created_datetime': to_created_datetime,
            'internal_calc': 'false',  # Zuoraの場合は必ず「false」を指定する
            'include_trial_data': 'false',
        }
        usage_csv_response: requests.Response = server_util.get_cebis_response(
            url=api_url,
            method='GET',
            params=api_params,
            api_key=api_key,
            data=dict(),
        )
        usage_csv_response_json: Dict[str, Any] = usage_csv_response.json()
        self.logger.info(f'Response status_code={usage_csv_response.status_code}')
        self.logger.info(f'Response body={usage_csv_response_json}')
        if usage_csv_response.status_code != 200:
            self.logger.fatal('Failed to get usage data from usageDownloadUrl API ...')
            self.logger.info(f'Failed URL = {api_url}')
            sys.exit(0)

        # Cebisの[一括処理ステータス確認]APIを実行しCSV作成状況を確認する
        request_id: str = usage_csv_response_json.get('request_id')  # リクエストID
        api_url: str = options.get('cebis_api_endpoint') + options.get('cebis_check_usage_csv_creation_url') + request_id
        check_usage_csv_creation_response = None
        for cnt in range(Command.CEBIS_CSV_CREATION_CHECK_RETRY_TIME):
            if cnt >= Command.CEBIS_CSV_CREATION_CHECK_RETRY_TIME:
                # 所定確認回数までにCSV作成が完了しなかった
                self.logger.fatal('Usage csv creation process on cebis exceeds timeout ...')
                sys.exit(0)

            # 一定時間待機
            time.sleep(Command.CEBIS_CSV_CREATION_WAIT_INTERVAL)

            # CSV作成状況確認
            check_usage_csv_creation_response: requests.Response = server_util.get_cebis_response(
                url=api_url,
                params=dict(),
                method='GET',
                api_key=api_key,
                data=dict(),
            )
            check_usage_csv_creation_response_json: Dict[str, Any] = check_usage_csv_creation_response.json()
            self.logger.info(f'Response status_code = {check_usage_csv_creation_response.status_code}')
            self.logger.info(f'Response body = {check_usage_csv_creation_response_json}')
            if check_usage_csv_creation_response.status_code != 200:
                self.logger.warn('Failed to get the usage csv creation status, try again ...')
                self.logger.info(f'Failed URL = {api_url}')
                continue

            # CSV作成ステータス確認
            process_result: str = check_usage_csv_creation_response_json.get('process_result')
            if process_result == 'Success':
                # CSV作成完了
                self.logger.info(f'Success URL = {api_url}')
                break
            elif process_result in ['NotProcessed', 'Processing']:
                # CSV作成未処理または作成中
                self.logger.info(f'Usage csv file creation on cebis is "{process_result}", try again ...')
                self.logger.info(f'request_id is {request_id}')
                continue
            else:
                # 上記以外のステータス
                self.logger.warn(f'Usage csv file creation on cebis is "{process_result}", try again ...')
                self.logger.info(f'request_id is {request_id}')
                continue

        # 従量データCSVファイルをダウンロードしハッシュ値チェック
        self.logger.info('Start download usage csv data from cebis url ...')
        download_csv_path = os.path.join(get_tmp_dir(), executed_datetime.strftime('%Y%m%d%H%M%S%f_') + 'zuora_download.csv')
        csv_file_url: str = usage_csv_response_json.get('presigned_url')
        try:
            for cnt in range(Command.CEBIS_USAGE_FILE_READ_RETRY_TIME):
                # CSVファイルダウンロード
                csv_file_download_response = requests.get(csv_file_url)
                if csv_file_download_response.status_code == 200:
                    # ダウンロード成功
                    self.logger.info('Success getting usage csv data from cebis url...')

                    # ファイルに書き込み
                    with open(download_csv_path, 'wb') as download_csv_file:
                        download_csv_file.write(csv_file_download_response.content)
                elif cnt < Command.CEBIS_USAGE_FILE_READ_RETRY_TIME:
                    # ダウンロード失敗なので一定時間スリープして再度トライ
                    self.logger.warn('Failed to get the Usage CSV File, try again...')
                    time.sleep(Command.CEBIS_USAGE_FILE_READ_WAIT_INTERVAL)
                    continue
                else:
                    # CSVファイルダウンロード回数上限に達しても成功しない場合は終了
                    raise Exception('Failed to get the Usage CSV File')

                # ダウンロードしたCSVファイルのMD5を求める
                with open(download_csv_path, 'r') as download_csv_file:
                    calculated_md5 = hashlib.md5(download_csv_file.read().encode()).hexdigest()

                # 事前に取得したMD5とダウンロードしたCSVファイルのMD5を比較
                csv_md5: str = check_usage_csv_creation_response.headers.get('content-md5-cebis')
                if calculated_md5 == csv_md5:
                    # MD5値が一致
                    self.logger.info('Usage CSV file successfully downloaded...')
                    break
                elif cnt < Command.CEBIS_USAGE_FILE_READ_RETRY_TIME:
                    # MD5値が一致しなかったので再度トライ
                    self.logger.warn('Usage CSV file hash values are inconsistent, read again...')
                    continue
                else:
                    # MD5値が一致せず確認回数の上限に達したため終了
                    raise Exception('Usage CSV file hash values are inconsistent, reached max count ...')

            self.logger.info('Completed to get the Usage CSV File')

            # CSVファイルの中身の従量データ情報を読み込む
            usage_csv_data_list: List[Dict[str, str]] = list()
            with open(download_csv_path, 'r') as download_csv_file:
                csv_reader = csv.DictReader(
                    download_csv_file,
                    delimiter=',',
                    doublequote=True,
                    lineterminator='\n',
                    quotechar='"',
                )
                usage_csv_data_list = [dict(d) for d in csv_reader]
        except Exception as e:
            self.logger.error(e)
            self.logger.info('System exit ...')
            sys.exit(0)
        finally:
            # ローカルからZuora用従量CSVファイルを削除
            try:
                if os.path.exists(download_csv_path):
                    os.remove(download_csv_path)
            except OSError as e:
                self.logger.error('Failed to delete CSV file from local ...')
                self.logger.info(f'CSV file path = [{download_csv_path}] ...')
                self.logger.info(f'Error = [{e}] ...')

        # CSVファイルのデータが0件の場合はバッチ終了
        if len(usage_csv_data_list) == 0:
            self.logger.info('No record in downloaded csv file ...')
            sys.exit(0)

        # Zuora対象のみのサブスクリプションIDおよび従量データを抽出
        self.logger.info('Start filtering for Zuora contract data ...')
        zuora_only_usage_data_list: List[Dict[str, str]] = list()  # Zuora対象の従量データを格納
        zuora_only_subscription_id_set: Set[str] = set()  # Zuora対象のサブスクリプションID（末尾文字の'G'を除外したもの）を格納
        for usage_data in usage_csv_data_list:
            # サブスクリプションID
            subscription_id: str = usage_data['subscription_id']

            # 対象サブスクリプションIDの契約情報の取得
            # TODO: ※Cebisから[契約情報単体取得]APIは実行できないので、DBから直接契約情報を取得している（今後の課題）
            contract_info: Optional[ContractInfo] = get_object_or_None(ContractInfo, pk=subscription_id)
            if contract_info is None:
                self.logger.error(f'subscription_id = [{subscription_id}] record not found in contract_info table ...')
                continue

            # Zuora対象かどうか判定
            if contract_info.is_zuora():
                # 後のバリデーション処理で利用するため、「仕向け地」の情報を追加する
                opco_code: str = contract_info.opco_code
                usage_data['opco_code'] = opco_code

                # 仕向け地のタイムゾーンが正しく取得できるかチェック
                try:
                    pytz.timezone(OPCO_TIMEZONE.get(opco_code))
                except:
                    self.logger.error(f'Unknown timezone in opco_code = [{opco_code}] and timezone = [{OPCO_TIMEZONE.get(opco_code)}] ...')
                    continue

                zuora_only_usage_data_list.append(usage_data)
                zuora_only_subscription_id_set.add(subscription_id)

        # Zuora対象データが0件の場合は終了
        if len(zuora_only_usage_data_list) == 0:
            self.logger.info('Usage data synchronization Zuora data empty ...')
            sys.exit(0)

        # Zuora対象データの商品コードを重複なしで取得
        zuora_only_product_code_set: Set[str] = {
            data['product_code'] for data in zuora_only_usage_data_list
        }

        # 従量CSVデータのバリデーション
        self.logger.info('Start validating Zuora usage data ...')
        validated_usage_data_list: List[Dict[str, str]] = list()
        for usage_data in zuora_only_usage_data_list:
            is_validate = self.__validate_usage_data(usage_data)
            if is_validate:
                # バリデートOK
                validated_usage_data_list.append(usage_data)

        # バッチ実行前日年月（JST）
        executed_prev_date_datetime = executed_datetime - timedelta(days=1)
        executed_prev_date_month = executed_prev_date_datetime.strftime('%Y%m')

        # バッチ実行前日の前月度年月（JST）
        executed_prev_date_month_datetime = executed_prev_date_datetime - dateutil.relativedelta.relativedelta(months=1)
        executed_prev_date_last_month = executed_prev_date_month_datetime.strftime('%Y%m')

        # フィルタリング
        self.logger.info('Start filtering Zuora usage data ...')
        zuora_only_usage_data_list = copy.deepcopy(validated_usage_data_list)
        validated_usage_data_list: List[Dict[str, str]] = list()
        for usage_data in zuora_only_usage_data_list:
            # サブスクリプションID
            subscription_id = usage_data['subscription_id']

            # 従量データの[対象月度]の取得
            target_month = usage_data['target_month']

            # バリデーションOKかどうか
            is_validate = True

            # 対象月度がバッチ実行日前日の年月 もしくは バッチ実行日前日の前月年月と一致する
            if target_month != executed_prev_date_month and target_month != executed_prev_date_last_month:
                self.logger.error('Validation error ...')
                self.logger.info(f'Subscription_id = [{subscription_id}] did not match target_month and (executed_date - 1) month ...')
                self.logger.info(f'    or target_month and month before (executed_date - 1) ...')
                self.logger.info(f'    target_month = {target_month} ...')
                is_validate = False

            if is_validate:
                # バリデートOK
                validated_usage_data_list.append(usage_data)

        # データバリデーション＆フィルタリング後のZuora対象データが0件の場合は終了
        if len(validated_usage_data_list) == 0:
            self.logger.info('Usage data after validation and filtering is empty ...')
            sys.exit(0)

        # Zuoraに従量データを登録するために必要な情報をデータクエリを利用してZuoraから取得する
        self.logger.info('Start getting information from Zuora ...')
        target_subscription_ids = ', '.join([f"'{id}'" for id in zuora_only_subscription_id_set])
        target_product_codes = ', '.join([f"'{code}'" for code in zuora_only_product_code_set])
        query = f'''
            SELECT DISTINCT
              rpc.kakinsubscriptionid__c AS subscription_id,  -- サブスクリプションID
              prpc.productcode__c AS product_code,  -- 商品コード
              acc.accountnumber AS account_number,  -- Zuoraアカウントナンバー（ACCOUNT_ID）
              sub.name AS subscription_number,  -- Zuoraサブスクリプション番号（SUBSCRIPTION_ID）
              rpc.chargenumber AS charge_number,  -- Zuoraチャージ番号（CHARGE_ID）
              prpc.uom AS uom  -- Zuora従量単位（UOM）
            FROM
              rateplancharge rpc
              JOIN productrateplancharge prpc ON prpc.id = rpc.productrateplanchargeid
              JOIN rateplan rp ON rp.id = rpc.rateplanid
              JOIN subscription sub ON sub.id = rp.subscriptionid
              JOIN account acc ON acc.id = sub.accountid
            WHERE
              rpc.kakinsubscriptionid__c IN({target_subscription_ids})
              AND prpc.productcode__c IN({target_product_codes})
        '''
        query_result = server_util.get_zuora_data_query_result(query, use_index_join=True)
        if query_result is None:
            self.logger.fatal(f'An error occurred while executing Zuora data query [{query}] ...')
            self.logger.info('System exit ...')
            sys.exit(0)
        elif len(query_result) == 0:
            self.logger.fatal('No subscription data fetched from Zuora ...')
            self.logger.info('System exit ...')
            sys.exit(0)

        # Zuoraの商品情報マップの作成
        #   キー: CebisのサブスクリプションID、商品コード
        #   バリュー: Zuoraのアカウントナンバー、サブスクリプション番号、チャージ番号、従量単位
        self.logger.info('Start creating Zuora product information map ...')
        zuora_product_info_map: Dict[Tuple(str, str), Tuple(str, str, str, str)] = {}
        for result in query_result:
            # サブスクリプションID
            subscription_id: str = result['subscription_id']

            # 商品コード
            product_code: str = result['product_code']

            # Zuoraアカウントナンバー（ACCOUNT_ID）
            account_number: str = result['account_number']

            # Zuoraサブスクリプション番号（SUBSCRIPTION_ID）
            subscription_number: str = result['subscription_number']

            # Zuoraチャージ番号（CHARGE_ID）
            charge_number: str = result['charge_number']

            # Zuora従量単位（UOM）
            uom: Optional[str] = result['uom']
            if not uom:
                # UOMの値が取得できない場合はスキップ
                self.logger.error(f'No UOM in Zuora. product_code = [{product_code}] ...')
                self.logger.info('Skip to next subscription data ...')
                continue

            key = (subscription_id, product_code)
            zuora_product_info_map[key] = (account_number, subscription_number, charge_number, uom)

        # ①サブスクリプションID、②商品コード、③対象月度、④利用開始日時の年月日
        # の単位で利用量を集計する
        self.logger.info('Start aggregating usage data ...')
        agg_usage_data: Dict[Tuple[str, str, str, str], Decimal] = {}
        for usage_data in validated_usage_data_list:
            # サブスクリプションID
            subscription_id = usage_data['subscription_id']

            # 商品コード
            product_code = usage_data['product_code']

            # 対象月度
            target_month = usage_data['target_month']

            # 仕向け地のタイムゾーン
            opco_code = usage_data['opco_code']
            local_tz = pytz.timezone(OPCO_TIMEZONE.get(opco_code))

            # 利用開始日（ローカル時間）
            start_date_time = usage_data['start_date_time']
            start_date = dateutil.parser.parse(start_date_time).astimezone(local_tz).strftime('%Y-%m-%d')

            # 利用終了日（ローカル時間）
            # ※利用終了日は現在利用しないため、以下の利用終了日取得処理はコメントアウト
            # end_date_time = usage_data['end_date_time']
            # end_date = dateutil.parser.parse(end_date_time).astimezone(local_tz).strftime('%Y-%m-%d')

            # 利用量
            try:
                quantity = Decimal(usage_data['quantity'])
            except InvalidOperation:
                # 数値変換エラー
                self.logger.error('Quantity value is not a number ...')
                self.logger.info(f'  subscription_id = [{subscription_id}] ...')
                self.logger.info(f'  product_code = [{product_code}] ...')
                self.logger.info(f'  target_month = [{target_month}] ...')
                self.logger.info(f"  quantity = [{usage_data['quantity']}] ...")
                continue

            # 利用量が負の値の場合は無視する
            if quantity < 0:
                self.logger.error('Quantity value is negative value ...')
                self.logger.info(f'  subscription_id = [{subscription_id}] ...')
                self.logger.info(f'  product_code = [{product_code}] ...')
                self.logger.info(f'  target_month = [{target_month}] ...')
                self.logger.info(f'  quantity = [{str(quantity)}] ...')
                continue

            # 利用量の集計
            key = (subscription_id, product_code, target_month, start_date)
            if key in agg_usage_data:
                # 同じキーの利用量が複数ある場合は加算
                agg_usage_data[key] += quantity
            else:
                # 利用量の初期値
                agg_usage_data[key] = quantity

        # Zuoraに連携する従量データCSVファイルパス
        zuora_usage_csv_path: str = os.path.join(get_tmp_dir(), f"zuora_usage_{executed_datetime.strftime('%Y%m%d')}.csv")

        # 現在時刻（JST）
        now_jst: datetime = datetime.utcnow().astimezone(pytz.timezone('Asia/Tokyo'))

        try:
            # Zuora用の従量データCSVファイルの作成（文字コードはUTF-8(BOMなし)）
            self.logger.info('Start creating usage data for Zuora ...')
            with open(zuora_usage_csv_path, mode='w', encoding='utf-8') as csv_file:
                # 出力CSVヘッダー
                output_csv_header = [
                    'ACCOUNT_ID',  # Zuoraアカウントナンバー
                    'UOM',  # 従量単位
                    'QTY',  # 従量
                    'STARTDATE',  # 開始日
                    'ENDDATE',  # 終了日
                    'SUBSCRIPTION_ID',  # Zuoraサブスクリプション番号
                    'CHARGE_ID',  # Zuoraチャージ番号
                    'DESCRIPTION',  # 説明
                ]

                # 出力CSVファイル情報
                writer = csv.DictWriter(
                    csv_file,
                    fieldnames=output_csv_header,  # ヘッダー指定
                    lineterminator='\r\n',  # 改行コードはCRLF
                    quoting=csv.QUOTE_NONE,  # 囲い文字はなし
                )

                # ヘッダー行書き込み
                writer.writeheader()

                # データ行書き込み
                for (key, quantity) in agg_usage_data.items():
                    subscription_id, product_code, _, start_date = key
                    if (subscription_id, product_code) not in zuora_product_info_map:
                        # 従量データに対応するのサブスクリプションIDと商品コードのデータがZuora上に存在しない場合はエラー
                        self.logger.error(f'subscription_id = [{subscription_id}] and product_code = [{product_code}] not found in Zuora.')
                        continue

                    # 事前に取得したZuora上のアカウントや商品情報を取得
                    account_number, subscription_number, charge_number, uom = zuora_product_info_map[(subscription_id, product_code)]

                    # STARTDATEは「MM/DD/YYYY」のフォーマット
                    # ※日付フォーマットはZuoraのAPIアカウントのロケール設定に依存する
                    start_date = dateutil.parser.parse(start_date).strftime('%m/%d/%Y')

                    row = {
                        'ACCOUNT_ID': account_number,  # Zuoraアカウントナンバー
                        'UOM': uom,  # 従量単位
                        'QTY': quantity,  # 従量
                        'STARTDATE': start_date,  # 開始日
                        'ENDDATE': start_date,  # 終了日 ※「開始日 > 終了日」という例外的なケースを避けるため、ENDDATEにはSTARTDATEの値を入れる
                        'SUBSCRIPTION_ID': subscription_number,  # Zuoraサブスクリプション番号
                        'CHARGE_ID': charge_number,  # Zuoraチャージ番号
                        'DESCRIPTION': f'executed_datetime = {now_jst.strftime("%Y-%m-%d %H:%M:%S.%f")}(JST)',  # 現在日時（JST）を記載
                    }
                    writer.writerow(row)

            # S3に従量データCSVファイルをアップロード
            s3 = boto3.client('s3')
            bucket_name: str = options.get('s3_for_zuora_usage_csv_bucket')
            executed_date_yyyymmdd = executed_datetime.strftime('%Y%m%d')
            key = f'{executed_date_yyyymmdd[:4]}/{executed_date_yyyymmdd[:6]}/zuora_usage_{executed_date_yyyymmdd}.csv'
            self.logger.info(f'Start uploading usage CSV file: {zuora_usage_csv_path} to s3://{bucket_name}/{key}')
            s3.upload_file(
                Filename=zuora_usage_csv_path,
                Bucket=bucket_name,
                Key=key,
            )
            self.logger.info(f'Complete uploading usage CSV file: {zuora_usage_csv_path} to s3://{bucket_name}/{key}')

            # Zuoraに従量データCSVファイルをアップロード
            self.logger.info('Start uploading usage CSV file to Zuora ...')
            csv_upload_api_url: str = options.get('zuora_api_endpoint') + options.get('zuora_usage_url')
            with open(zuora_usage_csv_path, 'rb') as csv_file:
                headers = {'Content-Type': None}  # Content-Typeはrequests内部で自動的に付与されるためここでは指定しない
                files = {'file': (
                    os.path.basename(zuora_usage_csv_path),
                    csv_file.read(),
                    'text/csv',
                )}
                csv_upload_response = server_util.execute_zuora_api(
                    url=csv_upload_api_url,
                    method='POST',
                    headers=headers,
                    files=files,
                )
            csv_upload_response_json: Dict[str, Any] = csv_upload_response.json()
            self.logger.info(f'Uploading CSV file to Zuora response = [{csv_upload_response_json}]')
            is_success: bool = csv_upload_response_json.get('success')
            if csv_upload_response.status_code != 200 or is_success == False:
                raise Exception('Uploading CSV file to Zuora failed ...')

            # Zuoraの従量データCSVファイル取り込みステータス確認
            check_import_status_url: str = options.get('zuora_api_endpoint') + csv_upload_response_json.get('checkImportStatus')
            for cnt in range(Command.ZUORA_CSV_IMPORT_CHECK_RETRY_TIME):
                if cnt >= Command.ZUORA_CSV_IMPORT_CHECK_RETRY_TIME:
                    # 所定確認回数までにCSVインポートが完了しなかった
                    raise Exception('Usage CSV file import process on Zuora exceeds retry count ...')

                # 一定時間待機
                time.sleep(Command.ZUORA_CSV_IMPORT_WAIT_INTERVAL)

                # 取り込みステータス確認API実行
                csv_check_status_response = server_util.execute_zuora_api(
                    url=check_import_status_url,
                    method='GET',
                )
                csv_check_status_response_json: Dict[str, Any] = csv_check_status_response.json()
                self.logger.info(f'Check import CSV file to Zuora response = [{csv_check_status_response_json}]')
                is_success: bool = csv_check_status_response_json.get('success')
                if csv_check_status_response.status_code != 200 or is_success == False:
                    self.logger.error('Check import CSV file to Zuora failed, try again ...')
                    continue

                # 取り込みステータス確認
                import_status: str = csv_check_status_response_json.get('importStatus')
                if import_status == 'Completed':
                    # 取り込み正常完了
                    self.logger.info('Import CSV file to Zuora Completed ...')
                    break
                elif import_status in ['Pending', 'Processing']:
                    # 取り込み待ち、取り込み中
                    self.logger.info(f'Import CSV file status = [{import_status}], try again ...')
                else:
                    # 取り込みエラー
                    self.logger.warn('Import CSV file to Zuora Failed, try again ...')
        except Exception as e:
            self.logger.error(e)
            self.logger.info('System exit ...')
            sys.exit(0)
        finally:
            # ローカルからZuora用従量CSVファイルを削除
            try:
                if os.path.exists(zuora_usage_csv_path):
                    os.remove(zuora_usage_csv_path)
            except Exception as e:
                self.logger.error('Failed to delete CSV file from local ...')
                self.logger.info(f'CSV file path = [{zuora_usage_csv_path}] ...')
                self.logger.info(f'Error = [{e}] ...')
