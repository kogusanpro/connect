"""
<copyright input_file_path="coohub_manual_execute_calculations.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2020-2020. All rights reserved.
</copyright>
"""
from django.core.management.base import CommandError
import os, sys
from datetime import datetime
from pytz import UTC, timezone
from rest_framework import status
import json
from batch.management.batch_command_base import BatchCommandBase
from lib.utils import ServerUtil, DateTimeUtil, check_date_ymd_format
from lib.const.coohub_k5_tenants import K5_TENANTS


class Command(BatchCommandBase):
    help = 'This Command Manual Execute Calculations Batch'

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.batch_name = 'Manual Execute Calculations batch'

    def add_arguments(self, parser):
        # バッチ実行日時(JST)
        parser.add_argument('--executed_date', type=str,
                            default=datetime.utcnow().replace(tzinfo=UTC).astimezone(timezone('Asia/Tokyo')).strftime(
                                '%Y%m%d'))
        # k5のホストアドレスのURL
        parser.add_argument('--k5_api_endpoint', type=str, default=os.environ['K5_API_ENDPOINT'])
        # k5のバッチを手動実行するAPIのURL
        parser.add_argument('--k5_manual_execute_calculations_url', type=str,
                            default=os.environ['K5_MANUAL_EXECUTE_CALCULATIONS_URL'])

    def main_process(self, *args, **options):
        """
        「料金計算バッチ」実行指示 メインの処理
        :param args:
        :param options:
        :return:
        """
        for k5_tenant in K5_TENANTS:
            self.manual_execute_calculations(options=options, k5_tenant=k5_tenant)

    def do_validate(self, *args, **options):
        """
        継承先で任意で実装するバリデーション処理
        :param args:
        :param options:
        :return:
        """

        if not check_date_ymd_format(options['executed_date']):
            raise CommandError(
                f'executed_date was invalid format in this request body')

    def manual_execute_calculations(self, options, k5_tenant):
        """
        債権情報取得
        :param args:
        :param options:
        :param k5_tenant:
        """
        self.logger.info('Start manual_execute_calculations ...')

        target_month = DateTimeUtil.get_prev_specific_date_ym(options['executed_date'])
        param_target_url = options['k5_api_endpoint'] + options['k5_manual_execute_calculations_url']

        data_execute = {
            'batch_division': '03',
            'target_month': target_month,
            'execute_restriction_release': '1'
        }
        self.logger.info(f'Start execte "/API/v2/api/manualexecute/calculations"API(K5)...data={data_execute} ')
        result = ServerUtil(self).get_k5_response(
            url=param_target_url,
            params=dict(),
            method='POST',
            allow_token_time_out_minutes=5,
            data=json.dumps(data_execute),
            k5_tenant=k5_tenant)

        result_json=result.json()
        self.logger.info(f'Response status_code={result.status_code}')
        self.logger.info(f'Response body ={result_json}')

        if result.status_code == status.HTTP_202_ACCEPTED:
            if result_json.get('result_information').get('result') == 'OK':
                self.logger.info(f'successed manual calculation finish')
                sys.exit(0)
            else:
                self.logger.error(f'Manual calculation batch failure for tenant {k5_tenant.get("client_id")}.')
                self.logger.info(f'Failed URL {param_target_url}')
                sys.exit(1)
        else:
            self.logger.error(f'Manual calculation batch failure for tenant {k5_tenant.get("client_id")}.')
            self.logger.info(f'Failed URL {param_target_url}')
            sys.exit(1)


