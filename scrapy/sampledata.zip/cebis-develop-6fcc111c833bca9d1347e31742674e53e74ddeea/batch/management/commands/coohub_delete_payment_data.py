"""
<copyright input_file_path="coohub_delete_payment_data.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2020-2020. All rights reserved.
</copyright>
"""
from django.core.management.base import CommandError
import os, sys
from datetime import datetime
from pytz import UTC, timezone
import json
from rest_framework import status
from batch.management.batch_command_base import BatchCommandBase
from lib.utils import check_date_ymd_format, today_is_the_end_of_month, DateTimeUtil, ServerUtil
from lib.const.coohub_k5_tenants import K5_TENANTS


class Command(BatchCommandBase):
    help = 'This Command Delete Credit Information Batch'

    # 月数（13ヶ月）
    months_13 = 13

    # 月数（1ヶ月）
    months_1 = 1

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.batch_name = 'delete credit information batch'

    def add_arguments(self, parser):
        # バッチ実行日時(JST)
        parser.add_argument('--executed_date', type=str,
                            default=datetime.utcnow().replace(tzinfo=UTC).astimezone(timezone('Asia/Tokyo')).strftime(
                                '%Y%m%d'))
        # カスタマーID
        parser.add_argument('--k5_customer_id', type=str, default=os.environ.get('K5_CUSTOMER_ID'))
        # k5のホストアドレスのURL
        parser.add_argument('--k5_api_endpoint', type=str, default=os.environ['K5_API_ENDPOINT'])
        # k5の債権情報検索削除APIのURL
        parser.add_argument('--k5_credit_url', type=str, default=os.environ['K5_CREDIT_URL'])

    def main_process(self, *args, **options):
        """
        料金計算結果削除指示 メインの処理
        :param args:
        :param options:
        :return:
        """
        for k5_tenant in K5_TENANTS:
            # 債権情報取得
            credit_list = self.get_credit_data(options=options, k5_tenant=k5_tenant)
            # 債権情報削除
            self.delete_credit_data(options=options, k5_tenant=k5_tenant, credit_list=credit_list)

    def do_validate(self, *args, **options):
        """
        継承先で任意で実装するバリデーション処理
        :param args:
        :param options:
        :return:
        """

        if not check_date_ymd_format(options['executed_date']):
            raise CommandError(
                f'executed_date was invalid format in this request body')

    def get_credit_data(self, options, k5_tenant):
        """
        債権情報取得
        :param args:
        :param options:
        :param k5_tenant:
        :return credit_list:
        """
        param_customer_id = options['k5_customer_id']
        param_target_url = options['k5_api_endpoint'] + options['k5_credit_url']
        param_executed_date = options['executed_date']

        credit_list = list()

        # 「check_date_whether_end_of_the_month」：日付が月末であるかのチェック。
        # １．実行日が月末の場合(日本時間の月末)：
        #         実行日の13か月前の月末の年月日をbusiness_dateに指定する。
        # ２．実行日が月末ではない場合(日本時間の毎月12日)：
        #         実行日の前月(1ヶ月前)月末の年月日をbusiness_dateに指定する。
        if today_is_the_end_of_month(param_executed_date):
            deletion_business_date = DateTimeUtil.get_prev_specific_date_ymd(param_executed_date, self.months_13)
        else:
            deletion_business_date = DateTimeUtil.get_prev_specific_date_ymd(param_executed_date, self.months_1)

        params_select = {
            'customer_id': param_customer_id,
            'business_date': deletion_business_date
        }
        result_select = ServerUtil(self).get_k5_response(
            url=param_target_url,
            params=params_select,
            method='GET',
            allow_token_time_out_minutes=5,
            data=dict(),
            k5_tenant=k5_tenant)

        if result_select.status_code == status.HTTP_200_OK:
            if result_select.json().get('result_information').get('result') == 'OK':
                for item in result_select.json().get('charge_adjustment_information_list'):
                    if deletion_business_date[0:6] == item.get('target_month'):
                        credit_list.append({"credit_id": item.get('credit_id')})

                return credit_list
            else:
                self.logger.error(f'Failed to get credit information for tenant {k5_tenant.get("client_id")}.')
                self.logger.info(f'Failed status_code {result_select.status_code}')
                self.logger.info(
                    f'Failed message {result_select.json().get("result_information").get("detailed_result")}')
                self.logger.info(f'Failed params {params_select}')
                self.logger.info(f'Failed URL {param_target_url}')
                sys.exit(1)
        else:
            self.logger.error(f'Failed to get credit information for tenant {k5_tenant.get("client_id")}.')
            self.logger.info(f'Failed status_code {result_select.status_code}')
            self.logger.info(f'Failed params {params_select}')
            self.logger.info(f'Failed URL {param_target_url}')
            sys.exit(1)

    def delete_credit_data(self, options, k5_tenant, credit_list):
        """
        債権情報削除
        :param args:
        :param options:
        :param k5_tenant:
        :param credit_list:
        :return :
        """
        param_target_url = options['k5_api_endpoint'] + options['k5_credit_url']

        split_list = []
        # 1000個ずつに分割する
        for i in range(0, len(credit_list), 1000):
            split_list.extend([credit_list[i:i + 1000]])

        for credit_information_delete_list in split_list:
            data_delete = {
                'credit_information_delete_list': credit_information_delete_list
            }
            result_delete = ServerUtil(self).get_k5_response(
                url=param_target_url,
                params=dict(),
                method='POST',
                allow_token_time_out_minutes=5,
                data=json.dumps(data_delete),
                k5_tenant=k5_tenant)

            if result_delete.status_code == status.HTTP_200_OK:
                if result_delete.json().get('result_information').get('result') == 'OK':
                    self.logger.info(f'successed delete credit data finish')
                else:
                    self.logger.error(f'Debt information for tenant {k5_tenant.get("client_id")} could not be deleted.')
                    self.logger.info(f'Failed status_code {result_delete.status_code}')
                    self.logger.info(
                        f'Failed message {result_delete.json().get("result_information").get("detailed_result")}')
                    self.logger.info(f'Failed data {data_delete}')
                    self.logger.info(f'Failed URL {param_target_url}')
            else:
                self.logger.error(f'Debt information for tenant {k5_tenant.get("client_id")} could not be deleted.')
                self.logger.info(f'Failed status_code {result_delete.status_code}')
                self.logger.info(f'Failed data {data_delete}')
                self.logger.info(f'Failed URL {param_target_url}')
