"""
<copyright file="create_billing_csv.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from botocore.exceptions import ClientError
from batch.management.batch_command_base import BatchCommandBase
from lib.const.opco_code import OPCO_CODE_LIST
from paramiko import SSHClient, AutoAddPolicy, SSHException
import boto3
import os
import sys
import tempfile
from django.conf import settings
from lib.utils import DateTimeUtil, check_date_ymd_format
from django.core.management.base import CommandError

class Command(BatchCommandBase):
    help = 'This Command Create Billing CSV FIle'
    ENV_KEY_PROFITSHARE_BUCKET = 'S3_FOR_PROFITSHARE_CSV_BUCKET'

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.batch_name = 'sending billig and profitshare csv files to SFTP Server'
        self.target_ym = DateTimeUtil.get_prev_ym()
        self.target_y = DateTimeUtil.get_prev_y()
        self.s3 = boto3.client('s3', endpoint_url=settings.AWS_S3_ENDPOINT)

    def add_arguments(self, parser):
        # バッチ実行日時(JST)
        parser.add_argument('--executed_date', type=str,default=None)

    def do_validate(self, *args, **options):
        """
        継承先で任意で実装するバリデーション処理
        :param args:
        :param options:
        :return:
        """
        self.executed_date=options['executed_date']
        if self.executed_date is not None and not check_date_ymd_format(self.executed_date):
            raise CommandError(
                f'executed_date was invalid format in this request body')

    def main_process(self, *args, **options):
        """
        SFTP送信バッチメイン処理
        :param args:
        :param options:
        :return:
        """
        # executed_date(YYYYMMDD)が指定された場合、バッチ実行日時としてで対応する
        if self.executed_date is not None:
            self.target_ym = DateTimeUtil.get_prev_specific_date_ym(self.executed_date)
            self.target_y = self.target_ym[0:4]

        self.__put_files_to_sftp(
            type='billing',
            bucket=os.environ.get('S3_FOR_BILLING_CSV_BUCKET')
        )
        self.__put_files_to_sftp(
            type='profitshare',
            bucket=os.environ.get('S3_FOR_PROFITSHARE_CSV_BUCKET')
        )

    def __get_target_billing_files(self, type, bucket):
        target_file_list = []
        for opco_code in OPCO_CODE_LIST:
            file_name = type + '_' + opco_code + '_' + self.target_ym + '.csv'
            file_path = opco_code + '/' + self.target_y + '/' + file_name
            try:
                self.s3.get_object(
                    Bucket=bucket,
                    Key=file_path
                )
                target_file_list.append({
                    'file_name': file_name,
                    'file_path': file_path
                })
            except ClientError:
                pass

        return target_file_list

    def __put_files_to_sftp(self, type, bucket):
        file_list = self.__get_target_billing_files(type, bucket)
        if not file_list:
            self.logger.error(f'Target files does not exists')
            return True

        for file in file_list:
            temp_csv_file = tempfile.NamedTemporaryFile()
            try:
                s3 = boto3.resource('s3', endpoint_url=settings.AWS_S3_ENDPOINT)
                s3.Bucket(bucket).download_file(
                    Key=file['file_path'],
                    Filename=temp_csv_file.name
                )
                self.__send_sftp(
                    local_file=temp_csv_file.name,
                    remote_file=file['file_name']
                )
            except ClientError as e:
                self.logger.error(e)
                sys.exit(1)

    def __send_sftp(self, local_file, remote_file):
        try:
            ssh = SSHClient()
            ssh.set_missing_host_key_policy(AutoAddPolicy())
            ssh.connect(
                hostname=settings.SFTP['HOST'],
                port=settings.SFTP['PORT'],
                username=settings.SFTP['USER'],
                password=settings.SFTP['PASSWORD']
            )
            remote_path = os.environ['SFTP_REMOTE_PATH']
            sftp = ssh.open_sftp()
            remote_files = sftp.listdir(remote_path)

            if remote_file not in remote_files:
                sftp.put(local_file, remote_path + remote_file)
                self.logger.info(f'{remote_file} has been uploaded to the sftp server.')
            else:
                count = 0
                old_remote_file = remote_file + '.old'
                if old_remote_file in remote_files:
                    count = 0
                    while True:
                        try:
                            count += 1
                            count_old_remote_file = old_remote_file + '.' + str(count)
                            if count_old_remote_file not in remote_files:
                                sftp.rename(
                                    oldpath=remote_path + old_remote_file,
                                    newpath=remote_path + count_old_remote_file
                                )
                                self.logger.info(
                                    f'{remote_path + old_remote_file} has been rename to the {remote_path + count_old_remote_file}.'
                                )
                                sftp.rename(
                                    oldpath=remote_path + remote_file,
                                    newpath=remote_path + old_remote_file
                                )
                                self.logger.info(
                                    f'{remote_path + remote_file} has been rename to the {remote_path + old_remote_file}.'
                                )
                                sftp.put(local_file, remote_path + remote_file)
                                self.logger.info(f'{remote_file} has been uploaded to the sftp server.')
                                break
                        except FileNotFoundError as e:
                            self.logger.error(e)
                            sys.exit(1)
                else:
                    sftp.rename(
                        oldpath=remote_path + remote_file,
                        newpath=remote_path + old_remote_file
                    )
                    sftp.put(local_file, remote_path + remote_file)
                    self.logger.info(f'{remote_file} has been uploaded to the sftp server.')
            sftp.close()
            ssh.close()
        except (SSHException, FileNotFoundError, PermissionError, TimeoutError) as e:
            self.logger.error(e)
            sys.exit(1)
