"""
<copyright file="sync-usage-data.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2019-2020. All rights reserved.
</copyright>
"""
import sys
import requests
import hashlib
import csv
import time
import os
import json

from decimal import Decimal, InvalidOperation
from io import StringIO
from batch.management.batch_command_base import BatchCommandBase
from django.utils.timezone import datetime, timedelta
from lib.utils import ServerUtil
from lib.const.coohub_k5_tenants import K5_TENANTS
from lib.const.internal_calc import SUBSCRIPTION_ID_POSTFIX
from pytz import UTC, timezone
from batch.services import get_tmp_dir
from lib.utils import check_datetime_format, DateTimeUtil
from lib.shortcuts import get_object_or_None
from django.core.management.base import CommandError
from subscriptions.models import ContractInfo

class Command(BatchCommandBase):
    help = 'This Command Synchronize Usage Data to K5'

    # 従量データCSVファイル作成確認のカウント
    cebis_csv_creation_check_retry_times = 30

    # 従量データCSVファイル作成確認待ち時間(60秒)
    cebis_csv_creation_wait_interval = 60

    # 従量データCSVファイルを読むカウント
    cebis_usage_file_read_retry_times = 3

    # 再実行までの待ち時間(60秒)
    retry_wait_time = 60

    # 利用実績登録状態監視回数(監視ロジック回数)
    register_timeout_max_num = 240

    def __init__(self):
        """
        グローバル変数を初期化する
        """
        super().__init__()
        # バッチ名
        self.batch_name = 'synchronize usage data to K5'
        # 今月度分従量データのリスト
        self.current_month_usage_data_list = list()
        # 前月度分従量データのリスト
        self.previous_month_usage_data_list = list()
        # 当月の年月
        self.current_month_date = None
        # 前月の年月
        self.previous_month_date = None
        # サービス契約対応表
        self.service_contracts_table = None
        # バッチ実行日時(JST)の年月日
        self.executed_date = None
        # cebisのホストアドレスのURL
        self.cebis_api_endpoint = None
        # k5のホストアドレスのURL
        self.k5_api_endpoint = None
        # 「利用実績を登録する」APIのURL
        self.k5_use_records_url = None
        # 「一括処理ステータス確認」APIIのURL
        self.cebis_check_usage_csv_creation_url = None
        # 「サービス契約を検索する」APIのURL
        self.k5_service_contract_url = None
        # 「バッチを手動実行する」APIのURL
        self.k5_manual_execute_calculations_url = None
        # 「従量データ一括取得用URL取得」APIのURL
        self.cebis_usage_download_url = None
        # 従量計算システムのAPIキー
        self.cebis_calculation_system_api_key = None
        # Downloadしたファイル名
        self.download_csv_file_path = None
        # バッチ実行時刻指定(UTC)
        self.from_created_datetime = None
        # バッチ実行時刻指定(UTC)
        self.to_created_datetime = None
        # 「非同期処理状況を取得する」APIのURL
        self.async_process_status_url = None
        # 自動実行が0,手動実行は1
        self.execute_flag = None

    def add_arguments(self, parser):
        """
        実行時に指定可能なパラメータの引数への追加処理
        :param parser:
        :return:
        """
        # バッチ実行日時(JST)
        parser.add_argument('--executed_date', type=str,
                            default=datetime.utcnow().replace(tzinfo=UTC).astimezone(timezone('Asia/Tokyo')))

        # バッチ実行時刻指定(UTC)
        parser.add_argument('--from_created_datetime', type=str, default="", )

        # バッチ実行時刻指定(UTC)
        parser.add_argument('--to_created_datetime', type=str, default="", )

        # cebisのホストアドレスのURL
        parser.add_argument('--cebis_api_endpoint', type=str, default=os.environ['CEBIS_API_ENDPOINT'])

        # k5のホストアドレスのURL
        parser.add_argument('--k5_api_endpoint', type=str, default=os.environ['K5_API_ENDPOINT'])

        # 「利用実績を登録する」APIのURL
        parser.add_argument('--k5_use_records_url', type=str, default=os.environ['K5_USE_RECORDS_URL'])

        # 「一括処理ステータス確認」APIのURL
        parser.add_argument('--cebis_check_usage_csv_creation_url', type=str,
                            default=os.environ['CEBIS_CHECK_USAGE_CSV_CREATION_URL'])

        # 「サービス契約を検索する」APIのURL
        parser.add_argument('--k5_service_contract_url', type=str, default=os.environ['K5_SERVICE_CONTRACT_URL'])

        # 「バッチを手動実行する」APIのURL
        parser.add_argument('--k5_manual_execute_calculations_url', type=str,
                            default=os.environ['K5_MANUAL_EXECUTE_CALCULATIONS_URL'])

        # 「従量データ一括取得用URL取得」APIのURL
        parser.add_argument('--cebis_usage_download_url', type=str, default=os.environ['CEBIS_USAGE_DOWNLOAD_URL'])

        # 従量計算システムのAPIキー
        parser.add_argument('--cebis_calculation_system_api_key', type=str, default=os.environ['CEBIS_CALCULATION_SYSTEM_API_KEY'])

        # 「非同期処理状況を取得する」APIのURL
        parser.add_argument('--async_process_status_url', type=str, default=os.environ['K5_ASYNC_PROCESS_STATUS_URL'])

    def __init_global_param(self, options):
        """
        グローバル変数を初期化する
        :return:
        """
        # バッチ実行日時(JST)の年月日
        # バッチ実行日時に渡されるパラメーター
        self.executed_date = options.get("executed_date")
        if not isinstance(self.executed_date, datetime):
            # 手動実行(JST)
            parameter_year = self.executed_date[0:4]
            parameter_month = self.executed_date[4:6]
            parameter_day = self.executed_date[6:8]
            self.executed_date = datetime(int(parameter_year), int(parameter_month), int(parameter_day), 4)\
                .replace(tzinfo=timezone('Asia/Tokyo'))
            self.execute_flag = 1
        else:
            # 自動実行
            self.executed_date = options.get("executed_date")
            self.execute_flag = 0

        self.logger.info(f'Executed date is {self.executed_date.strftime("%Y-%m-%d")} (JST)...')

        # サービス契約対応表
        self.service_contracts_table = dict()

        # cebisのホストアドレスのURL
        self.cebis_api_endpoint = options.get("cebis_api_endpoint")

        # k5のホストアドレスのURL
        self.k5_api_endpoint = options.get("k5_api_endpoint")

        # 「利用実績を登録する」APIのURL
        self.k5_use_records_url = options.get("k5_use_records_url")

        # 「一括処理ステータス確認」APIのURL
        self.cebis_check_usage_csv_creation_url = options.get("cebis_check_usage_csv_creation_url")

        # 「サービス契約を検索する」APIのURL
        self.k5_service_contract_url = options.get("k5_service_contract_url")

        # 「バッチを手動実行する」APIのURL
        self.k5_manual_execute_calculations_url = options.get("k5_manual_execute_calculations_url")

        # 「従量データ一括取得用URL取得」APIのURL
        self.cebis_usage_download_url = options.get("cebis_usage_download_url")

        # 従量計算システムのAPIキー
        self.cebis_calculation_system_api_key = options.get("cebis_calculation_system_api_key")

        # バッチ実行時刻指定(UTC)
        self.from_created_datetime = options.get('from_created_datetime')

        self.to_created_datetime = options.get('to_created_datetime')
        # 「非同期処理状況を取得する」APIのURL
        self.async_process_status_url = options.get("async_process_status_url")

    def main_process(self, *args, **options):
        """
        従量データ収集基盤から従量データ一覧を日次で取得し、従量計算システムへ同期する
        従量計算システムの「利用実績登録バッチ」を実行し、従量計算システム内に従量データを取り込ませる
        :param args: システムパラメータ
        :param options: システムパラメータ
        """

        # グローバル変数を初期化する
        self.__init_global_param(options)

        # cebisから従量データを取得する
        self.__get_usage_data_from_cebis()

        if len(self.current_month_usage_data_list).__gt__(0) or len(self.previous_month_usage_data_list).__gt__(0):

            # サービス対応表の取得
            self.__get_service_contracts_from_k5()

            # 従量データを従量計算システムへ登録する
            self.__register_usage_data_to_k5()
        else:
            self.logger.info('Usage data synchronization data empty ...')
            self.logger.info(f'current_month {self.current_month_date.strftime("%Y%m")}')
            self.logger.info(f'previous_month {self.previous_month_date.strftime("%Y%m")}')

        # 一時ファイルを削除する
        if os.path.exists(self.download_csv_file_path):
            os.remove(self.download_csv_file_path)
            self.logger.info(f'temporary file {self.download_csv_file_path} has been deleted')

        self.logger.info('Usage data synchronization completed ...')

    def do_validate(self, *args, **options):
        """
        引数等のバリデーション処理
        :param args:
        :param options:
        :return:
        """
        if options['from_created_datetime'] and options['to_created_datetime']:
            if not check_datetime_format(datetime=options['from_created_datetime']):
                raise CommandError(
                    f'from_created_datetime was invalid format in this request body')

            if not check_datetime_format(datetime=options['to_created_datetime']):
                raise CommandError(
                    f'to_created_datetime was invalid format in this request body')

            if DateTimeUtil.YmdTHMSZ_utc_to_YmdHMS_utc(options['from_created_datetime']) > \
                    DateTimeUtil.YmdTHMSZ_utc_to_YmdHMS_utc(options['to_created_datetime']):
                raise CommandError(
                    f'from_created_datetime was greater than to_created_datetime in this request body')

        elif (options['from_created_datetime'] and not options['to_created_datetime']) \
                or (not options['from_created_datetime'] and options['to_created_datetime']):
            raise CommandError(f'from_created_datetime and to_created_datetime are specified as a pair')

    def __get_usage_data_from_cebis(self):
        """
        cebisから従量データを取得する(従量データを一括取得する)
        """
        self.logger.info('Start getting usage data from cebis...')

        #  from_created_date = 前日の19時(UTC)
        #  to_created_date = 今日の19時(UTC)
        from_created_date = (self.executed_date - timedelta(days=1)) \
            .astimezone(UTC) \
            .replace(hour=19, minute=0, second=0) \
            .strftime("%Y%m%dT%H%M%SZ")

        to_created_date = self.executed_date \
            .astimezone(UTC) \
            .replace(hour=19, minute=0, second=0) \
            .strftime("%Y%m%dT%H%M%SZ")
        # AR99145の修正として、インシデント対応時にfrom/toの年月日時分秒を指定できるようにした
        if self.from_created_datetime and self.to_created_datetime:
            from_created_date = self.from_created_datetime
            to_created_date = self.to_created_datetime
            self.logger.info(f'using the specification time...')

        self.logger.info(f'from_created_date is {from_created_date} ')
        self.logger.info(f'to_created_date is {to_created_date} ')
        # cebisの「従量データ一括取得用URL取得」APIを実行する
        create_usage_csv_reponse = self.__get_usage_csv_creation_url(from_created_date, to_created_date)

        # 従量データ一覧CSVファイルの生成が完了するのを「一括処理ステータス確認」APIで定期監視する
        create_usage_csv_status = self.__check_usage_csv_creation_status(create_usage_csv_reponse.get('request_id'))

        # 従量データ一覧CSVファイルを読む
        usage_data_list = self.__get_usage_csv_data_from_cebis_url(create_usage_csv_reponse.get('presigned_url'),
                                                                   create_usage_csv_status.get('content_md5'))

        # サブスクリプションIDをキーとして、対応する契約情報の「サブスクリプション番号」の有無によって、K5商品かZuora商品かを判別
        usage_data_k5_list = []
        for usage_data in usage_data_list:
            # csv内の従量データに紐づく、subscription_idを取得。
            subscription_id = usage_data.get('subscription_id')
            # TODO: 今回は重複したCSVファイル内のサブスクリプションIDにて契約情報テーブルを参照することになるが、
            # 本来重複したサブスクリプションIDでの契約情報テーブル参照しない処理を追記したいものの可読性が失われる為、一旦保留
            if subscription_id.endswith(SUBSCRIPTION_ID_POSTFIX):
                subscription_id = subscription_id[:-1]
            
            # 従量データに紐づく、サブスクリプション番号を取得
            contract_info = get_object_or_None(ContractInfo, pk=subscription_id)
            if contract_info is None:
                self.logger.error(f'Contract not found subscription_id:{subscription_id}')
                continue

            if not contract_info.is_zuora():
                usage_data_k5_list.append(usage_data)

        # 条件に合致した従量データを同期対象従量データとして抽出する。
        self.__filter_usage_data_list(usage_data_k5_list)

    def __filter_usage_data_list(self, usage_data_k5_list):
        """
        同期対象従量データを抽出する
        :param usage_data_k5_list: CebisのK5従量データ
        """
        self.logger.info('Start extract the usage data separately for this month and the previous month...')
        # 今月度(バッチ実行日時(JST))
        self.current_month_date = self.executed_date
        # 前月度(バッチ実行日時(JST)の前月度)
        self.previous_month_date = self.__get_prev_month()

        # usage csvから読み取られるデータをフィルタリングし、「対象月度」で今月度対象と前月度対象に分ける。
        for usage_data in usage_data_k5_list:

            if self.__validate_usage_data_is_valid(usage_data):
                if self.current_month_date.strftime("%Y%m") == usage_data.get('target_month'):
                    # 今月度分と従量データの対象月度が一致する従量データ一覧
                    self.current_month_usage_data_list.append(usage_data)
                elif self.previous_month_date.strftime("%Y%m") == usage_data.get('target_month'):
                    # 前月度分と従量データの対象月度が一致する従量データ一覧
                    self.previous_month_usage_data_list.append(usage_data)
                else:
                    self.__output_usage_data_error_reason_log(usage_data," because usage_data.target_month do not match both this month and for the previous month.  ")
            else:
                self.__output_usage_data_error_reason_log(usage_data," because the year and month of the usage_data.end_date_time do not match usage_data.target_month.  ")

    def __validate_usage_data_is_valid(self, usage_data: dict):
        """
        データが有効かどうかをチェックする
        :param usage_data:従量データ
        :return チェック結果
        """
        end_date_time = self.__convert_iso_utc_to_jst(usage_data.get('end_date_time'))

        # 判定ルール
        # end_date_timeの年月 = target_month

        return usage_data.get('target_month') == end_date_time.strftime("%Y%m")

    def __get_usage_csv_creation_url(self, from_created_date, to_created_date):
        """
        cebisの「従量データ一括取得用URL取得」APIを実行する
        :param from_created_date バッチ実行日時(JST)前日の4時(JST)
        :param to_created_date バッチ実行日時(JST)当日の4時(JST)
        :return: CSVファイルのURLとリクエストIDを返す
        """
        params = {"from_created_datetime": from_created_date,
                  "to_created_datetime": to_created_date,
                  "internal_calc": 'true'}

        self.logger.info(f'Start execute"/usageDownloadUrl"API...params={params}')
        # cebisの「従量データ一括取得用URL取得」APIを呼び出す
        usage_csv_response = ServerUtil(self).get_cebis_response(
            url=self.cebis_api_endpoint + self.cebis_usage_download_url,
            method="GET",
            params=params,
            api_key=self.cebis_calculation_system_api_key,
            data=dict()
        )

        response_json=usage_csv_response.json()
        self.logger.info(f'Response status_code={usage_csv_response.status_code}')
        self.logger.info(f'Response body={response_json}')

        # API処理結果の判定
        if usage_csv_response.status_code != 200:
            self.logger.fatal('Failed to get usage data from usageDownloadUrl API ...')
            self.logger.info(f'Failed URL={self.cebis_api_endpoint + self.cebis_usage_download_url}')
            self.logger.info(f'Failed api key ={self.cebis_calculation_system_api_key}')
            sys.exit(0)

        return response_json

    def __check_usage_csv_creation_status(self, request_id):
        """
        cebisの「一括処理ステータス確認」APIを実行する
        :param request_id リクエストID
        :return: 一括処理ステータス
        """

        # 100秒間待機した後、処理結果を確認する。
        # チェック結果が進行中の場合は、100秒待ってから再度チェックすると、チェックが合計3回繰り返される。
        # 3回チェックしても処理結果が成功しない場合、処理は中断される。

        for index in range(0, self.cebis_csv_creation_check_retry_times):

            # 60s待機した後、apiを呼び出し、csv作成状態をチェックする
            time.sleep(self.cebis_csv_creation_wait_interval)

            self.logger.info(f'Start execute"/status/request_id"API...request_id={request_id}')
            # cebisの「一括処理ステータス確認」APIを呼び出す
            check_usage_csv_creation_response = ServerUtil(self).get_cebis_response(
                url=self.cebis_api_endpoint + self.cebis_check_usage_csv_creation_url + request_id,
                params=dict(),
                method="GET",
                api_key=self.cebis_calculation_system_api_key,
                data=dict())

            response_json = check_usage_csv_creation_response.json()
            self.logger.info(f'Response status_code={check_usage_csv_creation_response.status_code}')
            self.logger.info(f'Response body ={response_json}')

            # API処理結果の判定
            if check_usage_csv_creation_response.status_code != 200:
                self.logger.fatal('Failed to get the usage csv creation status ...')
                self.logger.info(f'Failed URL={self.cebis_api_endpoint + self.cebis_check_usage_csv_creation_url+ request_id}')
                self.logger.info(f'Failed api key ={self.cebis_calculation_system_api_key}')
                sys.exit(0)

            # responseのheaderからmd5暗号ストリングを取得する
            response_json.update(
                {'content_md5': check_usage_csv_creation_response.headers.get('content-md5-cebis')})

            if response_json.get("process_result") == "Success":
                self.logger.info(
                    f'Success URL={self.cebis_api_endpoint + self.cebis_check_usage_csv_creation_url + request_id}')
                return response_json
            elif response_json.get("process_result") in ["Processing", "NotProcessed"]:
                self.logger.info(
                    f"Usage csv file creation on cebis is {response_json.get('process_result')}, try again")
                self.logger.info(f'request_id is {request_id} ')
                if index == self.cebis_csv_creation_check_retry_times - 1:
                    self.logger.fatal("Usage csv creation process on cebis exceeds timeout.")
                    sys.exit(0)
                continue
            else:
                self.logger.fatal(f'Create usage csv is {response_json.get("process_result")}')
                sys.exit(0)

    def __get_usage_csv_data_from_cebis_url(self, download_url, content_md5):
        """
        従量データ一覧CSVファイルのデータを読む
        :param download_url: 従量データ一覧CSVのURL
        :param content_md5: MD5暗号化コード
        :return: usage csv data 従量データ一覧
         """
        self.logger.info('Start download　usage　csv　data　from　cebis　url...')
        for loop in range(0, self.cebis_usage_file_read_retry_times):
            # URLでCSVファイルを取得
            usage_csv_data_response = requests.get(url=download_url, stream=True)
            # 処理結果の判定
            if usage_csv_data_response.status_code != 200:
                if loop.__lt__(self.cebis_usage_file_read_retry_times - 1):
                    self.logger.fatal('Failed to get the Usage CSV File, try again...')
                    time.sleep(self.retry_wait_time)
                    continue
                else:
                    self.logger.fatal('Failed to get the Usage CSV File')
                    sys.exit(0)
            temp_usage_csv = os.path.join(get_tmp_dir(),
                                          self.executed_date.strftime("%Y%m%d%H%M%S%f_") + 'download.csv')
            self.__create_temp_usage_csv(temp_usage_csv, usage_csv_data_response)
            with open(temp_usage_csv, 'rU') as temp_file:
                usage_csv_content = temp_file.read()
                temp_file.close()

            # 一時フォルを一時保留
            self.download_csv_file_path = temp_usage_csv

            # 取得したファイルはMD5で暗号化され、パラメーター内のMD5暗号化文字列と比較される。
            md5_str = self.__get_md5_hexdigest_str(usage_csv_content.encode())
            if content_md5 == md5_str:
                data_content = StringIO(usage_csv_content)
                # 実際のファイルを作成せずにcsvの内容を読む
                return csv.DictReader(data_content, delimiter=",", doublequote=True, lineterminator="\n", quotechar='"')
            elif loop.__lt__(self.cebis_usage_file_read_retry_times - 1):
                self.logger.info('Usage CSV file hash values are inconsistent, read again...')
                continue
            else:
                self.logger.fatal('Usage CSV file hash values are inconsistent')
                sys.exit(0)

        self.logger.info('Completed to get the Usage CSV File')

    def __create_temp_usage_csv(self, temp_usage_csv, usage_csv_data_response):
        """
        従量データ一覧CSVを一時フォルダーに作成する
        :param temp_usage_csv　一時フォル
        :param usage_csv_data_response ファイルコンテンツ
        """
        with open(temp_usage_csv, 'wb') as temp_file:
            for chunk in usage_csv_data_response.iter_content(chunk_size=512):
                temp_file.write(chunk)
            temp_file.close()

    def __get_md5_hexdigest_str(self, encrypted_content):
        """
        MD5暗号化文字列を取得
        :param encrypted_content 暗号化前コンテンツ
        :return:暗号化前後の字符串
        """
        md5 = hashlib.md5()
        md5.update(encrypted_content)
        return md5.hexdigest()

    def __get_service_contracts_from_k5(self):
        """
        サービス対応表の作成
        :return: サービス対応表
        """
        remove_contract = set()
        # すべてのK5サーバーをトラバースし、異なるK5サーバーから情報を取得する(現在、K5 Serverが1台しかない)
        for k5_tenant in K5_TENANTS:
            # サービス対応表の情報を取得
            service_contract_list = self.__request_service_contracts(k5_tenant)

            for service_contract in service_contract_list:
                # キー値または値がNULLまたは空の場合は、エラーログを出力して処理を続行する。
                if service_contract.get('free_item1') is None or service_contract.get(
                        'free_item4') is None or service_contract.get(
                        'service_contract_id') is None or service_contract.get(
                        'price_plan_code') is None:
                    self.logger.error(
                        'Service contract is invalid... skip this service contract ... '
                        f'subscription_id:{service_contract.get("free_item1")} '
                        f'product_code:{service_contract.get("free_item4")} '
                        f'service_contract_id:{service_contract.get("service_contract_id")} '
                        f'price_plan_code:{service_contract.get("price_plan_code")} '
                    )
                    continue

                service_contract_key = '_'.join(
                    [service_contract.get('free_item1').strip(), service_contract.get('free_item4').strip()])

                if service_contract_key in self.service_contracts_table:
                    continue

                self.service_contracts_table.update(
                    {service_contract_key: {'service_contract_id': service_contract.get("service_contract_id"),
                                            'price_plan_code': service_contract.get("price_plan_code"),
                                            'charging_start_date': service_contract.get("charging_start_date"),
                                            'charging_end_date': service_contract.get("charging_end_date"),
                                            'free_item1': service_contract.get("free_item1"),
                                            'k5_client_id': k5_tenant.get('client_id')}
                     })

    def __request_service_contracts(self, k5_tenant: dict):
        """
        「サービス契約を検索する」APIを実行する
        :param k5_tenant: K5サーバ情報
        :return: サービス契約情報リスト
        """

        get_service_contracts_flag = True
        service_contracts = list()
        loop = 1
        # このループは、前のAPIの戻り値に従って次のループを実行するかどうかを確認する必要があるため、
        # 不定のループ数 forループを使用できない。
        while get_service_contracts_flag:
            params = {"start_position": 1 + 1000 * (loop - 1),
                      "end_position": 1000 * loop,
                      "sort_item1": "free_item1",
                      "sort1": 0,
                      "sort_item2": "free_item4",
                      "sort2": 0}
            # サービス契約を検索するAPIを実行する
            target_url = self.k5_api_endpoint + self.k5_service_contract_url
            self.logger.info(f'Start execute "/API/v2/api/servicecontracts" API(K5)...params={params}')
            service_contracts_result = ServerUtil(self).get_k5_response(
                url=target_url,
                params=params,
                method='GET',
                allow_token_time_out_minutes=5, data=dict(),
                k5_tenant=k5_tenant)

            service_contracts_result_json = service_contracts_result.json()
            self.logger.info(f'Response status_code={service_contracts_result.status_code}')
            self.logger.info(f'Response body ={service_contracts_result_json}')

            # API処理結果の判定
            if service_contracts_result.status_code is not 200:
                self.logger.error(f'Get service contracts failed on {k5_tenant.get("client_id")} K5 server...')
                self.logger.info(f'Failed URL={target_url}')
                break

            service_contracts.extend(service_contracts_result_json.get('customer_appoint_service_contract_information_list'))
            loop = loop + 1

            if len(service_contracts_result_json.get('customer_appoint_service_contract_information_list')).__lt__(1000):
                get_service_contracts_flag = False

        return service_contracts

    def __register_usage_data_to_k5(self):
        """
       「利用実績を登録する」APIの実行と、「バッチを手動実行する」APIを実行して「利用実績登録バッチ」を実行させることで、
        従量データを従量計算システムへ登録する。
        """
        self.logger.info('Start to register usage records to K5...')

        # 前月度の従量データを登録する
        # 「利用実績を登録する」APIを実行
        if len(self.previous_month_usage_data_list).__gt__(0):
            self.logger.info('Start to register pre_month usage records to K5...')
            register_response_list, processed_k5_client_id_list = self.__register_usage_records_to_k5(self.previous_month_usage_data_list)
            # 「バッチを手動実行する」APIを実行
            self.__execute_register_batch_on_k5(self.previous_month_date.strftime("%Y%m"), processed_k5_client_id_list)

            self.logger.info('Start to watch pre_month usage records status...')

            # 124939 Excetionエラー発生　かつ　アラートがない
            try:
                # 監視ロジック、前月度データK５に登録成功した後、当月分データを登録する
                self._async_process_status_watch(register_response_list, processed_k5_client_id_list[0])

            except:
                self.logger.error('pre_month usage records has not valid data')


        # 当月度の従量データを登録する
        # 「利用実績を登録する」APIを実行
        if len(self.current_month_usage_data_list).__gt__(0):
            self.logger.info('Start to register this_month usage records to K5...')
            register_response_list, processed_k5_client_id_list = self.__register_usage_records_to_k5(self.current_month_usage_data_list)
            # 「バッチを手動実行する」APIを実行
            self.__execute_register_batch_on_k5(self.current_month_date.strftime("%Y%m"), processed_k5_client_id_list)

    def __register_usage_records_to_k5(self, usage_data_list):
        """
        利用実績を登録する
        :param usage_data_list ログインする必要がある従量データ
        """
        register_response_list = list()
        processed_k5_client_id_list = list()
        # 契約情報を利用実績リストに追加
        register_usage_data = self.__add_service_contract_to_usage_data_list(self.service_contracts_table,
                                                                             usage_data_list)

        # 従量データの集約処理
        sum_up_quantity_register_data = self.__sum_quantity_usage_data_list(register_usage_data)

        for client_id in sum_up_quantity_register_data:
            processed_k5_client_id_list.append(client_id)
            # 一回全部データを登録する,今K5のclientは一つしかないので、register_responseは一つで確定。
            # もしclient_idが複数存在すれば、監視ロジックも修正しないといけない(k5_clientの数によって監視回数を追加する)
            register_response = self.__execute_usage_records_api_on_k5_parallel(
                sum_up_quantity_register_data.get(client_id), client_id)
            register_response_list.append(register_response)

        # 今K5のclientは一つしかないので、register_responseは一つで確定。
        return register_response_list, processed_k5_client_id_list

    def __add_service_contract_to_usage_data_list(self, service_contracts_table: dict, usage_data_list: list):
        """
        契約情報を登録する利用実績リストに追加
        Javaコードの実装に従って、サービス対応表中のservice_contract_idとprice_plan_codeを利用実績リストに追加し、
        従量データの集約処理に使用されます。
        :param service_contracts_table: サービス対応表
        :param usage_data_list: 従量データリスト
        :return
        """
        self.logger.info(f'Register contract information Add to usage record list... ')

        register_usage_data = dict()
        # ループ従量データリスト,従量データのkeyを作成し、
        # サービス対応表（service_contracts_table）のキーに対応するデータを検索します
        for usage_data in usage_data_list:

            key = '_'.join([usage_data.get('subscription_id').strip(), usage_data.get('product_code').strip()])
            service_contract = service_contracts_table.get(key)

            if service_contract is not None:
                # 期間チェック
                # 判定ルール
                # end_date_time > charging_start_date
                # end_date_time < charging_end_date
                if self.__check_with_in_period(service_contract, usage_data.get('end_date_time')):

                    # 期間内の場合
                    # Javaコードの実装に従って、サービス対応表中のservice_contract_idとprice_plan_codeを利用実績リストに追加し、
                    # 従量データの集約処理に使用されます。
                    usage_data.update({'service_contract_id': service_contract.get('service_contract_id')})
                    usage_data.update({'price_plan_code': service_contract.get('price_plan_code')})
                    usage_data.update({'free_item1': service_contract.get('free_item1')})
                    # 同じK5サーバーからのデータを統合する
                    if service_contract.get('k5_client_id') in register_usage_data:
                        register_usage_data.get(service_contract.get('k5_client_id')).append(usage_data)
                    else:
                        register_usage_data.update({service_contract.get('k5_client_id'): list()})
                        register_usage_data.get(service_contract.get('k5_client_id')).append(usage_data)
            else:
                self.__output_usage_data_error_reason_log(usage_data," because there is no service contract information on the K5 side.  ")

        return register_usage_data

    def __execute_usage_records_api_on_k5_parallel(self, register_data_list, client_id):
        """
       「利用実績を登録する」APIの実行
        :param register_data_list: 従量データ
        :param client_id: K5 サーバーのID
        """
        # 登録パラメータを作成
        params = {"monthly": register_data_list[0].get('target_month'),
                  "overlap_check": "1"}

        usage_record_entry_list = list()

        for register_data in register_data_list:
            usage_record_entry = {}
            start_date_time = register_data.get('start_date_time')
            end_date_time = register_data.get('end_date_time')
            # 開始日も利用終了日時にする
            start_data = end_date_time.date().strftime("%Y%m%d")
            start_time = "0000"+self.executed_date.strftime("%Y%m%d")[6:8] + "000000"
            end_date = end_date_time.date().strftime("%Y%m%d")
            end_time = "0000"+self.executed_date.strftime("%Y%m%d")[6:8] + "000000"

            usage_record_entry.update({"log_key": register_data.get('service_contract_id')})
            usage_record_entry.update({"price_plan_code": register_data.get('price_plan_code')})
            usage_record_entry.update({"use_start_date": start_data})
            usage_record_entry.update({"use_start_time": start_time})
            usage_record_entry.update({"use_end_date": end_date})
            usage_record_entry.update({"use_end_time": end_time})
            usage_record_entry.update({"use_volume": str(register_data.get('quantity'))})
            usage_record_entry.update({"use_element_1": "calcele001"})

            usage_record_entry_list.append(usage_record_entry)

        # 仕様書に記載されるパラメータフォーマットは、javaコード実装と不一致になっているが、javaで実装している。
        # Tパラメータに「use_record_entry_list」を追加した。その中に、登録必要なデータが２件含まれる。
        params.update({'use_record_entry_list': usage_record_entry_list})
        k5_tenant = [tenant for tenant in K5_TENANTS if tenant.get('client_id') == client_id][0]
        self.logger.info(f'Start execte "/API/v2/api/userecords"API(K5)... params={params} ')

        # 「利用実績を登録する」APIの実行
        register_response = ServerUtil(self).get_k5_response(
            url=self.k5_api_endpoint + self.k5_use_records_url,
            params=dict(),
            method='POST',
            allow_token_time_out_minutes=5,
            data=json.dumps(params),
            k5_tenant=k5_tenant)

        register_response_json=register_response.json()
        self.logger.info(f'Response status_code={register_response.status_code}')
        self.logger.info(f'Response body ={register_response_json} ')

        if register_response.status_code == 202:
            if register_response_json.get('result_information').get('result') == 'OK':
                self.logger.info('Usage data register successed... '
                                   f'subscription_id:{register_data.get("subscription_id")} '
                                   f'service_contract_id:{register_data.get("service_contract_id")} '
                                   f'url:{self.k5_api_endpoint + self.k5_use_records_url} '
                                   f'Target_month:{register_data.get("target_month")} ')
            else:
                self.logger.error('Usage data register failed... '
                                  f'subscription_id:{register_data.get("subscription_id")} '
                                  f'service_contract_id:{register_data.get("service_contract_id")} '
                                  f'url:{self.k5_api_endpoint + self.k5_use_records_url} '
                                  f'Target_month:{register_data.get("target_month")} ')
        else:
            self.logger.error('Usage data register failed... '
                              f'subscription_id:{register_data.get("subscription_id")} '
                              f'service_contract_id:{register_data.get("service_contract_id")} '
                              f'url:{self.k5_api_endpoint + self.k5_use_records_url} '
                              f'Target_month:{register_data.get("target_month")} ')
        return register_response_json

    def __execute_register_batch_on_k5(self, target_month, processed_k5_client_id_list):
        """
        「バッチを手動実行する」APIを実行
        :param target_month
        :param processed_k5_client_id_list: 処理するK5サーバーのID
        """
        params = {"batch_division": "02",
                  "target_month": target_month,
                  "execute_restriction_release": "1"
                  }

        for client_id in processed_k5_client_id_list:
            k5_tenant = [tenant for tenant in K5_TENANTS if tenant.get('client_id') == client_id][0]

            self.logger.info(f'Start execute "/API/v2/api/manualexecute/calculations"API(K5)...params={params}')
            # バッチを手動実行する」APIを実行
            k5_response = ServerUtil(self).get_k5_response(
                url=self.k5_api_endpoint + self.k5_manual_execute_calculations_url,
                params=dict(),
                method='POST',
                allow_token_time_out_minutes=5,
                data=json.dumps(params),
                k5_tenant=k5_tenant)

            k5_response_json=k5_response.json()
            self.logger.info(f'Response status_code={k5_response.status_code}')
            self.logger.info(f'Response body ={k5_response_json}')

            # API処理結果の判定
            if k5_response.status_code == 202:
                if k5_response_json.get('result_information').get('result') == 'OK':
                    self.logger.info(f'successed URL={self.k5_api_endpoint + self.k5_manual_execute_calculations_url}')
                else:
                    self.logger.error(f'Execute register batch failed on {client_id} K5 server ...')
                    self.logger.info(f'Failed URL={self.k5_api_endpoint + self.k5_manual_execute_calculations_url}')
            else:
                self.logger.error(f'Execute register batch failed on {client_id} K5 server ...')
                self.logger.info(f'Failed URL={self.k5_api_endpoint + self.k5_manual_execute_calculations_url}')

    def __check_with_in_period(self, service_contract, end_date_time):
        """
        期間外チェック
        :param service_contract: サービス情報
        :param end_date_time: 利用終了日
        :return: 期間内：true / 期間外：false
        """
        result = False
        end_time = datetime.strptime(end_date_time, "%Y-%m-%dT%H:%M:%SZ")
        charging_start_date = datetime.strptime(service_contract.get('charging_start_date'), "%Y%m%d")

        if end_time.__ge__(charging_start_date):
            # 「サービス開始手配完了日時」が利用終了日時」以降である
            result = True
            charging_end_date = service_contract.get('charging_end_date')

            if charging_end_date is not None:
                # サービス解約手配完了日時」が設定されていた場合
                charge_end = datetime.strptime(charging_end_date, '%Y%m%d')
                charge_end = charge_end + timedelta(days=1)
                result = (end_time.__lt__(charge_end))

        return result

    def __sum_quantity_usage_data_list(self, register_usage_data):
        """
        従量データの集約処理
        :param register_usage_data: 従量データ{key:k5_client_id. value:usage_data}
        :return sum_up_usage_list: 日次集計したデータ
        """
        self.logger.info(f'Aggregate processing of usage data... ')
        sum_quantity_usage_data = dict()

        for k5_client_id in register_usage_data:
            usage_register_dict = dict()
            for register_data in register_usage_data.get(k5_client_id):
                # 以下を集約対象のキーとして、利用量の加算計算を行う。
                key = {"subscription_id": register_data.get('subscription_id'),
                       "product_code": register_data.get('product_code'),
                       "target_month": register_data.get('target_month'),
                       "end_date_time": self.__convert_iso_utc_to_jst(register_data.get('end_date_time')).strftime(
                           "%Y-%m-%d"),
                       "service_contract_id": register_data.get('service_contract_id'),
                       "price_plan_code": register_data.get('price_plan_code')
                       }
                # 利用量の加算処理
                try:
                    # 利用量を倍精度浮動小数点数に変換する
                    quantity = Decimal(register_data.get('quantity').strip())
                    # フォーマット利用量 最後に無効な0を削除する
                    quantity.to_integral() if quantity == quantity.to_integral() else quantity.normalize()
                    if quantity.__lt__(0):
                        # 利用量が負の場合
                        self.logger.error(
                            f'Quantity is invalid... skip this register data... quantity: {quantity}')
                        continue
                    if str(key) in usage_register_dict:
                        usage_register_dict[str(key)] = usage_register_dict[str(key)] + quantity
                    else:
                        usage_register_dict.update({str(key): quantity})
                except InvalidOperation:
                    # 利用量が数字以外の文字の場合
                    self.logger.error(
                        f'Quantity is invalid... skip this register data... quantity: {register_data.get("quantity")}')
                    continue

            # 集約処理結果リスト
            sum_quantity_usage_data_list = list()

            # 集計データをList型に変換する
            for usage_register_key in usage_register_dict:

                usage_register_data = eval(usage_register_key)
                # 集約後の従量データの利用日の日時の変換処理
                end_date_time = datetime.strptime(usage_register_data.get('end_date_time'), '%Y-%m-%d')
                # 時分秒は0000ddとする。ddには集約後の従量データのローカル日時の年月日の日を指定する。
                specified_date = end_date_time.replace(second=self.executed_date.day)
                sum_usage_dict = {
                                  'target_month': usage_register_data.get('target_month'),
                                  'subscription_id': usage_register_data.get('subscription_id'),
                                  'start_date_time': specified_date,
                                  'end_date_time': specified_date,
                                  'quantity': usage_register_dict.get(usage_register_key),
                                  'service_contract_id': usage_register_data.get('service_contract_id'),
                                  'price_plan_code': usage_register_data.get('price_plan_code')
                                  }
                sum_quantity_usage_data_list.append(sum_usage_dict)
            # k5_client_idの値に基づいて、集約処理結果dictを作成
            sum_quantity_usage_data.update({k5_client_id: sum_quantity_usage_data_list})

        return sum_quantity_usage_data

    def __get_prev_month(self):
        """
        前月の日付を返す
        :return:
        """
        now = self.executed_date
        if now.month != 1:
            prev_month = now.replace(month=now.month - 1, day=1)
        else:
            prev_month = now.replace(year=now.year - 1, month=12, day=1)

        return prev_month

    def __convert_iso_utc_to_jst(self, date):
        """
        引数で受け取ったdateをJSTのTimeZoneに変換して返す
        :param date: String
        :return: 変換のdate対象
        """
        return datetime.strptime(date, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC).astimezone(timezone('Asia/Tokyo'))

    def __output_usage_data_error_reason_log(self, usage_data,error_case):
        """
        エラーログを出力して処理
        """
        self.logger.error(
            f'not synchronized {error_case} '
            f'Usage_id:{usage_data["#usage_id"]} '
            f'subscription_id:{usage_data["subscription_id"]} '
            f'Product_code:{usage_data["product_code"]} '
            f'Target_month:{usage_data["target_month"]} '
            f'Start_date_time:{usage_data["start_date_time"]} '
            f'End_date_time:{usage_data["end_date_time"]} '
            f'quantity:{usage_data["quantity"]} '
            f'Create_date_time:{usage_data["create_date_time"]}'
        )

    def _async_process_status_watch(self, response_list, client_id):
        """
        監視ロジック
        非同期処理、利用実績登録状態を監視する
        """

        if self.execute_flag == 0:
            time_now = datetime.utcnow()
        else:
            time_now = datetime.utcnow().replace(tzinfo=UTC).astimezone(timezone('Asia/Tokyo'))
        self.logger.info(f'Get async process status time is {time_now}')
        k5_tenant = [tenant for tenant in K5_TENANTS if tenant.get('client_id') == client_id][0]
        succeed_flag = None
        for i in range(0, self.register_timeout_max_num):

            if succeed_flag == 0 or succeed_flag == 1:
                break
            process_status_response_list = self.__get_async_process_status(k5_tenant, time_now)

            if process_status_response_list is not None:
                for process_status in process_status_response_list:
                    receipt_code = process_status.get("receipt_code")
                    if receipt_code == response_list[0].get("receipt_code"):
                        process_status_code = process_status.get("process_status")
                        if process_status_code == "10":
                            self.logger.info(f'async process status is processing succeed')
                            succeed_flag = 1
                            break
                        elif process_status_code == "00":
                            self.logger.info(f'async process status is processing status code is {process_status_code}')
                            time.sleep(self.retry_wait_time)
                        else:
                            self.logger.info(f'async process  was failed status code is {process_status_code}')
                            succeed_flag = 0
                            break
            else:
                self.logger.info(f'Get async process status from K5 failed... retry')
                time.sleep(self.retry_wait_time)

    def __get_async_process_status(self, k5_tenant, time_now):

        # バッチ実行日時(UTC)の年月日　このstatus取得使っている時間はUTC時間
        params = {'from_date': time_now.strftime("%Y%m%d")}

        self.logger.info(f'Start execte"/API/v2/api/asyncprocessstatus"API(K5) ...params={params}')
        # 「非同期処理状況を取得する」APIを実行する
        process_status_response = ServerUtil(self).get_k5_response(
            url=self.k5_api_endpoint + self.async_process_status_url,
            params=params,
            method='GET',
            allow_token_time_out_minutes=5,
            data=dict(),
            k5_tenant=k5_tenant)

        process_status_response_json=process_status_response.json()
        self.logger.info(f'Response status_code={process_status_response.status_code}')
        self.logger.info(f'Response body ={process_status_response_json} ')

        if process_status_response.status_code is 200:
            return process_status_response_json.get('async_process_status')
        else:
            return None