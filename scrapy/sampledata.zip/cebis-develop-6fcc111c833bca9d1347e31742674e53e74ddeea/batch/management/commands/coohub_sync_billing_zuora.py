"""
<copyright file="coohub_sync_billing_zuora.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2019-2020. All rights reserved.
</copyright>
"""
import itertools
import json
import math
import os
import sys
from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, Iterator, List, Optional, Tuple, Union

import pytz
import requests
from batch.management.batch_command_base import BatchCommandBase
from dateutil.relativedelta import relativedelta
from django.core.management.base import CommandError
from lib.const.billing_info_state import COMPLETED
from lib.const.coohub_zuora_tenant import ZUORA_TENANT
from lib.const.internal_calc import (SUBSCRIPTION_ID_POSTFIX,
                                     ZUORA_PROFITSHARE_CUSTOMFIELD_DICT)
from lib.const.opco_code import OPCO_CURRENCY
from lib.shortcuts import get_object_or_None
from lib.utils import ServerUtil, check_date_ymd_format
from subscriptions.models import ContractInfo


class Command(BatchCommandBase):
    help = 'This batch is used to synchronize the billing data between Zuora and Cebis'


    def __init__(self):
        '''コンストラクタ'''
        super().__init__()

        self.batch_name = 'synchronize billing data from Zuora'


    def add_arguments(self, parser) -> None:
        '''バッチオプション引数取得

        Args:
            parser: 引数パーサー
        '''
        # バッチ実行日時（JST）の年月日
        parser.add_argument('--executed_date', type=str, default='')

        # Cebis API関連
        parser.add_argument('--cebis_api_endpoint', type=str, default=os.environ.get('CEBIS_API_ENDPOINT'))  # エンドポイントURL
        parser.add_argument('--cebis_calculation_system_api_key', type=str, default=os.environ.get('CEBIS_CALCULATION_SYSTEM_API_KEY'))  # APIキー
        parser.add_argument('--cebis_subscriptions_url', type=str, default=os.environ.get('CEBIS_SUBSCRIPTIONS_URL'))  # 契約情報単体取得URL

        # Zuora請求実行ステータスチェックフラグ
        # このフラグを設定した場合、Zuoraから取得した請求実行（BillingRun）情報のステータスチェックを行わない
        parser.add_argument('--no_status_check', action='store_true')


    def do_validate(self, *args: Tuple[Any], **options: Dict[str, Any]) -> None:
        '''引数のバリデーション処理

        Args:
            args (Tuple[Any]): 引数（未使用）
            options (Dict[str, Any]): キーワード引数

        Raises:
            CommandError: バリデーションエラー
        '''
        # [executed_date]のフォーマットチェック
        if options['executed_date'] and not check_date_ymd_format(datetime=options['executed_date']):
            raise CommandError('executed_date was invalid format in this batch parameter')


    @staticmethod
    def _format_billing(billing: Decimal, decimal_places: Optional[int]) -> str:
        '''金額の出力フォーマットを変更した文字列を返す

        フォーマット内容
        ・金額小数点の桁数の整形
        ・金額への整数

        Args:
            billing (Decimal): フォーマット前の金額
            decimal_places (Optional[int]): 金額の小数点桁（>=0）

        Returns:
            str: フォーマット後の金額文字列
        '''
        if decimal_places is None or decimal_places == 0:
            # 小数点桁がNoneや0の場合は整数（小数点切り上げ）へ変換
            # TODO: APO展開時に見直し
            return str(math.ceil(billing))
        else:
            decimal_format = '{:.' + str(decimal_places) + 'f}'
            return decimal_format.format(billing)


    @staticmethod
    def _convert_to_int_or_float(quantity: float) -> Union[int, float]:
        '''引数の数が整数であれば整数型に変換して返し、それ以外はそのまま値を返す

        例：
            2.00 → 2 (int型)
            1.23 → 1.23 (float型)

        Args:
            quantity (float): 数値（実数型）

        Returns:
            Union[int, float]: 引数の数が整数であればint型に変換した数値、それ以外はそのままfloatとして返却する
        '''
        if quantity == int(quantity):
            return int(quantity)
        else:
            return quantity


    def main_process(self, *args, **options):
        '''Zuoraから請求情報一覧を取得し、Cebisに同期する

        Args:
            args (Any): 引数（未使用）
            options (Any): キーワード引数
        '''
        # バッチ実行日時（JST）の年月日
        executed_datetime = datetime.utcnow().astimezone(pytz.timezone('Asia/Tokyo'))
        executed_date = options.get('executed_date')
        if len(executed_date) > 0:
            # 本バッチのオプション引数で指定した場合はその日付で上書き
            executed_datetime = pytz.timezone('Asia/Tokyo').localize(
                datetime(
                    year=int(executed_date[0:4]),
                    month=int(executed_date[4:6]),
                    day=int(executed_date[6:8]),
                    hour=13,
                )
            )
        self.logger.info(f'executed_datetime is {executed_datetime.strftime("%Y-%m-%d %H:%M:%S")} (JST)...')

        # バッチ実行日の当月1日
        first_day_of_executed_month_datetime = executed_datetime.replace(day=1)
        first_day_of_executed_month = first_day_of_executed_month_datetime.strftime('%Y%m%d')

        # バッチ実行日の年月
        month_of_executed_date = executed_datetime.strftime('%Y%m')

        # バッチ実行日の翌月1日
        first_day_of_next_month_datetime = (executed_datetime + relativedelta(months=1)).replace(day=1)
        first_day_of_next_month = first_day_of_next_month_datetime.strftime('%Y%m%d')

        server_util = ServerUtil(self, zuora_tenant=ZUORA_TENANT)

        # Zuoraから請求対象データを取得
        profitshare_columns = ', '.join([
            f'inv_item.{col} AS {col}' for col in ZUORA_PROFITSHARE_CUSTOMFIELD_DICT.values()
        ])
        query = f"""
            SELECT
              rpc.kakinsubscriptionid__c AS subscription_id,  -- サブスクリプションID
              FORMAT_DATETIME(inv.targetdate, 'yyyyMM') AS target_month,  -- 請求対象月
              prpc.productcode__c AS product_code,  -- 商品コード
              prpc.name AS product_name,  -- 商品名（※未使用項目）
              rpc.chargenumber AS charge_number,  -- 利用明細番号
              inv.invoicenumber AS invoice_number,  -- 請求番号
              inv.amount AS amount,  -- 合計請求金額（※未使用項目）
              inv_item.balance AS balance,  -- 個別請求額
              inv_item.quantity AS quantity,  -- 利用量
              {profitshare_columns},  -- プロフィットシェアカスタムフィールド
              FORMAT_DATETIME(inv_item.servicestartdate, 'yyyyMMdd') AS service_start_date,  -- 請求のサービス開始日
              FORMAT_DATETIME(inv_item.serviceenddate, 'yyyyMMdd') AS service_end_date,  -- 請求のサービス終了日
              br.status AS billrun_status,  -- 請求実行ステータス
              br.totaltime AS billrun_totaltime  -- 請求実行時間（※未使用項目）
            FROM
              billingrun br
              JOIN invoice inv ON inv.sourceid = br.billingrunnumber
              JOIN invoiceitem inv_item ON inv_item.invoiceid = inv.id
              JOIN subscription sub ON sub.id = inv_item.subscriptionid
              JOIN rateplancharge rpc ON rpc.id = inv_item.rateplanchargeid
              JOIN productrateplancharge prpc ON prpc.id = rpc.productrateplanchargeid
            WHERE
              br.executeddate >= DATE('{first_day_of_executed_month_datetime.strftime('%Y-%m-%d')}')
              AND br.executeddate < DATE('{first_day_of_next_month_datetime.strftime('%Y-%m-%d')}')
              AND inv.source = 'BillRun'
              AND inv_item.appliedtoinvoiceitemid IS NULL
            ORDER BY
              subscription_id,
              target_month,
              product_code,
              service_end_date
        """
        query_result = server_util.get_zuora_data_query_result(query, use_index_join=True)
        if query_result is None:
            self.logger.error(f'An error occurred while executing Zuora data query = [{query}] ...')
            self.logger.info('System exit ...')
            sys.exit(0)
        elif len(query_result) == 0:
            self.logger.info('No billing data fetched from Zuora ...')
            self.logger.info('System exit ...')
            sys.exit(0)

        # サブスクリプションID、対象年月単位でグループ分け
        groupby_func = lambda x: (
            x.get('subscription_id'),
            x.get('target_month'),
        )
        invoice_iter: Iterator[Tuple[Tuple[str, str], Iterator[Dict[str, Any]]]] = \
            itertools.groupby(query_result, key=groupby_func)

        # サブスクリプションID、対象年月単位でCebisへの請求情報を作成
        no_status_check_flg: bool = options.get('no_status_check')
        billing_info_list: List[Tuple[str, str, Dict[str, Any]]] = []  # 請求情報を格納
        for ((subscription_id, target_month), invoice_item_iter) in invoice_iter:
            self.logger.info(f'Checking InvoiceItem of subscription_id = [{subscription_id}], target_month = [{target_month}]')

            # 処理中断させるかどうかのフラグ
            suspend_flg = False

            # 同じサブスクリプションID、対象年月のInvoiceItemのリスト
            invoice_item_list = list(invoice_item_iter)

            # バッチ実行時にオプション引数で'--no_status_check'が指定されている場合は請求実行のステータスチェックを行わない
            if not no_status_check_flg:
                # 請求実行のステータスが「確定済み」、「完了」以外は想定外データとして扱う
                billrun_status: str = invoice_item_list[0].get('billrun_status')
                if billrun_status not in ['Posted', 'Completed']:
                    suspend_flg = True
                    self.logger.error(f'BillingRun status is not "Posted" or "Completed". billrun_status = [{billrun_status}]')

            # 請求期間内のInvoiceItemのみを取得（バリデーション）
            invoice_items_in_period: List[Dict[str, Any]] = []
            for invoice_item in invoice_item_list:
                is_valid = True  # バリデーションOKかどうか

                # 商品コード
                product_code = invoice_item['product_code']
                self.logger.info(f"Checking invoice item of product_code = [{product_code}]")

                # 請求明細のサービス開始日（service_start_date）が請求対象期間外
                # ※3か月や6か月単位の支払いに対応にするためサービス開始日ではバリデーションを行わないのでコメントアウト
                # service_start_date: str = invoice_item.get('service_start_date')
                # if service_start_date < first_day_of_executed_month:
                #     self.logger.error(f'Service start date is before first day of executed month. service_start_date = [{service_start_date}]')
                #     is_valid = False

                # 請求明細のサービス終了日（service_end_date）が請求対象期間外
                service_end_date: str = invoice_item.get('service_end_date')
                if service_end_date >= first_day_of_next_month:
                    self.logger.error(f'Service end date is beyond first day of next month. service_end_date = [{service_end_date}]')
                    is_valid = False

                # バリデーションOK
                if is_valid:
                    self.logger.info(f'Validation success. product_code = [{product_code}]')
                    invoice_items_in_period.append(invoice_item)
                else:
                    # バリデーションが1つでもNGであれば後続処理で中断させる
                    suspend_flg = True

            # バリデーションOKなInvoiceItemがない場合は次のサブスクリプションID、請求対象日のデータを参照する
            if len(invoice_items_in_period) == 0:
                continue

            # InvoiceItemの中で最も古いのServiceStartDateを取得
            oldest_service_start_date: str = min(
                [invoice_item.get('service_start_date') for invoice_item in invoice_items_in_period]
            )

            # InvoiceItemの中で最も新しいServiceEndDateを取得
            latest_service_end_date: str = max(
                [invoice_item.get('service_end_date') for invoice_item in invoice_items_in_period]
            )

            # Cebisの契約情報取得
            # TODO: 契約情報から[仕向け地]を取得したいが、Cebis自身が[契約情報単体取得]APIを実行できないため、DBから直接契約情報を取得している（今後の課題）
            contract_info_from_cebis_db: ContractInfo = get_object_or_None(ContractInfo, pk=subscription_id)
            if contract_info_from_cebis_db is None:
                self.logger.error(f'Subscription not found in contract_info table. subscription_id = [{subscription_id}]')
                continue

            # OPCOコード
            opco_code: str = contract_info_from_cebis_db.opco_code

            # 仕向け地の通貨情報
            opco_currency_info: Optional[str] = OPCO_CURRENCY.get(opco_code)
            if not opco_currency_info:
                self.logger.error(f'Currency information not found in Cebis master. opco_code = [{opco_code}]')
                continue

            # 仕向け地の通貨単位
            opco_unit_of_money: Optional[str] = opco_currency_info.get('CURRENCY')
            if not opco_unit_of_money:
                self.logger.error(f'Unit of money information not found in Cebis master. opco_code = [{opco_code}]')
                continue

            # 仕向け地の通貨小数桁
            if 'DECIMAL_PLACES' not in opco_currency_info:
                self.logger.error(f'Decimal place info not found in Cebis master. opco_code = [{opco_code}]')
                continue

            # 通貨小数桁が正の数かチェック
            opco_decimal_places: Optional[int] = opco_currency_info.get('DECIMAL_PLACES')
            if not opco_decimal_places and opco_decimal_places < 0:
                self.logger.error(f'Decimal place is set as negative number in Cebis master. opco_code = [{opco_code}]')
                continue

            # ①請求金額の明細（商品コード毎に生成）
            billing_detail_list: List[str, Any] = []  # 請求明細情報を格納
            invoice_item_per_product = itertools.groupby(invoice_items_in_period, lambda x: x['product_code'])
            for (product_code, product_invoice_item_iter) in invoice_item_per_product:
                product_invoice_item_list = list(product_invoice_item_iter)  # 同じ商品コードのInvoiceItemリスト

                # 明細金額は各InvoiceItemの金額合計値
                product_billing: Decimal = sum([Decimal(str(invoice_item['balance'])) for invoice_item in product_invoice_item_list])

                # 明細金額を仕向け地の金額フォーマットに変更
                billing_formatted: str = Command._format_billing(product_billing, opco_decimal_places)

                # 数量は最新のInvoiceItemの数量を取得（float型で格納されているので、整数の場合は整数に変換する）
                latest_quantity: float = product_invoice_item_list[-1]['quantity']
                latest_quantity_formatted: Union[int, float] = Command._convert_to_int_or_float(latest_quantity)

                billing_detail = {
                    'product_code': product_code,
                    'license_quantity': math.ceil(latest_quantity),  # 小数点切り上げ
                    'billing': billing_formatted,
                    'quantity': str(latest_quantity_formatted),
                    'billing_usage_details': None,  # TODO: T.B.D.
                }
                billing_detail_list.append(billing_detail)

            # ①請求金額明細の合計
            billing_sum = sum([Decimal(billing_detail['billing']) for billing_detail in billing_detail_list])

            # ①請求金額情報
            billing_info: Dict[str, Any] = {
                'start_date': oldest_service_start_date,
                'end_date': latest_service_end_date,
                'billing': str(billing_sum),
                'unit_of_money': opco_unit_of_money,
                'state': COMPLETED,  # 固定
                'billing_details': billing_detail_list,
            }

            # ②プロフィットシェア金額の明細
            # プロフィットシェアの場合、各プロフィットシェア項目の商品コードや金額を設定
            profitshare_detail_list: List[str, Any] = []
            invoice_item_per_product = itertools.groupby(invoice_items_in_period, lambda x: x['product_code'])
            for (product_code, product_invoice_item_iter) in invoice_item_per_product:
                # 同一商品の中で最新のInvoiceItemを取得する
                latest_invoice_item = list(product_invoice_item_iter)[-1]

                # 数量がfloat型で格納されているので、整数の場合は整数に変換する
                latest_quantity: float = latest_invoice_item.get('quantity')
                latest_quantity_formatted: Union[int, float] = Command._convert_to_int_or_float(latest_quantity)

                for (code, col_name) in ZUORA_PROFITSHARE_CUSTOMFIELD_DICT.items():
                    # 明細金額は仕向け地の金額フォーマットに変更
                    try:
                        billing_str = latest_invoice_item.get(col_name)
                        if not billing_str:
                            # 金額がNoneや空文字の場合は無視
                            self.logger.error(f"Profitshare value not set in Zuora. invoice_number = [{latest_invoice_item.get('invoice_number')}], product_code = [{latest_invoice_item.get('product_code')}], column = [{col_name}]")
                            suspend_flg = True
                            continue

                        billing_formatted: str = Command._format_billing(Decimal(billing_str), opco_decimal_places)
                    except InvalidOperation:
                        # 金額文字列の変換エラーも無視
                        self.logger.error(f"Profitshare value is not number. invoice_number = [{latest_invoice_item.get('invoice_number')}], product_code = [{latest_invoice_item.get('product_code')}, column = [{col_name}], value = [{latest_invoice_item.get(col_name)}]")
                        suspend_flg = True
                        continue

                    profitshare_detail = {
                        'product_code': product_code + code,
                        'license_quantity': math.ceil(latest_quantity),  # 小数点切り上げ
                        'billing': billing_formatted,
                        'quantity': str(latest_quantity_formatted),
                        'billing_usage_details': None,  # TODO: T.B.D.
                    }
                    profitshare_detail_list.append(profitshare_detail)

            # ②プロフィットシェア金額の合計を求める
            profitshare_sum = sum([Decimal(profitshare_detail['billing']) for profitshare_detail in profitshare_detail_list])

            # ②プロフィットシェア金額情報
            profitshare_info: Dict[str, Any] = {
                'start_date': oldest_service_start_date,
                'end_date': latest_service_end_date,
                'billing': str(profitshare_sum),
                'unit_of_money': opco_unit_of_money,
                'state': COMPLETED,  # 固定
                'billing_details': profitshare_detail_list,
            }

            # バリデーションエラーでないサブスクリプションID、対象月度の請求データのみ処理対象とする
            if suspend_flg:
                self.logger.error(f'Skipped abnormal billing data. subscription_id = [{subscription_id}], target_month = [{target_month}]')
            else:
                billing_info_list.extend([
                    (subscription_id, target_month, billing_info),  # ①請求金額
                    (subscription_id + SUBSCRIPTION_ID_POSTFIX, target_month, profitshare_info),  # ②プロフィットシェア金額
                ])

        # [請求情報単体登録]APIを使用してCebisに請求情報を順次登録する
        api_key: str = options.get('cebis_calculation_system_api_key')
        for (subscription_id, target_month, billing_info) in billing_info_list:
            # 請求情報単体登録API URL
            api_url: str = options.get('cebis_api_endpoint') \
                           + options.get('cebis_subscriptions_url') \
                           + '/' + subscription_id + '/billing/' + target_month

            # API実行
            post_billing_response: requests.Response = server_util.get_cebis_response(
                url=api_url,
                method='POST',
                params=dict(),
                api_key=api_key,
                data=json.dumps(billing_info),
            )
            status_code = post_billing_response.status_code
            is_success: bool = post_billing_response.json().get('success')
            if status_code == 200 and is_success == True:
                self.logger.info(f'Billing register succeeded. subscription_id = [{subscription_id}]')
            else:
                self.logger.error(f'Billing register failed. subscription_id = [{subscription_id}]')
                self.logger.info(f'    target_month = [{target_month}]')
                self.logger.info(f'    body = [{billing_info}]')
                self.logger.info(f'    status_code = [{status_code}]')
                self.logger.info(f'    message = [{post_billing_response.content}]')
