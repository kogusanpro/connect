"""
<copyright file="create_billing_record.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import argparse
import copy

from django.db import transaction
from django.db.utils import IntegrityError
from django.utils.timezone import datetime
import datetime as _datetime

from batch.services import query_billing_target
from batch.management.batch_command_base import BatchCommandBase
from subscriptions.models import BillingInfo, BillingDetailInfo, ContractServiceInfo
from lib.const.billing_info_state import NEW
from lib.utils import DateTimeUtil


class Command(BatchCommandBase):
    help = 'This Command Create Billing info records'

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.batch_name = 'create billing info batch'
        self.target_month = ''

    def add_arguments(self, parser):
        """
        実行時に指定可能なパラメータの引数への追加処理
        :param parser:
        :return:
        """
        # テストや動作検証のため、last_monthオプションを外部から指定できるようにする
        parser.add_argument('--target_month', type=str,
                            default=DateTimeUtil.get_current_ym())  # 初期値はバッチ実行日時の年月

    def __get_current_ym_end_day(self, target_month):
        """
        対象月度の月末日を取得する
        :return:
        """
        next_month = target_month.replace(day=28) + _datetime.timedelta(days=4)  # this will never fail
        return next_month - _datetime.timedelta(days=next_month.day)

    def __create_billing(self, contract_service: ContractServiceInfo) -> BillingInfo:
        """
        契約サービス情報から請求情報のレコードを生成して返す
        :type contract_service: ContractServiceInfo
        :param contract_service:
        :rtype :BillingInfo
        :return:
        """

        now = DateTimeUtil.utc_now_aware()
        billing = BillingInfo()

        billing.subscription_id = contract_service.subscription_id      # サブスクリプションID
        billing.target_month = self.target_month                        # 対象月度
        billing.start_date = None                                       # 請求対象期間開始日
        billing.end_date = None                                         # 請求対象期間終了日
        billing.billing = 0                                             # 請求金額(総額)
        billing.unit_of_money = None                                    # 計算状態
        billing.state = NEW                                             # 計算状態
        billing.created_time = now                                      # 作成日時
        billing.updated_time = now                                      # 更新日時

        return billing

    def __create_profitshare_billing(self, contract_service: ContractServiceInfo) -> BillingInfo:
        """
        契約サービス情報からプロフィットシェア請求情報のレコードを生成して返す
        :type contract_service: ContractServiceInfo
        :param contract_service:
        :rtype :BillingInfo
        :return:
        """

        copied_contract_service = copy.copy(contract_service)
        copied_contract_service.subscription_id += 'G'

        return self.__create_billing(copied_contract_service)

    def __create_billing_detail(self, contract_service: ContractServiceInfo) -> BillingDetailInfo:
        """
        契約サービス情報から請求明細情報のレコードを生成して返す
        :type contract_service: ContractServiceInfo
        :param contract_service:
        :rtype: BillingDetailInfo
        :return:
        """

        now = DateTimeUtil.utc_now_aware()
        billing_detail = BillingDetailInfo()
        billing_detail.subscription_id = contract_service.subscription_id       # サブスクリプションID
        billing_detail.target_month = self.target_month                         # 対象月度
        billing_detail.product_code = contract_service.product_code             # 商品コード
        billing_detail.license_quantity = None                                  # ライセンス数
        billing_detail.billing = 0                                              # 商品コード別請求金額
        billing_detail.quantity = None                                          # 合計利用量
        billing_detail.created_time = now                                       # 作成日時
        billing_detail.updated_time = now                                       # 更新日時

        return billing_detail

    def __create_profitshare_billing_detail(self, contract_service: ContractServiceInfo,
                                            profuct_code_i: int) -> BillingInfo:
        """
        契約サービス情報からプロフィットシェア請求明細情報のレコードを生成して返す
        :type contract_service: ContractServiceInfo
        :param contract_service:
        :type profuct_code_i: int
        :param profuct_code_i:
        :rtype :BillingInfo
        :return:
        """

        copied_contract_service = copy.deepcopy(contract_service)
        copied_contract_service.subscription_id += 'G'
        copied_contract_service.product_code.pk += f'C{profuct_code_i}'

        return self.__create_billing_detail(copied_contract_service)

    def __exists_billing_info(self, subscription_id):
        """
        指定されたサブスクリプションIDの請求データが登録済みかをチェックして返す
        登録済みの場合はエラーログの出力も合わせて行う
        :type subscription_id int
        :param subscription_id:
        :rtype : bool
        :return:
        """
        try:
            BillingInfo.objects.get(subscription_id=subscription_id, target_month=self.target_month)
            self.logger.error(f'subscription_id {subscription_id} is already exists in billing_info')
            return True
        except BillingInfo.DoesNotExist:
            return False

    def __exists_profitshare_billing_info(self, subscription_id):
        """
        指定されたサブスクリプションIDのプロフィットシェア請求データが登録済みかをチェックして返す
        :type subscription_id int
        :param subscription_id:
        :rtype : bool
        :return:
        """
        return self.__exists_billing_info(subscription_id + 'G')

    def __exists_billing_detail(self, subscription_id, product):
        """
        指定されたサブスクリプションIDの請求データが登録済みかをチェックして返す
        登録済みの場合はエラーログの出力も合わせて行う
        :type subscription_id int
        :param subscription_id:
        :type product object
        :param product:
        :rtype : bool
        :return:
        """
        try:
            BillingDetailInfo.objects.get(subscription_id=subscription_id, target_month=self.target_month,
                                          product_code=product)
            self.logger.error(f'subscription_id {subscription_id} and product_code {product.product_code} is '
                              f'already exists in billing_info_detail')

            return True
        except BillingDetailInfo.DoesNotExist:
            return False

    def __exists_profitshare_billing_detail(self, subscription_id, product, profuct_code_i):
        """
        指定されたサブスクリプションIDのプロフィットシェア請求データが登録済みかをチェックして返す
        登録済みの場合はエラーログの出力も合わせて行う
        :type subscription_id int
        :param subscription_id:
        :type product object
        :param product:
        :type profuct_code_i: int
        :param profuct_code_i:
        :rtype : bool
        :return:
        """

        copied_product = copy.copy(product)
        copied_product.product_code += f'C{profuct_code_i}'
        subscription_id += 'G'
        return self.__exists_billing_detail(subscription_id, copied_product)

    @transaction.atomic()
    def main_process(self, *args, **options):
        """
        請求対象レコード生成バッチメイン処理
        :param args:
        :param options:
        :return:
        """

        self.target_month = options['target_month']
        days = self.__get_current_ym_end_day(_datetime.date(int(self.target_month[0:4]), int(self.target_month[4:6]), 1))
        now = DateTimeUtil.utc_now_aware()
        # begin_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        # begin_of_next_month = DateTimeUtil.get_begin_of_next_month(now)
        # begin_of_month = now.replace(year=int(target_month[0:4]), month=int(target_month[4:6]), day=1, hour=0,
        # minute=0, second=0, microsecond=0)
        batch_time = now.replace(year=int(self.target_month[0:4]), month=int(self.target_month[4:6]), day=days.day, hour=14,
                                 minute=0, second=0, microsecond=0)
        records = query_billing_target(batch_time)
        billing_header_cnt = 0
        billing_detail_cnt = 0
        profitshare_header_cnt = 0
        profitshare_detail_cnt = 0
        try:
            prev_subscription_id = ''
            for record in records:
                # サブスクリプションIDがブレイクしたらヘッダレコードを生成
                if prev_subscription_id != record.subscription_id:
                    billing = self.__create_billing(record)
                    prev_subscription_id = record.subscription_id
                    if not self.__exists_billing_info(billing.subscription_id):
                        billing.save()
                        billing_header_cnt += 1
                    if not self.__exists_profitshare_billing_info(billing.subscription_id):
                        profitshare_billing = self.__create_profitshare_billing(record)
                        profitshare_billing.save()
                        profitshare_header_cnt += 1

                billing_detail = self.__create_billing_detail(record)
                if not self.__exists_billing_detail(billing_detail.subscription_id, billing_detail.product_code):
                    billing_detail.save()
                    billing_detail_cnt += 1
                for i in range(6, 12):
                    if not self.__exists_profitshare_billing_detail(billing_detail.subscription_id,
                                                                    billing_detail.product_code, i):
                        profitshare_billing_detail = self.__create_profitshare_billing_detail(record, i)
                        profitshare_billing_detail.save()
                        profitshare_detail_cnt += 1

        except IntegrityError as e:
            self.logger.error(e)
            raise e

        self.logger.info('Successfully Created Billing info records')
        self.logger.info(f'Billing info created {billing_header_cnt} records')
        self.logger.info(f'Billing Detail info Created {billing_detail_cnt} records')
        self.logger.info(f'Profitshare Billing info created {profitshare_header_cnt} records')
        self.logger.info(f'Profitshare Billing Detail info Created {profitshare_detail_cnt} records')
