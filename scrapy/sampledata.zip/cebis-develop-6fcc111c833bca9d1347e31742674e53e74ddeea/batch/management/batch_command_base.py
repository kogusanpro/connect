"""
<copyright file="batch_command_base.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.core.management.base import BaseCommand
import logging
import time

class BatchCommandBase(BaseCommand):
    """
    バッチ処理コマンドの基底クラス
    """

    logger = None   # 単体テストのモック用にここで明示的に宣言

    def __init__(self):
        """
        コンストラクタ
        """
        super().__init__()
        self.logger = logging.getLogger('django')
        self.batch_name = ''    # 継承側でオーバーライドしてもらう

    def handle(self, *args, **options):
        """
        バッチコマンドメイン処理
        :param args:
        :param options:
        :return:
        """
        self.logger.info('Start %s' % self.batch_name)
        start_time = time.time()
        self.do_validate(*args, **options)
        self.main_process(*args, **options)
        self.logger.info('End %s' % self.batch_name)
        elapsed_time = time.time() - start_time
        self.logger.info('Elapsed Time = %.2f sec' % elapsed_time)

    def main_process(self, *args, **options):
        """
        継承先で実装するメインの処理
        :param args:
        :param options:
        :return:
        """
        raise Exception('child class must implements main process!')

    def do_validate(self, *args, **options):
        """
        継承先で任意で実装するバリデーション処理
        :param args:
        :param options:
        :return:
        """
        pass
