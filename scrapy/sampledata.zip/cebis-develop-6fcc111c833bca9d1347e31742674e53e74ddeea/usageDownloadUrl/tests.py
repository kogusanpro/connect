"""
<copyright file="tests.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from rest_framework.test import APIClient
from rest_framework.test import APITestCase
import string
import random
import boto3
import os
from django.conf import settings
from botocore.exceptions import ClientError
from unittest import mock
import sys


@mock.patch('usageDownloadUrl.views.aws_batch.submit_job')
class UsageDownloadUrlTest(APITestCase):

    def setUp(self):
        self.client = APIClient()
        """
        # # 環境設定済みので、createは不必要です。
        # os.environ['S3_USAGE_DOWNLOAD_BUCKET'] = self.request_id = \
        #     self._create_request_id()
        """
        self.request_id = self._create_request_id()
        self.s3 = boto3.client('s3', endpoint_url=settings.AWS_S3_ENDPOINT)
        """
        # # 環境設定済みので、create_bucketは不必要です。
        # self.s3.create_bucket(
        #     ACL='private',
        #     Bucket=os.environ['S3_USAGE_DOWNLOAD_BUCKET'],
        #     CreateBucketConfiguration={
        #         'LocationConstraint': 'ap-northeast-1'
        #     },
        # )
        """
        os.environ['BATCH_USAGE_DOWNLOAD_URL_JOBNAME'] = 'jobName'
        os.environ['BATCH_USAGE_DOWNLOAD_URL_JOBQUEUE'] = 'jobQueue'
        os.environ['BATCH_USAGE_DOWNLOAD_URL_JOBDEFINITION'] = 'jobDefinition'

    def tearDown(self):
        """
        # # Cebis_サービスレベルを定義して、本番とQA環境で全部のデータは10年間の保管が必要です。
        """
        if sys.argv[-1] == str('charlie.settings.ci'):
            bucket = os.environ['S3_USAGE_DOWNLOAD_BUCKET']
            s3 = boto3.resource('s3')
            Bucket = s3.Bucket(bucket)
            Bucket.objects.filter(Prefix='2018/').delete()
        else:
            pass

    def test_internal_calc_not_true_false(self, mock):
        """
        internal_calcがtrueあるいはfalseでない時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=UTC&internal_calc=xxxx',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_include_trial_data_not_true_false(self, mock):
        """
        include_trial_dataがtrueあるいはfalseでない時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=UTC'
            '&include_trial_data=xxxx',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_internal_calc_true(self, mock):
        """
        internal_calcがtrueで設定されるとバッチに--internal_calcフラグが渡される
        """
        mock.return_value = True
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=UTC'
            '&internal_calc=true&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_once_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': self.request_id +
                        ' 2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000.csv '
                        '--from_created_date 20180301 --to_created_date 20180331 --time_zone UTC '
                        '--internal_calc --subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

    def test_include_trial_data_true(self, mock):
        """
        include_trial_dataがtrueで設定されるとバッチに--include_trial_dataフラグが渡される
        """
        mock.return_value = True
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=UTC'
            '&subscription_id=dpa_70015100&product_code=ABCD1000&include_trial_data=true',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_once_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': self.request_id +
                        ' 2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000.csv '
                        '--from_created_date 20180301 --to_created_date 20180331 --time_zone UTC '
                        '--subscription_id dpa_70015100 --product_code ABCD1000 --include_trial_data'
            }
        )

    def test_internal_calc_false(self, mock):
        """
        internal_calcがfalseで設定されるとバッチに--internal_calcフラグが渡される
        """
        mock.return_value = True
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=UTC'
            '&internal_calc=true&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_once_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': self.request_id +
                        ' 2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000.csv '
                        '--from_created_date 20180301 --to_created_date 20180331 --time_zone UTC '
                        '--internal_calc --subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

    def test_include_trial_data_false(self, mock):
        """
        include_trial_dataがfalseで設定されるとバッチに--include_trial_dataフラグが渡される
        """
        mock.return_value = True
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=UTC'
            '&subscription_id=dpa_70015100&product_code=ABCD1000&include_trial_data=true',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_once_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': self.request_id +
                        ' 2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000.csv '
                        '--from_created_date 20180301 --to_created_date 20180331 --time_zone UTC '
                        '--subscription_id dpa_70015100 --product_code ABCD1000 --include_trial_data'
            }
        )

    def test_from_created_date_to_created_date_to_created_datetime(self, mock):
        """
        from_created_dateとto_created_dateが入力の場合、to_created_datetimeを入力すると400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=UTC'
            '&to_created_datetime=20180331T235959Z&internal_calc=false&include_trial_data=false',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_time_zone_format(self, mock):
        """
        time_zoneがUTCあるいはJSTでない時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=from_created_date&time_zone=XXX',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_from_created_date_format(self, mock):
        """
        from_created_dateがフォーマットエラーの時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=from_created_date&time_zone=UTC',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_to_created_date_format(self, mock):
        """
        to_created_dateがフォーマットエラーの時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=to_created_date&from_created_date=20180301&time_zone=UTC',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_rom_created_date_gt_to_created_date(self, mock):
        """
        from_created_date > to_created_dateの時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180301&from_created_date=20180302&time_zone=UTC',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_from_created_date_and_not_to_created_date_format(self, mock):
        """
        from_created_dateを入力、to_created_dateが未入力の時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180301&time_zone=UTC',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_not_from_created_date_and_to_created_date(self, mock):
        """
        from_created_dateを未入力、to_created_dateが入力の時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?from_created_date=20180301&time_zone=UTC',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_from_created_datetime_and_to_created_datetime_time_zone(self, mock):
        """
        from_created_datetimeを入力、to_created_datetimeを入力、time_zoneを入力の時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?to_created_datetime=20180331T235959Z&from_created_datetime=20180301T000000Z&time_zone=UTC',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_from_created_datetime_format(self, mock):
        """
        from_created_datetimeがフォーマットエラーの時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?to_created_datetime=20180301T000000Z&from_created_datetime=from_created_datetime',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_to_created_datetime_format(self, mock):
        """
        to_created_datetimeがフォーマットエラーの時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?to_created_datetime=to_created_datetime&from_created_datetime=20180301T000000Z',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_from_created_datetime_gt_to_created_datetime(self, mock):
        """
        from_created_datetime > to_created_datetimeの時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?to_created_datetime=20180301T000000Z&from_created_datetime=20180331T235959Z',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_not_from_created_datetime_and_to_created_datetime(self, mock):
        """
        from_created_datetime未入力、to_created_datetime入力の時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?to_created_datetime=20180331T235959Z',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_from_created_datetime_and_not_to_created_datetime(self, mock):
        """
        from_created_datetime入力、to_created_datetime未入力の時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?from_created_datetime=20180301T000000Z',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_not_from_created_not_to_created(self, mock):
        """
        from_created_date、to_created_date、from_created_datetime、to_created_datetime未入力の時400エラーを返す
        """
        response = self.client.get(
            '/usageDownloadUrl/?',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        mock.assert_not_called()

    def test_csv_name_1(self, mock):
        """
        to_created_dateとfrom_created_dateが別日になり明示的にUTCを指定した場合のファイル名のチェック
        """
        mock.return_value = True
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=UTC'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_once_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': self.request_id +
                        ' 2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000.csv '
                        '--from_created_date 20180301 --to_created_date 20180331 --time_zone UTC '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

    def test_csv_name_2(self, mock):
        """
        to_created_dateとfrom_created_dateが同日になり明示的にUTCを指定した場合のファイル名のチェック
        """
        mock.return_value = True
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180301&from_created_date=20180301&time_zone=UTC'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_once_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': self.request_id +
                        ' 2018/201803/verified_usage_UTC_20180301_dpa_70015100_ABCD1000.csv '
                        '--from_created_date 20180301 --to_created_date 20180301 --time_zone UTC '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

    def test_csv_name_3(self, mock):
        """
        to_created_datetimeとfrom_created_datetimeが別日になる場合のファイル名のチェック
        """
        mock.return_value = True
        response = self.client.get(
            '/usageDownloadUrl/?to_created_datetime=20180331T000000Z&from_created_datetime=20180301T000000Z'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_20180301T000000Z-20180331T000000Z_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_once_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': self.request_id +
                        ' 2018/201803/verified_usage_20180301T000000Z-20180331T000000Z_dpa_70015100_ABCD1000.csv '
                        '--time_zone  '
                        '--from_created_datetime 20180301T000000Z --to_created_datetime 20180331T000000Z '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

    def test_csv_name_4(self, mock):
        """
        to_created_datetimeとfrom_created_datetimeが同日になる場合のファイル名のチェック
        """
        mock.return_value = True
        response = self.client.get(
            '/usageDownloadUrl/?to_created_datetime=20180301T000000Z&from_created_datetime=20180301T000000Z'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_20180301T000000Z_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_once_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': self.request_id +
                        ' 2018/201803/verified_usage_20180301T000000Z_dpa_70015100_ABCD1000.csv --time_zone  '
                        '--from_created_datetime 20180301T000000Z --to_created_datetime 20180301T000000Z '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

    def test_csv_name_5(self, mock):
        """
        to_created_dateとfrom_created_dateが別日になり明示的にJSTを指定した場合のファイル名のチェック
        """
        mock.return_value = True
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=JST'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_JST_20180301-20180331_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_once_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': self.request_id +
                        ' 2018/201803/verified_usage_JST_20180301-20180331_dpa_70015100_ABCD1000.csv '
                        '--from_created_date 20180301 --to_created_date 20180331 --time_zone JST '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

    def test_csv_name_6(self, mock):
        """
        to_created_dateとfrom_created_dateが同日になり明示的にJSTを指定した場合のファイル名のチェック
        """
        mock.return_value = True
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180301&from_created_date=20180301&time_zone=JST'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_JST_20180301_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_once_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': self.request_id +
                        ' 2018/201803/verified_usage_JST_20180301_dpa_70015100_ABCD1000.csv '
                        '--from_created_date 20180301 --to_created_date 20180301 --time_zone JST '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

    def test_csv_name_7(self, mock):
        """
        to_created_dateとfrom_created_dateが別日になりファイル名が重複した場合にファイル名にポストフィックスがつくテスト
        """
        mock.return_value = True

        request_id = self._create_request_id()
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=UTC'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': request_id +
                        ' 2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000.csv '
                        '--from_created_date 20180301 --to_created_date 20180331 --time_zone UTC '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

        request_id = self._create_request_id()
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=UTC'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000_' + request_id + '.csv'
        ))
        mock.assert_called_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': request_id +
                        ' 2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000_' + request_id + '.csv '
                        '--from_created_date 20180301 --to_created_date 20180331 --time_zone UTC '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

        request_id = self._create_request_id()
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=UTC'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000_' + request_id + '.csv'
        ))
        mock.assert_called_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': request_id +
                        ' 2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100_ABCD1000_' + request_id + '.csv '
                        '--from_created_date 20180301 --to_created_date 20180331 --time_zone UTC '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

    def test_csv_name_8(self, mock):
        """
        to_created_datetimeとfrom_created_datetimeが別日になりファイル名が重複した場合にファイル名にポストフィックスがつくテスト
        """
        mock.return_value = True

        request_id = self._create_request_id()
        response = self.client.get(
            '/usageDownloadUrl/?to_created_datetime=20180331T000000Z&from_created_datetime=20180301T000000Z'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_20180301T000000Z-20180331T000000Z_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': request_id +
                        ' 2018/201803/verified_usage_20180301T000000Z-20180331T000000Z_dpa_70015100_ABCD1000.csv '
                        '--time_zone  --from_created_datetime 20180301T000000Z --to_created_datetime 20180331T000000Z '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

        request_id = self._create_request_id()
        response = self.client.get(
            '/usageDownloadUrl/?to_created_datetime=20180331T000000Z&from_created_datetime=20180301T000000Z'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_20180301T000000Z-20180331T000000Z_dpa_70015100_ABCD1000_'
                     + request_id + '.csv'
        ))
        mock.assert_called_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': request_id +
                        ' 2018/201803/verified_usage_20180301T000000Z-20180331T000000Z_dpa_70015100_ABCD1000_'
                        + request_id + '.csv --time_zone  '
                        '--from_created_datetime 20180301T000000Z --to_created_datetime 20180331T000000Z '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

        request_id = self._create_request_id()
        response = self.client.get(
            '/usageDownloadUrl/?to_created_datetime=20180331T000000Z&from_created_datetime=20180301T000000Z'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_20180301T000000Z-20180331T000000Z_dpa_70015100_ABCD1000_'
                     + request_id + '.csv'
        ))
        mock.assert_called_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': request_id +
                        ' 2018/201803/verified_usage_20180301T000000Z-20180331T000000Z_dpa_70015100_ABCD1000_'
                        + request_id + '.csv --time_zone  '
                        '--from_created_datetime 20180301T000000Z --to_created_datetime 20180331T000000Z '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

    def test_csv_name_9(self, mock):
        """
        to_created_dateとfrom_created_dateが同日になりファイル名が重複した場合にファイル名にポストフィックスがつくテスト
        """
        mock.return_value = True

        request_id = self._create_request_id()
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180301&from_created_date=20180301&time_zone=UTC'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': request_id +
                        ' 2018/201803/verified_usage_UTC_20180301_dpa_70015100_ABCD1000.csv '
                        '--from_created_date 20180301 --to_created_date 20180301 --time_zone UTC '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

        request_id = self._create_request_id()
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180301&from_created_date=20180301&time_zone=UTC'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301_dpa_70015100_ABCD1000_' + request_id + '.csv'
        ))
        mock.assert_called_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': request_id +
                        ' 2018/201803/verified_usage_UTC_20180301_dpa_70015100_ABCD1000_' + request_id + '.csv '
                        '--from_created_date 20180301 --to_created_date 20180301 --time_zone UTC '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

        request_id = self._create_request_id()
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180301&from_created_date=20180301&time_zone=UTC'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301_dpa_70015100_ABCD1000_' + request_id + '.csv'
        ))
        mock.assert_called_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': request_id +
                        ' 2018/201803/verified_usage_UTC_20180301_dpa_70015100_ABCD1000_' + request_id + '.csv '
                        '--from_created_date 20180301 --to_created_date 20180301 --time_zone UTC '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

    def test_csv_name_10(self, mock):
        """
        to_created_datetimeとfrom_created_datetimeが同日になりファイル名が重複した場合にファイル名にポストフィックスがつくテスト
        """
        mock.return_value = True

        request_id = self._create_request_id()
        response = self.client.get(
            '/usageDownloadUrl/?to_created_datetime=20180301T000000Z&from_created_datetime=20180301T000000Z'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_20180301T000000Z_dpa_70015100_ABCD1000.csv'
        ))
        mock.assert_called_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': request_id +
                        ' 2018/201803/verified_usage_20180301T000000Z_dpa_70015100_ABCD1000.csv '
                        '--time_zone  --from_created_datetime 20180301T000000Z --to_created_datetime 20180301T000000Z '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

        request_id = self._create_request_id()
        response = self.client.get(
            '/usageDownloadUrl/?to_created_datetime=20180301T000000Z&from_created_datetime=20180301T000000Z'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_20180301T000000Z_dpa_70015100_ABCD1000_'
                     + request_id + '.csv'
        ))
        mock.assert_called_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': request_id +
                        ' 2018/201803/verified_usage_20180301T000000Z_dpa_70015100_ABCD1000_'
                        + request_id + '.csv --time_zone  '
                        '--from_created_datetime 20180301T000000Z --to_created_datetime 20180301T000000Z '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

        request_id = self._create_request_id()
        response = self.client.get(
            '/usageDownloadUrl/?to_created_datetime=20180301T000000Z&from_created_datetime=20180301T000000Z'
            '&subscription_id=dpa_70015100&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_20180301T000000Z_dpa_70015100_ABCD1000_'
                     + request_id + '.csv'
        ))
        mock.assert_called_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': request_id +
                        ' 2018/201803/verified_usage_20180301T000000Z_dpa_70015100_ABCD1000_'
                        + request_id + '.csv --time_zone  '
                        '--from_created_datetime 20180301T000000Z --to_created_datetime 20180301T000000Z '
                        '--subscription_id dpa_70015100 --product_code ABCD1000'
            }
        )

    def test_csv_name_11(self, mock):
        """
        subscription_idが設定されていない時のファイル名のチェック
        """
        mock.return_value = True
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=UTC'
            '&internal_calc=true&product_code=ABCD1000',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301-20180331_ABCD1000.csv'
        ))
        mock.assert_called_once_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': self.request_id +
                        ' 2018/201803/verified_usage_UTC_20180301-20180331_ABCD1000.csv '
                        '--from_created_date 20180301 --to_created_date 20180331 --time_zone UTC '
                        '--internal_calc --product_code ABCD1000'
            }
        )

    def test_csv_name_12(self, mock):
        """
        product_codeが設定されていない時のファイル名のチェック
        """
        mock.return_value = True
        response = self.client.get(
            '/usageDownloadUrl/?to_created_date=20180331&from_created_date=20180301&time_zone=UTC'
            '&subscription_id=dpa_70015100&include_trial_data=true',
            **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.request_id}
        )
        assert response.status_code == 200
        self.assertTrue(self._is_file(
            filename='2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100.csv'
        ))
        mock.assert_called_once_with(
            jobName='jobName',
            jobQueue='jobQueue',
            jobDefinition='jobDefinition',
            parameters={
                'Args': self.request_id +
                        ' 2018/201803/verified_usage_UTC_20180301-20180331_dpa_70015100.csv '
                        '--from_created_date 20180301 --to_created_date 20180331 --time_zone UTC '
                        '--subscription_id dpa_70015100 --include_trial_data'
            }
        )

    def _is_file(self, filename):
        """
         S3にアップロードしようとしているファイルがあるかチェック
         :return: :boolean:
        """
        try:
            boto3.client(
                's3', endpoint_url=settings.AWS_S3_ENDPOINT).head_object(
                Bucket=os.environ['S3_USAGE_DOWNLOAD_BUCKET'],
                Key=filename
            )
            return True
        except ClientError:
            return False

    def _create_request_id(self):
        """
         リクエストIDを生成
         :return: :string:
        """
        return ''.join([
            random.choice('%s%s' % (string.ascii_letters, string.digits))
            for i in range(10)
        ])


