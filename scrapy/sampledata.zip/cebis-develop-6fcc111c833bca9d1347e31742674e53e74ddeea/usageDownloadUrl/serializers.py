"""
<copyright input_file_path="serializers.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from rest_framework import serializers
from rest_framework import status
from status.models import CsvBatchProcessInfo
from datetime import datetime
from lib.validator.datetime_validator import DateTimeValidator
from lib.utils import check_date_ymd_format, check_datetime_format, DateTimeUtil
from rest_framework.exceptions import APIException
from django.utils.encoding import force_text
from lib.utils import logger


class UsageDownloadUrlGetSerializer(serializers.BaseSerializer):
    def to_representation(self, data):
        from_created_date = data.get('from_created_date')
        to_created_date = data.get('to_created_date')
        time_zone = data.get('time_zone')
        from_created_datetime = data.get('from_created_datetime')
        to_created_datetime = data.get('to_created_datetime')
        subscription_id = data.get('subscription_id')
        product_code = data.get('product_code')
        internal_calc = data.get('internal_calc')
        include_trial_data = data.get('include_trial_data')

        internal_calc_allowed_value = [
            'true',
            'false'
        ]

        include_trial_data_allowed_value = [
           'true',
           'false'
        ]

        if internal_calc is not None and internal_calc not in internal_calc_allowed_value:
            logger().error('internal_calc is choice field but allowed value was not included in this request')
            raise UsageDownloadUrlValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )
        internal_calc = True if internal_calc == 'true' else False

        if include_trial_data is not None and include_trial_data not in include_trial_data_allowed_value:
            logger().error('include_trial_data is choice field but allowed value was not included in this request')
            raise UsageDownloadUrlValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )
        include_trial_data = True if include_trial_data == 'true' else False

        if time_zone is None:
            time_zone = ''

        if from_created_date and to_created_date:
            if not time_zone:
                time_zone = 'UTC'

            if from_created_datetime or to_created_datetime:
                logger().error('Either from_created_date, to_created_date or '
                               'from_created_datetime, to_created_datetime must be specified')
                raise UsageDownloadUrlValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )

            if not DateTimeValidator.is_valid_timezone(time_zone):
                logger().error('time_zone was invalid format in this request body')
                raise UsageDownloadUrlValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )

            if not check_date_ymd_format(datetime=from_created_date):
                logger().error('from_created_date was invalid format in this request body')
                raise UsageDownloadUrlValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )

            if not check_date_ymd_format(datetime=to_created_date):
                logger().error('to_created_date was invalid format in this request body')
                raise UsageDownloadUrlValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )

            if int(from_created_date) > int(to_created_date):
                logger().error('from_created_date was greater than to_created_date in this request body')
                raise UsageDownloadUrlValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )

        elif (from_created_date and not to_created_date) \
                or (not from_created_date and to_created_date):
            logger().error('from_created_date and to_created_date are specified as a pair')
            raise UsageDownloadUrlValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        else:
            if from_created_datetime and to_created_datetime:
                if time_zone:
                    logger().error('If from_created_datetime and to_created_datetime are specified, '
                                   'time_zone must not be specified')
                    raise UsageDownloadUrlValidationError(
                        'Invalid Parameter',
                        status.HTTP_400_BAD_REQUEST
                    )

                if not check_datetime_format(datetime=from_created_datetime):
                    logger().error('from_created_datetime was invalid format in this request body')
                    raise UsageDownloadUrlValidationError(
                        'Invalid Parameter',
                        status.HTTP_400_BAD_REQUEST
                    )

                if not check_datetime_format(datetime=to_created_datetime):
                    logger().error('to_created_datetime was invalid format in this request body')
                    raise UsageDownloadUrlValidationError(
                        'Invalid Parameter',
                        status.HTTP_400_BAD_REQUEST
                    )

                if DateTimeUtil.YmdTHMSZ_utc_to_YmdHMS_utc(from_created_datetime) > \
                        DateTimeUtil.YmdTHMSZ_utc_to_YmdHMS_utc(to_created_datetime):
                    logger().error('from_created_datetime was greater than to_created_datetime in this request body')
                    raise UsageDownloadUrlValidationError(
                        'Invalid Parameter',
                        status.HTTP_400_BAD_REQUEST
                    )

            elif (from_created_datetime and not to_created_datetime) \
                    or (not from_created_datetime and to_created_datetime):
                logger().error('from_created_datetime and to_created_datetime are specified as a pair')
                raise UsageDownloadUrlValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )

            else:
                logger().error('Either from_created_date, to_created_date or '
                               'from_created_datetime, to_created_datetime must be specified')
                raise UsageDownloadUrlValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )

        return {
            'from_created_date': from_created_date,
            'to_created_date': to_created_date,
            'time_zone': time_zone.upper(),
            'from_created_datetime': from_created_datetime,
            'to_created_datetime': to_created_datetime,
            'subscription_id': subscription_id,
            'product_code': product_code,
            'internal_calc': internal_calc,
            'include_trial_data': include_trial_data
        }


class CsvBatchProcessInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = CsvBatchProcessInfo
        fields = (
            'request_id',
            'requested_time',
            'content_md5',
            'presigned_url',
            'csv_link',
            'process_result',
            'records',
            'error_code'
        )


class UsageDownloadUrlValidationError(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'Invalid input.'
    default_code = 'invalid'

    def __init__(self, detail, status_code):
        if status_code is not None:
            self.status_code = status_code
        if detail is not None:
            self.detail = {
                'success': False,
                'time_stamp':
                datetime.now().strftime('%Y%m%dT%H:%M:%SZ'),
                'error_status': str(status_code),
                'error_message': force_text(detail)
            }
        else:
            self.detail = {'detail': force_text(self.default_detail)}
