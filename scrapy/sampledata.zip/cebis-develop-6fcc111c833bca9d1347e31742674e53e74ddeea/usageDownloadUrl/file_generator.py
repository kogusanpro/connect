"""
<copyright file="file_generator.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import boto3
import re
import os
from django.conf import settings
import tempfile
from botocore.exceptions import ClientError
from botocore.client import Config


class FileGenerator:
    def __init__(self, request_id, from_created_date=None, to_created_date=None,time_zone="",
                 subscription_id=None, product_code=None, internal_calc=None, include_trial_data=None):
        self.from_created_date = from_created_date
        self.to_created_date = to_created_date
        self.time_zone = time_zone.upper()
        self.subscription_id = subscription_id
        self.product_code = product_code
        self.internal_calc = internal_calc
        self.include_trial_data = include_trial_data
        self.bucketname = os.environ.get('S3_USAGE_DOWNLOAD_BUCKET')
        self.request_id = request_id
        self.create_key(filename=self.create_file_name())

    def create_key(self, filename):
        """
         S3にアップロードするためのキーを生成する
         :param filename:日時
         :type filename: str
         :return: :void:
        """
        date = re.search('(\d{4})(\d{2})', self.to_created_date)
        self.key = '%s/%s%s/%s' % (
            date.group(1),
            date.group(1),
            date.group(2),
            filename
        )

    def create_file_name(self):
        """
         S3にアップロードするためのファイル名を生成する
         :return: :string: ファイル名
        """
        filename = ''
        if self.time_zone:
            filename = 'verified_usage_%s' % (
                self.time_zone
            )
        else:
            filename = 'verified_usage'

        if self.from_created_date == self.to_created_date:
            filename += '_%s' % (
                self.from_created_date
            )
        else:
            filename += '_%s-%s' % (
                self.from_created_date,
                self.to_created_date
            )

        if self.subscription_id is not None:
            filename += '_%s' % (
                self.subscription_id
            )

        if self.product_code is not None:
            filename += '_%s' % (
                self.product_code
            )
        
        if self.internal_calc is not None:
            filename += '_%s' % (
                str(self.internal_calc).upper()
            )
        
        if self.include_trial_data is not None:
            filename += '_%s' % (
                str(self.include_trial_data).upper()
            )

        filename += '.csv'

        return filename

    def recreate_file_name(self):
        """
         S3にすでに同名のファイルが存在した際に新たにファイル名を生成する
         :param count:連番
         :type count: int
         :return: :string: ファイル名
        """
        filename = ''
        if self.time_zone:
            filename = 'verified_usage_%s' % (
                self.time_zone
            )
        else:
            filename = 'verified_usage'

        if self.from_created_date == self.to_created_date:
            filename += '_%s' % (
                self.from_created_date
            )
        else:
            filename += '_%s-%s' % (
                self.from_created_date,
                self.to_created_date
            )

        if self.subscription_id is not None:
            filename += '_%s' % (
                self.subscription_id
            )

        if self.product_code is not None:
            filename += '_%s' % (
                self.product_code
            )

        if self.internal_calc is not None:
            filename += '_%s' % (
                str(self.internal_calc).upper()
            )
        
        if self.include_trial_data is not None:
            filename += '_%s' % (
                str(self.include_trial_data).upper()
            )

        filename += '_%s.csv' % (
            self.request_id
        )

        return filename

    def generate(self):
        """
         S3にバッチ用のアップロードファイルを生成する
         :return: :void:
        """
        while self.is_the_file_on_S3():
            self.create_key(filename=self.recreate_file_name())

        temp_csv_file = tempfile.NamedTemporaryFile(delete=False)
        with open(temp_csv_file.name, 'a') as fp:
            fp.write('Now processing...')
            fp.close()
            s3 = boto3.resource('s3', endpoint_url=settings.AWS_S3_ENDPOINT)
            s3.meta.client.upload_file(
                temp_csv_file.name,
                self.bucketname,
                self.key
            )
        temp_csv_file.flush()
        return self.key

    def is_the_file_on_S3(self):
        """
         S3にアップロードしようとしているファイルがあるかチェック
         :return: :boolean:
        """
        try:
            boto3.client(
                's3', endpoint_url=settings.AWS_S3_ENDPOINT).head_object(
                Bucket=self.bucketname,
                Key=self.key
            )
            return True
        except ClientError:
            return False

    def get_download_url(self):
        """
         S3のpresigned_urlを発行する
         :return: :string: presigned_url
        """
        return boto3.client('s3', endpoint_url=settings.AWS_S3_ENDPOINT, config=Config(signature_version='s3v4'))\
            .generate_presigned_url(
            ClientMethod='get_object',
            Params={'Bucket': self.bucketname, 'Key': self.key},
            ExpiresIn=settings.USAGE_DOWNLOAD_EXPIRE_MINUTES*60,
            HttpMethod='GET'
        )
