"""
<copyright file="views.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.decorators import parser_classes
from rest_framework.response import Response
from rest_framework.parsers import JSONParser
from .serializers import UsageDownloadUrlGetSerializer
from .serializers import CsvBatchProcessInfoSerializer
from status.models import CsvBatchProcessInfo
from datetime import datetime
from lib.utils import logger
from .file_generator import FileGenerator
from botocore.exceptions import ClientError, ParamValidationError
from boto3.exceptions import S3UploadFailedError
import boto3
import os

aws_batch = boto3.client('batch')


@api_view(['GET'])
@parser_classes((JSONParser, ))
def usage_download_url(request):
    request_id = request.META.get('HTTP_X_AMZN_APIGATEWAY_REQUESTID')
    request_data = {
        'from_created_date': request.query_params.get('from_created_date'),
        'to_created_date': request.query_params.get('to_created_date'),
        'time_zone': request.query_params.get('time_zone'),
        'from_created_datetime': request.query_params.get('from_created_datetime'),
        'to_created_datetime': request.query_params.get('to_created_datetime'),
        'internal_calc': request.query_params.get('internal_calc'),
        'subscription_id': request.query_params.get('subscription_id'),
        'product_code': request.query_params.get('product_code'),
        'include_trial_data': request.query_params.get('include_trial_data')
    }
    validated_data = UsageDownloadUrlGetSerializer(request_data)
    csv_batch_process_info = CsvBatchProcessInfoSerializer(
        data={
            'request_id': request_id,
            'requested_time': datetime.utcnow(),
            'process_result': 'Processing',
        }
    )
    if not csv_batch_process_info.is_valid():
        logger().error(csv_batch_process_info.errors)
        return Response(
            {
                'success': False,
                'time_stamp':
                datetime.now().strftime('%Y%m%dT%H:%M:%SZ'),
                'error_status': '400',
                'error_message': 'Invalid Parameter'
            },
            status=status.HTTP_400_BAD_REQUEST)
    csv_batch_process_info.save()

    try:
        if validated_data.data['from_created_date'] and validated_data.data['to_created_date']:
            from_created = validated_data.data['from_created_date']
            to_created = validated_data.data['to_created_date']
        else:
            from_created = validated_data.data['from_created_datetime']
            to_created = validated_data.data['to_created_datetime']

        file_generator = FileGenerator(
            request_id=request_id,
            from_created_date=from_created,
            to_created_date=to_created,
            time_zone=validated_data.data['time_zone'],
            subscription_id=validated_data.data['subscription_id'],
            product_code=validated_data.data['product_code'],
            internal_calc=validated_data.data['internal_calc'],
            include_trial_data=validated_data.data['include_trial_data']
        )
        file_name = file_generator.generate()
        batch_param = '%s %s' % (
            request_id,
            file_name,
        )

        if validated_data.data['from_created_date'] is not None:
            batch_param += ' %s %s' % (
                '--from_created_date',
                validated_data.data['from_created_date']
            )

        if validated_data.data['to_created_date'] is not None:
            batch_param += ' %s %s' % (
                '--to_created_date',
                validated_data.data['to_created_date']
            )

        if validated_data.data['time_zone'] is not None and len(validated_data.data['time_zone']) > 0:
            batch_param += ' %s %s' % (
                '--time_zone',
                validated_data.data['time_zone']
            )

        if validated_data.data['from_created_datetime'] is not None:
            batch_param += ' %s %s' % (
                '--from_created_datetime',
                validated_data.data['from_created_datetime']
            )

        if validated_data.data['to_created_datetime'] is not None:
            batch_param += ' %s %s' % (
                '--to_created_datetime',
                validated_data.data['to_created_datetime']
            )

        if validated_data.data['internal_calc'] is True:
            batch_param += ' %s' % (
                '--internal_calc',
            )

        if validated_data.data['subscription_id'] is not None:
            batch_param += ' %s %s' % (
                '--subscription_id',
                validated_data.data['subscription_id']
            )

        if validated_data.data['product_code'] is not None:
            batch_param += ' %s %s' % (
                '--product_code',
                validated_data.data['product_code']
            )

        if validated_data.data['include_trial_data'] is True:
            batch_param += ' %s' % (
                '--include_trial_data'
            )

        # Batchの実行
        aws_batch.submit_job(
            jobName=os.environ.get('BATCH_USAGE_DOWNLOAD_URL_JOBNAME'),
            jobQueue=os.environ.get('BATCH_USAGE_DOWNLOAD_URL_JOBQUEUE'),
            jobDefinition=os.environ.get('BATCH_USAGE_DOWNLOAD_URL_JOBDEFINITION'),
            parameters={
                'Args': batch_param
            }
        )

        # import subprocess
        # cmd = "python manage.py create_usage_download_url_csv %s --settings charlie.settings.ci" % (batch_param)
        # subprocess.call(cmd, shell=True)
    except (ParamValidationError, ClientError, S3UploadFailedError) as e:
        logger().error(e)
        CsvBatchProcessInfo.objects.filter(
            request_id=request_id
        ).update(
            process_result='Fail',
            error_code='G',
            records=0
        )
        return Response(
            {
                'success': False,
                'presigned_url': None,
                'request_id': request_id,
                'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
                'error_status': '500',
                'error_message': 'Internal error'
            },
            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    return Response(
        {
            'success': True,
            'presigned_url': file_generator.get_download_url(),
            'request_id': request_id,
            'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
            'error_status': None,
            'error_message': None
        },
        status=status.HTTP_200_OK)
