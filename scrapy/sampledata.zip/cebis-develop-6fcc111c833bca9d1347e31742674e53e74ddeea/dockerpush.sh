#!/usr/bin/env bash

$(aws ecr get-login --no-include-email --region ap-northeast-1)
docker build -t cebis .
docker tag cebis:latest 216681005049.dkr.ecr.ap-northeast-1.amazonaws.com/cebis:prd
docker push 216681005049.dkr.ecr.ap-northeast-1.amazonaws.com/cebis:prd
