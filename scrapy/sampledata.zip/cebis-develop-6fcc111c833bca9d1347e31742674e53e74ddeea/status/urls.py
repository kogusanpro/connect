"""
<copyright file="urls.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.conf.urls import url
from status import views

urlpatterns = [
    url(r'(?P<pk>.+)/$', views.batch_process_info),
]
