"""
<copyright file="models.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.db import models
from datetime import datetime


class CsvBatchProcessInfo(models.Model):
    request_id = models.CharField(max_length=64, primary_key=True)
    requested_time = models.DateTimeField()
    content_md5 = models.CharField(max_length=34, null=True)
    presigned_url = models.CharField(max_length=2048, null=True)
    csv_link = models.CharField(max_length=1024, null=True)
    process_result = models.CharField(max_length=16)
    records = models.IntegerField(null=True)
    error_code = models.CharField(max_length=10, null=True)
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'csv_batch_process_info'
        indexes = [
            models.Index(fields=['requested_time']),
            models.Index(fields=['process_result']),
        ]

    def save(self, *args, **kwargs):
        self.content_md5 = self.content_md5.lower() if self.content_md5 else None
        return super(CsvBatchProcessInfo, self).save(*args, **kwargs)
