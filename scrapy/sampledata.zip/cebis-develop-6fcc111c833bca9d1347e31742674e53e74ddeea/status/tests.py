"""
<copyright file="tests.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from rest_framework.test import APIClient
from rest_framework.test import APITestCase
from datetime import datetime
from .models import CsvBatchProcessInfo
from lib.utils import check_datetime_format, DateTimeUtil


class CsvBatchProcessInfoTest(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.not_exist_request_id = '4729e860-2686-11e5-80f4-222222222222'
        self.test_process_result = 'NotPrecessed'

        self.error_statuses = {
            'A': 'Content MD5 value doesn\'t match',
            'B1': 'Invalid CSV file encoding. It should be UTF-8 (no-BOM).',
            'B2': 'Invalid CSV file line feed. It should be LF.',
            'B3': 'Not found header in the CSV file, or invalid header.',
            'B4': 'Invalid CSV file quotation. It should be double quote.',
            'B5': 'Not found valid usage record in the CSV file, '
                  'or more than 1000 records.',
            'C123': 'Invalid record found : L:123',
            'D': 'Redundant record found.',
            'E456': 'Missing information found : L:456',
            'F': 'Faild to write DB but succeeds rollback.',
            'G': 'General error occurs.',
            'H789': 'Unable to calculate this month billing : L:789',
            'S': 'Adding records to DB successfully completed.'
        }
        self.TEST_MD5 = '820eb5b696ea2a657c0db1e258dc7d81'
        for error_status in self.error_statuses:
            CsvBatchProcessInfo.objects.create(
                request_id=error_status,
                records=1,
                requested_time=DateTimeUtil.utc_now_aware(),
                process_result=self.test_process_result,
                error_code=error_status,
                content_md5=self.TEST_MD5
            )

    def test_exist_request_id(self):
        """
        存在するリクエストIDのステータスを引けるか
        """
        for error_status, error_message in self.error_statuses.items():
            response = self.client.get(f'/status/{error_status}/')
            if response.data['error_status'] != 'S':
                assert response.status_code == 400
            else:
                assert response.status_code == 200
            assert response.data['process_result'] == self.test_process_result
            assert response.data['request_id'] == error_status
            assert response.data['total_records'] == 1
            assert check_datetime_format(response.data['time_stamp'])
            assert response.data['error_status'] == error_status
            assert response.data['error_message'] == error_message

    def test_not_exist_request_id(self):
        """
        存在しないリクエストIDのステータスが指定された場合、404を返すか
        """
        response = self.client.get(f'/status/{self.not_exist_request_id}/')
        assert response.status_code == 404
        assert response.data['request_id'] == self.not_exist_request_id
        assert response.data['total_records'] is None
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] == '404'
        assert response.data['error_message'] == 'Request ID not found'

    def test_records_is_null(self):
        """
        recordsを指定しなかった場合、NULLになるか
        """
        CsvBatchProcessInfo.objects.create(
            request_id='shouldbenull',
            requested_time=DateTimeUtil.utc_now_aware(),
            process_result=self.test_process_result
        )
        csv_batch_process_info = CsvBatchProcessInfo.objects.get(pk='shouldbenull')
        assert csv_batch_process_info.records is None
