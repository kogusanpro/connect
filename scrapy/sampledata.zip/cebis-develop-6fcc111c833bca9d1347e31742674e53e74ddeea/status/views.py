"""
<copyright file="views.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from datetime import datetime
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.decorators import parser_classes
from rest_framework.response import Response
from rest_framework.parsers import JSONParser
from .models import CsvBatchProcessInfo
from django.db import DatabaseError, transaction
from lib.utils import logger


@api_view(['GET'])
@parser_classes((JSONParser,))
@transaction.atomic
def batch_process_info(request, pk):
    try:
        batch_process_info = CsvBatchProcessInfo.objects.get(pk=pk)
    except CsvBatchProcessInfo.DoesNotExist:
        return Response(
            {
                'state': False,
                'request_id': pk,
                'total_records': None,
                'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
                'error_status': '404',
                'error_message': 'Request ID not found'
            },
            status=status.HTTP_404_NOT_FOUND)
    except DatabaseError as e:
        logger().error(e)
        return Response(
            {
                'state': False,
                'request_id': pk,
                'total_records': None,
                'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
                'error_status': '500',
                'error_message': 'Internal error'
            },
            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    error_status = batch_process_info.error_code
    error_message = None
    if error_status is None:
        pass
    elif error_status == 'A':
        error_message = 'Content MD5 value doesn\'t match'
    elif error_status == 'B1':
        error_message = \
            'Invalid CSV file encoding. It should be UTF-8 (no-BOM).'
    elif error_status == 'B2':
        error_message = 'Invalid CSV file line feed. It should be LF.'
    elif error_status == 'B3':
        error_message = 'Not found header in the CSV file, or invalid header.'
    elif error_status == 'B4':
        error_message = \
            'Invalid CSV file quotation. It should be double quote.'
    elif error_status == 'B5':
        error_message = \
            'Not found valid usage record in the CSV file, ' \
            'or more than 1000 records.'
    elif error_status.startswith('C'):
        error_message = f'Invalid record found : L:{error_status[1:]}'
    elif error_status == 'D':
        error_message = 'Redundant record found.'
    elif error_status.startswith('E'):
        error_message = f'Missing information found : L:{error_status[1:]}'
    elif error_status == 'F':
        error_message = 'Faild to write DB but succeeds rollback.'
    elif error_status == 'G':
        error_message = 'General error occurs.'
    elif error_status.startswith('H'):
        error_message = \
            f'Unable to calculate this month billing : L:{error_status[1:]}'
    elif error_status == 'S':
        error_message = 'Adding records to DB successfully completed.'

    process_items = ['Processing', 'NotProcessed']

    return Response(
        {
            'process_result': batch_process_info.process_result,
            'request_id': batch_process_info.request_id,
            'total_records': batch_process_info.records,
            'time_stamp': batch_process_info.updated_time
                .strftime('%Y%m%dT%H%M%SZ'),
            'error_status': error_status,
            'error_message': error_message
        },
        status=status.HTTP_200_OK if error_status == 'S' or batch_process_info.process_result in process_items else status.HTTP_400_BAD_REQUEST,
        headers={'Content-MD5-Cebis': batch_process_info.content_md5})
