#!/usr/bin/env bash
ARGS=`echo ${@:1}`
python manage.py ${ARGS}
