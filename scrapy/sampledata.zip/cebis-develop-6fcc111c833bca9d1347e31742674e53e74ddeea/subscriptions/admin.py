"""
<copyright file="admin.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.contrib import admin
from .models import ContractInfo, ContractServiceInfo

admin.site.register(ContractInfo)
admin.site.register(ContractServiceInfo)
