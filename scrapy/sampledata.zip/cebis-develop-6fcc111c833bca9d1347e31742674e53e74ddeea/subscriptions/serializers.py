"""
<copyright file="serializers.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2019. All rights reserved.
</copyright>
"""
from datetime import datetime, date, time, timedelta

from dateutil import parser
from django.utils.encoding import force_text
from pytz import timezone
from rest_framework import serializers
from rest_framework import status
from rest_framework.exceptions import APIException

from lib.const.opco_code import OPCO_TIMEZONE
from lib.utils import check_datetime_format, check_date_ym_format
from lib.utils import convert_date_format
from lib.utils import convert_datetime_format, check_date_ymd_format
from lib.utils import logger
from subscriptions.models import CalculatedUsageInfo
from .models import BillingDetailInfo, BillingUsageDetailInfo, ProductInfo
from .models import ContractInfo, ContractServiceInfo, UsageInfo, BillingInfo


class BillingUsageDetailInfoPostSerializer(serializers.BaseSerializer):
    def to_representation(self, data):
        subscription = data.get('subscription_id')
        target_month = data.get('target_month')
        product_code = data.get('product_code')
        license_user = data.get('license_user')
        billing = data.get('billing')
        quantity = data.get('quantity')

        if license_user is None:
            logger().error('missing parameter license_user in this request body')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        return {
            'subscription': subscription,
            'target_month': target_month,
            'product_code': product_code,
            'license_user': license_user,
            'billing': billing,
            'quantity': quantity
        }


class BillingDetailInfoPostSerializer(serializers.BaseSerializer):
    def to_representation(self, data):
        subscription = data.get('subscription_id')
        target_month = data.get('target_month')
        product_code = data.get('product_code')
        license_quantity = data.get('license_quantity')
        billing = data.get('billing')
        quantity = data.get('quantity')

        if product_code is None:
            logger().error('missing parameter product_code in this request body')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        if 'billing_usage_details' not in data:
            logger().error('missing parameter billing_usage_details in this request body')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        return {
            'subscription': subscription,
            'target_month': target_month,
            'product_code': product_code,
            'license_quantity': license_quantity,
            'billing': billing,
            'quantity': quantity
        }


class BillingInfoPostSerializer(serializers.BaseSerializer):
    def to_representation(self, data):
        subscription = data.get('subscription_id')
        target_month = data.get('target_month')
        start_date = data.get('start_date')
        end_date = data.get('end_date')
        billing = data.get('billing')
        unit_of_money = data.get('unit_of_money')
        state = data.get('state')
        billing_details = data.get('billing_details')

        if state is None:
            logger().error('missing parameter state in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        if not billing_details:
            logger().error('missing parameter billing_details in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        if not check_date_ym_format(datetime=target_month):
            logger().error('target_month went wrong format in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        if start_date is not None:
            if not check_date_ymd_format(datetime=start_date):
                logger().error('start_date went wrong format in this request')
                raise SubscriptionsValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )

        if end_date is not None:
            if not check_date_ymd_format(datetime=end_date):
                logger().error('end_date went wrong format in this request')
                raise SubscriptionsValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )

        allow_values = ['new', 'calculating', 'completed']
        if state not in allow_values:
            logger().error('state is choice field but allowed value was not included in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        try:
            bi = BillingInfo.objects.get(
                subscription=subscription,
                target_month=target_month
            )
            if bi.state == 'completed':
                raise SubscriptionsValidationError(
                    'Billing already exists',
                    status.HTTP_403_FORBIDDEN
                )
        except BillingInfo.DoesNotExist:
            pass

        start_date = convert_date_format(start_date)
        end_date = convert_date_format(end_date)
        return {
            'subscription': subscription,
            'target_month': target_month,
            'start_date': start_date,
            'end_date': end_date,
            'billing': billing,
            'unit_of_money': unit_of_money,
            'state': state,
        }


class ContractServiceInfoPostSerializer(serializers.BaseSerializer):
    def to_representation(self, data):
        subscription = data.get('subscription_id')
        product_code = data.get('product_code')
        product_type = data.get('product_type')
        state = data.get('state')
        license_quantity = data.get('license_quantity')
        license_users = data.get('license_users')
        service_start_time = data.get('service_start_time')
        service_update_time = data.get('service_update_time')
        service_cancel_time = data.get('service_cancel_time')

        if service_start_time is not None:
            if not check_datetime_format(datetime=service_start_time):
                logger().error('service_start_time went wrong format in this request')
                raise SubscriptionsValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )
            else:
                service_start_time = convert_datetime_format(
                    service_start_time)

        if service_update_time is not None:
            if not check_datetime_format(datetime=service_update_time):
                logger().error('service_update_time went wrong format in this request')
                raise SubscriptionsValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )
            else:
                service_update_time = convert_datetime_format(
                    service_update_time)

        if service_cancel_time is not None:
            if not check_datetime_format(datetime=service_cancel_time):
                logger().error('service_cancel_time went wrong format in this request')
                raise SubscriptionsValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )
            else:
                service_cancel_time = convert_datetime_format(
                    service_cancel_time)

        if license_users is not None:
            if not isinstance(license_users, list):
                logger().error('missing parameter license_users in this request')
                raise SubscriptionsValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )
            else:
                license_users = ','.join(license_users)

        allow_values = ['basic', 'option']
        if product_type not in allow_values:
            logger().error('product_type is choice field but allowed value was not included in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        allow_values = ['active', 'inactive', 'trial']
        if data['state'] not in allow_values:
            logger().error('state is choice field but allowed value was not included in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        return {
            'subscription': subscription,
            'service_start_time': service_start_time,
            'service_update_time': service_update_time,
            'service_cancel_time': service_cancel_time,
            'license_users': license_users,
            'state': state,
            'product_type': product_type,
            'product_code': product_code,
            'license_quantity': license_quantity,
        }


class ContractInfoPostSerializer(serializers.BaseSerializer):

    # #130593 契約情報単体登録APIに商品コード存在チェックを追加する
    def __exists_product_info(self, product_code):
        try:
            ProductInfo.objects.get(product_code=product_code)
            return   True
        except ProductInfo.DoesNotExist:
            return False

    def to_representation(self, data):
        subscription_id = data.get('subscription_id')
        subscription_number = data.get('subscription_number')
        contract_code = data.get('contract_code')
        spf_tenant_id = data.get('spf_tenant_id')
        opco_code = data.get('opco_code')
        closing_day = int(data.get('closing_day'))
        products = data.get('products')

        now = datetime.now(timezone('Asia/Tokyo')).time()
        if not time(4, 0, 0) < now < time(22, 0, 0):
            raise SubscriptionsValidationError(
                'Out of registration time',
                status.HTTP_403_FORBIDDEN
            )

        if not products:
            logger().error('missing parameter products in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        # 130593 契約情報単体登録APIに商品コード存在チェックを追加する
        for product in products:
            product_code = product['product_code']
            if not product_code:
                logger().error('missing parameter product_code in this request')
                raise SubscriptionsValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )

            if not self.__exists_product_info(product_code):
               logger().error('parameter product_code not exist in product_info')
               raise SubscriptionsValidationError(
                   'Product Code not found',
                   status.HTTP_404_NOT_FOUND
               )

        if opco_code is None:
            logger().error('missing parameter opco_code in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        if closing_day is None:
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        if (closing_day < -1) or (closing_day > 31):
            logger().error('closing_day is range field but this was actually out of range')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        allow_values = [
            'FX', 'FXA', 'FXCA', 'FXCL', 'FXHK', 'FXK', 'FXM', 'FXMM', 'FXNZ',
            'FXP', 'FXS', 'FXTH', 'FXTW', 'FXV','PTAG'
        ]
        if opco_code not in allow_values:
            logger().error('opco_code is choice field but allowed value was not included in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        return {
            'subscription_id': subscription_id,
            'subscription_number': subscription_number,
            'contract_code': contract_code,
            'spf_tenant_id': spf_tenant_id,
            'opco_code': opco_code,
            'closing_day': closing_day
        }


class SubscriptionsUsagePostSerializer(serializers.BaseSerializer):
    def to_representation(self, data):
        subscription = data.get('subscription_id')
        target_month = data.get('target_month')
        product_code = data.get('product_code')
        start_time = data.get('start_time')
        end_time = data.get('end_time')
        quantity = data.get('quantity')
        license_user = data.get('license_user')

        if type(license_user) is str:
            license_user = license_user.strip()

        if product_code is None:
            logger().error('missing parameter product_code in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        if start_time is None:
            logger().error('missing parameter start_time in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        if end_time is None:
            logger().error('missing parameter end_time in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        if quantity is None:
            logger().error('missing parameter quantity in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        if not check_datetime_format(datetime=start_time):
            logger().error('start_time went wrong format in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        if not check_datetime_format(datetime=end_time):
            logger().error('end_time went wrong format in this request')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        contract_info = self.get_contract_info(subscription)
        target_timezone = self.get_target_timezone_info(
            contract_info.opco_code.strip())

        if target_month is not None:
            if not check_date_ym_format(datetime=target_month):
                logger().error('target_month went wrong format in this request')
                raise SubscriptionsValidationError(
                    'Invalid Parameter',
                    status.HTTP_400_BAD_REQUEST
                )
        else:
            target_month = parser.parse(end_time).astimezone(
                timezone(target_timezone)).strftime('%Y%m')

        if target_month is not None:
            local_end_time = parser.parse(end_time).astimezone(
                timezone(target_timezone))
            target_month_dt = datetime.strptime(target_month, '%Y%m')
            if date(local_end_time.year, local_end_time.month, 1) > date(
                    target_month_dt.year, target_month_dt.month, 1):
                raise SubscriptionsValidationError(
                    'Contradiction occurs',
                    status.HTTP_403_FORBIDDEN
                )

        usage_id = self.generate_usage_id(
            subscription_id=subscription,
            product_code=product_code,
            start_time=start_time,
            end_time=end_time,
            quantity=quantity,
            license_user=license_user
        )

        try:
            UsageInfo.objects.get(
                usage_id=usage_id
            )
            raise SubscriptionsValidationError(
                'Duplicate registrations',
                status.HTTP_409_CONFLICT
            )
        except UsageInfo.DoesNotExist:
            pass

        return {
            'subscription': subscription,
            'usage_id': usage_id,
            'product_code': product_code,
            'target_month': target_month,
            'start_time': convert_datetime_format(start_time),
            'end_time': convert_datetime_format(end_time),
            'deleted': False,
            'quantity': quantity,
            'license_user': license_user,
            'free_item1': data.get('free_item1'),
            'free_item2': data.get('free_item2'),
        }

    def get_target_timezone_info(self, opco_code):
        """
        仕向け地に応じるタイムゾーンを取得する
        :param:仕向け地
        :return:タイムゾーン
        """
        target_timezone = OPCO_TIMEZONE.get(opco_code)
        """
        target_timezoneを取得できなかった場合、確認要
        :param:仕向け地
        :return:タイムゾーン
        """
        if target_timezone is None: 
            logger().error('could not get the target_timezone from the contract_info, '
                           'the opco_code is not allowed or miss.')
            raise SubscriptionsValidationError(
                'Invalid Parameter',
                status.HTTP_400_BAD_REQUEST
            )

        return target_timezone

    def get_contract_info(self, subscription_id):
        """
        契約情報を取得する
        :param:サブスクリプションID
        :return:契約情報
        """
        try:
            contract_info = ContractInfo.objects.get(subscription_id=subscription_id)
            return contract_info
        # 取得できなかった場合、確認要
        except ContractInfo.DoesNotExist:
            logger().error('Contract not found')
            raise SubscriptionsValidationError(
                'Contract not found',
                status.HTTP_404_NOT_FOUND
            )

    def generate_usage_id(
            self, subscription_id, product_code,
            start_time, end_time, quantity, license_user=None):
        if license_user is None:
            return '{0}_{1}_{2}_{3}_{4}'.format(
                    subscription_id, product_code, start_time,
                    end_time, quantity)
        else:
            return '{0}_{1}_{2}_{3}_{4}_{5}'.format(
                    subscription_id, product_code, start_time,
                    end_time, quantity, license_user)


class UsageInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = UsageInfo
        fields = (
            'subscription',
            'usage_id',
            'product_code',
            'target_month',
            'start_time',
            'deleted',
            'end_time',
            'quantity',
            'license_user',
            'free_item1',
            'free_item2'
        )


class BillingInfoSerializer(serializers.ModelSerializer):
    subscription = serializers.CharField(max_length=17)
    def update(self, instance: BillingInfo, validated_data: dict):
        subscription = validated_data.get('subscription', instance.subscription_id)
        instance.subscription = ContractInfo(subscription_id=subscription)
        instance.target_month = validated_data.get('target_month', instance.target_month)
        instance.start_date = validated_data.get('start_date', instance.start_date)
        instance.end_date = validated_data.get('end_date', instance.end_date)
        instance.unit_of_money = validated_data.get('unit_of_money', instance.unit_of_money)
        instance.billing = validated_data.get('billing', instance.billing)
        instance.state = validated_data.get('state', instance.state)

        instance.save()
        return instance

    def create(self, validated_data):
        subscription = ContractInfo(
            subscription_id=validated_data['subscription'],
        )
        validated_data['subscription'] = subscription
        return BillingInfo.objects.create(**validated_data)

    class Meta:
        model = BillingInfo
        fields = (
            'subscription',
            'target_month',
            'start_date',
            'end_date',
            'billing',
            'unit_of_money',
            'state'
        )


class BillingDetailInfoSerializer(serializers.ModelSerializer):
    # 商品マスタ及び契約情報マスタの存在チェックが走らないようにオーバーライドする
    product_code = serializers.CharField(max_length=12)
    subscription = serializers.CharField(max_length=17)

    def update(self, instance: BillingDetailInfo, validated_data: dict):
        subscription = validated_data.get('subscription', instance.subscription_id)
        instance.subscription = ContractInfo(subscription_id=subscription)
        product_code = validated_data.get('product_code', instance.product_code_id)
        instance.product_code = ProductInfo(product_code=product_code)

        instance.target_month = validated_data.get('target_month', instance.target_month)
        instance.license_quantity = validated_data.get('license_quantity', instance.license_quantity)
        instance.billing = validated_data.get('billing', instance.billing)
        instance.quantity = validated_data.get('quantity', instance.quantity)

        instance.save()
        return instance

    def create(self, validated_data):
        product = ProductInfo(
            product_code=validated_data['product_code'],
        )
        validated_data['product_code'] = product
        subscription = ContractInfo(
            subscription_id=validated_data['subscription'],
        )
        validated_data['subscription'] = subscription
        return BillingDetailInfo.objects.create(**validated_data)

    class Meta:
        model = BillingDetailInfo
        fields = (
            'subscription',
            'target_month',
            'product_code',
            'license_quantity',
            'billing',
            'quantity'
        )


class BillingUsageDetailInfoSerializer(serializers.ModelSerializer):
    # 商品マスタ及び契約情報マスタの存在チェックが走らないようにオーバーライドする
    product_code = serializers.CharField(max_length=12)
    subscription = serializers.CharField(max_length=17)

    def update(self, instance: BillingUsageDetailInfo, validated_data: dict):
        subscription = validated_data.get('subscription', instance.subscription_id)
        instance.subscription = ContractInfo(subscription_id=subscription)
        product_code = validated_data.get('product_code', instance.product_code_id)
        instance.product_code = ProductInfo(product_code=product_code)

        instance.target_month = validated_data.get('target_month', instance.target_month)
        instance.license_user = validated_data.get('license_user', instance.license_user)
        instance.billing = validated_data.get('billing', instance.billing)
        instance.quantity = validated_data.get('quantity', instance.quantity)
        instance.save()
        return instance

    def create(self, validated_data):
        product = ProductInfo(
            product_code=validated_data['product_code'],
        )
        validated_data['product_code'] = product
        subscription = ContractInfo(
            subscription_id=validated_data['subscription'],
        )
        validated_data['subscription'] = subscription
        return BillingUsageDetailInfo.objects.create(**validated_data)

    class Meta:
        model = BillingUsageDetailInfo
        fields = (
            'subscription',
            'target_month',
            'product_code',
            'license_user',
            'billing',
            'quantity'
        )


class ContractInfoSerializer(serializers.ModelSerializer):
    def to_representation(self, instance):
        ret = super().to_representation(instance)
        try:
            ret['created_time'] = datetime.strptime(
                ret['created_time'],
                '%Y-%m-%dT%H:%M:%SZ').strftime('%Y%m%dT%H%M%SZ')
        except ValueError:
            ret['created_time'] = datetime.strptime(
                ret['created_time'],
                '%Y-%m-%dT%H:%M:%S.%fZ').strftime('%Y%m%dT%H%M%SZ')
        try:
            ret['updated_time'] = datetime.strptime(
                ret['updated_time'],
                '%Y-%m-%dT%H:%M:%SZ').strftime('%Y%m%dT%H%M%SZ')
        except ValueError:
            ret['updated_time'] = datetime.strptime(
                ret['updated_time'],
                '%Y-%m-%dT%H:%M:%S.%fZ').strftime('%Y%m%dT%H%M%SZ')
        return ret

    class Meta:
        model = ContractInfo
        fields = (
            'subscription_id',
            'subscription_number',
            'contract_code',
            'opco_code',
            'spf_tenant_id',
            'closing_day',
            'created_time',
            'updated_time',
        )


class ContractServiceInfoSerializer(serializers.ModelSerializer):

    # 商品マスタの存在チェックが走らないようにオーバーライドする
    product_code = serializers.CharField(max_length=12)

    def update(self, instance: ContractServiceInfo, validated_data:dict):

        instance.subscription = validated_data.get('subscription', instance.subscription)
        product_code = validated_data.get('product_code', instance.product_code_id)
        instance.product_code = ProductInfo(product_code=product_code)

        instance.product_type = validated_data.get('product_type', instance.product_type)
        instance.state = validated_data.get('state', instance.state)
        instance.license_users = validated_data.get('license_users', instance.license_users)
        instance.license_quantity = validated_data.get('license_quantity', instance.license_quantity)
        instance.service_start_time = validated_data.get('service_start_time', instance.service_start_time)
        instance.service_update_time = validated_data.get('service_update_time', instance.service_update_time)
        instance.service_start_time = validated_data.get('service_start_time', instance.service_start_time)
        instance.service_cancel_time = validated_data.get('service_cancel_time', instance.service_cancel_time)
        instance.save()
        return instance

    def create(self, validated_data):
        product = ProductInfo(
            product_code=validated_data['product_code'],
        )
        validated_data['product_code'] = product
        return ContractServiceInfo.objects.create(**validated_data)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        product_code = ''
        if hasattr(instance, 'product_code_id'):
            product_code = instance.product_code_id

        ret = {
            'product_code': product_code,
            'product_type': data['product_type'],
            'state': data['state'],
            'license_users': data['license_users'],
            'license_quantity': data['license_quantity'],
            'service_start_time': data['service_start_time'],
            'service_update_time': data['service_update_time'],
            'service_cancel_time': data['service_cancel_time'],
        }

        for service_time in ['service_start_time', 'service_update_time', 'service_cancel_time']:
            if ret[service_time] is not None:
                try:
                    ret[service_time] = datetime.strptime(
                        data[service_time],
                        '%Y-%m-%dT%H:%M:%SZ').strftime('%Y%m%dT%H%M%SZ')
                except ValueError:
                    ret[service_time] = datetime.strptime(
                        data[service_time],
                        '%Y-%m-%dT%H:%M:%S.%fZ').strftime('%Y%m%dT%H%M%SZ')

        if ret['license_users'] is not None:
            ret['license_users'] = ret['license_users'].split(',')
        return ret

    class Meta:
        model = ContractServiceInfo
        fields = ('subscription', 'product_code', 'product_type', 'state',
                  'license_quantity', 'license_users', 'service_start_time',
                  'service_update_time', 'service_cancel_time')


class SubscriptionsValidationError(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'Invalid input.'
    default_code = 'invalid'

    def __init__(self, detail, status_code):
        if status_code is not None:
            self.status_code = status_code
        if detail is not None:
            self.detail = {
                'success': False,
                'time_stamp':
                datetime.now().strftime('%Y%m%dT%H:%M:%SZ'),
                'error_status': str(status_code),
                'error_message': force_text(detail)
            }
        else:
            self.detail = {'detail': force_text(self.default_detail)}


class CalculatedUsageInfoSerializer(serializers.ModelSerializer):
    subscription_id = serializers.CharField(max_length=17)
    product_code = serializers.CharField(max_length=12)
    target_day = serializers.CharField(max_length=10)

    def update(self, instance: CalculatedUsageInfo, validated_data: dict):
        subscription = validated_data.get('subscription_id', instance.subscription_id)
        instance.subscription = ContractInfo(subscription_id=subscription)
        product_code = validated_data.get('product_code', instance.product_code_id)
        instance.product_code = ProductInfo(product_code=product_code)
        target_day = validated_data.get('target_day', instance.target_day)
        instance.target_day = ProductInfo(target_day=target_day)

        instance.target_month = validated_data.get('target_month', instance.target_month)
        instance.daily_usage = validated_data.get('daily_usage', instance.daily_usage)
        instance.cumulative_usage = validated_data.get('cumulative_usage', instance.cumulative_usage)
        instance.save()
        return instance

    def create(self, validated_data):
        subscription_id = ContractInfo(
            subscription_id=validated_data['subscription_id'],
        )
        validated_data['subscription_id'] = subscription_id
        product_code = ProductInfo(
            product_code=validated_data['product_code'],
        )
        validated_data['product_code'] = product_code
        return CalculatedUsageInfo.objects.create(**validated_data)

    class Meta:
        model = CalculatedUsageInfo
        fields = ('subscription_id', 'product_code', 'target_month',
                  'target_day', 'daily_usage', 'cumulative_usage', 'created_time', 'updated_time')
