"""
<copyright file="tests_subscriptions_bulk_fetch.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import freezegun
import time
import pytz
from datetime import datetime

from rest_framework.test import APIClient
from rest_framework.test import APITestCase

from .models import ContractInfo, ContractServiceInfo, ProductInfo
from lib.utils import check_datetime_format


class SubscriptionsBulkFetchTest(APITestCase):
    def setUp(self):
        self.client = APIClient()

        contract1 = ContractInfo.objects.create(
            subscription_id='1',
            subscription_number='xxx',
            contract_code='xxx',
            spf_tenant_id='spf0000000123',
            opco_code='FX',
            closing_day=30,
        )
        contract2 = ContractInfo.objects.create(
            subscription_id='2',
            subscription_number=None,
            contract_code='yyy',
            spf_tenant_id='spf0000000456',
            opco_code='FX',
            closing_day=30,
        )

        product1 = ProductInfo.objects.create(
            product_code='ABCXX1000',
            product_name='ABCXX1000',
            flat_rate=False,
            created_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
            updated_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
        )
        product2 = ProductInfo.objects.create(
            product_code='ABCD1001',
            product_name='ABCD1001',
            flat_rate=False,
            created_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
            updated_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
        )
        product3 = ProductInfo.objects.create(
            product_code='FFFF1002',
            product_name='FFFF1002',
            flat_rate=False,
            created_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
            updated_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
        )

        ContractServiceInfo.objects.create(
            subscription=contract1,
            product_code=product2,
            product_type='option',
            state='active',
            license_quantity=None,
            license_users='003,002',
            service_start_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
            service_update_time=None,
            service_cancel_time=None
        )
        ContractServiceInfo.objects.create(
            subscription=contract1,
            product_code=product1,
            product_type='basic',
            state='active',
            license_quantity=15,
            license_users=None,
            service_start_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
            service_update_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
            service_cancel_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC)
        )
        with freezegun.freeze_time('2015-06-01', tick=True):
            ContractServiceInfo.objects.create(
                subscription=contract2,
                product_code=product3,
                product_type='basic',
                state='active',
                license_quantity=10,
                license_users=None,
                service_start_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                service_update_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                service_cancel_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC)
            )

        product4 = ProductInfo.objects.create(
            product_code='QWER7890',
            product_name='QWER7890',
            flat_rate=False,
            created_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
            updated_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
        )

        with freezegun.freeze_time('2015-03-01', tick=True):
            for num in range(100):
                ci = ContractInfo.objects.create(
                    subscription_id='aaa' + str(num),
                    subscription_number='xxx',
                    contract_code='yyy',
                    spf_tenant_id='spf0000000789',
                    opco_code='FX',
                    closing_day=30,
                )
                ContractServiceInfo.objects.create(
                    subscription=ci,
                    product_code=product4,
                    product_type='basic',
                    state='active',
                    license_quantity=15,
                    license_users=None,
                    service_start_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                    service_update_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                    service_cancel_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC)
                )

    def test_invalid_updated_time(self):
        """
        from_updated_timeかto_updated_timeが日付でない場合に400を返すか
        """
        params = ['from_updated_time', 'to_updated_time']

        for param in params:
            response = self.client.get(
                '/subscriptions/',
                {param: '2000thisisnotdate11'})
            assert response.status_code == 400
            assert response.data['success'] is False
            assert response.data['count'] is None
            assert check_datetime_format(response.data['time_stamp'])
            assert response.data['error_status'] == '400'
            assert response.data['error_message'] == 'Invalid Parameter'
            assert response.data['subscriptions'] is None

    def test_time_paradox(self):
        """
        終了日時が開始日時より早い場合に400を返すか
        """
        response = self.client.get(
            '/subscriptions/',
            {
                'from_updated_time': '20200101T000000Z',
                'to_updated_time': '19640101T000000Z'
            })
        assert response.status_code == 400
        assert response.data['success'] is False
        assert response.data['count'] is None
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] == '400'
        assert response.data['error_message'] == 'Invalid Parameter'
        assert response.data['subscriptions'] is None

    def test_invalid_offset(self):
        """
        不正なoffsetを与えた場合に400を返すか
        """
        invalid_offsets = ['thisisnotnumber', '-1', '0']

        for invalid_offset in invalid_offsets:
            response = self.client.get(
                '/subscriptions/',
                {'offset': invalid_offset})
            assert response.status_code == 400
            assert response.data['success'] is False
            assert response.data['count'] is None
            assert check_datetime_format(response.data['time_stamp'])
            assert response.data['error_status'] == '400'
            assert response.data['error_message'] == 'Invalid Parameter'
            assert response.data['subscriptions'] is None

    def test_too_big_offset(self):
        """
        最大要素数より大きいをoffset与えた場合に400を返すか
        """
        time.sleep(1)
        response = self.client.get(
            '/subscriptions/',
            {'offset': 103})
        assert response.status_code == 400
        assert response.data['success'] is False
        assert response.data['count'] is None
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] == '400'
        assert response.data['error_message'] == 'Invalid Parameter'
        assert response.data['subscriptions'] is None

    def test_equal_count_offset(self):
        """
        最大要素数と同じoffsetを与えた場合に200を返すか
        """
        time.sleep(1)
        response = self.client.get(
            '/subscriptions/',
            {'offset': 102})
        assert response.status_code == 200
        assert response.data['success'] is True
        assert response.data['count'] is 102
        assert len(response.data['subscriptions']) == 1
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] is None
        assert response.data['error_message'] is None

    def test_not_found(self):
        """
        指定範囲に契約情報が見つからなかった場合に404を返すか
        """
        response = self.client.get(
            '/subscriptions/',
            {
                'from_updated_time': '20200101T000000Z',
                'to_updated_time': '20200101T000000Z'
            })
        assert response.status_code == 404
        assert response.data['success'] is False
        assert response.data['count'] is None
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] == '404'
        assert response.data['error_message'] == 'Contract not found'
        assert response.data['subscriptions'] is None

    def test_offset(self):
        """
        offsetを指定した場合に正常に200を返すか
        """
        time.sleep(1)
        response = self.client.get(
            '/subscriptions/',
            {'offset': 101})
        assert response.status_code == 200
        assert response.data['success'] is True
        assert response.data['count'] is 102
        assert len(response.data['subscriptions']) == 2
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] is None
        assert response.data['error_message'] is None

    def test_from_updated_time_boundary_value(self):
        """
        from_updated_timeと同時刻の要素を拾ってこれるか
        """
        time.sleep(1)
        response = self.client.get(
            '/subscriptions/',
            {
                'from_updated_time': '20150601T000000Z',
                'to_updated_time': '20150602T000000Z'
            })
        assert response.status_code == 200
        assert response.data['success'] is True
        assert response.data['count'] is 1
        assert len(response.data['subscriptions']) == 1
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] is None
        assert response.data['error_message'] is None

    def test_to_updated_time_boundary_value(self):
        """
        to_updated_timeと同時刻の要素を拾ってこないかどうか
        """
        time.sleep(1)
        response = self.client.get(
            '/subscriptions/',
            {
                'from_updated_time': '20150501T000000Z',
                'to_updated_time': '20150601T000000Z'
            })
        assert response.status_code == 404
        assert response.data['success'] is False
        assert response.data['count'] is None
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] == '404'
        assert response.data['error_message'] == 'Contract not found'
        assert response.data['subscriptions'] is None

    def test_success(self):
        """
        特にオプションを指定しない場合に正常に200を返すか
        """
        time.sleep(1)
        response = self.client.get('/subscriptions/')
        assert response.status_code == 200
        assert response.data['success'] is True
        assert response.data['count'] is 102
        assert len(response.data['subscriptions']) == 100
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] is None
        assert response.data['error_message'] is None
        assert response.data['subscriptions'][0][
                   'subscription_id'] == '1'
        assert response.data['subscriptions'][0]['subscription_number'] == 'xxx'
        with self.assertRaises(KeyError):
            response.data['subscriptions'][0]['contract_code']
        assert response.data['subscriptions'][0][
                   'spf_tenant_id'] == 'spf0000000123'
        assert response.data['subscriptions'][0]['opco_code'] == 'FX'
        assert response.data['subscriptions'][0]['closing_day'] == 30
        assert response.data['subscriptions'][0]['products'][0][
                   'product_code'] == 'ABCD1001'
        assert response.data['subscriptions'][0]['products'][0][
                   'product_type'] == 'option'
        assert response.data['subscriptions'][0]['products'][0][
                   'state'] == 'active'
        assert response.data['subscriptions'][0]['products'][0][
                   'license_quantity'] is None
        assert response.data['subscriptions'][0]['products'][0][
                   'license_users'][0] == '003'
        assert response.data['subscriptions'][0]['products'][0][
                   'license_users'][1] == '002'
        assert response.data['subscriptions'][0]['products'][0][
                   'service_start_time'] == '20180201T000000Z'
        assert response.data['subscriptions'][0]['products'][0][
                   'service_update_time'] is None
        assert response.data['subscriptions'][0]['products'][0][
                   'service_cancel_time'] is None
        assert response.data['subscriptions'][0]['products'][1][
                   'product_code'] == 'ABCXX1000'
        assert response.data['subscriptions'][0]['products'][1][
                   'product_type'] == 'basic'
        assert response.data['subscriptions'][0]['products'][1][
                   'state'] == 'active'
        assert response.data['subscriptions'][0]['products'][1][
                   'license_quantity'] == 15
        assert response.data['subscriptions'][0]['products'][1][
                   'license_users'] is None
        assert response.data['subscriptions'][0]['products'][1][
                   'service_start_time'] == '20180201T000000Z'
        assert response.data['subscriptions'][0]['products'][1][
                   'service_update_time'] == '20180201T000000Z'
        assert response.data['subscriptions'][0]['products'][1][
                   'service_cancel_time'] == '20180201T000000Z'
        assert response.data['subscriptions'][1][
                   'subscription_id'] == '2'
        assert response.data['subscriptions'][1]['subscription_number'] is None
        with self.assertRaises(KeyError):
            response.data['subscriptions'][1]['contract_code']
        assert response.data['subscriptions'][1][
                   'spf_tenant_id'] == 'spf0000000456'
        assert response.data['subscriptions'][1]['opco_code'] == 'FX'
        assert response.data['subscriptions'][1]['closing_day'] == 30
        assert response.data['subscriptions'][1]['products'][0][
                   'product_code'] == 'FFFF1002'
        assert response.data['subscriptions'][1]['products'][0][
                   'product_type'] == 'basic'
        assert response.data['subscriptions'][1]['products'][0][
                   'state'] == 'active'
        assert response.data['subscriptions'][1]['products'][0][
                   'license_quantity'] == 10
        assert response.data['subscriptions'][1]['products'][0][
                   'license_users'] is None
        assert response.data['subscriptions'][1]['products'][0][
                   'service_start_time'] == '20180201T000000Z'
        assert response.data['subscriptions'][1]['products'][0][
                   'service_update_time'] == '20180201T000000Z'
        assert response.data['subscriptions'][1]['products'][0][
                   'service_cancel_time'] == '20180201T000000Z'

    def test_success_without_contract_code(self):
        """
        契約連番がnull及び空文字列のデータは取得されていないことを確認
        """
        ContractInfo.objects.all().delete()
        ContractServiceInfo.objects.all().delete()
        ProductInfo.objects.all().delete()

        with freezegun.freeze_time('2015-06-02', tick=True):
            contract1 = ContractInfo.objects.create(
                subscription_id='dpa_70015',
                subscription_number='xxx',
                contract_code='',
                spf_tenant_id='spf0000000123',
                opco_code='FX',
                closing_day=30,
            )
            contract2 = ContractInfo.objects.create(
                subscription_id='dpa_70016',
                subscription_number='yyy',
                contract_code=None,
                spf_tenant_id='spf0000000456',
                opco_code='FX',
                closing_day=30,
            )
            contract3 = ContractInfo.objects.create(
                subscription_id='dpa_70017',
                subscription_number=None,
                contract_code='xxx',
                spf_tenant_id='spf0000000456',
                opco_code='FX',
                closing_day=30,
            )
            product = ProductInfo.objects.create(
                product_code='ABCXX1000',
                product_name='ABCXX1000',
                flat_rate=False,
                created_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                updated_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
            )
            ContractServiceInfo.objects.create(
                subscription=contract1,
                product_code=product,
                product_type='option',
                state='active',
                license_quantity=None,
                license_users='003,002',
                service_start_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                service_update_time=None,
                service_cancel_time=None
            )
            ContractServiceInfo.objects.create(
                subscription=contract2,
                product_code=product,
                product_type='option',
                state='active',
                license_quantity=None,
                license_users='003,002',
                service_start_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                service_update_time=None,
                service_cancel_time=None
            )
            ContractServiceInfo.objects.create(
                subscription=contract3,
                product_code=product,
                product_type='option',
                state='active',
                license_quantity=None,
                license_users='003,002',
                service_start_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                service_update_time=None,
                service_cancel_time=None
            )
        response = self.client.get(
            '/subscriptions/',
            {
                'from_updated_time': '20150601T000000Z',
                'to_updated_time': '20150603T000000Z'
            })
        assert response.status_code == 200
        assert response.data['success'] is True
        assert response.data['count'] is 1
        assert len(response.data['subscriptions']) == 1
        assert response.data['subscriptions'][0][
                   'subscription_id'] == 'dpa_70017'
        ContractInfo.objects.all().delete()
        ContractServiceInfo.objects.all().delete()
        ProductInfo.objects.all().delete()

    def test_validate_internal_calc(self):
        """
        リクエストパラメータのinternal_calcがtrueかfalse以外だと400エラーが返る
        """
        response = self.client.get(
            '/subscriptions/?internal_calc=xxxxx'
        )
        assert response.status_code == 400
        assert response.data['success'] is False
        assert response.data['count'] is None
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] == '400'
        assert response.data['error_message'] == 'Invalid Parameter'
        assert response.data['subscriptions'] is None

    def test_set_internal_calc_with_false(self):
        """
        リクエストパラメータにinternal_calcがfalseで設定されるとプロフィットシェア無効の結果が返る
        """
        ContractInfo.objects.all().delete()
        ContractServiceInfo.objects.all().delete()
        ProductInfo.objects.all().delete()

        with freezegun.freeze_time('2015-06-02', tick=True):
            contract1 = ContractInfo.objects.create(
                subscription_id='dpa_70015',
                subscription_number='',
                contract_code='',
                spf_tenant_id='spf0000000123',
                opco_code='FX',
                closing_day=30,
            )
            contract2 = ContractInfo.objects.create(
                subscription_id='dpa_70016',
                subscription_number=None,
                contract_code=None,
                spf_tenant_id='spf0000000456',
                opco_code='FX',
                closing_day=30,
            )
            contract3 = ContractInfo.objects.create(
                subscription_id='dpa_70017',
                subscription_number='xxx',
                contract_code='xxx',
                spf_tenant_id='spf0000000456',
                opco_code='FX',
                closing_day=30,
            )
            product = ProductInfo.objects.create(
                product_code='ABCXX1000',
                product_name='ABCXX1000',
                flat_rate=False,
                created_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                updated_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
            )
            ContractServiceInfo.objects.create(
                subscription=contract1,
                product_code=product,
                product_type='option',
                state='active',
                license_quantity=None,
                license_users='003,002',
                service_start_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                service_update_time=None,
                service_cancel_time=None
            )
            ContractServiceInfo.objects.create(
                subscription=contract2,
                product_code=product,
                product_type='option',
                state='active',
                license_quantity=None,
                license_users='003,002',
                service_start_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                service_update_time=None,
                service_cancel_time=None
            )
            ContractServiceInfo.objects.create(
                subscription=contract3,
                product_code=product,
                product_type='option',
                state='active',
                license_quantity=None,
                license_users='003,002',
                service_start_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                service_update_time=None,
                service_cancel_time=None
            )
        response = self.client.get(
            '/subscriptions/',
            {
                'from_updated_time': '20150601T000000Z',
                'to_updated_time': '20150603T000000Z',
                'internal_calc': 'false'
            })

        assert response.status_code == 200
        assert response.data['success'] is True
        assert response.data['count'] is 1
        assert len(response.data['subscriptions']) == 1
        assert response.data['subscriptions'][0][
                   'subscription_id'] == 'dpa_70017'
        ContractInfo.objects.all().delete()
        ContractServiceInfo.objects.all().delete()
        ProductInfo.objects.all().delete()

    def test_set_internal_calc_with_true(self):
        """
        リクエストパラメータにinternal_calcがtrueで設定されるとプロフィットシェアの結果が返る
        """
        ContractInfo.objects.all().delete()
        ContractServiceInfo.objects.all().delete()
        ProductInfo.objects.all().delete()

        with freezegun.freeze_time('2015-06-02', tick=True):
            contract1 = ContractInfo.objects.create(
                subscription_id='dpa_70015',
                subscription_number='',
                contract_code='',
                spf_tenant_id='spf0000000123',
                opco_code='FXS',
                closing_day=30,
            )
            contract2 = ContractInfo.objects.create(
                subscription_id='dpa_70016',
                subscription_number=None,
                contract_code=None,
                spf_tenant_id='spf0000000456',
                opco_code='FXS',
                closing_day=30,
            )
            contract3 = ContractInfo.objects.create(
                subscription_id='dpa_70017',
                subscription_number='xxx',
                contract_code='xxx',
                spf_tenant_id='spf0000000456',
                opco_code='FXS',
                closing_day=30,
            )
            product = ProductInfo.objects.create(
                product_code='ABCXX1000',
                product_name='ABCXX1000',
                flat_rate=False,
                created_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                updated_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
            )
            ContractServiceInfo.objects.create(
                subscription=contract1,
                product_code=product,
                product_type='option',
                state='active',
                license_quantity=None,
                license_users='003,002',
                service_start_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                service_update_time=None,
                service_cancel_time=None
            )
            ContractServiceInfo.objects.create(
                subscription=contract2,
                product_code=product,
                product_type='option',
                state='active',
                license_quantity=None,
                license_users='003,002',
                service_start_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                service_update_time=None,
                service_cancel_time=None
            )
            ContractServiceInfo.objects.create(
                subscription=contract3,
                product_code=product,
                product_type='option',
                state='active',
                license_quantity=None,
                license_users='003,002',
                service_start_time=datetime(2018, 2, 1, 0, 0, 0, tzinfo=pytz.UTC),
                service_update_time=None,
                service_cancel_time=None
            )
        response = self.client.get(
            '/subscriptions/',
            {
                'from_updated_time': '20150601T000000Z',
                'to_updated_time': '20150603T000000Z',
                'internal_calc': 'true'
            })

        assert response.status_code == 200
        assert response.data['success'] is True
        assert response.data['count'] is 2
        assert len(response.data['subscriptions']) == 2
        assert response.data['subscriptions'][1][
                   'subscription_id'] == 'dpa_70017G'
        assert response.data['subscriptions'][1][
                   'subscription_number'] == 'xxx'
        assert response.data['subscriptions'][1][
                   'spf_tenant_id'] == 'spf0000000456'
        assert response.data['subscriptions'][1][
                   'opco_code'] == 'FX'
        assert response.data['subscriptions'][1][
                   'products'][0]['product_code'] == 'ABCXX1000C6'
        assert response.data['subscriptions'][1][
                   'products'][1]['product_code'] == 'ABCXX1000C7'
        assert response.data['subscriptions'][1][
                   'products'][2]['product_code'] == 'ABCXX1000C8'
        assert response.data['subscriptions'][1][
                   'products'][3]['product_code'] == 'ABCXX1000C9'
        assert response.data['subscriptions'][1][
                   'products'][4]['product_code'] == 'ABCXX1000C10'
        assert response.data['subscriptions'][1][
                   'products'][5]['product_code'] == 'ABCXX1000C11'
        ContractInfo.objects.all().delete()
        ContractServiceInfo.objects.all().delete()
        ProductInfo.objects.all().delete()

    def test_count_internal_calc_with_true(self):
        """
        リクエストパラメータにinternal_calcがtrueで設定されても上限は100件
        """
        response = self.client.get(
            '/subscriptions/',
            {
                'internal_calc': 'true'
            })
        assert response.status_code == 200
        assert response.data['success'] is True
        assert len(response.data['subscriptions']) == 100
