"""
<copyright file="views.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import copy
from datetime import datetime

from dateutil.relativedelta import relativedelta
from django.db import DatabaseError, transaction, connection
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.decorators import parser_classes
from rest_framework.parsers import JSONParser
from rest_framework.response import Response

from lib.const.billing_info_state import COMPLETED
from lib.const.error_message import USAGE_NOT_FOUND, USAGE_NOT_CALCULATED, BILLING_RECORDS_ARE_NOT_CREATED, \
    CONTRACT_NOT_FOUND, INVALID_PARAMETER
from lib.const.internal_calc import SUBSCRIPTION_ID_POSTFIX, PRODUCT_CODE_POSTFIXES
from lib.http_response_util import HttpResponseUtil
from lib.shortcuts import get_object_or_None
from lib.utils import logger, check_date_ym_format, DateTimeUtil
from .models import BillingDetailInfo, BillingUsageDetailInfo
from .models import ContractInfo, ContractServiceInfo, BillingInfo, UsageInfo
from .serializers import BillingDetailInfoPostSerializer
from .serializers import BillingDetailInfoSerializer
from .serializers import BillingInfoPostSerializer
from .serializers import BillingInfoSerializer
from .serializers import BillingUsageDetailInfoPostSerializer
from .serializers import BillingUsageDetailInfoSerializer
from .serializers import ContractInfoPostSerializer
from .serializers import ContractInfoSerializer
from .serializers import ContractServiceInfoPostSerializer
from .serializers import ContractServiceInfoSerializer
from .serializers import UsageInfoSerializer, SubscriptionsUsagePostSerializer


@api_view(['GET', 'POST'])
@parser_classes((JSONParser, ))
@transaction.atomic
def subscriptions_detail(request, pk):
    if request.method == 'GET':
        return _get_subscriptions_detail(pk)
    elif request.method == 'POST':
        return _post_subscriptions_detail(request, pk)


def _get_subscriptions_detail(pk):
    """
    サブスクリプションIDを指定して契約情報の単体取得を行う
    :param pk: サブスクリプションID
    :return:
    """
    error_extra_info = {
        'extra_info': {
            'count': None,
            'subscription': None
        }
    }

    try:
        contract_info = ContractInfo.objects.get(pk=pk)
        contract_service_infos = ContractServiceInfo.objects.filter(
            subscription_id=pk)
    except ContractInfo.DoesNotExist:
        return HttpResponseUtil.not_found(error_message=CONTRACT_NOT_FOUND, **error_extra_info)
    contract_info_serializer = ContractInfoSerializer(contract_info)
    products = []
    for contract_service_info in contract_service_infos:
        contract_service_info_serializer = ContractServiceInfoSerializer(
            contract_service_info)
        products.append(contract_service_info_serializer.data)
    response = {
        'success':  True,
        'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
        'error_status': None,
        'error_message': None,
        'subscription': contract_info_serializer.data
    }
    response['subscription']['products'] = products
    return Response(response)


def _post_subscriptions_detail(request, pk):
    """
    サブスクリプションIDを指定して契約情報の単体登録を行う
    :param request:
    :param pk:
    :return:
    """
    request_data = request.data
    request_data['subscription_id'] = pk
    validated_data = ContractInfoPostSerializer(request_data)

    contract_instance = get_object_or_None(ContractInfo, pk=pk)
    if contract_instance is None:
        contract_info = ContractInfoSerializer(
            ContractInfo(subscription_id=pk),
            data=validated_data.data,
        )
    else:
        contract_info = ContractInfoSerializer(
            contract_instance,
            data=validated_data.data,
        )

    if not contract_info.is_valid():
        logger().error(contract_info.errors)
        return Response(
            {
                'success': False,
                'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
                'error_status': '400',
                'error_message': 'Invalid Parameter'
            },
            status=status.HTTP_400_BAD_REQUEST)
    try:
        with transaction.atomic():
            contract_info.save()
            for product in request.data.get('products'):
                request_data = product
                request_data['subscription_id'] = pk
                validated_data = ContractServiceInfoPostSerializer(
                    request_data)

                csi_instance = get_object_or_None(ContractServiceInfo,
                                                  subscription=pk,
                                                  product_code=validated_data.data['product_code']
                                                  )
                if csi_instance is None:
                    contract_service_info = ContractServiceInfoSerializer(
                        data=validated_data.data
                    )
                else:
                    contract_service_info = ContractServiceInfoSerializer(
                        csi_instance,
                        data=validated_data.data
                    )

                if not contract_service_info.is_valid():
                    logger().error(contract_service_info.errors)
                    return Response(
                        {
                            'success': False,
                            'time_stamp':
                                datetime.now().strftime(
                                    '%Y%m%dT%H:%M:%SZ'),
                            'error_status': '400',
                            'error_message':
                                'Invalid Parameter'
                        },
                        status=status.HTTP_400_BAD_REQUEST
                    )
                contract_service_info.save()

        return Response(
            {
                'success': True,
                'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
                'error_status': None,
                'error_message': None
            },
            status=status.HTTP_200_OK)
    except DatabaseError as e:
        logger().error(e)
        return Response(
            {
                'success': False,
                'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
                'error_status': '500',
                'error_message': 'Internal error'
            },
            status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['POST'])
@parser_classes((JSONParser, ))
@transaction.atomic
def subscriptions_usage(request, pk):
    if request.method == 'POST':
        request_data = request.data
        request_data['subscription_id'] = pk
        request_data_serializer = SubscriptionsUsagePostSerializer(
            request_data)
        usage_info = UsageInfoSerializer(
            data=request_data_serializer.data
        )

        if not usage_info.is_valid():
            errors = usage_info.errors
            if errors.get('subscription'):
                if list(filter(lambda x: x.code != 'does_not_exist', errors.get('subscription'))) == []:
                    del errors['subscription']
            if errors:
                logger().error(errors)
                return Response(
                    {
                        'success': False,
                        'time_stamp':
                        datetime.now().strftime('%Y%m%dT%H:%M:%SZ'),
                        'error_status': '400',
                        'error_message': 'Invalid Parameter'
                    },
                    status=status.HTTP_400_BAD_REQUEST)

        contract_info = get_object_or_None(ContractInfo, pk=pk)
        if contract_info:
            request_data_serializer.data['subscription'] = contract_info
        else:
            request_data_serializer.data['subscription'] = ContractInfo({
                'subscription_id': request_data_serializer.data['subscription']
            })
        usage_info = UsageInfo(**request_data_serializer.data)
        usage_info.subscription_id = request_data['subscription_id']
        usage_info.start_time += '+00:00'
        usage_info.end_time += '+00:00'

        try:
            with transaction.atomic():
                usage_info.save()

                if contract_info is None:
                    logger().error(f'The usage info(usage_id={usage_info.usage_id})\'s subscription_id({pk}) does not found in ContractInfo')

                return Response(
                    {
                        'success': True,
                        'usage_id': usage_info.usage_id,
                        'time_stamp': datetime.now().strftime(
                            '%Y%m%dT%H%M%SZ'),
                        'error_status': None,
                        'error_message': None
                    },
                    status=status.HTTP_200_OK
                )
        except DatabaseError as e:
            logger().error(e)
            return Response(
                {
                    'success': False,
                    'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
                    'error_status': '500',
                    'error_message': 'Internal error'
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['GET'])
@parser_classes((JSONParser, ))
@transaction.atomic
def subscriptions_bulk_fetch(request):
    # 指定がなければepochから今時点まで
    from_updated_time = request.GET.get(
        key='from_updated_time',
        default=datetime.fromtimestamp(0).strftime(
            '%Y%m%dT%H%M%SZ'))
    to_updated_time = request.GET.get(
        key='to_updated_time',
        default=datetime.now().strftime('%Y%m%dT%H%M%SZ'))
    internal_calc = request.GET.get('internal_calc')

    response_400 = Response(
        {
            'success': False,
            'count': None,
            'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
            'error_status': '400',
            'error_message': 'Invalid Parameter',
            'subscriptions': None
        },
        status=status.HTTP_400_BAD_REQUEST)

    try:
        from_updated_time = DateTimeUtil.replace_utc(
            datetime.strptime(from_updated_time, '%Y%m%dT%H%M%SZ'))
        to_updated_time = DateTimeUtil.replace_utc(
            datetime.strptime(to_updated_time, '%Y%m%dT%H%M%SZ'))
    except ValueError as e:
        logger().error(e)
        return response_400

    if from_updated_time > to_updated_time:
        return response_400

    internal_calc_allowed_value = [
        'true',
        'false'
    ]
    if internal_calc is not None and internal_calc not in internal_calc_allowed_value:
        logger().error('internal_calc is choice field but allowed value was not included in this request')
        return response_400

    if internal_calc == 'true':
        internal_calc = True
        limit = 50
    else:
        internal_calc = False
        limit = 100

    offset = request.GET.get(
        key='offset',
        default='1')

    try:
        if int(offset) < 1:
            raise ValueError
    except ValueError as e:
        logger().error(e)
        return response_400

    contract_infos = ContractInfo.objects.raw(f'''
        select * from (
            select distinct ci.subscription_id, max(csi.updated_time)
            from contract_info ci
            inner join contract_service_info csi on ci.subscription_id = csi.subscription_id
            where
                "{from_updated_time.strftime("%Y-%m-%d %H:%M:%S")}" <= csi.updated_time
                and
                csi.updated_time < "{to_updated_time.strftime("%Y-%m-%d %H:%M:%S")}"
                and
                ci.contract_code is not null
                and
                ci.contract_code <> ""
            group by ci.subscription_id
            order by max(csi.updated_time) desc
            limit {str(limit)} offset {str(int(offset)-1)}
        ) ci
        inner join contract_service_info csi on ci.subscription_id = csi.subscription_id
    ''')
    count = len(list(contract_infos))
    with connection.cursor() as cursor:
        cursor.execute(f'''
            select count(distinct ci.subscription_id)
        from contract_info ci
        inner join contract_service_info csi on ci.subscription_id = csi.subscription_id
        where
            "{from_updated_time.strftime("%Y-%m-%d %H:%M:%S")}" <= csi.updated_time
            and
            csi.updated_time < "{to_updated_time.strftime("%Y-%m-%d %H:%M:%S")}"
            and
            ci.contract_code is not null
            and
            ci.contract_code <> ""
        ''')
        count_without_limit = cursor.fetchone()[0]

    if count_without_limit < int(offset) and int(offset) > 1:
        return response_400

    if internal_calc:
        count_without_limit *= 2

    if count == 0:
        return Response(
            {
                'success': False,
                'count': None,
                'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
                'error_status': '404',
                'error_message': 'Contract not found',
                'subscriptions': None
            },
            status=status.HTTP_404_NOT_FOUND)

    def serialize(contract_info):
        contract_info.subscription = ''
        contract_info.product_code_id = contract_info.product_code
        return ContractServiceInfoSerializer(contract_info).data
    subscriptions = []
    for contract_info in contract_infos:
        stored = False
        for subscription in subscriptions:
            if subscription['subscription_id'] == \
                    contract_info.subscription_id:
                subscription['products'].append(serialize(contract_info))
                stored = True
        if stored is False:
            contract_info_serializer = \
                ContractInfoSerializer(contract_info).data
            del contract_info_serializer['contract_code']
            contract_info.subscription = ''
            contract_info.product_code_id = contract_info.product_code
            contract_info_serializer['products'] = [serialize(contract_info)]
            subscriptions.append(contract_info_serializer)

    for subscription in subscriptions:
        subscription['products'].sort(key=lambda x: x['product_code'])
    if internal_calc is True:
        subscriptions_ghost = copy.deepcopy(subscriptions)
        for subscription_ghost in subscriptions_ghost:
            subscription_ghost['subscription_id'] = subscription_ghost['subscription_id'] + SUBSCRIPTION_ID_POSTFIX
            subscription_ghost['opco_code'] = 'FX'
            if subscription_ghost.get('products') is not None:
                products_ghost = []
                for product in subscription_ghost['products']:
                    product_ghost = copy.deepcopy(product)
                    for ghost_product_code in PRODUCT_CODE_POSTFIXES:
                        product_ghost['product_code'] = product['product_code'] + ghost_product_code
                        products_ghost.append(copy.deepcopy(product_ghost))
                subscription_ghost['products'] = products_ghost
        subscriptions.extend(subscriptions_ghost)

    return Response(
        {
            'success': True,
            'count': count_without_limit,
            'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
            'error_status': None,
            'error_message': None,
            'subscriptions': subscriptions
        },
        status=status.HTTP_200_OK
    )


@api_view(['GET'])
@parser_classes((JSONParser, ))
@transaction.atomic
def usage_info(request, pk, target_month):
    return _get_subscriptions_billing(request, pk, target_month)


@api_view(['POST'])
@parser_classes((JSONParser, ))
@transaction.atomic
def subscriptions_billing(request, pk, target_month):
    return _post_subscriptions_billing(request, pk, target_month)


def _get_subscriptions_billing(request, subscription, target_month):
    error_extra_info = {'extra_info': {'usage': None}}
    if check_date_ym_format(target_month) is False:
        logger().error('target_month went wrong format in this request')
        return HttpResponseUtil.bad_request(**error_extra_info)

    try:
        billing_info = BillingInfo.objects.get(subscription=subscription, target_month=target_month)
    except BillingInfo.DoesNotExist:
        return HttpResponseUtil.not_found(USAGE_NOT_FOUND, **error_extra_info)

    if billing_info.state != COMPLETED:
        return HttpResponseUtil.forbidden(USAGE_NOT_CALCULATED, **error_extra_info)

    product_code = request.GET.get('product_code')
    if product_code:
        billing_detail_infos = BillingDetailInfo.objects.filter(subscription=subscription, target_month=target_month, product_code=product_code)
        billing_usage_detail_infos = BillingUsageDetailInfo.objects.filter(subscription=subscription, target_month=target_month, product_code=product_code)
    else:
        billing_detail_infos = BillingDetailInfo.objects.filter(subscription=subscription, target_month=target_month)
        billing_usage_detail_infos = BillingUsageDetailInfo.objects.filter(subscription=subscription, target_month=target_month)

    if billing_detail_infos.count() == 0:
        return HttpResponseUtil.not_found(USAGE_NOT_FOUND, **error_extra_info)

    billing_details = list()
    for billing_detail_info in billing_detail_infos:
        same_product_code_billing_usage_detail_infos = list(filter(
            lambda x: x.product_code_id == billing_detail_info.product_code_id,
            billing_usage_detail_infos
        ))

        billing_detail = BillingDetailInfoSerializer(billing_detail_info).data
        del billing_detail['subscription']
        del billing_detail['target_month']
        del billing_detail['billing']
        billing_detail['product_code'] = billing_detail_info.product_code_id
        billing_detail['user_usage_details'] = list()
        for billing_usage_detail_info in same_product_code_billing_usage_detail_infos:
            billing_usage_detail = BillingUsageDetailInfoSerializer(billing_usage_detail_info).data
            del billing_usage_detail['product_code']
            del billing_usage_detail['subscription']
            del billing_usage_detail['target_month']
            del billing_usage_detail['billing']
            billing_detail['user_usage_details'].append(billing_usage_detail)

        billing_details.append(billing_detail)

    extra_info = {
        'usage': {
            'subscription_id': subscription,
            'target_month': target_month,
            'usage_details': billing_details
        }
    }
    return HttpResponseUtil.ok(**{'extra_info': extra_info})


def _post_subscriptions_billing(request, pk, target_month):
        try:
            with transaction.atomic():
                request_data = request.data
                request_data['subscription_id'] = pk
                request_data['target_month'] = target_month
                validated_data = BillingInfoPostSerializer(request_data)
                
                subscription_id = pk
                if pk.endswith(SUBSCRIPTION_ID_POSTFIX):
                    subscription_id = subscription_id[:-1]
                ci = get_object_or_None(ContractInfo, pk=subscription_id)
                
                if ci is None:
                    raise DatabaseError(CONTRACT_NOT_FOUND)
                else:
                    ci_is_zuora = ci.is_zuora()
                    bi = get_object_or_None(BillingInfo,
                                         subscription=validated_data.data['subscription'],
                                         target_month=validated_data.data['target_month']
                                            )
                    # K5契約に関しては、更新のみ許可
                    if not ci_is_zuora and bi is None:
                        raise DatabaseError(BILLING_RECORDS_ARE_NOT_CREATED)

                    billing_info = BillingInfoSerializer(
                        bi,
                        data=validated_data.data)

                if not billing_info.is_valid():
                    logger().error(billing_info.errors)
                    raise DatabaseError(INVALID_PARAMETER)
                    return HttpResponseUtil.bad_request()
                billing_info.save()
                for billing_detail in request.data.get('billing_details'):
                    request_data = billing_detail
                    request_data['subscription_id'] = pk
                    request_data['target_month'] = target_month
                    validated_data = BillingDetailInfoPostSerializer(
                            request_data)

                    bdi = get_object_or_None(BillingDetailInfo,
                                             subscription=validated_data.data['subscription'],
                                             target_month=validated_data.data['target_month'],
                                             product_code=validated_data.data['product_code']
                                             )
                    # K5契約に関しては、更新のみ許可
                    if not ci_is_zuora and bdi is None:
                        raise DatabaseError(BILLING_RECORDS_ARE_NOT_CREATED)

                    billing_detail_info = BillingDetailInfoSerializer(
                        bdi,
                        data=validated_data.data)

                    if not billing_detail_info.is_valid():
                        logger().error(billing_detail_info.errors)
                        raise DatabaseError(INVALID_PARAMETER)
                    billing_detail_info.save()

                    billing_usage_details = billing_detail.get(
                        'billing_usage_details')
                    if (billing_usage_details is not None)\
                            and billing_usage_details != []:
                        for billing_usage_detail in billing_usage_details:
                            request_data = billing_usage_detail
                            request_data['subscription_id'] = pk
                            request_data['target_month'] = target_month
                            request_data['product_code'] = billing_detail.get(
                                'product_code')
                            validated_data = \
                                BillingUsageDetailInfoPostSerializer(
                                    request_data)
                            budi = get_object_or_None(BillingUsageDetailInfo,
                                                      subscription=validated_data.data[
                                                          'subscription'],
                                                      target_month=validated_data.data[
                                                          'target_month'],
                                                      product_code=validated_data.data[
                                                          'product_code'],
                                                      license_user=validated_data.data[
                                                          'license_user']
                                                      )
                            if budi is None:
                                billing_usage_detail_info = \
                                    BillingUsageDetailInfoSerializer(
                                        data=validated_data.data)
                            else:
                                billing_usage_detail_info = \
                                    BillingUsageDetailInfoSerializer(
                                        budi,
                                        data=validated_data.data)

                            if not billing_usage_detail_info.is_valid():
                                logger().error(billing_usage_detail_info.errors)
                                raise DatabaseError(INVALID_PARAMETER)

                            billing_usage_detail_info.save()
                return HttpResponseUtil.ok()
        except DatabaseError as e:
            logger().error(e)
            if str(e) == BILLING_RECORDS_ARE_NOT_CREATED:
                return HttpResponseUtil.forbidden(BILLING_RECORDS_ARE_NOT_CREATED)
            elif str(e) == INVALID_PARAMETER:
                return HttpResponseUtil.bad_request()
            elif str(e) == CONTRACT_NOT_FOUND:
                return HttpResponseUtil.not_found(CONTRACT_NOT_FOUND)
            return HttpResponseUtil.internal_server_error()


@api_view(['GET', 'POST'])
@parser_classes((JSONParser,))
@transaction.atomic
def subscriptions_billings(request, pk):
    if request.method == 'GET':
        return _get_subscriptions_billings(request, pk)


def _get_subscriptions_billings(request, pk):
    from_target_month = request.GET.get('from_target_month')
    to_target_month = request.GET.get('to_target_month')
    bad_request_error_extra_info = {
        'extra_info': {'subscription_id': pk, 'error_message': 'Invalid Parameter', 'billing_infos': None}}
    not_found_error_extra_info = {
        'extra_info': {'subscription_id': pk, 'error_message': 'Any billing not found', 'billing_infos': None}}
    response_400 = HttpResponseUtil.bad_request(**bad_request_error_extra_info)
    response_404 = HttpResponseUtil.not_found(**not_found_error_extra_info)

    if (check_date_ym_format(from_target_month) and check_date_ym_format(to_target_month)) is False:
        logger().error(f'date format is invalid: {from_target_month}, {to_target_month}')
        return response_400

    if from_target_month > to_target_month:
        logger().error(f'designated term is logically invalid: {from_target_month} - {to_target_month}')
        return response_400

    if _requested_term(from_target_month, to_target_month) > 23:
        logger().error(f'requested term exceeds maximum value.')
        return response_400
    logger().info(f'designated term is effective: {from_target_month} - {to_target_month}')

    if pk.lower().endswith('g'):
        logger().error(f'requested subscription is ghost.')
        return response_404
    billing_infos = BillingInfo.objects.raw(f'''
        SELECT DISTINCT
            bl.id,
            bl.subscription_id,
            bl.target_month,
            bl.start_date,
            bl.end_date,
            bl.billing,
            bl.unit_of_money,
            bl.state,
            bdi.id,
            bdi.product_code,
            bdi.license_quantity,
            bdi.billing AS bdi_billing,
            bdi.quantity,
            budi.id,
            budi.license_user,
            budi.billing AS budi_billing,
            budi.quantity AS budi_quantity
            FROM billing_info bl
            LEFT OUTER JOIN `billing_detail_info` bdi
            ON bl.target_month = bdi.target_month
                AND bl.subscription_id = bdi.subscription_id
            LEFT OUTER JOIN billing_usage_detail_info budi
            ON bdi.target_month = budi.target_month
                AND bdi.subscription_id = budi.subscription_id
                AND bdi.product_code = budi.product_code
            WHERE bl.subscription_id = '{pk}'
            AND bl.target_month >= '{from_target_month}'
            AND bl.target_month <= '{to_target_month}'
            ORDER BY bl.target_month, bdi.product_code, budi.license_user
    ''')
    if len(list(billing_infos)) == 0:
        return response_404
    logger().info(f'{len(list(billing_infos))} entries are queried from the database')
    billing_info_response = _billing_info_response_builder(billing_infos)
    billing_info_response_len = len(list(billing_info_response))
    if billing_info_response_len == 0:
        return response_404
    ok_200_extra_info = {'extra_info': {'success': True, 'subscription_id': pk, 'billing_infos': billing_info_response}}
    response_200 = HttpResponseUtil.ok(**ok_200_extra_info)
    response_207 = HttpResponseUtil.response(http_status=207, success=True, error_status=None, error_message=None,
                                             **ok_200_extra_info)
    return response_200 if _is_month_continuous(billing_info_response) else response_207


def _requested_term(from_target_month, to_target_month):
    from_target_month_term = datetime(int(from_target_month[0:4]), int(from_target_month[4:6]), 1)
    to_target_month_term = datetime(int(to_target_month[0:4]), int(to_target_month[4:6]), 1)
    years_count = (to_target_month_term.year - from_target_month_term.year) * 12
    month_count = from_target_month_term.month - to_target_month_term.month
    return years_count + month_count


def _billing_info_response_builder(billing_infos):
    target_month = None
    product_code = None
    license_user = None
    billing_info_response = list()
    for i, billing_info in enumerate(billing_infos):
        if billing_info.product_code is None:
            logger().error(
                f'any billing detail info for subscription_id={billing_info.subscription_id},target_month={billing_info.target_month} is not found...')
            continue
        if target_month != billing_info.target_month and billing_info.state == COMPLETED:
            target_month = billing_info.target_month
            product_code = None
            billing_info_response.append(_billing_info_builder(billing_info))
        elif billing_info.state != COMPLETED:
            if target_month != billing_info.target_month:
                logger().info(
                    f'subscription_id={billing_info.subscription_id}, target_month={billing_info.target_month} billing detail info is not completed...')
                target_month = billing_info.target_month
            continue
        if product_code != billing_info.product_code:
            product_code = billing_info.product_code
            billing_info_response[-1]["billing_details"].append(_billing_details_builder(billing_info))
            license_user = None
        if (license_user != billing_info.license_user) and billing_info.license_user is not None:
            license_user = billing_info.license_user
            billing_info_response[-1]["billing_details"][-1]["billing_usage_detail"] \
                .append(_billing_usage_detail_builder(billing_info))
    return billing_info_response


def _billing_info_builder(billing_info):
    return {
        "target_month": billing_info.target_month,
        "start_date": billing_info.start_date.strftime('%Y%m%d'),
        "end_date": billing_info.end_date.strftime('%Y%m%d'),
        "billing": billing_info.billing,
        "unit_of_money": billing_info.unit_of_money,
        "billing_details": list()
    }


def _billing_details_builder(billing_info):
    return {
        "product_code": billing_info.product_code,
        "license_quantity": billing_info.license_quantity,
        "billing": billing_info.bdi_billing,
        "quantity": billing_info.quantity,
        "billing_usage_detail": list()}


def _billing_usage_detail_builder(billing_info):
    return {
        "license_user": billing_info.license_user,
        "billing": billing_info.budi_billing,
        "quantity": billing_info.budi_quantity}


def _is_month_continuous(billing_infos):
    temp_target_month = None
    is_continuous = True

    for billing_info in billing_infos:
        if temp_target_month is None:
            temp_target_month = billing_info['target_month']
        else:
            next_month = __get_next_month(temp_target_month)
            while (billing_info['target_month'] != next_month) and (next_month < billing_infos[-1]['target_month']):
                next_month = __get_next_month(next_month)
                logger().info(f'{temp_target_month} info is not found...')
                is_continuous = False
            temp_target_month = next_month
    return is_continuous


def __get_next_month(month):
    start_month = datetime(int(month[0:4]), int(month[4:6]), 1)
    new_month = start_month + relativedelta(months=1)
    return new_month.strftime('%Y%m')
