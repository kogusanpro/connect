"""
<copyright file="tests_subscriptions_billing.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from rest_framework.test import APIClient
from rest_framework.test import APITestCase
from .models import ContractInfo, ContractServiceInfo, UsageInfo
from .models import BillingInfo, BillingDetailInfo, BillingUsageDetailInfo, ProductInfo
from lib.utils import check_datetime_format, DateTimeUtil
from .factory_boy import BillingDetailInfoFactory, BillingUsageDetailInfoFactory, BillingInfoFactory, ContractInfoFactory
from lib.const.billing_info_state import NEW, COMPLETED

from datetime import datetime
import string
import random
import freezegun
import time
from pprint import pprint
import pytz


class SubscriptionsBillingTest(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.subscription_id = ''.join([
            random.choice('%s%s' % (string.ascii_letters, string.digits))
            for i in range(10)
        ])
        c = ContractInfo(
            subscription_id=self.subscription_id,
            subscription_number = 'xxx',
            contract_code='xxx',
            spf_tenant_id='spf0000000123',
            opco_code='FX',
            closing_day=2
        )
        c.save()

    def test_validation_target_month(self):
        '''
        リクエストパタメータのtarget_monthがyyyymm形式じゃないときに400エラーを返す
        '''
        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'completed',
            'billing_details': [
                {
                    'product_code': 'ABCD1000',
                    'product_type': 'basic',
                    'license_quantity': 1,
                    'billing': '4500',
                    'quantity': '450',
                },
                {
                    'product_code': 'ABCD1001',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '001',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812123/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
            'error_message'] == 'Invalid Parameter'
        self.assertRaises(BillingInfo.DoesNotExist, BillingInfo.objects.get,
                          subscription=self.subscription_id,
                          target_month='201812123')

    def test_validation_non_state(self):
        '''
        リクエストbodyにstateが無いときに400エラーを返す
        '''
        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'billing_details': [
                {
                    'product_code': 'ABCD1000',
                    'product_type': 'basic',
                    'license_quantity': 1,
                    'billing': '4500',
                    'quantity': '450',
                },
                {
                    'product_code': 'ABCD1001',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '001',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
            'error_message'] == 'Invalid Parameter'
        self.assertRaises(BillingInfo.DoesNotExist, BillingInfo.objects.get,
                          subscription=self.subscription_id,
                          target_month='201812')

    def test_validation_billing_details(self):
        '''
        リクエストbodyにbilling_detailsが無いときに400エラーを返す
        '''
        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'state': 'completed',
            'unit_of_money': 'JPY',
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
            'error_message'] == 'Invalid Parameter'

        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'state': 'completed',
            'unit_of_money': 'JPY',
            'billing_details': None
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
            'error_message'] == 'Invalid Parameter'

        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'state': 'completed',
            'unit_of_money': 'JPY',
            'billing_details': []
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
            'error_message'] == 'Invalid Parameter'
        self.assertRaises(BillingInfo.DoesNotExist, BillingInfo.objects.get,
                          subscription=self.subscription_id,
                          target_month='201812')

    def test_validation_start_date_format(self):
        '''
        リクエストbodyのstart_dateがyyyymm形式じゃないときに400エラーを返す
        '''
        body = {
            'start_date': '201803010',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'completed',
            'billing_details': [
                {
                    'product_code': 'ABCD1000',
                    'product_type': 'basic',
                    'license_quantity': 1,
                    'billing': '4500',
                    'quantity': '450',
                },
                {
                    'product_code': 'ABCD1001',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '001',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
            'error_message'] == 'Invalid Parameter'
        self.assertRaises(BillingInfo.DoesNotExist, BillingInfo.objects.get,
                          subscription=self.subscription_id,
                          target_month='201812')

    def test_validation_end_date_format(self):
        '''
        リクエストbodyのstart_dateがyyyymm形式じゃないときに400エラーを返す
        '''
        body = {
            'start_date': '20180301',
            'end_date': '201803310',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'completed',
            'billing_details': [
                {
                    'product_code': 'ABCD1000',
                    'product_type': 'basic',
                    'license_quantity': 1,
                    'billing': '4500',
                    'quantity': '450',
                },
                {
                    'product_code': 'ABCD1001',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '001',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
            'error_message'] == 'Invalid Parameter'
        self.assertRaises(BillingInfo.DoesNotExist, BillingInfo.objects.get,
                          subscription=self.subscription_id,
                          target_month='201812')

    def test_validation_range_state(self):
        '''
        リクエストbodyのstateがnew,calculating,completed以外の時400エラーを返す
        '''
        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'completeds',
            'billing_details': [
                {
                    'product_code': 'ABCD1000',
                    'product_type': 'basic',
                    'license_quantity': 1,
                    'billing': '4500',
                    'quantity': '450',
                },
                {
                    'product_code': 'ABCD1001',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '001',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
            'error_message'] == 'Invalid Parameter'
        self.assertRaises(BillingInfo.DoesNotExist, BillingInfo.objects.get,
                          subscription=self.subscription_id,
                          target_month='201812')

    def test_duplicate(self):
        '''
        stateがcompletedのデータを更新しようとすると403エラーを返す
        '''
        BillingInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            state='completed'
        )
        BillingDetailInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            product_code=ProductInfo(product_code='ABCD1000')
        )
        BillingDetailInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            product_code=ProductInfo(product_code='ABCD1001')
        )

        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'completed',
            'billing_details': [
                {
                    'product_code': 'ABCD1000',
                    'product_type': 'basic',
                    'license_quantity': 1,
                    'billing': '4500',
                    'quantity': '450',
                    'billing_usage_details': [
                        {
                            'license_user': '001',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                },
                {
                    'product_code': 'ABCD1001',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '001',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 403
        assert response.data[
            'error_message'] == 'Billing already exists'
        assert BillingInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812'
        ).subscription_id == self.subscription_id

    def test_validation_non_product_code(self):
        '''
        リクエストボディにproduct_codeが無いと400エラーを返す
        '''
        BillingInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            state='new'
        )

        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'completed',
            'billing_details': [
                {
                    'license_quantity': 1,
                    'billing': '4500',
                    'quantity': '450',
                    'billing_usage_details': [
                        {
                            'license_user': '001',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                },
                {
                    'product_code': 'ABCD1001',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '001',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
            'error_message'] == 'Invalid Parameter'

    def test_validation_non_billing_usage_details(self):
        '''
        リクエストボディにbilling_usage_detailsが無いと400エラーを返す
        '''
        BillingInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            state='new'
        )

        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'completed',
            'billing_details': [
                {
                    'product_code': 'ABCD1000',
                    'license_quantity': 1,
                    'billing': '4500',
                    'quantity': '450',
                },
                {
                    'product_code': 'ABCD1001',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '001',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
            'error_message'] == 'Invalid Parameter'

    def test_validation_non_license_user(self):
        '''
        リクエストボディにlicense_userが無いと400エラーを返す
        '''
        BillingInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            state='new'
        )
        BillingDetailInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            product_code=ProductInfo(product_code='ABCD1001')
        )

        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'completed',
            'billing_details': [
                {
                    'product_code': 'ABCD1001',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
            'error_message'] == 'Invalid Parameter'

    def test_validation_model(self):
        '''
        DBの制約に引っかかるリクエストデータは自動でmodelが400エラーを返す
        '''
        BillingInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            state='new'
        )

        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPYaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
            'state': 'completed',
            'billing_details': [
                {
                    'product_code': 'ABCD1001',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400

    def test_post_success_with_billing_usage_details_is_null(self):
        '''
        billing_usage_detailsがnullでも正常なデータで正常にデータ登録が完了する
        '''
        BillingInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            state='new'
        )
        BillingDetailInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            product_code=ProductInfo(product_code='ABCD1001')
        )
        BillingDetailInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            product_code=ProductInfo(product_code='ABCD1002')
        )

        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'completed',
            'billing_details': [
                {
                    'product_code': 'ABCD1001',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': None
                },
                {
                    'product_code': 'ABCD1002',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '004',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 200
        assert BillingInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812'
        ).subscription_id == self.subscription_id
        assert BillingDetailInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812',
            product_code='ABCD1001'
        ).subscription_id == self.subscription_id
        assert BillingDetailInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812',
            product_code='ABCD1002'
        ).subscription_id == self.subscription_id
        assert BillingUsageDetailInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812',
            product_code='ABCD1002',
            license_user='004'
        ).subscription_id == self.subscription_id
        assert BillingUsageDetailInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812',
            product_code='ABCD1002',
            license_user='002'
        ).subscription_id == self.subscription_id

    def test_post_success_with_billing_usage_details_is_emptylist(self):
        '''
        billing_usage_detailsが空配列でも正常なデータで正常にデータ登録が完了する
        '''
        BillingInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            state='new'
        )
        BillingDetailInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            product_code=ProductInfo(product_code='ABCD1001')
        )
        BillingDetailInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            product_code=ProductInfo(product_code='ABCD1002')
        )

        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'completed',
            'billing_details': [
                {
                    'product_code': 'ABCD1001',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': []
                },
                {
                    'product_code': 'ABCD1002',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '004',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 200
        assert BillingInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812'
        ).subscription_id == self.subscription_id
        assert BillingDetailInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812',
            product_code='ABCD1001'
        ).subscription_id == self.subscription_id
        assert BillingDetailInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812',
            product_code='ABCD1002'
        ).subscription_id == self.subscription_id
        assert BillingUsageDetailInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812',
            product_code='ABCD1002',
            license_user='004'
        ).subscription_id == self.subscription_id
        assert BillingUsageDetailInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812',
            product_code='ABCD1002',
            license_user='002'
        ).subscription_id == self.subscription_id

    def test_post_update_success(self):
        '''
        stateがcompletedでは無いデータはアップデートされる
        '''
        BillingInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            state='new'
        )
        BillingDetailInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            product_code=ProductInfo(product_code='ABCD1002')
        )

        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'new',
            'billing_details': [
                {
                    'product_code': 'ABCD1002',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '004',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '002',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 200

        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'new',
            'billing_details': [
                {
                    'product_code': 'ABCD1002',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '004',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '005',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 200
        assert BillingInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812'
        ).subscription_id == self.subscription_id
        assert BillingDetailInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812',
            product_code='ABCD1002'
        ).subscription_id == self.subscription_id
        assert BillingUsageDetailInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812',
            product_code='ABCD1002',
            license_user='002'
        ).subscription_id == self.subscription_id
        assert BillingUsageDetailInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812',
            product_code='ABCD1002',
            license_user='004'
        ).subscription_id == self.subscription_id
        assert BillingUsageDetailInfo.objects.get(
            subscription=self.subscription_id,
            target_month='201812',
            product_code='ABCD1002',
            license_user='005'
        ).subscription_id == self.subscription_id

    def test_billinginfo_not_created(self):
        """
        事前に対象の請求情報レコードが作成されていなかった場合に403を返す
        """
        BillingDetailInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            product_code=ProductInfo(product_code='ABCD1002')
        )
        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'new',
            'billing_details': [
                {
                    'product_code': 'ABCD1002',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '004',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '005',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 403
        assert response.data['success'] is False
        assert response.data['error_status'] == '403'
        assert response.data['error_message'] == 'Billing records are not created.'

    def test_billingdetailinfo_not_created(self):
        """
        事前に対象の請求明細情報レコードが作成されていなかった場合に403を返す
        """
        BillingInfoFactory(
            subscription=ContractInfo(subscription_id=self.subscription_id),
            target_month='201812',
            state='new'
        )
        body = {
            'start_date': '20180301',
            'end_date': '20180331',
            'billing': '5000',
            'unit_of_money': 'JPY',
            'state': 'new',
            'billing_details': [
                {
                    'product_code': 'ABCD1002',
                    'license_quantity': 2,
                    'billing': '500',
                    'quantity': '50',
                    'billing_usage_details': [
                        {
                            'license_user': '004',
                            'billing': '300',
                            'quantity': '30'
                        },
                        {
                            'license_user': '005',
                            'billing': '200',
                            'quantity': '20'
                        }
                    ]
                }
            ]
        }
        response = self.client.post(
            '/subscriptions/%s/billing/201812/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 403
        assert response.data['success'] is False
        assert response.data['error_status'] == '403'
        assert response.data['error_message'] == 'Billing records are not created.'

    def test_get_subscription_success(self):
        """
        商品コードの指定なしでリクエストし、正しい結果が帰ってくるか
        """
        bdi1 = BillingDetailInfoFactory()
        bdi2 = BillingDetailInfoFactory(subscription=bdi1.subscription)
        BillingDetailInfoFactory()
        BillingInfoFactory(subscription=bdi1.subscription, state=COMPLETED)
        budi1 = BillingUsageDetailInfoFactory(
            subscription=bdi1.subscription, product_code=bdi1.product_code,
            license_user='user01', billing=100, quantity=10)
        budi2 = BillingUsageDetailInfoFactory(
            subscription=bdi1.subscription, product_code=bdi1.product_code,
            license_user='user02', billing=200, quantity=20)
        budi3 = BillingUsageDetailInfoFactory(
            subscription=bdi1.subscription, product_code=bdi2.product_code,
            license_user='user03', billing=300, quantity=30)
        BillingUsageDetailInfoFactory()

        response = self.client.get(
            f'/subscriptions/{bdi1.subscription.subscription_id}/usage/{DateTimeUtil.get_current_ym()}/')
        assert response.data['success'] is True
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] is None
        assert response.data['error_message'] is None
        assert response.data['usage']['subscription_id'] == str(bdi1.subscription.subscription_id)
        assert response.data['usage']['target_month'] == DateTimeUtil.get_current_ym()
        assert len(response.data['usage']['usage_details']) == 2
        assert response.data['usage']['usage_details'][0]['product_code'] == bdi1.product_code.product_code
        assert response.data['usage']['usage_details'][0]['license_quantity'] == bdi1.license_quantity
        assert response.data['usage']['usage_details'][0]['quantity'] == str(bdi1.quantity)
        assert len(response.data['usage']['usage_details'][0]['user_usage_details']) == 2
        assert response.data['usage']['usage_details'][0]['user_usage_details'][0]['license_user'] == budi1.license_user
        assert response.data['usage']['usage_details'][0]['user_usage_details'][0]['quantity'] == str(budi1.quantity)
        assert response.data['usage']['usage_details'][0]['user_usage_details'][1]['license_user'] == budi2.license_user
        assert response.data['usage']['usage_details'][0]['user_usage_details'][1]['quantity'] == str(budi2.quantity)
        assert len(response.data['usage']['usage_details'][1]['user_usage_details']) == 1
        assert response.data['usage']['usage_details'][1]['user_usage_details'][0]['license_user'] == budi3.license_user
        assert response.data['usage']['usage_details'][1]['user_usage_details'][0]['quantity'] == str(budi3.quantity)

    def test_get_subscription_success_with_product_code(self):
        """
        商品コードの指定をしてリクエストし、正しい結果が帰ってくるか
        """
        bdi1 = BillingDetailInfoFactory()
        bdi2 = BillingDetailInfoFactory(subscription=bdi1.subscription)
        BillingDetailInfoFactory()
        BillingInfoFactory(subscription=bdi1.subscription, state=COMPLETED)
        budi1 = BillingUsageDetailInfoFactory(
            subscription=bdi1.subscription, product_code=bdi1.product_code,
            license_user='user01', billing=100, quantity=10)
        budi2 = BillingUsageDetailInfoFactory(
            subscription=bdi1.subscription, product_code=bdi1.product_code,
            license_user='user02', billing=200, quantity=20)
        BillingUsageDetailInfoFactory(
            subscription=bdi1.subscription, product_code=bdi2.product_code,
            license_user='user03', billing=300, quantity=30)
        BillingUsageDetailInfoFactory()

        response = self.client.get(
            f'/subscriptions/{bdi1.subscription.subscription_id}/usage/{DateTimeUtil.get_current_ym()}/',
            {'product_code': bdi1.product_code.product_code})
        assert response.data['success'] is True
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] is None
        assert response.data['error_message'] is None
        assert response.data['usage']['subscription_id'] == str(bdi1.subscription.subscription_id)
        assert response.data['usage']['target_month'] == DateTimeUtil.get_current_ym()
        assert len(response.data['usage']['usage_details']) == 1
        assert response.data['usage']['usage_details'][0]['product_code'] == bdi1.product_code.product_code
        assert response.data['usage']['usage_details'][0]['license_quantity'] == bdi1.license_quantity
        assert response.data['usage']['usage_details'][0]['quantity'] == str(bdi1.quantity)
        assert len(response.data['usage']['usage_details'][0]['user_usage_details']) == 2
        assert response.data['usage']['usage_details'][0]['user_usage_details'][0]['license_user'] == budi1.license_user
        assert response.data['usage']['usage_details'][0]['user_usage_details'][0]['quantity'] == str(budi1.quantity)
        assert response.data['usage']['usage_details'][0]['user_usage_details'][1]['license_user'] == budi2.license_user
        assert response.data['usage']['usage_details'][0]['user_usage_details'][1]['quantity'] == str(budi2.quantity)

    def test_get_subscription_not_found_billing_info(self):
        """
        存在しない請求情報をリクエストし、404が帰ってくるか
        """
        response = self.client.get(
            f'/subscriptions/test123/usage/201204/')
        assert response.data['success'] is False
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] == '404'
        assert response.data['error_message'] == 'Usage not found'
        assert response.data['usage'] is None

    def test_get_subscription_not_found_billing_detail_info(self):
        """
        存在しない請求明細情報をリクエストし、404が帰ってくるか
        """
        ci = ContractInfoFactory()
        bi = BillingInfoFactory(subscription=ci, state=COMPLETED)
        response = self.client.get(
            f'/subscriptions/{bi.subscription_id}/usage/{bi.target_month}/')
        assert response.data['success'] is False
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] == '404'
        assert response.data['error_message'] == 'Usage not found'
        assert response.data['usage'] is None

    def test_get_subscription_with_invalid_parameter(self):
        """
        正常でない年月を指定してリクエストし、400が帰ってくるか
        """
        response = self.client.get(
            '/subscriptions/testsample123/usage/200012345/')
        assert response.data['success'] is False
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] == '400'
        assert response.data['error_message'] == 'Invalid Parameter'
        assert response.data['usage'] is None

    def test_get_subscription_403(self):
        """
        請求情報テーブルにある状態が”completed”以外の場合、403が帰ってくるか
        """
        bdi1 = BillingDetailInfoFactory()
        BillingInfoFactory(subscription=bdi1.subscription, state=NEW)
        response = self.client.get(
            f'/subscriptions/{bdi1.subscription_id}/usage/{bdi1.target_month}/')
        assert response.data['success'] is False
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] == '403'
        assert response.data['error_message'] == 'Usage not calculated'
        assert response.data['usage'] is None
