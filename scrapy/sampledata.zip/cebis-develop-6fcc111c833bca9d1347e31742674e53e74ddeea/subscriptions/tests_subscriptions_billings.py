"""
<copyright file="tests_subscriptions_billings.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""

from dateutil.relativedelta import relativedelta
from rest_framework.test import APIClient
from rest_framework.test import APITestCase

from lib.shortcuts import get_object_or_None
from lib.utils import DateTimeUtil
from subscriptions.factory_boy import ContractInfoFactory, BillingInfoFactory, BillingDetailInfoFactory, \
    BillingUsageDetailInfoFactory, ProductInfoFactory
from subscriptions.models import ProductInfo, BillingInfo, BillingDetailInfo


class SubscriptionsBillingsTest(APITestCase):
    subscription_id = "dp_01"
    now = DateTimeUtil.utc_now_aware()

    @classmethod
    def setUp(cls):
        cls.client = APIClient()
        now = DateTimeUtil.utc_now_aware()
        product_count = 3
        target_months_count = 5
        license_user_count = 2
        contract_info = ContractInfoFactory(subscription_id=cls.subscription_id, opco_code="FX")
        for j in range(target_months_count):
            target_month = (now - relativedelta(month=j + 1)).strftime('%Y%m')
            BillingInfoFactory(subscription=contract_info, target_month=target_month, unit_of_money='JPY',
                               state='completed')
            for k in range(product_count):
                if get_object_or_None(ProductInfo, product_code='prd' + str(k)):
                    product = ProductInfo.objects.get(product_code='prd' + str(k))
                else:
                    product = ProductInfoFactory(product_code='prd' + str(k), flat_rate=False)
                BillingDetailInfoFactory(subscription=contract_info, target_month=target_month,
                                         product_code=product)
                for l in range(license_user_count):
                    BillingUsageDetailInfoFactory(subscription=contract_info, target_month=target_month,
                                                  product_code=product, license_user='license_user' + str(l))

    def test_01_all_date_return_200(self):
        """
        すべてのデータは正しく200が返る
        """
        response = self.client.get(
            '/subscriptions/%s/billing?from_target_month=201901&to_target_month=%s' % (
                self.subscription_id, self.now.strftime('%Y%m')))
        assert (response.status_code == 200)

    def test_02_date_included_not_completed_date_return_207(self):
        """
        completed以外の状態のデータ207が返る
        """
        target_month = (self.now - relativedelta(month=3)).strftime('%Y%m')
        BillingInfo.objects.filter(target_month=target_month).update(state='new')

        response = self.client.get(
            '/subscriptions/%s/billing?from_target_month=201901&to_target_month=%s' % (
                self.subscription_id, self.now.strftime('%Y%m')))
        assert (response.status_code == 207)

    def test_03_one_target_month_not_included_billing_return_207(self):
        """
        指定された月にデータがありません,207が返る
        """
        target_month = (self.now - relativedelta(month=3)).strftime('%Y%m')
        BillingInfo.objects.filter(target_month=target_month).update(state='completed')
        BillingDetailInfo.objects.filter(target_month=target_month).delete()

        response = self.client.get(
            '/subscriptions/%s/billing?from_target_month=201901&to_target_month=%s' % (
                self.subscription_id, self.now.strftime('%Y%m')))
        assert (response.status_code == 207)

    def test_04_target_month_data_not_exist_return_207(self):
        """
        指定された月のデータはありません,207が返る
        """
        target_month = (self.now - relativedelta(month=3)).strftime('%Y%m')
        BillingInfo.objects.filter(target_month=target_month).delete()

        response = self.client.get(
            '/subscriptions/%s/billing?from_target_month=201901&to_target_month=%s' % (
                self.subscription_id, self.now.strftime('%Y%m')))
        assert (response.status_code == 207)

    def test_05_date_format_is_invalid_return_400(self):
        """
        月チェックが正しくありません,400が返る
        """
        response = self.client.get(
            '/subscriptions/%s/billing?from_target_month=20190&to_target_month=%s' % (
                self.subscription_id, self.now.strftime('%Y%m')))

        assert (response.status_code == 400)

    def test_06_term_is_logically_invalid_return_400(self):
        """
        月の論理が正しくありません,400が返る
        """

        response = self.client.get(
            '/subscriptions/%s/billing?from_target_month=201901&to_target_month=201812' % (
                self.subscription_id))
        assert (response.status_code == 400)

    def test_07_term_exceeds_maximum_value_return_400(self):
        """
        その月の24ヶ月以上,400が返る
        """

        response = self.client.get(
            '/subscriptions/%s/billing?from_target_month=201501&to_target_month=201812' % (
                self.subscription_id))
        assert (response.status_code == 400)

    def test_08_ghost_invalid_return_404(self):
        """
        ゴーストユーザーの状況,404が返る
        """
        response = self.client.get(
            '/subscriptions/%s/billing?from_target_month=201901&to_target_month=%s' % (
                self.subscription_id + 'G', self.now.strftime('%Y%m')))
        assert (response.status_code == 404)

    def test_09_none_query_result(self):
        """
        データが見つかりません,404が返る
        """
        response = self.client.get(
            '/subscriptions/%s/billing?from_target_month=201601&to_target_month=201612' % (
                self.subscription_id))
        assert (response.status_code == 404)

    def test_10_none_response_result(self):
        """
        データが返されません,404が返る
        """
        BillingInfo.objects.all().update(state='new')
        response = self.client.get(
            '/subscriptions/%s/billing?from_target_month=201901&to_target_month=%s' % (
                self.subscription_id, self.now.strftime('%Y%m')))
        assert (response.status_code == 404)
