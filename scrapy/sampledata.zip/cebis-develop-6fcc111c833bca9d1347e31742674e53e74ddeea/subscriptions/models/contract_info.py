"""
<copyright file="contract_info.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.db import models


class ContractInfo(models.Model):
    subscription_id = models.CharField(max_length=17, primary_key=True)
    subscription_number = models.CharField(max_length=32, null=True, blank=True)
    contract_code = models.CharField(max_length=10, null=True)
    spf_tenant_id = models.CharField(max_length=32, null=True)
    opco_code = models.CharField(max_length=5)
    closing_day = models.SmallIntegerField()
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'contract_info'
        indexes = [
            models.Index(fields=['opco_code']),
        ]

    def is_zuora(self) -> bool:
        """
        Zuora契約のものかどうかの判定結果を返す
        :return: Zuoraの場合はTrue、それ以外はFalse
        """
        if self.subscription_number is None or len(self.subscription_number) == 0:
            is_zuora = False
        else:
            is_zuora = True
        return is_zuora
