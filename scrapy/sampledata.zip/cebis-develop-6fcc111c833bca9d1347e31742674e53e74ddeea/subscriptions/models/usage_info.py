"""
<copyright file="usage_info.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.db import models
from .contract_info import ContractInfo
from lib.utils import DateTimeUtil


class UsageInfo(models.Model):
    id = models.AutoField(primary_key=True)
    subscription = models.ForeignKey(ContractInfo,
                                     on_delete=models.CASCADE,
                                     db_constraint=False,
                                     db_index=False)
    usage_id = models.CharField(max_length=751)
    product_code = models.CharField(max_length=12)
    target_month = models.CharField(max_length=10)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    quantity = models.CharField(max_length=160)
    license_user = models.CharField(max_length=512, null=True)
    deleted = models.BooleanField(default=False)
    free_item1 = models.CharField(max_length=2048, null=True)
    free_item2 = models.CharField(max_length=2048, null=True)
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'usage_info'
        unique_together = ('subscription', 'usage_id')
        indexes = [
            models.Index(fields=['end_time']),
            models.Index(fields=['created_time']),
        ]

    def create_usage_id(self):
        """
        サブスクリプションID,商品コード、開始・終了日時、利用量、ユーザーから
        従量IDを生成して返す
        :return:
        """

        start_time = DateTimeUtil.format_YmdTHMSZ_utc(self.start_time)
        end_time = DateTimeUtil.format_YmdTHMSZ_utc(self.end_time)
        usage_id = "%s_%s_%s_%s_%s" % (self.subscription_id,
                                       self.product_code,
                                       start_time,
                                       end_time,
                                       self.quantity)
        if self.license_user is not None:
            usage_id = usage_id + "_%s" % self.license_user
        return usage_id
