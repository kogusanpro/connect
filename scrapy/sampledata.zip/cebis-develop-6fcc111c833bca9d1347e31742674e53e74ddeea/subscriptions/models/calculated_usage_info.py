"""
<copyright file="calculated_usage_info.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.db import models

from subscriptions.models import ProductInfo, ContractInfo


class CalculatedUsageInfo(models.Model):
    id = models.AutoField(primary_key=True, serialize=False)
    subscription_id = models.ForeignKey(ContractInfo,
                                        on_delete=models.CASCADE,
                                        db_constraint=False,
                                        db_index=False, db_column='subscription_id')
    product_code = models.ForeignKey(ProductInfo,
                                     on_delete=models.CASCADE,
                                     db_constraint=False,
                                     db_index=False, db_column='product_code')
    target_month = models.CharField(max_length=10)
    target_day = models.CharField(max_length=10)
    daily_usage = models.FloatField(null=True)
    cumulative_usage = models.FloatField(null=True)
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'calculated_usage_info'
        unique_together = ('subscription_id', 'product_code', 'target_day')
        indexes = [
            models.Index(fields=['subscription_id']), models.Index(fields=['product_code'])
        ]
