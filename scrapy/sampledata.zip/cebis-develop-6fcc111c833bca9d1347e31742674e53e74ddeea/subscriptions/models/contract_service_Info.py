"""
<copyright file="contract_service_info.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.db import models
from .contract_info import ContractInfo
from .product_info import ProductInfo


class ContractServiceInfo(models.Model):
    id = models.AutoField(primary_key=True)
    subscription = models.ForeignKey(ContractInfo, on_delete=models.CASCADE, db_constraint=False, db_index=False)
    product_code = models.ForeignKey(ProductInfo, on_delete=models.CASCADE, db_constraint=False, db_index=False,
                                     db_column='product_code')

    product_type = models.CharField(max_length=10)
    state = models.CharField(max_length=10, null=True)
    license_quantity = models.IntegerField(null=True)
    license_users = models.CharField(max_length=2048, null=True)
    service_start_time = models.DateTimeField(null=True)
    service_update_time = models.DateTimeField(null=True)
    service_cancel_time = models.DateTimeField(null=True)
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'contract_service_info'
        unique_together = ('subscription', 'product_code')
        indexes = [
            models.Index(fields=['product_code']),
            models.Index(fields=['state', 'service_start_time']),
            models.Index(fields=['state', 'service_cancel_time']),
            models.Index(fields=['updated_time']),
        ]
