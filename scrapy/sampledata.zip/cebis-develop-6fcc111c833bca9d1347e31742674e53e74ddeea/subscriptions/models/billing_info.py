"""
<copyright file="billing_info.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.db import models
from .contract_info import ContractInfo


class BillingInfo(models.Model):
    id = models.AutoField(primary_key=True)
    subscription = models.ForeignKey(ContractInfo,
                                     on_delete=models.CASCADE,
                                     db_constraint=False,
                                     db_index=False)
    target_month = models.CharField(max_length=10)
    start_date = models.DateField(null=True)
    end_date = models.DateField(null=True)
    billing = models.CharField(max_length=128, null=True)
    unit_of_money = models.CharField(max_length=16, null=True)
    state = models.CharField(max_length=16)
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'billing_info'
        unique_together = ('subscription', 'target_month')
        indexes = [
            models.Index(fields=['target_month']),
        ]


def save(self, *args, **kwargs):
        try:
            self.created_time = BillingInfo.objects.get(
                subscription_id=self.subscription_id,
                target_month=self.target_month
            ).created_time
        except BillingInfo.DoesNotExist:
            pass
        return super(BillingInfo, self).save(*args, **kwargs)
