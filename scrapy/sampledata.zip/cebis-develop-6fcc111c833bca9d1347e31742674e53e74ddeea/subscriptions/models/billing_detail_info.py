"""
<copyright file="billing_detail_info.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.db import models
from .contract_info import ContractInfo
from .product_info import ProductInfo


class BillingDetailInfo(models.Model):
    id = models.AutoField(primary_key=True)
    subscription = models.ForeignKey(ContractInfo,
                                     on_delete=models.CASCADE,
                                     db_constraint=False,
                                     db_index=False)
    target_month = models.CharField(max_length=10)
    product_code = models.ForeignKey(ProductInfo, on_delete=models.CASCADE, db_constraint=False, db_index=False,
                                     db_column='product_code')
    license_quantity = models.IntegerField(null=True)
    billing = models.CharField(max_length=128, null=True)
    quantity = models.CharField(max_length=512, null=True)
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'billing_detail_info'
        unique_together = ('subscription', 'target_month', 'product_code')

    def is_same_key(self, obj):

        return (self.subscription_id == obj.subscription_id) &\
               (self.target_month == obj.target_month) &\
               (self.product_code_id == obj.product_code_id)
