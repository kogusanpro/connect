"""
<copyright file="billing_usage_detail_info.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.db import models
from .contract_info import ContractInfo
from .product_info import ProductInfo


class BillingUsageDetailInfo(models.Model):
    id = models.AutoField(primary_key=True)
    subscription = models.ForeignKey(ContractInfo,
                                     on_delete=models.CASCADE,
                                     db_constraint=False,
                                     db_index=False)
    target_month = models.CharField(max_length=10)
    product_code = models.ForeignKey(ProductInfo, on_delete=models.CASCADE, db_constraint=False, db_index=False,
                                     db_column='product_code')
    license_user = models.CharField(max_length=128)
    billing = models.CharField(max_length=128, null=True)
    quantity = models.CharField(max_length=512, null=True)
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'billing_usage_detail_info'
        unique_together = ('subscription', 'target_month',
                           'product_code', 'license_user')
