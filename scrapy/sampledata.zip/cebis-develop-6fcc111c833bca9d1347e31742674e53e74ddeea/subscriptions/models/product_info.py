"""
<copyright file="product_info.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.db import models


class ProductInfo(models.Model):
    product_code = models.CharField(max_length=12, primary_key=True)
    product_name = models.CharField(max_length=1024)
    free_item1= models.CharField(max_length=2048)
    flat_rate = models.BooleanField()
    dummy_usage = models.BooleanField(default=False)
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'product_info'
