"""
<copyright file="tests_subscriptions_usage.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import copy
from datetime import datetime
import string
import random
import pytz
from unittest import mock
from unittest.mock import call

from rest_framework.test import APIClient
from rest_framework.test import APITestCase

from .models import ContractInfo, ContractServiceInfo, UsageInfo


class SubscriptionsUsageTest(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.subscription_id = ''.join([
            random.choice('%s%s' % (string.ascii_letters, string.digits))
            for i in range(10)
        ])
        c = ContractInfo(
            subscription_id=self.subscription_id,
            subscription_number='xxx',
            contract_code='xxx',
            spf_tenant_id='spf0000000123',
            opco_code='FX',
            closing_day=2
        )
        c.save()

    def test_post_success(self):
        """
        リクエストが正しければ正しくデータが登録され200が返る
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'start_time': '20180130T000000Z',
            'end_time': '20180130T230000Z',
            'license_user': '001',
            'quantity': 30,
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 200
        usage_info = UsageInfo.objects.get(
            subscription_id=self.subscription_id,
            product_code='product'
        )
        assert usage_info.target_month == '201801'
        self.assertEqual(usage_info.start_time, datetime(
            2018, 1, 30, 0, 0, 0, tzinfo=pytz.UTC))
        self.assertEqual(usage_info.end_time, datetime(
            2018, 1, 30, 23, 0, 0, tzinfo=pytz.UTC))
        assert usage_info.usage_id == self.subscription_id + \
            '_product_20180130T000000Z_20180130T230000Z_30_001'
        assert usage_info.license_user == '001'
        assert usage_info.quantity == '30'
        assert usage_info.free_item1 == 'aaaaaa'
        assert usage_info.free_item2 == 'bbbbbb'

    def test_post_success_with_white_space_within_license_user(self):
        """
        license_userに空白があればトリムして登録される
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'start_time': '20180130T000000Z',
            'end_time': '20180130T230000Z',
            'license_user': ' 山田太郎',
            'quantity': 30,
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 200
        usage_info = UsageInfo.objects.get(
            subscription_id=self.subscription_id,
            product_code='product'
        )
        assert usage_info.target_month == '201801'
        self.assertEqual(usage_info.start_time, datetime(
            2018, 1, 30, 0, 0, 0, tzinfo=pytz.UTC))
        self.assertEqual(usage_info.end_time, datetime(
            2018, 1, 30, 23, 0, 0, tzinfo=pytz.UTC))
        print(usage_info.usage_id)
        assert usage_info.usage_id == self.subscription_id + \
            '_product_20180130T000000Z_20180130T230000Z_30_山田太郎'
        assert usage_info.license_user == '山田太郎'
        assert usage_info.quantity == '30'
        assert usage_info.free_item1 == 'aaaaaa'
        assert usage_info.free_item2 == 'bbbbbb'

    def test_post_success_with_space_into_free_item(self):
        """
        free_itemに半角空白があっても、正しくデータが登録され200が返る
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'start_time': '20180130T000000Z',
            'end_time': '20180130T230000Z',
            'license_user': '001',
            'quantity': 30,
            'free_item1': 'aaa aaa',
            'free_item2': 'bbbb bb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 200
        usage_info = UsageInfo.objects.get(
            subscription_id=self.subscription_id,
            product_code='product'
        )
        assert usage_info.target_month == '201801'
        self.assertEqual(usage_info.start_time, datetime(
            2018, 1, 30, 0, 0, 0, tzinfo=pytz.UTC))
        self.assertEqual(usage_info.end_time, datetime(
            2018, 1, 30, 23, 0, 0, tzinfo=pytz.UTC))
        assert usage_info.usage_id == self.subscription_id + \
            '_product_20180130T000000Z_20180130T230000Z_30_001'
        assert usage_info.license_user == '001'
        assert usage_info.quantity == '30'
        assert usage_info.free_item1 == 'aaa aaa'
        assert usage_info.free_item2 == 'bbbb bb'

    def test_post_success_with_multibyte_space_into_free_item(self):
        """
        free_itemに全角空白があっても、正しくデータが登録され200が返る
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'start_time': '20180130T000000Z',
            'end_time': '20180130T230000Z',
            'license_user': '001',
            'quantity': 30,
            'free_item1': 'aaa　aaa',
            'free_item2': 'bbb　bbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 200
        usage_info = UsageInfo.objects.get(
            subscription_id=self.subscription_id,
            product_code='product'
        )
        assert usage_info.target_month == '201801'
        self.assertEqual(usage_info.start_time, datetime(
            2018, 1, 30, 0, 0, 0, tzinfo=pytz.UTC))
        self.assertEqual(usage_info.end_time, datetime(
            2018, 1, 30, 23, 0, 0, tzinfo=pytz.UTC))
        assert usage_info.usage_id == self.subscription_id + \
            '_product_20180130T000000Z_20180130T230000Z_30_001'
        assert usage_info.license_user == '001'
        assert usage_info.quantity == '30'
        assert usage_info.free_item1 == 'aaa　aaa'
        assert usage_info.free_item2 == 'bbb　bbb'

    def test_post_success_with_line_break_into_free_item(self):
        """
        free_itemに改行があっても、正しくデータが登録され200が返る
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'start_time': '20180130T000000Z',
            'end_time': '20180130T230000Z',
            'license_user': '001',
            'quantity': 30,
            'free_item1': "aaa\naaa",
            'free_item2': "bbb\nbbb"
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 200
        usage_info = UsageInfo.objects.get(
            subscription_id=self.subscription_id,
            product_code='product'
        )
        assert usage_info.target_month == '201801'
        self.assertEqual(usage_info.start_time, datetime(
            2018, 1, 30, 0, 0, 0, tzinfo=pytz.UTC))
        self.assertEqual(usage_info.end_time, datetime(
            2018, 1, 30, 23, 0, 0, tzinfo=pytz.UTC))
        assert usage_info.usage_id == self.subscription_id + \
            '_product_20180130T000000Z_20180130T230000Z_30_001'
        assert usage_info.license_user == '001'
        assert usage_info.quantity == '30'
        assert usage_info.free_item1 == "aaa\naaa"
        assert usage_info.free_item2 == "bbb\nbbb"

    def test_post_success_without_license_user(self):
        """
        リクエストにlicense_userが無くても正しくデータが登録され200が返る
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'start_time': '20180130T000000Z',
            'end_time': '20180130T230000Z',
            'quantity': 30,
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 200
        usage_info = UsageInfo.objects.get(
            subscription_id=self.subscription_id,
            product_code='product'
        )
        assert usage_info.usage_id == self.subscription_id + \
               '_product_20180130T000000Z_20180130T230000Z_30'

    def test_validation_non_product_code(self):
        """
        リクエストにproduct_codeがないと400エラーを返す
        """
        body = {
            'target_month': '201801',
            'start_time': '20180101T000000Z',
            'end_time': '20180130T230000Z',
            'quantity': '30',
            'license_user': '001',
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'

    def test_validation_non_start_time(self):
        """
        リクエストにstart_timeがないと400エラーを返す
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'end_time': '20180130T230000Z',
            'quantity': '30',
            'license_user': '001',
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'

    def test_validation_non_end_time(self):
        """
        リクエストにend_timeがないと400エラーを返す
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'start_time': '20180130T230000Z',
            'quantity': '30',
            'license_user': '001',
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'

    def test_validation_non_quantity(self):
        """
        リクエストにquantityがないと400エラーを返す
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'start_time': '20180130T000000Z',
            'end_time': '20180130T230000Z',
            'license_user': '001',
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'

    def test_validation_duplicate(self):
        """
        重複登録の場合は409エラーを返す
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'start_time': '20180130T000000Z',
            'end_time': '20180130T230000Z',
            'license_user': '001',
            'quantity': '30',
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 409
        assert response.data['error_message'] == 'Duplicate registrations'

    def test_validation_format_start_time(self):
        """
        リクエストのstart_timeのフォーマットが仕様どおりでなければ400エラーを返す
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'start_time': '0180130T230000Z',
            'end_time': '20180130T230000Z',
            'quantity': '30',
            'license_user': '001',
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
                   'error_message'] == 'Invalid Parameter'

    def test_validation_format_end_time(self):
        """
        リクエストのend_timeのフォーマットが仕様どおりでなければ400エラーを返す
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'start_time': '20180130T230000Z',
            'end_time': '2180130T230000Z',
            'quantity': '30',
            'license_user': '001',
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
                   'error_message'] == 'Invalid Parameter'

    def test_validation_format_target_month(self):
        """
        リクエストのtarget_monthのフォーマットが仕様どおりでなければ400エラーを返す
        """
        body = {
            'product_code': 'product',
            'target_month': '20181',
            'start_time': '20180130T230000Z',
            'end_time': '20180130T230000Z',
            'quantity': '30',
            'license_user': '001',
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
                   'error_message'] == 'Invalid Parameter'

    def test_validation_fit_target_month_and_end_time(self):
        """
        リクエストのend_timeを日本時間に変換した際にその月がtarget_monthを超えれば403エラー
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'start_time': '20180130T230000Z',
            'end_time': '20180131T230000Z',
            'quantity': '30',
            'license_user': '001',
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 403
        assert response.data[
                   'error_message'] == 'Contradiction occurs'

    def test_validation_max_length(self):
        """
        最大桁数のバリデーションが仕様通りに実装されていることを確認する
        """
        product_code = ''.join(random.choices(string.ascii_letters, k=12))
        target_month = '201801'
        start_time = '20180130T000000Z'
        end_time = '20180130T230000Z'
        license_user = ''.join(random.choices(string.ascii_letters, k=512))
        quantity = ''.join(random.choices('0123456789', k=160))
        free_item1 = ''.join(random.choices(string.ascii_letters, k=2048))
        free_item2 = ''.join(random.choices(string.ascii_letters, k=2048))

        base_body = {
            'product_code': product_code,
            'target_month': target_month,
            'start_time': start_time,
            'end_time': end_time,
            'license_user': license_user,
            'quantity': quantity,
            'free_item1': free_item1,
            'free_item2': free_item2
        }
        url = f'/subscriptions/{self.subscription_id}/usage/'
        # 商品コード桁数オーバー
        body = copy.copy(base_body)
        body['product_code'] = base_body['product_code'] + '1'
        response = self.client.post(url, data=body, format='json')
        assert response.status_code == 400

        # 商品コード桁数オーバー
        body = copy.copy(base_body)
        body['product_code'] = base_body['product_code'] + '1'
        response = self.client.post(url, data=body, format='json')
        assert response.status_code == 400

        # 利用量桁数オーバー
        body = copy.copy(base_body)
        body['quantity'] = base_body['quantity'] + '1'
        response = self.client.post(url, data=body, format='json')
        assert response.status_code == 400

        # ユーザー桁数オーバー
        body = copy.copy(base_body)
        body['license_user'] = base_body['license_user'] + '1'
        response = self.client.post(url, data=body, format='json')
        assert response.status_code == 400

        # 自由入力1桁数オーバー
        body = copy.copy(base_body)
        body['free_item1'] = base_body['free_item1'] + '1'
        response = self.client.post(url, data=body, format='json')
        assert response.status_code == 400

        # 自由入力2桁数オーバー
        body = copy.copy(base_body)
        body['free_item2'] = base_body['free_item2'] + '1'
        response = self.client.post(url, data=body, format='json')
        assert response.status_code == 400

        # フル桁で正常終了
        response = self.client.post(url, data=base_body, format='json')
        assert response.status_code == 200

    def test_auto_setting_target_month(self):
        """
        リクエストにtarget_monthがないとend_timeを日本時間に直してデータ投入する
        """
        body = {
            'product_code': 'product',
            'start_time': '20180130T000000Z',
            'end_time': '20180131T230000Z',
            'license_user': '001',
            'quantity': 30,
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 200
        usage_info = UsageInfo.objects.get(
            subscription_id=self.subscription_id,
            product_code='product'
        )
        assert usage_info.target_month == '201802'

    def test_validation_model_serializer(self):
        """
        model_serializerがDB定義に基づいたバリデーションを行うテスト
        """
        body = {
            'product_code': 'productxxxxxxxxxxxxx',
            'start_time': '20180130T000000Z',
            'target_month': '201802',
            'end_time': '20180131T230000Z',
            'license_user': '001',
            'quantity': 30,
            'free_item1': 'aaaaaa',
            'free_item2': 'bbbbbb'
        }

        response = self.client.post(
            '/subscriptions/%s/usage/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400

    @mock.patch('logging.Logger.error')
    def test_logging_error_when_usage_infos_subscription_id_does_not_found(self, mock_logger):
        """
        DBに登録されていないsubscription_idでも登録でき、またその際にエラーログを吐くか
        """
        body = {
            'product_code': 'product',
            'target_month': '201801',
            'start_time': '20180130T000000Z',
            'end_time': '20180130T230000Z',
            'quantity': 30,
            'free_item1': 'cccccc',
            'free_item2': 'dddddd'
        }

        not_exist_subscription_id = 'qwerty1234'
        response = self.client.post(
            f'/subscriptions/{not_exist_subscription_id}/usage/',
            data=body,
            format='json')

        assert ContractInfo.objects.all().count() == 1
        assert UsageInfo.objects.all().count() == 1

        usage_id = response.data['usage_id']
        mock_logger.assert_has_calls([
            call(f'The usage info(usage_id={usage_id})\'s subscription_id({not_exist_subscription_id}) does not found in ContractInfo')
        ])

    def test_post_success_then_fail(self):
            """
            従量データ登録を二度行い、2つのデータが登録されているかどうか
            """
            body = {
                'product_code': 'product',
                'target_month': '201801',
                'start_time': '20180130T000000Z',
                'end_time': '20180130T230000Z',
                'quantity': 30,
                'free_item1': 'cccccc',
                'free_item2': 'dddddd'
            }
            subscription_id = 'qwerty123'

            assert UsageInfo.objects.all().count() == 0

            response = self.client.post(
                f'/subscriptions/{subscription_id}/usage/',
                data=body,
                format='json')
            assert response.status_code == 200
            assert UsageInfo.objects.all().count() == 1

            body['product_code'] = 'product2'
            response = self.client.post(
                f'/subscriptions/{subscription_id}/usage/',
                data=body,
                format='json')
            assert response.status_code == 200
            assert UsageInfo.objects.all().count() == 2
