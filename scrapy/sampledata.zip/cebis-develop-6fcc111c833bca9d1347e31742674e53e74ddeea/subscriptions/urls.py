"""
<copyright file="urls.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.conf.urls import url
from subscriptions import views

urlpatterns = [
    url(r'(?P<pk>.+)/billing/(?P<target_month>.+)/$',
        views.subscriptions_billing),
    url(r'(?P<pk>.+)/billing/(?P<target_month>.+)$',
        views.subscriptions_billing),
    url(r'(?P<pk>.+)/usage/?$', views.subscriptions_usage),
    url(r'(?P<pk>.+)/usage/(?P<target_month>.+)/$',
        views.usage_info),
    url(r'(?P<pk>.+)/usage/(?P<target_month>.+)$',
        views.usage_info),
    url(r'(?P<pk>.+)/billing/?$',
        views.subscriptions_billings),
    url(r'(?P<pk>.+)/$', views.subscriptions_detail),
    url(r'(?P<pk>.+)$', views.subscriptions_detail),
    url(r'^$', views.subscriptions_bulk_fetch),
]
