"""
<copyright file="factory_boy.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from datetime import datetime
from factory.django import DjangoModelFactory
from factory import LazyAttribute, Sequence, SubFactory
from factory.fuzzy import FuzzyChoice, FuzzyInteger, FuzzyDateTime, FuzzyText, FuzzyDate
import factory

from django.utils.timezone import datetime, timedelta

from subscriptions.models import BillingInfo, BillingDetailInfo, BillingUsageDetailInfo, ContractInfo, \
    ContractServiceInfo, ProductInfo, UsageInfo
from lib.const.contract_service_state import ACTIVE, INACTIVE, TRIAL
from lib.const.product_type import BASIC, OPTION
from lib.const.billing_info_state import NEW, COMPLETED
from lib.utils import DateTimeUtil


class ProductInfoFactory(DjangoModelFactory):
    """
    商品情報テーブルのファクトリークラス
    """

    class Meta:
        model = ProductInfo

    product_code = factory.Sequence(lambda n: 'prd%s' % '{0:04d}'.format(n))
    product_name = factory.Sequence(lambda n: 'product %s' % '{0:07d}'.format(n))
    flat_rate = FuzzyChoice(choices=[False, True])
    created_time = DateTimeUtil.utc_now_aware()
    updated_time = DateTimeUtil.utc_now_aware()


class ContractInfoFactory(DjangoModelFactory):
    """
    契約情報のファクトリークラス
    """
    class Meta:
        model = ContractInfo

    subscription_id = factory.Sequence(lambda n: n)
    subscription_number = '1'
    contract_code = '0000000001'
    spf_tenant_id = 'ST00000000000001'
    opco_code = FuzzyChoice(choices=('FX', 'FXAP', 'FXPC', 'FXCL', 'FXHK', 'FXK', 'FXM', 'FXNZ', 'FXP',
                                     'FXS', 'FXTH', 'FXTW', 'FXV', 'PTAG', 'FXA'))
    closing_day = -1
    created_time = DateTimeUtil.utc_now_aware()
    updated_time = DateTimeUtil.utc_now_aware()


class ContractServiceInfoFactory(DjangoModelFactory):
    """
    契約サービス情報のファクトリークラス
    """
    class Meta:
        model = ContractServiceInfo

    subscription = factory.SubFactory(ContractInfoFactory)
    product_code = SubFactory(ProductInfoFactory)
    product_type = FuzzyChoice(choices=(BASIC, OPTION))
    state = FuzzyChoice(choices=(ACTIVE, INACTIVE, TRIAL))
    license_quantity = 0
    license_users = '"090-1111-2222","080-3333-4444"'
    service_start_time = FuzzyDateTime(
        DateTimeUtil.utc_now_aware() + timedelta(days=-3650), DateTimeUtil.utc_now_aware() + timedelta(days=3650))
    service_update_time = FuzzyDateTime(
        DateTimeUtil.utc_now_aware() + timedelta(days=-3650), DateTimeUtil.utc_now_aware() + timedelta(days=3650))
    service_cancel_time = FuzzyDateTime(
        DateTimeUtil.utc_now_aware() + timedelta(days=-3650), DateTimeUtil.utc_now_aware() + timedelta(days=3650))
    created_time = DateTimeUtil.utc_now_aware()
    updated_time = DateTimeUtil.utc_now_aware()


class BillingInfoFactory(DjangoModelFactory):
    """
    請求情報テーブルのファクトリークラス
    """
    class Meta:
        model = BillingInfo

    subscription = factory.Sequence(lambda n: n)
    target_month = DateTimeUtil.get_current_ym()
    start_date = FuzzyDate(
        DateTimeUtil.utc_now_aware() + timedelta(days=-3650), DateTimeUtil.utc_now_aware() + timedelta(days=3650))
    end_date = FuzzyDate(
        DateTimeUtil.utc_now_aware() + timedelta(days=-3650), DateTimeUtil.utc_now_aware() + timedelta(days=3650))
    billing = FuzzyInteger(low=1, high=100000)
    unit_of_money = FuzzyChoice([u'円'])
    state = FuzzyChoice(choices=(NEW, COMPLETED))
    created_time = DateTimeUtil.utc_now_aware()
    updated_time = DateTimeUtil.utc_now_aware()


class BillingDetailInfoFactory(DjangoModelFactory):
    """
    請求明細情報テーブルのファクトリークラス
    """
    class Meta:
        model = BillingDetailInfo

    subscription = factory.SubFactory(ContractInfoFactory)
    target_month = DateTimeUtil.get_current_ym()
    product_code = factory.SubFactory(ProductInfoFactory)
    license_quantity = 0
    billing = FuzzyInteger(low=1, high=10000)
    quantity = FuzzyInteger(low=1, high=10000)
    created_time = DateTimeUtil.utc_now_aware()
    updated_time = DateTimeUtil.utc_now_aware()


class BillingUsageDetailInfoFactory(DjangoModelFactory):
    """
    利用明細情報テーブルのファクトリークラス
    """

    class Meta:
        model = BillingUsageDetailInfo

    id = factory.Sequence(lambda n: n + 1)
    subscription = factory.SubFactory(ContractInfoFactory)
    target_month = DateTimeUtil.get_current_ym()
    product_code = factory.SubFactory(ProductInfoFactory)
    license_user = FuzzyText()
    billing = FuzzyInteger(1, 10000)
    quantity = FuzzyInteger(1, 100)
    created_time = DateTimeUtil.utc_now_aware()
    updated_time = DateTimeUtil.utc_now_aware()


class UsageInfoFactory(DjangoModelFactory):
    """
    従量データテーブルのファクトリークラス
    """

    class Meta:
        model = UsageInfo

    id = factory.Sequence(lambda n: n + 1)
    subscription = factory.SubFactory(ContractInfoFactory)
    usage_id = factory.Sequence(lambda n: n)
    product_code = factory.Sequence(lambda n: 'prd%s' % str(n))
    target_month = DateTimeUtil.get_current_ym()
    start_time = DateTimeUtil.utc_now_aware()
    end_time = DateTimeUtil.utc_now_aware()
    quantity = FuzzyInteger(low=1, high=100)
    license_user = FuzzyText()
    deleted = False
    free_item1 = FuzzyText()
    free_item2 = FuzzyText()
    created_time = DateTimeUtil.utc_now_aware()
    updated_time = DateTimeUtil.utc_now_aware()

    @classmethod
    def _create(cls, target_class, *args, **kwargs):
        """
        created_timeをコンストラクタで指定できるようにする
        :param target_class:
        :param args:
        :param kwargs:
        :return:
        """
        created_time = kwargs.pop('created_time', None)
        obj = super(UsageInfoFactory, cls)._create(target_class, *args, **kwargs)
        if created_time is not None:
            obj.created_time = created_time
            obj.save()
        return obj
