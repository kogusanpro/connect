"""
<copyright file="tests_subscriptions.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from datetime import datetime
import freezegun
import pytz
import random
import string
import time

from rest_framework.test import APIClient
from rest_framework.test import APITestCase

from .models import ContractInfo, ContractServiceInfo
from lib.utils import check_datetime_format


class SubscriptionsTest(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.subscription_id = ''.join([
            random.choice('%s%s' % (string.ascii_letters, string.digits))
            for i in range(10)
        ])

    def test_validation_non_products_list(self):
        """
        リクエストにproductsの配列がない場合に400エラーを返す
        """
        body = {
            'subscription_number': 'xxx',
            'contract_code': 'xxx',
            'spf_tenant_id': 'spf0000000123',
            'opco_code': 'FX',
            'closing_day': '-1'
        }
        response = self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
                   'error_message'] == 'Invalid Parameter'

    def test_validation_opco_code(self):
        """
        リクエストのopco_codeが許可された値でない場合に400エラーを返す
        """
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FXX',
            'closing_day':
                '-1',
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basic',
                'state': 'active',
                'license_quantity': 15,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '20180201T000000Z'
            }, {
                'product_code': 'ABCD1001',
                'product_type': 'option',
                'state': 'active',
                'license_quantity': 2,
                'license_users': ['003', '002'],
                'service_start_time': '20180201T000000Z',
                'service_update_time': None,
                'service_cancel_time': None
            }]
        }
        response = self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        assert len(ContractInfo.objects.all()) == 0

    def test_validation_range_closing_day(self):
        """
        リクエストのclosing_dayが許可された範囲でない場合に400エラーを返す
        """
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                32,
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basic',
                'state': 'active',
                'license_quantity': 15,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '20180201T000000Z'
            }, {
                'product_code': 'ABCD1001',
                'product_type': 'option',
                'state': 'active',
                'license_quantity': 2,
                'license_users': ['003', '002'],
                'service_start_time': '20180201T000000Z',
                'service_update_time': None,
                'service_cancel_time': None
            }]
        }
        response = self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
                   'error_message'] == 'Invalid Parameter'
        body['closing_day'] = -2
        response = self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
                   'error_message'] == 'Invalid Parameter'
        assert len(ContractInfo.objects.all()) == 0

    def test_validation_format_service_start_time(self):
        """
        リクエストのservice_start_timeが許可されたフォーマットでない場合に400エラーを返す
        """
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                30,
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basic',
                'state': 'active',
                'license_quantity': 15,
                'license_users': None,
                'service_start_time': '2018/02/01T00:00:00Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '20180201T000000Z'
            }, {
                'product_code': 'ABCD1001',
                'product_type': 'option',
                'state': 'active',
                'license_quantity': 2,
                'license_users': ['003', '002'],
                'service_start_time': '20180201T000000Z',
                'service_update_time': None,
                'service_cancel_time': None
            }]
        }
        response = self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data['error_message'] == 'Invalid Parameter'
        assert len(ContractInfo.objects.all()) == 0

    def test_validation_format_service_update_time(self):
        """
        リクエストのservice_update_timeが許可されたフォーマットでない場合に400エラーを返す
        """
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                30,
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basic',
                'state': 'active',
                'license_quantity': 15,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '2018/02/01T00:00:00Z',
                'service_cancel_time': '20180201T000000Z'
            }, {
                'product_code': 'ABCD1001',
                'product_type': 'option',
                'state': 'active',
                'license_quantity': 2,
                'license_users': ['003', '002'],
                'service_start_time': '20180201T000000Z',
                'service_update_time': None,
                'service_cancel_time': None
            }]
        }
        response = self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
                   'error_message'] == 'Invalid Parameter'
        assert len(ContractInfo.objects.all()) == 0

    def test_validation_format_service_cancel_time(self):
        """
        リクエストのservice_cancel_timeが許可されたフォーマットでない場合に400エラーを返す
        """
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                30,
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basic',
                'state': 'active',
                'license_quantity': 15,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '2018/02/01T00:00:00Z'
            }, {
                'product_code': 'ABCD1001',
                'product_type': 'option',
                'state': 'active',
                'license_quantity': 2,
                'license_users': ['003', '002'],
                'service_start_time': '20180201T000000Z',
                'service_update_time': None,
                'service_cancel_time': None
            }]
        }
        response = self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
                   'error_message'] == 'Invalid Parameter'
        assert len(ContractInfo.objects.all()) == 0

    def test_validation_format_license_users_list(self):
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                30,
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basic',
                'state': 'active',
                'license_quantity': 15,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '20180201T000000Z'
            }, {
                'product_code': 'ABCD1001',
                'product_type': 'option',
                'state': 'active',
                'license_quantity': 2,
                'license_users': '003',
                'service_start_time': '20180201T000000Z',
                'service_update_time': None,
                'service_cancel_time': None
            }]
        }
        response = self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
                   'error_message'] == 'Invalid Parameter'
        assert len(ContractInfo.objects.all()) == 0

    def test_validation_format_product_type(self):
        """
        リクエストのproduct_typeが許可された値でない場合に400エラーを返す
        """
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                30,
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basex',
                'state': 'active',
                'license_quantity': 15,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '20180201T000000Z'
            }, {
                'product_code': 'ABCD1001',
                'product_type': 'option',
                'state': 'active',
                'license_quantity': 2,
                'license_users': ['003', '002'],
                'service_start_time': '20180201T000000Z',
                'service_update_time': None,
                'service_cancel_time': None
            }]
        }
        response = self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
                   'error_message'] == 'Invalid Parameter'
        assert len(ContractInfo.objects.all()) == 0

    def test_validation_format_state(self):
        """
        リクエストのstateが許可された値でない場合に400エラーを返す
        """
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                30,
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basic',
                'state': 'activex',
                'license_quantity': 15,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '20180201T000000Z'
            }, {
                'product_code': 'ABCD1001',
                'product_type': 'option',
                'state': 'active',
                'license_quantity': 2,
                'license_users': ['003', '002'],
                'service_start_time': '20180201T000000Z',
                'service_update_time': None,
                'service_cancel_time': None
            }]
        }
        response = self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 400
        assert response.data[
                   'error_message'] == 'Invalid Parameter'
        assert len(ContractInfo.objects.all()) == 0

    def test_validation_range_datetime(self):
        """
        APIの使用許可時間外であれば403エラーを返す
        """
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                30,
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basic',
                'state': 'active',
                'license_quantity': 15,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '20180201T000000Z'
            }, {
                'product_code': 'ABCD1001',
                'product_type': 'option',
                'state': 'active',
                'license_quantity': 2,
                'license_users': ['003', '002'],
                'service_start_time': '20180201T000000Z',
                'service_update_time': None,
                'service_cancel_time': None
            }]
        }
        with freezegun.freeze_time(datetime(2018, 1, 1, 13, 0, 0)):
            response = self.client.post(
                '/subscriptions/%s/' % self.subscription_id,
                data=body,
                format='json',
                )
            assert response.status_code == 403
            assert response.data[
                       'error_message'] == 'Out of registration time'
            assert len(ContractInfo.objects.all()) == 0
        with freezegun.freeze_time(datetime(2018, 1, 1, 19, 0, 0)):
            response = self.client.post(
                '/subscriptions/%s/' % self.subscription_id,
                data=body,
                format='json')
            assert response.status_code == 403
            assert response.data[
                       'error_message'] == 'Out of registration time'
            assert len(ContractInfo.objects.all()) == 0

    def test_post_success(self):
        """
        リクエストが正しければ正しくデータが登録され200が返る
        """
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                30,
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basic',
                'state': 'active',
                'license_quantity': 15,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '20180201T000000Z'
            }, {
                'product_code': 'ABCD1001',
                'product_type': 'option',
                'state': 'active',
                'license_quantity': 2,
                'license_users': ['003', '002'],
                'service_start_time': '20180201T000000Z',
                'service_update_time': None,
                'service_cancel_time': None
            }]
        }
        response = self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 200
        assert len(ContractInfo.objects.all()) == 1
        assert len(ContractServiceInfo.objects.all()) == 2
        ContractServiceInfo_instance = ContractServiceInfo.objects.get(
            subscription_id=self.subscription_id, product_code='ABCXX1000')
        assert ContractServiceInfo_instance.service_start_time.strftime(
            '%Y%m%dT%H%M%SZ') == '20180201T000000Z'
        assert ContractServiceInfo_instance.service_update_time.strftime(
            '%Y%m%dT%H%M%SZ') == '20180201T000000Z'
        assert ContractServiceInfo_instance.service_cancel_time.strftime(
            '%Y%m%dT%H%M%SZ') == '20180201T000000Z'

    def test_post_success_against_existing_data(self):
        """
        既存のデータは上書きアップデートして200を返す
        """
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                30,
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basic',
                'state': 'active',
                'license_quantity': 15,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '20180201T000000Z'
            }, {
                'product_code': 'ABCD1001',
                'product_type': 'option',
                'state': 'active',
                'license_quantity': 2,
                'license_users': ['003', '002'],
                'service_start_time': '20180201T000000Z',
                'service_update_time': None,
                'service_cancel_time': None
            }]
        }
        response = self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')

        body = {
            'subscription_number':
                'yyy',
            'contract_code':
                'yyy',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                30,
            'products': [{
                'product_code': 'ABCY1000',
                'product_type': 'basic',
                'state': 'active',
                'license_quantity': 15,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '20180201T000000Z'
            }, {
                'product_code': 'ABCW1001',
                'product_type': 'option',
                'state': 'active',
                'license_quantity': 2,
                'license_users': ['003', '002'],
                'service_start_time': '20180201T000000Z',
                'service_update_time': None,
                'service_cancel_time': None
            }]
        }
        response = self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        assert response.status_code == 200
        assert len(ContractInfo.objects.all()) == 1
        assert len(ContractServiceInfo.objects.all()) == 4
        assert ContractInfo.objects.get().contract_code == 'yyy'

    def test_post_created_updated_time_behavior(self):
        """
        created_timeとupdated_timeの振る舞いをテスト
        """
        time_format = '{0:%H:%M:%S}'
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                30,
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basic',
                'state': 'active',
                'license_quantity': None,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '20180201T000000Z'
            }]
        }
        self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        contract_info_created = time_format.format(ContractInfo.objects.get(
            pk=self.subscription_id).created_time)
        contract_service_info_created = time_format.format(
            ContractInfo.objects.get(
                pk=self.subscription_id).created_time)
        self.assertEqual(
            contract_info_created,
            time_format.format(ContractInfo.objects.get(
                pk=self.subscription_id).updated_time)
        )
        self.assertEqual(
            contract_service_info_created,
            time_format.format(ContractServiceInfo.objects.get(
                subscription_id=self.subscription_id).updated_time)
        )
        time.sleep(3)
        self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        self.assertEqual(
            contract_info_created,
            time_format.format(ContractInfo.objects.get(
                pk=self.subscription_id).created_time)
        )
        self.assertEqual(
            contract_service_info_created,
            time_format.format(ContractServiceInfo.objects.get(
                subscription_id=self.subscription_id).created_time)
        )
        assert time_format.format(ContractInfo.objects.get(
            pk=self.subscription_id).created_time) < \
            time_format.format(ContractInfo.objects.get(
                   pk=self.subscription_id).updated_time)
        assert time_format.format(ContractServiceInfo.objects.get(
            subscription_id=self.subscription_id).created_time) < \
            time_format.format(ContractServiceInfo.objects.get(
                   subscription_id=self.subscription_id).updated_time)

    def test_post_service_update_time_behavior(self):
        """
        service_update_timeの振る舞いをテスト
        """
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                30,
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basic',
                'state': 'active',
                'license_quantity': None,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '20180201T000000Z'
            }]
        }
        self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        # リクエストで受け取ったサービス開始手配完了日時を契約情報サービステーブルにセットする
        assert ContractServiceInfo.objects.get(
            subscription_id=self.subscription_id,
            product_code='ABCXX1000'
        ).service_update_time == datetime(2018, 2, 1, 0, 0, tzinfo=pytz.UTC)

        # リクエストで受け取ったサービス更新手配完了日時を契約情報サービステーブルにセットする
        assert ContractServiceInfo.objects.get(
            subscription_id=self.subscription_id,
            product_code='ABCXX1000'
        ).service_update_time == datetime(2018, 2, 1, 0, 0, tzinfo=pytz.UTC)

        # リクエストで受け取ったサービス解約手配完了日時を契約情報サービステーブルにセットする
        assert ContractServiceInfo.objects.get(
            subscription_id=self.subscription_id,
            product_code='ABCXX1000'
        ).service_cancel_time == datetime(2018, 2, 1, 0, 0, tzinfo=pytz.UTC)

        # データ更新時のテスト
        body['products'][0]['service_start_time'] = '20180202T000000Z'
        body['products'][0]['service_update_time'] = '20180202T000000Z'
        body['products'][0]['service_cancel_time'] = '20180202T000000Z'
        self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')
        # リクエストで受け取ったサービス開始手配完了日時を契約情報サービステーブルにセットする
        assert ContractServiceInfo.objects.get(
            subscription_id=self.subscription_id,
            product_code='ABCXX1000'
        ).service_update_time == datetime(2018, 2, 2, 0, 0, tzinfo=pytz.UTC)

        # リクエストで受け取ったサービス更新手配完了日時を契約情報サービステーブルにセットする
        assert ContractServiceInfo.objects.get(
            subscription_id=self.subscription_id,
            product_code='ABCXX1000'
        ).service_update_time == datetime(2018, 2, 2, 0, 0, tzinfo=pytz.UTC)

        # リクエストで受け取ったサービス解約手配完了日時を契約情報サービステーブルにセットする
        assert ContractServiceInfo.objects.get(
            subscription_id=self.subscription_id,
            product_code='ABCXX1000'
        ).service_cancel_time == datetime(2018, 2, 2, 0, 0, tzinfo=pytz.UTC)

    def test_get_success(self):
        """
        GETで仕様どおりのフォーマットが返ってくることをテスト
        """
        body = {
            'subscription_number':
                'xxx',
            'contract_code':
                'xxx',
            'spf_tenant_id':
                'spf0000000123',
            'opco_code':
                'FX',
            'closing_day':
                30,
            'products': [{
                'product_code': 'ABCXX1000',
                'product_type': 'basic',
                'state': 'active',
                'license_quantity': 15,
                'license_users': None,
                'service_start_time': '20180201T000000Z',
                'service_update_time': '20180201T000000Z',
                'service_cancel_time': '20180201T000000Z'
            }, {
                'product_code': 'ABCD1001',
                'product_type': 'option',
                'state': 'active',
                'license_quantity': None,
                'license_users': ['003', '002'],
                'service_start_time': '20180201T000000Z',
                'service_update_time': None,
                'service_cancel_time': None
            }]
        }
        self.client.post(
            '/subscriptions/%s/' % self.subscription_id,
            data=body,
            format='json')

        response = self.client.get('/subscriptions/%s/' % self.subscription_id)
        assert response.status_code == 200
        assert response.data['subscription'][
                   'subscription_id'] == self.subscription_id
        assert response.data['subscription']['subscription_number'] == 'xxx'
        assert response.data['subscription']['contract_code'] == 'xxx'
        assert response.data['subscription'][
                   'spf_tenant_id'] == 'spf0000000123'
        assert response.data['subscription']['opco_code'] == 'FX'
        assert response.data['subscription']['closing_day'] == 30
        self.assertEqual('created_time' in response.data['subscription'], True)
        self.assertEqual('updated_time' in response.data['subscription'], True)
        assert response.data['subscription']['products'][0][
                   'product_code'] == 'ABCD1001'
        assert response.data['subscription']['products'][0][
                   'product_type'] == 'option'
        assert response.data['subscription']['products'][0][
                   'state'] == 'active'
        assert response.data['subscription']['products'][0][
                   'license_quantity'] is None
        assert response.data['subscription']['products'][0][
                   'license_users'][0] == '003'
        assert response.data['subscription']['products'][0][
                   'license_users'][1] == '002'
        assert response.data['subscription']['products'][0][
                   'service_start_time'] == '20180201T000000Z'
        assert response.data['subscription']['products'][0][
                   'service_update_time'] is None
        assert response.data['subscription']['products'][0][
                   'service_cancel_time'] is None
        assert response.data['subscription']['products'][1][
                   'product_code'] == 'ABCXX1000'
        assert response.data['subscription']['products'][1][
                   'product_type'] == 'basic'
        assert response.data['subscription']['products'][1][
                   'state'] == 'active'
        assert response.data['subscription']['products'][1][
                   'license_quantity'] == 15
        assert response.data['subscription']['products'][1][
                   'license_users'] is None
        assert response.data['subscription']['products'][1][
                   'service_start_time'] == '20180201T000000Z'
        assert response.data['subscription']['products'][1][
                   'service_update_time'] == '20180201T000000Z'
        assert response.data['subscription']['products'][1][
                   'service_cancel_time'] == '20180201T000000Z'

    def test_contract_info_not_found(self):
        """
        対象の請求情報がない場合に404を返すか
        """
        response = self.client.get('/subscriptions/%s/' % self.subscription_id)
        assert response.status_code == 404
        assert response.data['success'] is False
        assert response.data['count'] is None
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] == '404'
        assert response.data['error_message'] == 'Contract not found'
        assert response.data['subscription'] is None