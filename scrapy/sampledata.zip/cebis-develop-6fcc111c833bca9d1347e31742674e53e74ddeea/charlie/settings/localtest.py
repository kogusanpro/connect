"""
<copyright file="localtest.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from charlie.settings.base import *

AWS_S3_ENDPOINT = 'http://localstack:4572'
del LOGGING
