"""
<copyright file="sst_batch.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from charlie.settings.base import *
import boto3
import pymysql
import os

db_host = os.getenv('DB_HOST')
db_user = os.getenv('DB_USER')
db_password = os.getenv('DB_PASSWORD')

client = boto3.client('ssm')
ssm_param_names = [db_host, db_user, db_password]
ssm_response = client.get_parameters(Names=ssm_param_names, WithDecryption=True)
ssm_params = {r['Name']: r['Value'] for r in ssm_response['Parameters']}

DEBUG = False

ALLOWED_HOSTS = ['*']

pymysql.install_as_MySQLdb()
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'cebis_batch_prd',
        'USER': ssm_params[db_user],
        'PASSWORD': ssm_params[db_password],
        'HOST': ssm_params[db_host],
        'PORT': 3306,
        'OPTIONS': {
            'charset': 'utf8mb4',
        },
    }
}

if 'SFTP_HOST' in os.environ and 'SFTP_USER' in os.environ and 'SFTP_PASSWORD' in os.environ:
    sftp_host = os.getenv('SFTP_HOST')
    sftp_user = os.getenv('SFTP_USER')
    sftp_password = os.getenv('SFTP_PASSWORD')

    sftp_ssm_param_names = [sftp_host, sftp_user, sftp_password]
    sftp_ssm_response = client.get_parameters(Names=sftp_ssm_param_names, WithDecryption=True)
    sftp_ssm_params = {r['Name']: r['Value'] for r in sftp_ssm_response['Parameters']}

    SFTP = {
        'USER': sftp_ssm_params[sftp_user],
        'PASSWORD': sftp_ssm_params[sftp_password],
        'HOST': sftp_ssm_params[sftp_host],
        'PORT': 22
    }
