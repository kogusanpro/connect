"""
<copyright file="ci.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from charlie.settings.base import *

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

WSGI_APPLICATION = 'charlie.wsgi.application'

ALLOWED_HOSTS = ['*']

# Database
# https://docs.djangoproject.com/en/1.11/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'cebis',
        'USER': 'root',
        'PASSWORD': 'password',
        'HOST': 'db',
        'PORT': 3306,
        'OPTIONS': {
            'charset': 'utf8mb4',
        },
        'TEST': {
            'CHARSET': 'utf8mb4',
        },
    }
}

SFTP = {
    'USER': 'foo',
    'PASSWORD': 'pass',
    'HOST': 'sftp',
    'PORT': 22
}

AWS_S3_ENDPOINT = None

K5_TOKEN = {
    'USER': 'fx28845',
    'PASSWORD': 'P@ssw0rd'
}

# Zuora接続設定
if all([
    'ZUORA_CLIENT_ID' in os.environ,
    'ZUORA_CLIENT_SECRET' in os.environ,
    'ZUORA_API_ENDPOINT' in os.environ,
    'ZUORA_OAUTH_TOKEN_URL' in os.environ,
    'ZUORA_DATA_QUERY_URL' in os.environ,
]):
    zuora_client_id = os.getenv('ZUORA_CLIENT_ID')
    zuora_client_secret = os.getenv('ZUORA_CLIENT_SECRET')
    zuora_endoint_url = os.getenv('ZUORA_API_ENDPOINT')
    zuora_auth_url = os.getenv('ZUORA_OAUTH_TOKEN_URL')
    zuora_data_query_url = os.getenv('ZUORA_DATA_QUERY_URL')

    ZUORA_TOKEN = {
        'CLIENT_ID': zuora_client_id,
        'CLIENT_SECRET': zuora_client_secret,
        'API_ENDPOINT': zuora_endoint_url,
        'AUTH_URL': zuora_auth_url,
        'DATA_QUERY_URL': zuora_data_query_url,
    }

del LOGGING
