"""
<copyright file="prd.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from charlie.settings.base import *
import boto3
import os

db_host = os.getenv('DB_HOST')
db_user = os.getenv('DB_USER')
db_password = os.getenv('DB_PASSWORD')

client = boto3.client('ssm')
ssm_param_names = [db_host, db_user, db_password]
ssm_response = client.get_parameters(Names=ssm_param_names, WithDecryption=True)
ssm_params = {r['Name']: r['Value'] for r in ssm_response['Parameters']}

DEBUG = False

ALLOWED_HOSTS = ['*']

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'cebis',
        'USER': ssm_params[db_user],
        'PASSWORD': ssm_params[db_password],
        'HOST': ssm_params[db_host],
        'PORT': 3306,
        'OPTIONS': {
            'charset': 'utf8mb4',
        },
    }
}

if 'SFTP_HOST' in os.environ and 'SFTP_USER' in os.environ and 'SFTP_PASSWORD' in os.environ:
    sftp_host = os.getenv('SFTP_HOST')
    sftp_user = os.getenv('SFTP_USER')
    sftp_password = os.getenv('SFTP_PASSWORD')

    sftp_ssm_param_names = [sftp_host, sftp_user, sftp_password]
    sftp_ssm_response = client.get_parameters(Names=sftp_ssm_param_names, WithDecryption=True)
    sftp_ssm_params = {r['Name']: r['Value'] for r in sftp_ssm_response['Parameters']}

    SFTP = {
        'USER': sftp_ssm_params[sftp_user],
        'PASSWORD': sftp_ssm_params[sftp_password],
        'HOST': sftp_ssm_params[sftp_host],
        'PORT': 22
    }

if 'K5_TOKEN_USER' in os.environ and 'K5_TOKEN_PASSWORD' in os.environ:

    k5_user = os.getenv('K5_TOKEN_USER')
    k5_password = os.getenv('K5_TOKEN_PASSWORD')

    k5_ssm_param_names = [k5_user, k5_password]
    k5_ssm_response = client.get_parameters(Names=k5_ssm_param_names, WithDecryption=True)
    k5_ssm_params = {r['Name']: r['Value'] for r in k5_ssm_response['Parameters']}

    K5_TOKEN = {
        'USER': k5_ssm_params[k5_user],
        'PASSWORD': k5_ssm_params[k5_password]
    }

# Zuora接続設定
if all([
    'ZUORA_CLIENT_ID' in os.environ,
    'ZUORA_CLIENT_SECRET' in os.environ,
    'ZUORA_API_ENDPOINT' in os.environ,
    'ZUORA_OAUTH_TOKEN_URL' in os.environ,
    'ZUORA_DATA_QUERY_URL' in os.environ,
]):
    zuora_client_id = os.getenv('ZUORA_CLIENT_ID')
    zuora_client_secret = os.getenv('ZUORA_CLIENT_SECRET')
    zuora_endpoint_url = os.getenv('ZUORA_API_ENDPOINT')
    zuora_auth_url = os.getenv('ZUORA_OAUTH_TOKEN_URL')
    zuora_data_query_url = os.getenv('ZUORA_DATA_QUERY_URL')

    zuora_ssm_param_names = [
        zuora_client_id,
        zuora_client_secret,
    ]
    zuora_ssm_response = client.get_parameters(Names=zuora_ssm_param_names, WithDecryption=True)
    zuora_ssm_params = {r['Name']: r['Value'] for r in zuora_ssm_response['Parameters']}

    ZUORA_TOKEN = {
        'CLIENT_ID': zuora_ssm_params[zuora_client_id],
        'CLIENT_SECRET': zuora_ssm_params[zuora_client_secret],
        'API_ENDPOINT': zuora_endpoint_url,
        'AUTH_URL': zuora_auth_url,
        'DATA_QUERY_URL': zuora_data_query_url,
    }
