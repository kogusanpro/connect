"""charlie URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

"""
<copyright file="urls.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from django.contrib import admin
from django.conf.urls import include, url
from subscriptions import urls as subscriptions_urls
from status import urls as status_urls
from usageUploadUrl.views import usage_upload_url
from usageDownloadUrl.views import usage_download_url

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^subscriptions/', include(subscriptions_urls)),
    url(r'^status/', include(status_urls)),
    url(r'^usageUploadUrl/?$', usage_upload_url),
    url(r'^usageDownloadUrl/$', usage_download_url),
]
