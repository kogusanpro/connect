"""
<copyright file="tests.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from rest_framework.test import APIClient
from rest_framework.test import APITestCase
from lib.utils import check_datetime_format
import hashlib
from moto import mock_s3
import os


class UsageUploadUrlTest(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.test_md5 = hashlib.md5('test'.encode('utf-8')).hexdigest()
        self.test_invalid_md5 = 'thisisinvalidmd5'
        self.test_request_id = '1o8jp80zfg'

        os.environ['S3_SUBSCRIPTION_USAGE_BUCKET'] = 'testBucket'

    def test_no_content_md5(self):
        """
        md5がリクエストにない場合、400を返すか
        """
        response = self.client.post('/usageUploadUrl', **{
            'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.test_request_id})
        assert response.status_code == 400
        assert response.data['success'] is False
        assert response.data['presigned_url'] is None
        assert response.data['request_id'] == self.test_request_id
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] == '400'
        assert response.data['error_message'] == 'Invalid Parameter'

    @mock_s3
    def test_valid_content_md5(self):
        """
        正しいmd5を付けてリクエストした場合、200が返るか
        """
        response = self.client.post(
            '/usageUploadUrl',
            **{'HTTP_CONTENT_MD5_CEBIS': self.test_md5,
                'HTTP_X_AMZN_APIGATEWAY_REQUESTID': self.test_request_id})
        assert response.status_code == 200
        assert response.data['success']
        assert response.data['presigned_url']
        assert response.data['request_id'] == self.test_request_id
        assert check_datetime_format(response.data['time_stamp'])
        assert response.data['error_status'] is None
        assert response.data['error_message'] is None
