"""
<copyright file="views.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from datetime import datetime
import boto3
from botocore.client import Config
import os

from django.db import transaction
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.decorators import parser_classes
from rest_framework.response import Response
from rest_framework.parsers import JSONParser

from status.models import CsvBatchProcessInfo
from lib.utils import DateTimeUtil
from lib.const.s3_for_usage import CSV_DIR_IN
from lib.utils import logger

@api_view(['POST'])
@parser_classes((JSONParser, ))
@transaction.atomic
def usage_upload_url(request):
    CONTENT_MD5 = request.META.get('HTTP_CONTENT_MD5_CEBIS')
    request_id = request.META.get('HTTP_X_AMZN_APIGATEWAY_REQUESTID')
    if CONTENT_MD5 is None:
        logger().error('missing parameter CONTENT_MD5 in this request header')
        return Response(
            {
                'success': False,
                'presigned_url': None,
                'request_id': request_id,
                'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
                'error_status': '400',
                'error_message': 'Invalid Parameter'
            },
            status=status.HTTP_400_BAD_REQUEST)

    BUCKET = os.environ.get('S3_SUBSCRIPTION_USAGE_BUCKET')
    KEY = CSV_DIR_IN + '/' + request_id
    presigned_url = boto3.client('s3', config=Config(signature_version='s3v4')).generate_presigned_url(
        ClientMethod='put_object',
        Params={'Bucket': BUCKET, 'Key': KEY},
        ExpiresIn=5 * 60,  # 5分
        HttpMethod='PUT')

    CsvBatchProcessInfo.objects.create(
        request_id=request_id,
        requested_time=DateTimeUtil.utc_now_aware(),
        content_md5=CONTENT_MD5,
        presigned_url=presigned_url,
        process_result='NotProcessed'
    )

    return Response(
        {
            'success': True,
            'presigned_url': presigned_url,
            'request_id': request_id,
            'time_stamp': DateTimeUtil.utc_now_aware().strftime('%Y%m%dT%H%M%SZ'),
            'error_status': None,
            'error_message': None
        },
        status=status.HTTP_200_OK)
