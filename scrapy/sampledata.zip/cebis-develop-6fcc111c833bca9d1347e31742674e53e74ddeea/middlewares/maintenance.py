"""
<copyright file="maintenance.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
import os
import boto3
from botocore.exceptions import ClientError
import yaml
from datetime import datetime
import pytz
from django.http import JsonResponse

from lib.utils import logger
from lib.const.settings_key import MAINTENANCE_YAML_KEY
from lib.const.auth_table import get_auth_table


class MaintenanceMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):
        try:
            s3 = boto3.resource('s3')
            bucket = os.environ.get('S3_SETTINGS_BUCKET')
            maintenance_yaml = s3.Object(bucket, MAINTENANCE_YAML_KEY).get()['Body']
        except ClientError as err:
            if err.response['Error']['Code'] == 'NoSuchKey':
                return None
            logger().error('maintenance.yml fetch client error')
            logger().error(err)
            return None
        except Exception as err:
            logger().error('maintenance.yml fetch error')
            logger().error(err)
            return None

        try:
            maintenance_yaml = yaml.load(maintenance_yaml)
        except yaml.YAMLError as err:
            logger().error('maintenance.yml parse error')
            logger().error(err)
            return None

        try:
            start_time = datetime.strptime(maintenance_yaml['maintenance_term']['start_time'], '%Y%m%dT%H%M%SZ').replace(tzinfo=pytz.utc)
            end_time = datetime.strptime(maintenance_yaml['maintenance_term']['end_time'], '%Y%m%dT%H%M%SZ').replace(tzinfo=pytz.utc)
        except (KeyError, ValueError) as err:
            logger().error('maintenance.yml syntax error')
            logger().error(err)
            return None

        base_error = {
            'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
            'error_status': '503',
            'error_message': 'Under maintenance'
        }
        request_id = request.META.get('HTTP_X_AMZN_APIGATEWAY_REQUESTID')
        auth_table = get_auth_table(base_error, request_id)

        if start_time <= datetime.utcnow().replace(tzinfo=pytz.utc) < end_time:
            for view, method, _, response in auth_table:
                if view_func.__name__ == view and request.method == method:
                    if view_func.__name__ in ['usage_upload_url', 'usage_download_url']:
                        del response['presigned_url']
                    return JsonResponse(response, status=503)
