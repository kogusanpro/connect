"""
<copyright file="api_request_logger.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from lib.utils import logger
import re
import json

class ApiRequestLogger(object):
    """
    APIリクエストのログを取得する。リクエストの前段でheaderとbodyをinfoの情報として出力
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        self.process_request(request)
        response = self.get_response(request)
        self.process_response(request, response)

        return response

    def process_request(self, request):
        logger().info('--->Start Request')
        logger().info('RequestID: %s' % request.META.get('HTTP_X_AMZN_APIGATEWAY_REQUESTID'))
        for (header, value) in request.META.items():
            logger().info('%s: %s' % (header,value));

        if (request.method == 'POST'):
            try:
                logger().info('body: %s' % json.loads(request.body.decode('utf-8')))
            except json.decoder.JSONDecodeError:
                logger().info('body: %s' % request.body.decode('utf-8'))

    def process_response(self, request, response):
        logger().info('--->End Request');
