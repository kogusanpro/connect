"""
<copyright file="auth.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from datetime import datetime
from django.http import JsonResponse
import os
import boto3
import sys
from lib.const.auth_table import get_auth_table


class AuthMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):
        if sys.argv[1] == 'test':
            if sys.argv[2] == '--tag=auth':
                pass
            else:
                return None

        s3 = boto3.resource('s3')
        bucket = os.environ['S3_CREDENTIALS_BUCKET']

        credentials = {}
        for s3_obj in s3.Bucket(bucket).objects.all():
            origin = s3_obj.key.split('/')[0]
            api_key = s3_obj.key.split('/')[1]
            if credentials.get(origin):
                credentials[origin].append(api_key)
            else:
                credentials[origin] = [api_key]

        api_key = request.META.get('HTTP_X_API_KEY')
        origin_of_api_key = None
        for origin, s3_api_keys in credentials.items():
            for s3_api_key in s3_api_keys:
                if api_key == s3_api_key:
                    origin_of_api_key = origin

        base_error = {
            'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
            'error_status': '401',
            'error_message': 'Invalid IP address or API key'
        }
        request_id = request.META.get('HTTP_X_AMZN_APIGATEWAY_REQUESTID')
        auth_table = get_auth_table(base_error, request_id)

        for view, method, allow_origins, response in auth_table:
            if view_func.__name__ == view and request.method == method:
                if origin_of_api_key not in allow_origins:
                    return JsonResponse(response, status=401)
                return None
