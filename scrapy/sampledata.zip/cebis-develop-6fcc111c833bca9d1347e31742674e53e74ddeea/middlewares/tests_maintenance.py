"""
<copyright file="tests_maintenance.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from rest_framework.test import APIClient
from rest_framework.test import APITestCase
import boto3
import os
import json
from collections import namedtuple
from datetime import datetime, timedelta
from moto import mock_s3
from freezegun import freeze_time
from unittest import mock
from unittest.mock import call

from lib.const.settings_key import MAINTENANCE_YAML_KEY


class MaintenanceTest(APITestCase):
    def setUp(self):
        self.client = APIClient()

        self.mock = mock_s3()
        self.mock.start()

        self.s3 = boto3.resource('s3')
        # os.environ['S3_SETTINGS_BUCKET'] = 'setting-bucket-123'
        os.environ['S3_SETTINGS_BUCKET'] = 'ppup-prototype'
        self.bucket = os.environ['S3_SETTINGS_BUCKET']
        self.s3.create_bucket(Bucket=os.environ['S3_SETTINGS_BUCKET'])

    def tearDown(self):
        self.mock.stop()

    @freeze_time()
    def test_on_maintenance(self):
        """
        メンテナンス中だった場合503を返すか
        """
        maintenance_yaml = f'''maintenance_term:
            start_time: {(datetime.utcnow() + timedelta(minutes=-10)).strftime('%Y%m%dT%H%M%SZ')}
            end_time: {(datetime.utcnow() + timedelta(minutes=10)).strftime('%Y%m%dT%H%M%SZ')}'''
        self.s3.Object(self.bucket, MAINTENANCE_YAML_KEY).put(Body=maintenance_yaml)

        AuthItem = namedtuple('AuthItem', ('url', 'method', 'response'))
        base_error = {
            'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
            'error_status': '503',
            'error_message': 'Under maintenance'
        }
        REQUEST_ID = '123abc'
        AUTH_TABLE = [
            AuthItem('/subscriptions/1/usage/', 'post', dict(base_error, **{'success': False, 'usage_id': None})),
            AuthItem('/usageUploadUrl/', 'post', dict(base_error, **{'success': False, 'request_id': REQUEST_ID})),
            AuthItem('/usageDownloadUrl/', 'get', dict(base_error, **{'success': False, 'request_id': REQUEST_ID})),
            AuthItem('/subscriptions/', 'get', dict(base_error, **{'success': False, 'count': None, 'subscriptions': None})),
            AuthItem('/subscriptions/1/billing/201801/', 'post', dict(base_error, **{'success': False})),
            AuthItem('/subscriptions/1/', 'post', dict(base_error, **{'success': False})),
            AuthItem('/subscriptions/1/', 'get', dict(base_error, **{'success': False, 'count': None, 'subscriptions': None})),
            AuthItem('/status/1/', 'get', dict(base_error, **{'state': 'failure', 'total_records': None, 'request_id': REQUEST_ID})),
            AuthItem('/subscriptions/1/usage/201801/', 'get', dict(base_error, **{'success': False})),
        ]

        for auth in AUTH_TABLE:
            response = getattr(
                self.client,
                auth.method
            )(auth.url, data={}, content_type='application/json', **{'HTTP_X_AMZN_APIGATEWAY_REQUESTID': REQUEST_ID})
            assert response.status_code == 503
            assert json.loads(response.content) == auth.response

    def test_on_non_maintenance(self):
        """
        メンテナンスファイルを置いていない場合、メンテナンスモードに入らず、503以外を返すか
        """
        response = self.client.get('/subscriptions/')
        assert response.status_code != 503

    @mock.patch('logging.Logger.error')
    def test_invalid_maintenance_yaml(self, mock_logger):
        """
        正しいフォーマットでないメンテナンスファイルが置かれていた場合、エラーログを出しつつメンテナンスモードに入らないかどうか
        """
        maintenance_yaml = f'''maintenance_term:
            start_start_time: {(datetime.utcnow() + timedelta(minutes=-10)).strftime('%Y%m%dT%H%M%SZ')}
            end_end_time: {(datetime.utcnow() + timedelta(minutes=10)).strftime('%Y%m%dT%H%M%SZ')}'''
        self.s3.Object(self.bucket, MAINTENANCE_YAML_KEY).put(Body=maintenance_yaml)

        response = self.client.get('/subscriptions/')
        assert response.status_code != 503
        mock_logger.assert_has_calls([
            call('maintenance.yml syntax error')
        ])

    @mock.patch('logging.Logger.error')
    def test_maintenance_is_json(self, mock_logger):
        """
        メンテナンスファイルがYAMLではなくJSONだった場合、エラーログを出しつつメンテナンスモードに入らないかどうか
        """
        maintenance_json = f'''{{
            maintenance_term: {{
                start_start_time: {(datetime.utcnow() + timedelta(minutes=-10)).strftime('%Y%m%dT%H%M%SZ')}
                end_end_time: {(datetime.utcnow() + timedelta(minutes=10)).strftime('%Y%m%dT%H%M%SZ')}
            }}
        }}'''
        self.s3.Object(self.bucket, MAINTENANCE_YAML_KEY).put(Body=maintenance_json)

        response = self.client.get('/subscriptions/')
        assert response.status_code != 503
        mock_logger.assert_has_calls([
            call('maintenance.yml parse error')
        ])

    @freeze_time()
    def test_boundary_value(self):
        """
        メンテナンスモードに入る時間の境界値テスト
        """
        Time = namedtuple('Time', ('start_time', 'end_time', 'on_maintenance'))

        times = [
            Time(datetime.utcnow() - timedelta(seconds=1), datetime.utcnow() - timedelta(seconds=1), False),
            Time(datetime.utcnow() - timedelta(seconds=1), datetime.utcnow(), False),
            Time(datetime.utcnow(), datetime.utcnow() + timedelta(seconds=1), True),
            Time(datetime.utcnow() + timedelta(seconds=1), datetime.utcnow() + timedelta(seconds=1), False)
        ]

        for time in times:
            maintenance_yaml = f'''maintenance_term:
            start_time: {time.start_time.strftime('%Y%m%dT%H%M%SZ')}
            end_time: {time.end_time.strftime('%Y%m%dT%H%M%SZ')}'''
            self.s3.Object(self.bucket, MAINTENANCE_YAML_KEY).put(Body=maintenance_yaml)

            response = self.client.get('/subscriptions/')
            if time.on_maintenance:
                assert response.status_code == 503
            else:
                assert response.status_code != 503
