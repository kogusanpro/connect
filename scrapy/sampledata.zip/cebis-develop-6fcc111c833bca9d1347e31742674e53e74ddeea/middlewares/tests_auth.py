"""
<copyright file="tests_auth.py" company="Fuji Xerox Co., Ltd.">
Copyright (C) Fuji Xerox Co., Ltd. 2018-2018. All rights reserved.
</copyright>
"""
from rest_framework.test import APIClient
from rest_framework.test import APITestCase
from lib.const.calling_api_origins import BILLING_INFRASTRUCTURE, CALCULATION_SYSTEM, SERVICE_PROVIDER
import boto3
import os
from moto import mock_s3
from collections import namedtuple
from freezegun import freeze_time
from datetime import datetime
import json
from django.test import tag


@tag('auth')
class AuthTest(APITestCase):
    def setUp(self):
        self.client = APIClient()

    @mock_s3
    @freeze_time()
    def test_auth(self):
        """
        認証が正しく行われているか、また401エラーを返した場合に仕様通りのエラーが返るか
        """
        APIKey = namedtuple('AuthItem', ('origin', 'key'))
        API_KEYS = [
            APIKey(None, '1234'),
            APIKey(BILLING_INFRASTRUCTURE, 'abcd'),
            APIKey(CALCULATION_SYSTEM, '4567'),
            APIKey(SERVICE_PROVIDER, 'efgh')
        ]

        AuthItem = namedtuple('AuthItem', ('url', 'method', 'permissions', 'response'))
        base_error = {
            'time_stamp': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
            'error_status': '401',
            'error_message': 'Invalid IP address or API key'
        }
        REQUEST_ID = '123abc'
        AUTH_TABLE = [
            AuthItem('/subscriptions/1/usage/', 'post', [0, 0, 0, 1], dict(base_error, **{'success': False, 'usage_id': None})),
            AuthItem('/usageUploadUrl/', 'post', [0, 0, 0, 1], dict(base_error, **{'success': False, 'presigned_url': None, 'request_id': REQUEST_ID})),
            AuthItem('/usageDownloadUrl/', 'get', [0, 0, 1, 1], dict(base_error, **{'success': False, 'presigned_url': None, 'request_id': REQUEST_ID})),
            AuthItem('/subscriptions/', 'get', [0, 0, 1, 0], dict(base_error, **{'success': False, 'count': None, 'subscriptions': None})),
            AuthItem('/subscriptions/1/billing/201801/', 'post', [0, 0, 1, 0], dict(base_error, **{'success': False})),
            AuthItem('/subscriptions/1/', 'post', [0, 1, 0, 0], dict(base_error, **{'success': False})),
            AuthItem('/subscriptions/1/', 'get', [0, 1, 0, 0], dict(base_error, **{'success': False, 'count': None, 'subscriptions': None})),
            AuthItem('/status/1/', 'get', [0, 0, 1, 1], dict(base_error, **{'state': 'failure', 'request_id': REQUEST_ID, 'total_records': None})),
            AuthItem('/subscriptions/1/usage/201801/', 'get', [0, 0, 0, 1], dict(base_error, **{'success': False})),
        ]

        # S3_CREDENTIALS_BUCKET = 'credential-bucket123'
        S3_CREDENTIALS_BUCKET = 'ppup-prototype'
        s3 = boto3.resource('s3')
        s3.create_bucket(Bucket=S3_CREDENTIALS_BUCKET)
        os.environ['S3_CREDENTIALS_BUCKET'] = S3_CREDENTIALS_BUCKET
        for api_key in API_KEYS[1:]:
            s3.Object(
                os.environ['S3_CREDENTIALS_BUCKET'],
                api_key.origin + '/' + api_key.key
            ).put()
        for auth in AUTH_TABLE:
            for index, permission in enumerate(auth.permissions):
                response = getattr(
                    self.client,
                    auth.method
                )(auth.url, data={}, **{'HTTP_X_API_KEY': API_KEYS[index].key, 'HTTP_X_AMZN_APIGATEWAY_REQUESTID': REQUEST_ID})
                auth_succeed = response.status_code != 401
                assert auth_succeed == permission
                if not auth_succeed:
                    assert json.loads(response.content) == auth.response

    @mock_s3
    def test_multiple_api_keys(self):
        # S3_CREDENTIALS_BUCKET = 'credential-bucket123'
        S3_CREDENTIALS_BUCKET = 'ppup-prototype'
        s3 = boto3.resource('s3')
        s3.create_bucket(Bucket=S3_CREDENTIALS_BUCKET)
        os.environ['S3_CREDENTIALS_BUCKET'] = S3_CREDENTIALS_BUCKET

        url = '/status/1/'
        origin = SERVICE_PROVIDER

        api_keys = ['abcd', '1234', '5678']
        for api_key in api_keys:
            s3.Object(
                os.environ['S3_CREDENTIALS_BUCKET'],
                origin + '/' + api_key
            ).put()

        for api_key in api_keys:
            response = self.client.get(url, data={}, **{'HTTP_X_API_KEY': api_key})
            assert response.status_code != 401

        not_api_key = 'xyz'
        response = self.client.get(url, data={}, **{'HTTP_X_API_KEY': not_api_key})
        assert response.status_code == 401
